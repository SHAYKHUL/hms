# Quick Start - Room & Booking Improvements

## 🚀 What's New?

Your hotel management system now has a **smarter room management and booking system** without being complicated. Here's what you can do:

---

## Room Management

### Set Up Room Capacity (New!)

When adding or editing a room, you now specify:
- **Number of Beds** - How many beds in the room
- **Max Guests** - How many people can stay

**Example:**
- Room 101: Single room → 1 bed, 1 guest max
- Room 202: Double room → 2 beds, 2 guests max  
- Room 305: Suite → 2 beds, 4 guests max

### View Room Details

Room cards now show:
```
Room 201 | Double
Price: ₹2,500/night
Beds: 2 | Max Guests: 2
Status: Available
```

---

## Smart Bookings

### Better Booking Form

**Step 1: Guest Details** (same as before)
- Search for existing guest or add new guest

**Step 2: Room Selection** (improved!)
- Select check-in and check-out dates
- **NEW:** Specify number of guests
- System shows only available rooms
- Rooms automatically checked for conflicts

**Step 3: Payment** (enhanced!)
- **NEW:** Apply discount (percentage or fixed amount)
- **NEW:** Add discount reason (loyalty, group, corporate, etc.)
- View detailed booking summary
- Confirm payment details

### Booking Summary Shows

```
Guest: John Doe
Room: 201 (Double)
Number of Guests: 2
Check-in: 25 Feb 2026
Check-out: 28 Feb 2026
Nights: 3
Rate: ₹2,500/night

Subtotal: ₹7,500
Discount (10%): -₹750  ← NEW!
Subtotal after Discount: ₹6,750
Tax (18% GST): ₹1,215
───────────────────
Total: ₹7,965
```

---

## Key Features in Action

### 1️⃣ Smart Room Assignment

**Before:** Had to manually check room capacity
**Now:** System knows:
- Room 101 has 1 bed for 1 guest
- Room 305 has 2 beds for 4 guests
- It suggests appropriate rooms automatically

### 2️⃣ Conflict-Free Bookings

**Before:** Could accidentally double-book
**Now:** 
- System checks if dates overlap with existing bookings
- Verifies room capacity matches guest count
- Shows "Not available" if there's a conflict

### 3️⃣ Flexible Discounts

**Before:** No way to track discounts
**Now:**
- Give 10% discount for loyalty
- Fixed ₹500 off for groups
- Track why discount was given
- See discount history in reports

---

## Typical Use Cases

### Booking a Single Guest
1. Add guest info
2. Select dates (Jan 25-28)
3. System suggests room 101 for 1 guest
4. Select room, proceed to payment
5. No discount needed
6. Confirm

### Group Booking (Corporate)
1. Add guest (company contact)
2. Select dates (Jan 20-22)
3. Enter **4 guests** → System suggests Suite (2 beds, 4 guests)
4. Select room
5. Apply **10% corporate discount**
6. Add reason: "Corporate Booking"
7. Confirm booking

### Last Minute Vacancy Fill
1. Add guest
2. Select dates 
3. System shows available rooms
4. Apply **20% discount** to fill vacancy
5. Add reason: "Last Minute Deal"
6. Send confirmation

---

## Admin Features

### Check Occupancy Rates

Use the API endpoint:
```
GET /rooms/stats/occupancy?startDate=2026-02-01&endDate=2026-02-28
```

Returns:
- Total rooms: 50
- Room nights available: 1,500
- Room nights booked: 1,200
- **Occupancy: 80%**

### Analyze Revenue by Room

Use the API endpoint:
```
GET /rooms/stats/revenue?startDate=2026-02-01&endDate=2026-02-28
```

Shows which rooms generated most revenue - helps optimize pricing.

### Verify Room Availability

Before creating special offers:
```
POST /rooms/check-availability
{
  "roomId": 201,
  "checkIn": "2026-02-25",
  "checkOut": "2026-02-28"
}
```

Response: `{ "available": true }`

---

## Database Changes (Tech Info)

### Rooms Table
| Column | What it does |
|--------|------------|
| `bed_count` | Number of beds |
| `max_guests` | Guest capacity |

### Bookings Table
| Column | What it does |
|--------|------------|
| `number_of_guests` | How many people for this booking |
| `room_price` | Price per night (captured at booking time) |
| `discount_type` | None / Percentage / Fixed |
| `discount_value` | Amount or percentage of discount |
| `discount_reason` | Why discount was given |

**Safety:** All changes add data - nothing is deleted or modified.

---

## Common Scenarios

### "I want to give a loyalty discount"
1. Open booking details
2. Click "Apply Discount"
3. Select: Percentage
4. Enter: 10
5. Reason: Loyalty Program
6. Save

### "Can I see which rooms are most profitable?"
Yes! API shows revenue per room with booking count and average booking value.

### "What if a guest exceeds room capacity?"
System prevents it:
- If guest specifies 6 people, only 6+ capacity rooms show
- 4-person suite won't be offered

### "How do I track why discounts were given?"
All saved in database:
- `discount_reason`: "Group Booking", "Loyalty", "Corporate", etc.
- You can report on discounts by reason

---

## Tips & Best Practices

✅ **DO:**
- Set accurate bed counts and guest limits
- Use discount reasons consistently
- Review occupancy reports monthly
- Update room capacity if you renovate

❌ **DON'T:**
- Overbookings (system prevents this anyway)
- Give large discounts without reason
- Forget to update room capacity changes

---

## Troubleshooting

**Q: Why doesn't my room show for this booking?**
A: Check:
- Room is not in "Maintenance" status
- Room hasn't got existing bookings for those dates
- Guest count fits room capacity

**Q: Can I change discount after booking?**
A: Yes, through admin panel - find booking and apply/modify discount

**Q: What if I want to add more room types?**
A: Database supports Single/Double/Suite/Deluxe - modify as needed

**Q: How do I see booking history with discounts?**
A: Query bookings where discount_type != 'None'

---

## Next Steps

1. **Update Database:** Follow migration guide
2. **Test:** Create a few test bookings with new features
3. **Train Staff:** Show them the improved forms
4. **Monitor:** Check occupancy and revenue reports
5. **Optimize:** Use data to adjust pricing and promotions

---

## Support Notes

- All changes are backwards compatible
- Existing bookings still work fine
- New fields have sensible defaults
- No data loss during migration

**Your system is now simpler to use but more powerful!**

---

*Reference Guide - February 24, 2026*
