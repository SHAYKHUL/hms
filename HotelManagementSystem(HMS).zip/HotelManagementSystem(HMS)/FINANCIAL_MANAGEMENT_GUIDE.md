# Financial Management System Implementation Guide

## Overview
This implementation adds comprehensive staff salary management, income tracking, and expense management to the Hotel Management System.

## Database Migration

### 1. Run the migration SQL file
```bash
# From the project root directory
cd database
mysql -u root -p hotel_db < financial_management_migration.sql
```

Or manually execute in MySQL Workbench:
- Open `database/financial_management_migration.sql`
- Execute all statements

### 2. Verify tables created
```sql
SHOW TABLES LIKE '%staff_salaries%';
SHOW TABLES LIKE '%income_records%';
SHOW TABLES LIKE '%expense_records%';
SHOW TABLES LIKE '%staff_attendance%';
```

## Backend Structure

### New Files Created:
1. **backend/models/FinancialManagement.js** - Handles all financial operations
2. **backend/routes/financial.js** - API endpoints for financial management
3. **database/financial_management_migration.sql** - Database schema updates

### Updated Files:
1. **backend/models/Housekeeping.js** - Added salary fields support
2. **backend/routes/housekeepings.js** - Updated staff CRUD operations
3. **backend/server.js** - Registered financial routes

## API Endpoints

### Staff Salary Management
- `GET /api/financial/salaries` - Get all salary records
- `GET /api/financial/salaries/:id` - Get specific salary record
- `GET /api/financial/salaries/staff/:staffId` - Get salary history for a staff member
- `POST /api/financial/salaries` - Create new salary record
- `PUT /api/financial/salaries/:id` - Update salary record
- `PATCH /api/financial/salaries/:id/pay` - Mark salary as paid
- `GET /api/financial/salaries/stats/summary` - Get salary statistics

### Income Management
- `GET /api/financial/income` - Get all income records
- `GET /api/financial/income/:id` - Get specific income record
- `POST /api/financial/income` - Create new income record
- `PUT /api/financial/income/:id` - Update income record
- `DELETE /api/financial/income/:id` - Delete income record
- `GET /api/financial/income/stats/summary` - Get income statistics

### Expense Management
- `GET /api/financial/expenses` - Get all expense records
- `GET /api/financial/expenses/:id` - Get specific expense record
- `POST /api/financial/expenses` - Create new expense record
- `PUT /api/financial/expenses/:id` - Update expense record
- `PATCH /api/financial/expenses/:id/pay` - Mark expense as paid
- `DELETE /api/financial/expenses/:id` - Delete expense record
- `GET /api/financial/expenses/stats/summary` - Get expense statistics

### Financial Reports
- `GET /api/financial/reports/profit-loss` - Get profit & loss summary
- `GET /api/financial/reports/monthly/:year/:month` - Get monthly financial summary
- `GET /api/financial/dashboard/stats` - Get dashboard statistics

## Frontend Usage Guide

### Housekeeping Page Features

#### 1. Staff Management Tab
- View all staff members with their salary information
- Add new staff with complete details including monthly salary
- Edit staff information
- Track staff status (Active, Inactive, On Leave)

#### 2. Salary Management Tab (New)
- View all salary payments
- Record monthly salaries with bonuses, deductions, overtime
- Track payment status (Pending/Paid)
- Generate salary slips

#### 3. Income Tracking Tab (New)
- Record all hotel income sources:
  - Room bookings
  - Services
  - Food & Beverage
  - Laundry
  - Events
  - Other
- View income by date, type, payment method
- Generate income reports

#### 4. Expense Tracking Tab (New)
- Record all hotel expenses:
  - Salaries
  - Maintenance costs
  - Inventory purchases
  - Utilities (electricity, water)
  - Marketing
  - Insurance
  - Equipment
  - Supplies
- Track payment status
- Manage vendor information

#### 5. Financial Reports Tab (New)
- Profit & Loss Summary
- Monthly/Yearly Reports
- Income vs Expense Analysis
- Department-wise expense breakdown
- Payment method statistics

## Testing the System

### 1. Start the backend server
```bash
cd backend
node server.js
```

### 2. Test API endpoints
```bash
# Get salary statistics
curl http://localhost:3000/api/financial/salaries/stats/summary

# Get income records
curl http://localhost:3000/api/financial/income

# Get expense records
curl http://localhost:3000/api/financial/expenses

# Get profit & loss
curl http://localhost:3000/api/financial/reports/profit-loss
```

### 3. Access the frontend
Navigate to: `http://localhost:3000/housekeeping.html`

## Sample Data
The migration includes sample data:
- Staff salary records for current month
- Sample income records (bookings, services, laundry)
- Sample expense records (utilities, maintenance, supplies)

## Database Views Created
1. `monthly_income_summary` - Income grouped by month and type
2. `monthly_expense_summary` - Expenses grouped by month and type
3. `profit_loss_summary` - Monthly profit/loss calculation
4. `staff_salary_summary` - Staff salary payment history

## Key Features

### Staff Management
✅ Complete staff profiles with salary information
✅ Bank account details for payments
✅ Emergency contact information
✅ Hire date tracking

### Salary Management  
✅ Monthly salary records
✅ Bonus and deduction tracking
✅ Overtime calculation
✅ Multiple payment methods
✅ Payment status tracking

### Income Management
✅ Multiple income source types
✅ Link to bookings and service orders
✅ Invoice number tracking
✅ Payment method recording
✅ Income categorization

### Expense Management
✅ Comprehensive expense categories
✅ Vendor management
✅ Invoice/receipt tracking
✅ Payment status
✅ Link to staff, maintenance, inventory

### Financial Reporting
✅ Real-time profit & loss
✅ Monthly summaries
✅ Income breakdown by type
✅ Expense breakdown by category
✅ Payment method analysis
✅ Profit margin calculation

## Security Considerations
- Implement authentication for financial endpoints
- Add role-based access control (only managers should access financial data)
- Log all financial transactions
- Regular database backups
- Encrypt sensitive financial information

## Future Enhancements
- [ ] PDF export for reports
- [ ] Email salary slips to staff
- [ ] SMS notifications for payments
- [ ] Budget planning and forecasting
- [ ] Tax calculation and reporting
- [ ] Multi-currency support
- [ ] Bank integration for automatic reconciliation
- [ ] Advanced analytics and charts
- [ ] Mobile app for expense tracking
- [ ] Receipt photo upload

## Troubleshooting

### Migration fails
- Check database credentials in `backend/config/database.js`
- Ensure MySQL server is running
- Verify user has CREATE TABLE permissions

### API returns 500 error
- Check server logs for detailed error messages
- Verify all tables exist in database
- Check that foreign key constraints are satisfied

### Data not showing in frontend
- Open browser console for JavaScript errors
- Check API responses in Network tab
- Verify API_BASE_URL in config.js

## Support
For issues or questions, check:
- Server logs: `backend/logs/`
- API documentation: `http://localhost:3000/api`
- Database schema: `database/schema.sql`
