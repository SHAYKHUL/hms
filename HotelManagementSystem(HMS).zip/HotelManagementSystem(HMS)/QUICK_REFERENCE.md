# Quick Reference - Guest Portal PIN System

## 🏨 For Hotel Staff

### ✓ How to Check-In a Guest for Portal Access

**5 Simple Steps:**

1. **Navigate to Bookings Page**
   - Open application → Click "Bookings" menu
   
2. **Find Guest Booking**
   - Look for guest name and "Confirmed" status
   - Example: John Test, Room 1013, Check-in: Feb 24
   
3. **Click Check-In Button**
   - Look for ✓ icon in Actions column
   - Click it next to guest's booking
   
4. **Confirm Check-In**
   - Dialog appears asking "Confirm check-in?"
   - Click "Yes" or "Confirm"
   
5. **Copy & Share PIN**
   - Beautiful modal shows 6-digit PIN (e.g., "123456")
   - Click "Copy PIN" button
   - Give PIN to guest via:
     - Written note with PIN
     - SMS or WhatsApp: "Your PIN: 123456"
     - Email

**That's it! Guest can now access portal.**

---

### → How to Check-Out Guest

**3 Simple Steps:**

1. **Find Checking-Out Guest**
   - Look for guest with "CheckedIn" status
   
2. **Click Check-Out Button**
   - Look for → icon in Actions column
   
3. **Confirm Check-Out**
   - Dialog confirms check-out
   - Click "Yes"
   - PIN automatically becomes invalid

**Guest portal access is now blocked.**

---

### 📋 Common PIN-Related Issues

| Issue | Solution |
|-------|----------|
| Where's the PIN? | It shows in modal after clicking check-in |
| PIN didn't copy | Click "Copy PIN" button again |
| Guest doesn't remember PIN | Check bookings page, select booking, PIN is visible |
| Guest complaints: "PIN expired" | PIN valid until check-out; guest should re-login |
| Where to find active PINs? | Admin Dashboard → Active Sessions (if available) |

---

## 📱 For Guests

### How to Access Guest Portal

**4 Simple Steps:**

1. **Get PIN from Staff**
   - Staff gives you 6-digit PIN (e.g., "123456")
   - Write it down or note it
   
2. **Open Guest Portal**
   - Click link: "Guest Portal" on hotel website/app
   - Or navigate directly to portal page
   
3. **Enter PIN**
   - See login screen with PIN input box
   - Type PIN carefully (example: 123456)
   
4. **Click "Access Portal"**
   - Portal unlocks and shows:
     - Your booking details
     - Available services and amenities
     - Your service orders

**You're in! Browse and order services.**

---

### 🔐 Portal Features

Once logged in, you can:

✅ **View Booking Details**
- Room number
- Check-in/Check-out dates
- Guest name

✅ **Browse Services**
- Room service (breakfast, lunch, dinner)
- Housekeeping
- Laundry service
- Spa & wellness

✅ **Order Services**
- Select service
- Choose quantity
- Add special requests
- Click "Order"

✅ **Track Orders**
- See all your orders
- Check order status
- View order time

✅ **Logout**
- Click "Logout" button in top right
- Safely exit portal

---

### 📝 Sample PIN Entry

```
Screen shows: "Enter 6-digit PIN"
Input box: ________

Example:
PIN from Staff: 123456
You type: 123456
Click: "Access Portal" ✓
```

**Note:** PIN is case-insensitive, numeric only (0-9)

---

### ❓ Guest FAQ

**Q: What if I enter wrong PIN?**
A: See error message "Invalid PIN. Please try again." Try again or ask staff.

**Q: What if I lose the PIN?**
A: Contact front desk. Staff can verify your booking and provide PIN again.

**Q: Can I share PIN with family?**
A: Yes, PIN works for all guest room members until check-out.

**Q: What happens when I check out?**
A: PIN becomes invalid. Portal access blocked. (Re-enter to get new PIN next visit)

**Q: Is my data secure?**
A: Yes! PIN is unique to you, encrypted, and auto-deleted on check-out.

**Q: Can I change the PIN?**
A: No, but you can logout and contact front desk for new PIN (staff will generate fresh PIN).

---

## 🛠️ Technical Reference

### PIN Format
- **Length**: 6 digits
- **Format**: 000000 - 999999
- **Example**: 123456, 789012

### Token (Backend)
- **Length**: 64 characters
- **Type**: Hexadecimal
- **Generated**: Automatically during check-in
- **Stored**: Database + Browser localStorage
- **Removed**: Automatically on check-out

### Browser Storage
- **localStorage keys**: 
  - `guestPortalToken` (encrypted access token)
  - `guestBookingData` (guest information)

---

## 📊 System Information

| Component | Details |
|-----------|---------|
| PIN Length | 6 digits |
| Token Type | 256-bit hex |
| Storage Location | Database + Browser |
| Validity Period | Check-in to Check-out |
| Max Access Attempts | Unlimited (until check-out) |
| Session Logging | All access tracked |
| Auto Cleanup | On checkout |
| Timezone | Server timezone |

---

## 🚨 Important Notes

### For Staff
- ⚠️ **PIN is single-use per booking** (one PIN per check-in)
- ⚠️ **PIN becomes invalid after check-out**
- ⚠️ **Each booking gets new PIN on next check-in**
- ⚠️ **Copy PIN carefully** (no special characters)

### For Guests
- ⚠️ **PIN expires when you check out**
- ⚠️ **Sharing PIN with guests outside your room** is your choice
- ⚠️ **Logout when leaving portal** for security
- ⚠️ **Don't share PIN publicly** on social media

---

## 🔄 Complete Customer Journey

```
DAY 1 - ARRIVAL
├── Guest arrives at hotel
├── Staff checks booking (Status: "Confirmed")
├── Staff clicks check-in button ✓
├── System generates PIN: "123456"
├── Staff says: "Your PIN is 123456"
├── Guest receives PIN
└── Check-in complete (Status: "CheckedIn")

DAY 1-3 - GUEST STAY
├── Guest opens portal page
├── Guest enters PIN: 123456
├── Portal unlocks
├── Guest orders room service, laundry, etc.
├── Guest checks order status
├── Orders are tracked and fulfilled
└── Guest returns to portal anytime

DAY 3 - CHECKOUT
├── Guest prepares to leave
├── Staff finds booking in system
├── Staff clicks check-out button →
├── System deactivates PIN: "123456"
├── Room status: "Available" again
├── Check-out complete (Status: "CheckedOut")
└── Guest's portal access: BLOCKED

AFTER CHECKOUT
└── If guest returns: New booking → New PIN → New access
```

---

## 📞 Support Contact

**Issue with PIN?**
- Check with front desk staff
- Verify booking status
- Request PIN regeneration if needed

**Technical Issues?**
- Refresh page (F5)
- Clear browser cache (Ctrl+Shift+Delete)
- Try different browser
- Contact IT support

---

## 💡 Pro Tips

### For Staff
1. **Copy PIN before giving to guest** - Use copy button
2. **Write PIN on paper** - Guest appreciates written record
3. **SMS PIN if possible** - Reduces miscommunication
4. **Verify check-in status** - Always confirm status changed to "CheckedIn"
5. **Keep PIN confidential** - Don't broadcast to other staff

### For Guests
1. **Enter PIN carefully** - Double-check digits before submitting
2. **Bookmark the portal** - For faster access next visit
3. **Order early** - Services processed during operating hours
4. **Check order status** - Updates real-time
5. **Logout when done** - Good practice for security

---

## 📚 More Information

For detailed information, see:
- **TOKEN_AUTH_GUIDE.md** - Complete technical documentation
- **TESTING_GUIDE.md** - How to test the system
- **API_REFERENCE.md** - REST API endpoints
- **README.md** - System overview

---

**Version**: 2.1.0  
**Last Updated**: February 24, 2026  
**Quick Reference Card** - Keep for staff training
