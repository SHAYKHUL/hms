#!/usr/bin/env node

/**
 * cPanel Deployment Preparation Script
 * Run this before uploading to cPanel shared hosting
 */

const fs = require('fs');
const path = require('path');

console.log('🚀 Preparing Hotel Management System for cPanel Deployment...\n');

// 1. Check if we're in the right directory
const currentDir = process.cwd();
const expectedFiles = ['backend/package.json', 'frontend/index.html', 'database/schema.sql'];

console.log('📁 Checking project structure...');
const allFilesExist = expectedFiles.every(file => {
    const exists = fs.existsSync(path.join(currentDir, file));
    console.log(`  ${exists ? '✅' : '❌'} ${file}`);
    return exists;
});

if (!allFilesExist) {
    console.log('\n❌ Error: Please run this script from the project root directory');
    process.exit(1);
}

// 2. Check package.json
console.log('\n📦 Analyzing package.json...');
const packageJson = JSON.parse(fs.readFileSync(path.join(currentDir, 'backend/package.json'), 'utf8'));

console.log(`  ✅ Main file: ${packageJson.main}`);
console.log(`  ✅ Start script: ${packageJson.scripts.start}`);
console.log('  📋 Dependencies:');
Object.keys(packageJson.dependencies).forEach(dep => {
    console.log(`    - ${dep}: ${packageJson.dependencies[dep]}`);
});

// 3. Create deployment instructions
console.log('\n📝 Creating deployment instructions...');

const instructions = `
# 🚀 cPanel Deployment Instructions for ${packageJson.name}

## Upload Instructions:

### Backend (Node.js App):
1. In cPanel, create Node.js app with these settings:
   - Application root: HotelManagementSystem(HMS)/backend
   - Startup file: ${packageJson.main}
   - Node.js version: Latest available (18+)

2. Upload these backend files to application root:
   📁 backend/config/
   📁 backend/models/ 
   📁 backend/routes/
   📄 backend/package.json
   📄 backend/server.js
   📄 backend/setup-database.js (if needed)

### Frontend:
Upload frontend/ contents to your domain root or subdomain folder:
   📁 css/
   📁 js/
   📄 *.html files

### Database:
1. Create MySQL database in cPanel
2. Import database/schema.sql via phpMyAdmin

## Environment Variables (Set in cPanel Node.js app):
NODE_ENV=production
PORT=3000
DB_HOST=localhost
DB_USER=[your_cpanel_db_user]
DB_PASSWORD=[your_cpanel_db_password] 
DB_NAME=[your_cpanel_db_name]

## Frontend Configuration:
Replace frontend/js/config.js with frontend/js/config.production.js
OR
Update API_BASE_URL in config.js to: 'https://hms.algolizen.com/api'

## Testing:
1. API Test: https://hms.algolizen.com/
2. Frontend Test: https://your-domain.com (or subdomain)

## Troubleshooting:
- Check cPanel Error Logs for Node.js app
- Verify database connection in cPanel 
- Test API endpoints individually
- Ensure frontend points to correct API URL
`;

fs.writeFileSync('CPANEL_DEPLOYMENT_INSTRUCTIONS.txt', instructions);
console.log('  ✅ Created CPANEL_DEPLOYMENT_INSTRUCTIONS.txt');

// 4. Create zip preparation info
console.log('\n📦 Files ready for upload:');
console.log('\nBackend files to zip and upload to cPanel:');
const backendFiles = [
    'backend/package.json',
    'backend/server.js', 
    'backend/config/',
    'backend/models/',
    'backend/routes/'
];

backendFiles.forEach(file => {
    const exists = fs.existsSync(path.join(currentDir, file));
    console.log(`  ${exists ? '✅' : '❌'} ${file}`);
});

console.log('\n🎯 Next Steps:');
console.log('1. Create MySQL database in cPanel');
console.log('2. Import database/schema.sql');
console.log('3. Zip and upload backend files to Node.js app root');
console.log('4. Set environment variables in cPanel');
console.log('5. Install npm packages via cPanel interface');
console.log('6. Upload frontend files to web root');
console.log('7. Update frontend/js/config.js with production API URL');
console.log('8. Test your application!');

console.log('\n✅ Deployment preparation complete!');
console.log('📖 Read CPANEL_DEPLOYMENT_INSTRUCTIONS.txt for detailed steps');