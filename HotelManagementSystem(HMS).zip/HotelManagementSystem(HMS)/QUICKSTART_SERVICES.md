# Quick Start Guide - Room Services Feature

## Getting Started with the New Features

### Step 1: Update Database

Run the updated schema or the update script:

**Option A: Fresh Installation**
```bash
mysql -u root -p hotel_management < database/schema.sql
```

**Option B: Update Existing Database**
```bash
mysql -u root -p hotel_management < database/add_services.sql
```

### Step 2: Start the Server

```bash
cd backend
npm start
```

The server will run on `http://localhost:3000`

### Step 3: Access the Application

Open `frontend/index.html` in your browser or use a local server:

```bash
# Using Python
cd frontend
python -m http.server 8080

# Using Node.js http-server
npx http-server frontend -p 8080
```

Then visit: `http://localhost:8080`

### Step 4: Explore New Features

#### For Hotel Staff:

1. **Manage Services**
   - Click **Services** in the sidebar
   - View all available services (26 pre-loaded services)
   - Add new services or edit existing ones
   - Set service availability

2. **Handle Service Orders**
   - Go to **Services** → **Service Orders** tab
   - View all customer orders
   - Check **Pending Orders** tab for new requests
   - Update order status as you fulfill them

#### For Guests:

1. **Access Guest Portal**
   - Click **Guest Portal** in the sidebar
   - Select your booking from the dropdown
   - View your room details

2. **Order Services**
   - Browse services by category
   - Select quantity
   - Click **Order**
   - Add special instructions if needed
   - Track orders in "My Orders" section

### Step 5: Test the System

#### Test Scenario 1: Order Room Service
1. Go to **Guest Portal**
2. Select an active booking (booking status: Confirmed or CheckedIn)
3. Browse the Food category
4. Order "Breakfast Buffet" (₹500)
5. Add special instruction: "Extra butter please"
6. Check "My Orders" - status should be "Pending"

#### Test Scenario 2: Fulfill Orders
1. Go to **Services** page
2. Click **Pending Orders** tab
3. You should see the breakfast order
4. Click **Start** to change status to "InProgress"
5. Once ready, click **Complete**
6. Go back to Guest Portal - order now shows "Completed"

#### Test Scenario 3: View Statistics
1. Dashboard now shows "Pending Service Orders" count
2. Go to **Services** → **Service Orders**
3. Filter by status to see completed orders
4. View revenue from completed service orders

## Quick Tips

### Pre-loaded Services Categories:
- **Food**: 6 items (Breakfast, Curry, Biryani, Sandwich, Pizza, Salad)
- **Beverage**: 5 items (Juice, Coffee, Tea, Soft Drinks, Water)
- **Laundry**: 3 items (Regular, Express, Dry Cleaning)
- **Spa**: 3 items (Massage, Facial, Aromatherapy)
- **Transport**: 3 items (Airport Pickup, City Tour, Car Rental)
- **Housekeeping**: 3 items (Towels, Bedding, Cleaning)
- **Other**: 3 items (Newspaper, Iron, Baby Cot)

### Service Management Tips:
- ✅ Mark services as "Unavailable" when out of stock
- ✅ Update prices as needed
- ✅ Add descriptions to help guests choose
- ✅ Monitor pending orders regularly
- ✅ Complete orders promptly for better guest satisfaction

### Navigation:
- **Services Page**: For hotel staff to manage catalog and orders
- **Guest Portal**: Guest-friendly interface for ordering
- **Dashboard**: Shows pending orders count at a glance

## Common Workflows

### Daily Operations:
1. Morning: Check pending orders from overnight
2. Throughout day: Monitor pending orders tab
3. Update order status as services are fulfilled
4. Evening: Review completed orders and revenue

### Guest Experience:
1. Guest checks in (create/confirm booking)
2. Guest selects booking in Guest Portal
3. Guest browses and orders services
4. Staff fulfills orders
5. Orders tracked until checkout

## Need Help?

See the comprehensive guide: `SERVICES_GUIDE.md`

## What's Next?

The system is now fully functional with room service capabilities. You can:
- Customize services for your hotel
- Add more categories if needed
- Track service revenue
- Analyze popular services
- Improve guest satisfaction with quick service

Enjoy your enhanced Hotel Management System! 🎉
