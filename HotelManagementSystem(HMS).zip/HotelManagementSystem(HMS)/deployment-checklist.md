# cPanel Deployment Checklist

## Files to Upload to Application Root (HotelManagementSystem(HMS)/backend)

### Required Files:
- [ ] package.json
- [ ] server.js
- [ ] config/ (entire folder)
- [ ] middleware/ (entire folder)  
- [ ] models/ (entire folder)
- [ ] routes/ (entire folder)

### Files NOT to upload:
- [ ] node_modules/ (will be installed via cPanel)
- [ ] .env (use cPanel environment variables instead)
- [ ] dev dependencies

## Upload Steps:
1. Compress backend folder contents (not the folder itself)
2. Upload via cPanel File Manager 
3. Extract to: /public_html/HotelManagementSystem(HMS)/backend/
4. Install dependencies via cPanel Node.js interface

## Frontend Deployment:
Upload frontend/ folder contents to:
/public_html/ (for main domain)
OR
/public_html/subdomain_folder/ (if using subdomain for frontend)

## After Upload:
1. Install npm packages via cPanel
2. Test API endpoints
3. Update frontend API URLs if needed