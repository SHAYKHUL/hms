# Hotel Room Counting & Occupancy Analytics Guide

This guide explains how the HMS system implements hotel industry standards for counting rooms per day and calculating occupancy metrics.

---

## 1. Hotel Industry Standards for Room Counting

### The Hotel Day vs Calendar Day

**Standard Hotel Day Definition:**
- **Check-in time:** 2:00 PM – 3:00 PM
- **Check-out time:** 11:00 AM – 12:00 PM
- A "day" is counted from one check-out time to the next, NOT from midnight to midnight

### Room Night Definition

A **room night** is one occupied room for one night.

**Example:**
- Guest checks in: March 1
- Guest checks out: March 3
- **Duration:** 2 room nights (March 1 & 2)

**Multi-room example:**
- 5 rooms booked for 1 night = 5 room nights
- 1 room booked for 3 nights = 3 room nights

---

## 2. How HMS Calculates Daily Room Counts

### The Query Logic

For any given date in the hotel day:

```sql
WHERE check_in <= selected_date AND check_out > selected_date
```

**What this means:**
- Include rooms where check-in is on or before the date
- Include rooms where check-out is after the date
- This correctly counts a room as occupied for the entire stay

**Example:**
- Date to check: February 25, 2026
- Query: `WHERE check_in <= '2026-02-25' AND check_out > '2026-02-25'`
- A booking from Feb 24 to Feb 26: **YES, counted as occupied**
- A booking from Feb 25 to Feb 28: **YES, counted as occupied**
- A booking from Feb 24 to Feb 25: **NO, not counted (checkout is on this date)**

---

## 3. Key Occupancy Metrics

### 3.1 Occupancy Rate (%)

```
Occupancy % = (Rooms Occupied ÷ Total Available Rooms) × 100
```

**What it shows:** Percentage of rooms that are occupied on a given day

**Example:**
- 75 rooms occupied
- 100 total available rooms
- **Occupancy = (75 ÷ 100) × 100 = 75%**

---

### 3.2 ADR (Average Daily Rate)

```
ADR = Total Room Revenue ÷ Number of Rooms Sold
```

**What it shows:** Average price per room sold on a given day

**Example:**
- Day's revenue: ₹75,000
- Rooms sold: 60
- **ADR = ₹75,000 ÷ 60 = ₹1,250 per room**

---

### 3.3 RevPAR (Revenue Per Available Room)

```
RevPAR = Total Room Revenue ÷ Total Available Rooms
```

OR

```
RevPAR = Occupancy % × ADR
```

**What it shows:** How much revenue is generated per available room (whether sold or not)

**Example:**
- Total revenue: ₹75,000
- Total available rooms: 100
- **RevPAR = ₹75,000 ÷ 100 = ₹750 per room**

**Alternative calculation:**
- Occupancy: 75%
- ADR: ₹1,000
- **RevPAR = 75% × ₹1,000 = ₹750**

---

### 3.4 Room Nights Booked

```
Room Nights = SUM(DATEDIFF(check_out, check_in))
```

**What it shows:** Total number of room-night slots filled

**Example:**
- 3 rooms booked for 5 nights each
- **Room Nights = 3 × 5 = 15 room nights booked**

---

### 3.5 Available Room Nights

```
Available Room Nights = Total Available Rooms × Number of Days
```

**What it shows:** Total possible room-night slots available

**Example:**
- 100 available rooms
- 30-day period
- **Available = 100 × 30 = 3,000 room nights**

---

## 4. API Endpoints for Occupancy Analytics

All endpoints return JSON responses with success/error indicators.

### 4.1 Get Daily Room Count

**Endpoint:**
```
GET /api/bookings/analytics/daily-count?date=YYYY-MM-DD
```

**Response:**
```json
{
  "success": true,
  "date": "2026-02-25",
  "data": {
    "occupied_rooms": 75,
    "total_guests": 152
  }
}
```

---

### 4.2 Get Daily Occupancy Metrics

**Endpoint:**
```
GET /api/bookings/analytics/daily-metrics?date=YYYY-MM-DD
```

**Response:**
```json
{
  "success": true,
  "data": {
    "date": "2026-02-25",
    "occupied_rooms": 75,
    "available_rooms": 100,
    "rooms_sold": 75,
    "total_guests": 152,
    "occupancy_percentage": 75.00,
    "room_revenue": "75000.00",
    "adr": "1000.00",
    "revpar": "750.00",
    "available_capacity": 25
  }
}
```

---

### 4.3 Get Period Occupancy Analysis

**Endpoint:**
```
GET /api/bookings/analytics/period-analysis?startDate=YYYY-MM-DD&endDate=YYYY-MM-DD
```

**Response:**
```json
{
  "success": true,
  "data": {
    "period": {
      "start_date": "2026-01-25",
      "end_date": "2026-02-25",
      "days": 32
    },
    "rooms": {
      "total_available": 100,
      "unique_rooms_booked": 92,
      "total_available_nights": 3200
    },
    "bookings": {
      "total_room_nights": 2550,
      "total_bookings": 28,
      "average_booking_value": "2750.00"
    },
    "metrics": {
      "occupancy_percentage": 79.69,
      "total_revenue": "7012500.00",
      "average_nightly_revenue": "2191406.25",
      "revpar": "2191.41"
    }
  }
}
```

---

### 4.4 Get Daily Occupancy Trend

**Endpoint:**
```
GET /api/bookings/analytics/occupancy-trend?startDate=YYYY-MM-DD&endDate=YYYY-MM-DD
```

**Response:**
```json
{
  "success": true,
  "count": 32,
  "data": [
    {
      "date": "2026-01-25",
      "occupied_rooms": 72,
      "checked_in": 60,
      "confirmed": 12,
      "available_rooms": 100,
      "occupancy_percentage": "72.00",
      "daily_revenue": "72000.00",
      "adr": "1000.00",
      "total_guests": 144
    },
    ...more days...
  ]
}
```

**Use case:** Create charts showing occupancy trends over time

---

### 4.5 Get Room Status for a Date

**Endpoint:**
```
GET /api/bookings/analytics/room-status?date=YYYY-MM-DD
```

**Response:**
```json
{
  "success": true,
  "date": "2026-02-25",
  "summary": {
    "occupied_rooms": 75,
    "vacant_rooms": 25,
    "total_rooms": 100,
    "occupancy_percentage": "75.00"
  },
  "data": [
    {
      "room_id": 1,
      "room_number": "101",
      "room_type": "Single",
      "price": "800",
      "booking_id": 542,
      "guest_id": 18,
      "guest_name": "John Doe",
      "check_in": "2026-02-24",
      "check_out": "2026-02-27",
      "status": "CheckedIn",
      "cleaning_status": "Ready for Guest"
    },
    ...more rooms...
  ]
}
```

**Use case:** See which specific rooms are occupied and who occupies them

---

### 4.6 Get Occupancy by Room Type

**Endpoint:**
```
GET /api/bookings/analytics/by-room-type?startDate=YYYY-MM-DD&endDate=YYYY-MM-DD
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "room_type": "Single",
      "total_rooms": 30,
      "rooms_booked": 24,
      "occupancy_rate": "80.00",
      "total_nights_booked": 672,
      "total_revenue": "537600.00"
    },
    {
      "room_type": "Double",
      "total_rooms": 40,
      "rooms_booked": 32,
      "occupancy_rate": "80.00",
      "total_nights_booked": 1024,
      "total_revenue": "1229440.00"
    },
    {
      "room_type": "Suite",
      "total_rooms": 20,
      "rooms_booked": 16,
      "occupancy_rate": "80.00",
      "total_nights_booked": 854,
      "total_revenue": "2137000.00"
    },
    {
      "room_type": "Deluxe",
      "total_rooms": 10,
      "rooms_booked": 8,
      "occupancy_rate": "80.00",
      "total_nights_booked": 214,
      "total_revenue": "856000.00"
    }
  ]
}
```

**Use case:** Compare occupancy performance across different room types

---

## 5. Practical Examples

### Example 1: Daily Occupancy Check

**Scenario:** Check how many rooms are occupied on February 25, 2026

```javascript
// Call API
const response = await fetch('/api/bookings/analytics/daily-metrics?date=2026-02-25');
const data = await response.json();

console.log(`Date: ${data.data.date}`);
console.log(`Occupied: ${data.data.occupied_rooms}/${data.data.available_rooms}`);
console.log(`Occupancy Rate: ${data.data.occupancy_percentage}%`);
console.log(`ADR: ₹${data.data.adr}`);
console.log(`RevPAR: ₹${data.data.revpar}`);
```

**Output:**
```
Date: 2026-02-25
Occupied: 75/100
Occupancy Rate: 75.00%
ADR: ₹1000.00
RevPAR: ₹750.00
```

---

### Example 2: Monthly Occupancy Analysis

**Scenario:** Analyze occupancy for the month of February 2026

```javascript
const response = await fetch('/api/bookings/analytics/period-analysis?startDate=2026-02-01&endDate=2026-02-28');
const analysis = await response.json();

console.log(`Month Occupancy: ${analysis.data.metrics.occupancy_percentage}%`);
console.log(`Total Revenue: ₹${analysis.data.metrics.total_revenue}`);
console.log(`RevPAR: ₹${analysis.data.metrics.revpar}`);
console.log(`Room Nights Booked: ${analysis.data.bookings.total_room_nights}`);
```

---

### Example 3: Room Status View

**Scenario:** See which rooms are occupied and which are vacant on a specific date

```javascript
const response = await fetch('/api/bookings/analytics/room-status?date=2026-02-25');
const status = await response.json();

// Summary
console.log(`Occupied: ${status.summary.occupied_rooms}, Vacant: ${status.summary.vacant_rooms}`);

// Get vacant rooms
const vacantRooms = status.data.filter(r => r.status === 'Vacant');
console.log('Available rooms:', vacantRooms.map(r => r.room_number).join(', '));

// Get occupied rooms with guests
const occupiedRooms = status.data.filter(r => r.status !== 'Vacant');
occupiedRooms.forEach(room => {
    console.log(`Room ${room.room_number}: ${room.guest_name} (${room.check_in} to ${room.check_out})`);
});
```

---

## 6. Using the Reports Dashboard

The Reports page in HMS now displays:

### Statistics Cards
- **Total Bookings:** Number of bookings in the period
- **Total Revenue:** Sum of all booking amounts
- **Collected:** Amount already paid
- **Pending:** Amount still due
- **Occupancy Rate:** Percentage of rooms occupied (new)
- **Room Nights Booked:** Total room-night slots filled (new)
- **RevPAR:** Revenue per available room (new)
- **Available Room Nights:** Total possible room-night slots (new)

### Occupancy Trend
- Daily breakdown for the selected period
- Shows occupied rooms, occupancy percentage, ADR, and revenue per day

### Occupancy by Room Type
- Comparison of occupancy rates across different room types
- Helps identify which room types are popular

### Booking Details
- Detailed list of all bookings in the selected period

---

## 7. Best Practices for Room Counting

### ✅ DO
- Count rooms based on `check_in <= date AND check_out > date`
- Use occupancy percentage to understand hotel performance
- Track ADR and RevPAR trends over weeks and months
- Compare occupancy rates across room types
- Review RevPAR as a better metric than just occupancy (accounts for both occupancy AND price)

### ❌ DON'T
- Count calendar days (midnight to midnight) for bookings
- Assume higher occupancy always equals higher revenue (RevPAR tells the real story)
- Ignore room-night calculations (important for capacity planning)
- Only track occupancy percentage (RevPAR is more insightful)

---

## 8. Database Queries Reference

### Quick Query: Rooms Occupied Today

```sql
SELECT COUNT(*) as occupied_rooms
FROM bookings
WHERE DATE(check_in) <= CURDATE()
AND DATE(check_out) > CURDATE()
AND booking_status IN ('Confirmed', 'CheckedIn');
```

### Quick Query: Occupancy Percentage Today

```sql
SELECT 
  COUNT(*) as occupied_rooms,
  (SELECT COUNT(*) FROM rooms WHERE status != 'Maintenance') as available_rooms,
  ROUND((COUNT(*) / (SELECT COUNT(*) FROM rooms WHERE status != 'Maintenance') * 100), 2) as occupancy_percentage
FROM bookings
WHERE check_in <= CURDATE()
AND check_out > CURDATE()
AND booking_status IN ('Confirmed', 'CheckedIn');
```

### Quick Query: Daily ADR

```sql
SELECT 
  SUM(total_amount) / COUNT(*) as adr
FROM bookings
WHERE check_in <= CURDATE()
AND check_out > CURDATE()
AND booking_status IN ('Confirmed', 'CheckedIn');
```

---

## 9. Integration with Your HMS System

The new methods are integrated into:

### Backend
- **Model:** `backend/models/Booking.js`
  - `getDailyRoomCount(date)`
  - `getDailyOccupancyMetrics(date)`
  - `getPeriodOccupancyAnalysis(startDate, endDate)`
  - `getDailyOccupancyTrend(startDate, endDate)`
  - `getDailyRoomStatus(date)`
  - `getOccupancyByRoomType(startDate, endDate)`

- **Routes:** `backend/routes/bookings.js`
  - All 6 new API endpoints under `/analytics/*`

### Frontend
- **Script:** `frontend/js/reports.js`
  - `generateReport()` - Enhanced to fetch occupancy data
  - `getTodayMetrics()` - Get today's metrics
  - `getRoomStatus(date)` - Get room-specific status
  - `displayOccupancyTrend()` - Display trend data
  - `displayRoomTypeOccupancy()` - Display room type stats

- **Page:** `frontend/reports.html`
  - New metric cards for occupancy, room nights, and RevPAR
  - Containers for occupancy trend and room type analysis

---

## 10. Troubleshooting

### Q: Why is occupancy not showing?
**A:** Ensure bookings have `booking_status` set to 'Confirmed' or 'CheckedIn'

### Q: ADR showing 0?
**A:** Check that room_price and total_amount are properly stored

### Q: RevPAR calculation seems off?
**A:** RevPAR = Revenue ÷ Total Available Rooms (not occupied rooms)

### Q: How do I exclude maintenance rooms?
**A:** The queries use `WHERE status != 'Maintenance'` automatically

---

## 11. Future Enhancements

Possible additions:
- Forecast occupancy for upcoming dates
- Compare current month to previous months
- Set occupancy targets and track vs actual
- Export reports to PDF/Excel
- Email scheduled reports
- Seasonal trend analysis

---

**Last Updated:** February 25, 2026

For questions or issues, refer to the API_REFERENCE.md for more technical details.
