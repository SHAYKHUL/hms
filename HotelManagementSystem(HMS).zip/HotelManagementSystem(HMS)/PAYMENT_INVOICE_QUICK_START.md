# Payment & Invoice System - Quick Setup Guide

## ⚡ Quick Start (5 minutes)

### Step 1: Execute Database Migration
```bash
# Navigate to database directory
cd database

# Execute the migration script
mysql -u root -p hms_database < payment_invoice_migration.sql
```

### Step 2: Verify Backend Routes
Check that `/backend/server.js` includes:
```javascript
const invoiceRoutes = require('./routes/invoices');
const paymentRoutes = require('./routes/payments');

app.use('/api/invoices', invoiceRoutes);
app.use('/api/payments', paymentRoutes);
```

### Step 3: Restart Backend
```bash
cd backend
npm start
```

### Step 4: Test in Browser
1. Go to http://localhost:3000
2. Create a test booking
3. Check in → Check out
4. In Bookings page, find "Generate Invoice" option
5. View invoice and record payment

---

## 📋 What's Implemented

✅ **Database Tables**
- invoices
- invoice_items  
- payments
- payment_methods
- billing_settings
- refunds

✅ **Backend Models**
- Invoice.js
- Payment.js
- Refund.js

✅ **Backend Routes**
- /api/invoices (8 endpoints)
- /api/payments (15 endpoints)

✅ **Frontend Files**
- js/billing.js (core functions)
- Updated bookings.html (modals)
- Updated bookings.js (handlers)
- Updated guest-portal.html (billing section)
- Updated guest-portal.js (guest functions)

---

## 🎯 Key Features

### Invoice Management
- Auto-generate on checkout
- Room + Services + Tax + Discounts
- Print/Download
- Multiple statuses

### Payment Recording
- 6 payment methods
- Reference tracking
- Receipt printing
- Payment history

### Refund Processing
- Create refund requests
- Approval workflow
- Track refund status

### Guest Portal
- View invoice details
- Download/Print
- See amount due
- Access after checkout

---

## 📡 API Endpoints Quick Reference

### Invoice Endpoints
| Action | Endpoint |
|--------|----------|
| Generate | POST /api/invoices/generate |
| View | GET /api/invoices/:id |
| By Booking | GET /api/invoices/booking/:bookingId |
| By Guest | GET /api/invoices/guest/:guestId |

### Payment Endpoints
| Action | Endpoint |
|--------|----------|
| Record | POST /api/payments |
| View | GET /api/payments/:id |
| By Invoice | GET /api/payments/invoice/:invoiceId |
| By Booking | GET /api/payments/booking/:bookingId |

---

## 🔧 Configuration

Edit `billing_settings` table in database:

```sql
UPDATE billing_settings 
SET setting_value = 18 
WHERE setting_key = 'tax_rate';

UPDATE billing_settings 
SET setting_value = 'INV-' 
WHERE setting_key = 'invoice_prefix';

UPDATE billing_settings 
SET setting_value = 'Your Hotel Name' 
WHERE setting_key = 'company_name';
```

---

## 🧪 Quick Test

### Generate Invoice
```bash
curl -X POST http://localhost:3000/api/invoices/generate \
  -H "Content-Type: application/json" \
  -d '{"booking_id": 1}'
```

### Record Payment
```bash
curl -X POST http://localhost:3000/api/payments \
  -H "Content-Type: application/json" \
  -d '{
    "invoice_id": 1,
    "booking_id": 1,
    "guest_id": 1,
    "amount": 5000,
    "payment_method": "Cash",
    "received_by": "Admin"
  }'
```

---

## 📚 Full Documentation

See `PAYMENT_INVOICE_IMPLEMENTATION.md` for complete details.

---

## ✅ Verification Checklist

- [ ] Database migration executed successfully
- [ ] Backend server started
- [ ] All 3 new models exist in `/backend/models/`
- [ ] Both route files exist in `/backend/routes/`
- [ ] `server.js` has both route imports
- [ ] `billing.js` exists in `/frontend/js/`
- [ ] Bookings page has payment/invoice modals
- [ ] Guest portal shows billing section
- [ ] Can generate invoice from admin
- [ ] Can record payment
- [ ] Can print invoice
- [ ] Guest can see invoice in portal

---

## 🚀 You're Ready!

The payment and invoice system is now fully operational. Start generating invoices and processing payments!

**Need Help?** Check the comprehensive guide at `PAYMENT_INVOICE_IMPLEMENTATION.md`
