# Housekeeping Management System - Complete Implementation Guide

## Overview

The Enhanced Housekeeping Management system provides comprehensive features for:
- **Room Cleaning Status Tracking** - Monitor cleaning progress of each room
- **Maintenance Issue Management** - Report, track, and resolve maintenance problems
- **Staff Performance Monitoring** - Track housekeeping staff efficiency and workload
- **Automated Room Status Updates** - Automatically update room status based on cleaning and maintenance needs
- **Comprehensive Reporting** - Generate detailed reports on cleaning efficiency and maintenance metrics

## Features Implemented

### 1. Room Cleaning Status Management

#### Cleaning Status States
- **Pending**: Initial state, not yet scheduled for cleaning
- **Dirty**: Room needs cleaning (post-checkout or after use)
- **Cleaning in Progress**: Staff currently cleaning the room
- **Cleaned**: Cleaning completed, awaiting inspection
- **Ready for Guest**: Room inspected and ready for check-in
- **Inspecting**: Quality control inspection in progress

#### Key Operations

**Update Room Cleaning Status**
```
PATCH /api/housekeeping/rooms/{roomId}/status
{
  "cleaningStatus": "Cleaned",
  "staffId": 2  // Optional: staff who cleaned the room
}
```

**Get Room Cleaning Status**
```
GET /api/housekeeping/rooms/{roomId}/status
```

**Get All Rooms with Cleaning Status**
```
GET /api/housekeeping/rooms
```

**Get Rooms Needing Cleaning**
```
GET /api/housekeeping/rooms/needs/cleaning
```

**Get Rooms by Cleaning Status**
```
GET /api/housekeeping/rooms/status/{cleaningStatus}
```

**Schedule Next Cleaning**
```
PATCH /api/housekeeping/rooms/{roomId}/schedule-cleaning
{
  "scheduledDate": "2026-02-25"
}
```

### 2. Cleaning Task Management

#### Task Types
- **Turnover**: Complete cleaning after guest checkout
- **Deep Clean**: Thorough cleaning (weekly/monthly)
- **Regular Clean**: Daily standard cleaning
- **Quick Clean**: Light tidying and restocking
- **Spot Clean**: Targeted cleaning for specific areas

#### Task Status Lifecycle
- **Not Started**: Task created, not yet begun
- **In Progress**: Staff started working on the task
- **Completed**: Task finished and marked complete
- **Pending Approval**: Awaiting supervisor approval
- **Cancelled**: Task cancelled

#### Key Operations

**Create Cleaning Task**
```
POST /api/housekeeping/tasks
{
  "roomId": 1,
  "taskType": "Turnover",
  "priority": "High",
  "scheduledDate": "2026-02-24",
  "scheduledTime": "09:00:00",
  "notes": "Full deep clean",
  "assignedBy": 1,
  "staffId": 2  // Optional
}
```

**Get Cleaning Tasks**
```
GET /api/housekeeping/tasks?limit=50&offset=0
```

**Get Tasks by Status**
```
GET /api/housekeeping/tasks/status/{status}
```

**Get Staff Tasks**
```
GET /api/housekeeping/tasks/staff/{staffId}
```

**Start Task**
```
PATCH /api/housekeeping/tasks/{taskId}/start
```

**Complete Task**
```
PATCH /api/housekeeping/tasks/{taskId}/complete
{
  "notes": "Task completed successfully"
}
```

**Assign Task to Staff**
```
PATCH /api/housekeeping/tasks/{taskId}/assign
{
  "staffId": 2
}
```

**Get Cleaning Statistics**
```
GET /api/housekeeping/stats/overview
```

### 3. Maintenance Issue Tracking

#### Maintenance Types
- **Plumbing**: Water, pipes, drains
- **Electrical**: Power, lighting, outlets
- **HVAC**: Heating, cooling, ventilation
- **Furniture**: Beds, chairs, tables, fixtures
- **Appliance**: Microwave, refrigerator, etc.
- **Paint**: Wall damage, cracks, peeling
- **Flooring**: Carpet, tiles, wood damage
- **Other**: Miscellaneous issues

#### Severity Levels
- **Critical**: Impacts guest safety/comfort, requires immediate action
- **High**: Affects room usability, should resolve within 24 hours
- **Medium**: Impacts room quality, resolve within 3-5 days
- **Low**: Minor issues, resolve within a week

#### Maintenance Status
- **Reported**: Issue reported, awaiting assignment
- **Assigned**: Issue assigned to maintenance staff
- **In Progress**: Work in progress
- **Completed**: Issue resolved
- **On Hold**: Work paused, awaiting materials/parts

#### Key Operations

**Report Maintenance Issue**
```
POST /api/housekeeping/maintenance/report-with-room-update
{
  "roomId": 2,
  "maintenanceType": "Plumbing",
  "issueDescription": "Bathroom sink drains slowly",
  "severity": "Medium",
  "reportedBy": "Housekeeping Staff",
  "costEstimate": 800.00,
  "partsRequired": "Pipe cleaner, new trap"
}
```

**Get All Maintenance Logs**
```
GET /api/housekeeping/maintenance?limit=100&offset=0
```

**Get Logs by Status**
```
GET /api/housekeeping/maintenance/status/{status}
```

**Get Logs by Severity**
```
GET /api/housekeeping/maintenance/severity/{severity}
```

**Get Critical Issues**
```
GET /api/housekeeping/maintenance/critical
```

**Assign Maintenance**
```
PATCH /api/housekeeping/maintenance/{logId}/assign
{
  "assignedTo": "Ali Hassan"
}
```

**Start Maintenance Work**
```
PATCH /api/housekeeping/maintenance/{logId}/start
```

**Complete Maintenance**
```
PATCH /api/housekeeping/maintenance/{logId}/complete-with-room-update
{
  "actualCost": 750.00,
  "notes": "Pipe cleaned successfully, sink drains normally"
}
```

**Hold Maintenance (Pause Work)**
```
PATCH /api/housekeeping/maintenance/{logId}/hold
{
  "reason": "Waiting for spare parts delivery"
}
```

**Update Maintenance Details**
```
PUT /api/housekeeping/maintenance/{logId}
{
  "costEstimate": 1000.00,
  "actualCost": 950.00,
  "notes": "Updated estimate",
  "partsRequired": "New compressor"
}
```

### 4. Automatic Room Status Management

When maintenance is reported:
- **Critical/High severity**: Room status automatically updated to "Maintenance"
- **Room cleaning status**: Updated to "Inspecting"

When maintenance is completed:
- If no other pending issues: Room status reverts to "Available"
- Room cleaning status set to "Dirty" (needs re-cleaning)

### 5. Comprehensive Dashboard

**Get Comprehensive Housekeeping Dashboard**
```
GET /api/housekeeping/dashboard/comprehensive
```

Returns:
- Staff statistics (active staff, roles breakdown)
- Cleaning statistics (completed today, pending tasks)
- Maintenance statistics (pending issues, severity breakdown)
- Room statistics (available, booked, maintenance, cleaned)
- Rooms needing attention (dirty, pending cleaning, under maintenance)
- Staff workload (assigned tasks, pending tasks per staff)
- Critical maintenance issues requiring immediate attention

### 6. Reporting Endpoints

**Cleaning Efficiency Report (Last N Days)**
```
GET /api/housekeeping/reports/cleaning-efficiency?days=30
```

Returns per staff:
- Total tasks assigned
- Completed tasks
- Completion rate %
- Average time per task (minutes)
- Urgent tasks handled
- Performance metrics

**Maintenance Tracking Report (Last N Days)**
```
GET /api/housekeeping/reports/maintenance-tracking?days=30
```

Returns per maintenance type:
- Total issues reported
- Completed issues
- Pending issues
- Critical count
- Average estimated cost
- Total actual costs
- Average days to resolve

**Daily Cleaning Summary**
```
GET /api/housekeeping/reports/daily-summary?date=2026-02-24
```

Returns:
- Total tasks scheduled
- Completed tasks
- In-progress tasks
- Not started tasks
- Staff involved
- Rooms scheduled for cleaning

### 7. Staff Management

**Get All Staff**
```
GET /api/housekeeping/staff
```

**Get Active Staff Only**
```
GET /api/housekeeping/staff/active
```

**Get Staff by Role**
```
GET /api/housekeeping/staff/role/{role}
```

**Add New Staff**
```
POST /api/housekeeping/staff
{
  "staffName": "John Doe",
  "phone": "9876543210",
  "email": "john@hotel.com",
  "role": "Housekeeper",
  "shift": "Morning",
  "assignedFloors": "1,2",
  "hireDate": "2026-01-01"
}
```

**Update Staff Status**
```
PATCH /api/housekeeping/staff/{staffId}/status
{
  "status": "On Leave"  // Active, Inactive, On Leave
}
```

**Get Staff Workload**
```
GET /api/housekeeping/staff/workload/stats
```

## Database Schema

### Tables

1. **room_cleaning_status**
   - Tracks current cleaning status of each room
   - Stores last cleaned date and by whom
   - Stores next scheduled cleaning date

2. **room_cleaning_history**
   - Audit trail of all room cleaning activities
   - Tracks status changes and staff involved
   - Records time taken for cleaning tasks

3. **cleaning_tasks**
   - Detailed records of cleaning assignments
   - Links to rooms, staff, and supervisors

4. **maintenance_logs**
   - Maintenance issue tracking and history
   - Cost estimation and actual cost tracking
   - Staff assignment and completion dates

5. **housekeeping_staff**
   - Staff information and schedules
   - Role, shift, and assigned floor information

## Frontend Usage

### JavaScript Enhancements

The `housekeeping-enhanced.js` file provides:
- Comprehensive dashboard loading
- Room cleaning status display and updates
- Cleaning task management
- Maintenance issue tracking
- Staff workload monitoring
- Report generation

### Key Functions

```javascript
// Load comprehensive dashboard
loadDashboard()

// Load rooms with cleaning status
loadRoomsWithCleaningStatus()

// Update room cleaning status
updateCleaningStatus(roomId, cleaningStatus, staffId)

// Complete a cleaning task
completeTask(taskId)

// Complete maintenance with automatic room status update
completeMaintenance(logId)

// Generate cleaning efficiency report
generateCleaningReport()

// Generate maintenance tracking report
generateMaintenanceReport()
```

## Workflow Examples

### Example 1: Room Turnover After Guest Checkout

1. Guest checks out
2. Report room status as "Dirty"
3. Create cleaning task with type "Turnover"
4. Assign to available housekeeper
5. Staff starts task (status: "In Progress")
6. Update room cleaning status to "Cleaning in Progress"
7. Staff completes task
8. Supervisor inspects room
9. Update status to "Ready for Guest"
10. Room available for new booking

### Example 2: Handling a Maintenance Emergency

1. Housekeeping discovers critical issue (AC not working)
2. Report critical maintenance issue
   - Automatically updates room to "Maintenance"
   - Cleaning status set to "Inspecting"
3. System alerts about critical issue
4. Maintenance staff assigned
5. Issue resolved
6. Complete maintenance with actual cost
7. Room automatically reverts to "Available"
8. Cleaning staff schedules cleaning
9. Room ready for new guest

### Example 3: Daily Operations Summary

1. Generate daily cleaning summary report
2. View staff efficiency metrics
3. Identify underperforming staff members
4. Check rooms needing attention
5. Prioritize cleaning tasks
6. Track maintenance issue trends

## Performance Metrics Tracked

### Cleaning Efficiency
- Tasks per staff member
- Average completion time
- Completion rate %
- Priority handling capability
- Quality of work

### Maintenance Metrics
- Response time to reported issues
- Average resolution time
- Cost tracking (estimated vs actual)
- Critical issue response time
- Staff performance by maintenance type

### Room Management
- Cleaning frequency
- Time between cleaning cycles
- Room availability percentage
- Maintenance incidents per room
- Guest satisfaction correlation

## API Response Format

All API responses follow standard format:

```json
{
  "success": true/false,
  "message": "Description of operation result",
  "data": { /* response data */ },
  "timestamp": "2026-02-24T15:30:00.000Z"
}
```

## Error Handling

Common error responses:

- **400**: Invalid request data
- **404**: Resource not found
- **500**: Server error

Always check `success` flag before processing response data.

## Best Practices

1. **Always assign cleaning tasks** to specific staff members
2. **Set realistic priorities** - don't mark everything as urgent
3. **Record completion notes** for quality assurance
4. **Track maintenance costs** accurately for budgeting
5. **Use room status updates** to prevent double-booking
6. **Review reports regularly** to identify trends
7. **Update staff skills** based on maintenance type performance
8. **Schedule preventive maintenance** to reduce critical issues

## Future Enhancements

- Mobile app for staff real-time updates
- QR code based room inspection
- Photo documentation of cleaning/maintenance
- Predictive maintenance analytics
- Staff performance dashboards
- Integration with guest feedback for correlation
- Automated SMS notifications for critical issues
- Historical trending and forecasting
