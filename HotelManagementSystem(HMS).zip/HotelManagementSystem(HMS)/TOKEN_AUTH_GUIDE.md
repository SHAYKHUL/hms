# Guest Portal Token Authentication System - Implementation Guide

## 🔐 System Overview

A complete token-based authentication system for secure guest portal access with the following features:

✅ **Unique 6-digit PIN** generated during check-in
✅ **Long-format token** stored in database (32-byte hex hash)
✅ **Automatic token removal** on guest checkout
✅ **Access logging** with timestamps and access counts
✅ **localStorage-based** session management on frontend
✅ **PIN validation** before portal access
✅ **User-friendly** PIN display during check-in

## 📊 Database Schema

### `guest_sessions` Table
```sql
CREATE TABLE guest_sessions (
    session_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL UNIQUE,
    guest_id INT NOT NULL,
    access_token VARCHAR(256) NOT NULL UNIQUE,
    token_pin VARCHAR(6) NOT NULL,
    is_active TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NULL,
    checked_out_at TIMESTAMP NULL,
    last_accessed TIMESTAMP NULL,
    access_count INT DEFAULT 0,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
    FOREIGN KEY (guest_id) REFERENCES guests(guest_id) ON DELETE CASCADE
);
```

### Key Columns
- `access_token`: Long-format secure token (32-byte hex)
- `token_pin`: 6-digit PIN shown to guest
- `is_active`: 1 when active, 0 when checked out
- `access_count`: Tracks portal access attempts
- `checked_out_at`: When token was deactivated

## 🔄 Authentication Flow

### Check-In Process (Staff Side)
```
1. Staff clicks "Check-in" on Bookings page
2. System generates unique token & 6-digit PIN
3. Stores in guest_sessions table
4. Shows modal with PIN and instructions
5. Staff provides PIN to guest
```

### Guest Portal Access Flow
```
1. Guest opens Guest Portal page
2. System redirects to PIN login screen (no dropdown)
3. Guest enters 6-digit PIN received at check-in
4. System validates PIN via API: /api/guest-sessions/validate-pin
5. Token stored in localStorage
6. Portal content displays with guest data
```

### Check-Out Process (Staff Side)
```
1. Staff clicks "Check-out" on Bookings page
2. System calls GuestSession.removeSession()
3. is_active set to 0, checked_out_at timestamp added
4. Guest PIN becomes invalid immediately
5. Room status changes to Available
```

## 🛠️ Backend Implementation

### 1. GuestSession Model (`backend/models/GuestSession.js`)

**Key Methods:**
- `generateToken()` - Creates secure token & 6-digit PIN
- `create(bookingId, guestId)` - Creates session on check-in
- `getByToken(token)` - Retrieves session by token
- `getByPin(pin)` - Retrieves session by PIN
- `validateToken(token)` - Validates token and updates access logs
- `validatePin(pin)` - Validates PIN and updates access logs
- `removeSession(bookingId)` - Deactivates session on checkout

**Security Features:**
- 256-bit hex token (unguessable)
- 6-digit PIN for human-friendly access
- Access logging with timestamps
- Session expiry support (optional)
- One-to-one binding: one booking = one active session

### 2. Updated Booking Model (`backend/models/Booking.js`)

**Modified Methods:**
- `checkIn(bookingId)` - Now generates token and returns session data
- `checkOut(bookingId)` - Now removes guest session

```javascript
// Check-in returns session object
const result = await Booking.checkIn(bookingId);
// result = {
//   affectedRows: 1,
//   session: {
//     pin: "123456",
//     token: "abc123...",
//     bookingId: 1,
//     guestId: 1
//   }
// }
```

### 3. Guest Sessions Routes (`backend/routes/guestSessions.js`)

**Endpoints:**
```
POST   /api/guest-sessions/validate-token
POST   /api/guest-sessions/validate-pin
GET    /api/guest-sessions/booking/:bookingId
GET    /api/guest-sessions
POST   /api/guest-sessions/cleanup/expired
```

**Example: Validate PIN**
```bash
curl -X POST http://localhost:3000/api/guest-sessions/validate-pin \
  -H "Content-Type: application/json" \
  -d '{"pin":"123456"}'

# Response:
{
  "success": true,
  "message": "PIN is valid",
  "data": {
    "token": "abc123...",
    "bookingId": 1,
    "guestId": 1,
    "guestName": "Mr. X",
    "roomNumber": "1013"
  }
}
```

## 🎨 Frontend Implementation

### 1. Guest Portal JavaScript (`frontend/js/guest-portal.js`)

**Key Functions:**
- `authenticateGuest()` - Validates PIN on login screen
- `validateAndLoadPortal()` - Checks token validity on page load
- `loadPortal()` - Loads services and orders after auth
- `logoutGuest()` - Clears token and shows login screen

**LocalStorage Usage:**
```javascript
localStorage.setItem('guestPortalToken', token);
localStorage.setItem('guestBookingData', JSON.stringify(booking));
```

### 2. Login Screen

**Features:**
- Clean, modern design with PIN input
- Error messages for invalid PIN
- Auto-focus on PIN field
- Enter key to submit

```html
<input type="text" 
    id="accessPin" 
    placeholder="Enter 6-digit PIN" 
    maxlength="6"
    onkeypress="if(event.key === 'Enter') authenticateGuest()"
>
```

### 3. Bookings JavaScript (`frontend/js/bookings.js`)

**Updated Check-in Function:**
- Captures session data from API response
- Shows modal with PIN
- Provides copy-to-clipboard functionality
- Displays clear instructions for staff

## 📈 Usage Examples

### For Hotel Staff

**Check-in Flow:**
1. Navigate to Bookings page
2. Find booking for guest (e.g., Mr. X, Room 1013)
3. Click check-in button (✓)
4. Confirm check-in
5. Modal appears with PIN: **123456**
6. Copy PIN and give to guest
7. Click OK

**Check-out Flow:**
1. Find guest in bookings
2. Click check-out button (→)
3. Confirm check-out
4. Token automatically deactivated
5. Guest PIN becomes invalid immediately

### For Guests

**Portal Access Flow:**
1. Receive PIN from staff: **123456**
2. Open Guest Portal page
3. See login screen requesting PIN
4. Enter PIN: 123456
5. Click "Access Portal"
6. System validates PIN
7. Portal loads with services
8. Browse, order, and track services
9. Click Logout before leaving hotel

## 🔒 Security Features

### Implemented
- ✅ 256-bit secure tokens
- ✅ 6-digit PINs for user convenience
- ✅ Token auto-expiry on checkout
- ✅ Access logging and counting
- ✅ Database-level uniqueness on tokens
- ✅ HTTPS-ready (use in production)

### Optional Enhancements
- Implement token expiry time limit (e.g., 24 hours)
- IP-based rate limiting on PIN validation
- Email notifications on successful check-in
- QR code generation for PIN
- One-time PIN (OTP) option
- SMS delivery of PIN

## 📞 API Reference

### Validate PIN
```bash
POST /api/guest-sessions/validate-pin
Content-Type: application/json

{
  "pin": "123456"
}

Response (Success):
{
  "success": true,
  "message": "PIN is valid",
  "data": {
    "token": "abc123...",
    "bookingId": 1,
    "guestId": 1,
    "guestName": "Mr. X",
    "roomNumber": "1013"
  }
}
```

### Validate Token
```bash
POST /api/guest-sessions/validate-token
Content-Type: application/json

{
  "token": "abc123..."
}

Response (Success):
{
  "success": true,
  "message": "Token is valid",
  "data": {
    "bookingId": 1,
    "guestId": 1,
    "guestName": "Mr. X",
    "roomNumber": "1013"
  }
}
```

### Get Session by Booking ID
```bash
GET /api/guest-sessions/booking/1

Response:
{
  "success": true,
  "data": {
    "session_id": 1,
    "booking_id": 1,
    "token_pin": "123456",
    "is_active": 1,
    "created_at": "2026-02-24T10:30:00Z",
    "access_count": 5
  }
}
```

## 📋 Workflow Summary

| Step | Actor | Action | Result |
|------|-------|--------|--------|
| 1 | Guest | Book room | Booking created (Confirmed status) |
| 2 | Staff | Check-in guest | Token generated, PIN shown |
| 3 | Staff | Give PIN to guest | Guest has access code |
| 4 | Guest | Open portal, enter PIN | Portal unlocked |
| 5 | Guest | Browse & order services | Order tracked |
| 6 | Staff | Check-out guest | Token deactivated |
| 7 | Guest | Try portal again | "Invalid PIN" error |

## ⚙️ Configuration

### Token Generation (backend/models/GuestSession.js)
```javascript
// 32-byte (256-bit) secure token
const token = crypto.randomBytes(32).toString('hex');

// 6-digit PIN
const pin = Math.floor(100000 + Math.random() * 900000).toString();
```

### PIN Input Validation (frontend)
```javascript
if (pin.length !== 6) {
    errorDiv.textContent = 'PIN must be 6 digits';
}
```

### Session Storage
```javascript
localStorage.setItem('guestPortalToken', guestToken);
localStorage.setItem('guestBookingData', JSON.stringify(currentBooking));
```

## 🐛 Troubleshooting

### Issue: "Invalid PIN" at login
**Solution**: Verify PIN hasn't expired (check is_active=1 in database)

### Issue: PIN still works after checkout
**Solution**: Clear browser cache and localStorage

### Issue: Multiple active sessions per booking
**Solution**: Check database for duplicate booking_ids, use cleanup routine

### Issue: Lost PIN
**Solution**: Staff can check database or regenerate on bookings page

## 📊 Database Queries

### View all active sessions
```sql
SELECT * FROM guest_sessions WHERE is_active = 1 ORDER BY created_at DESC;
```

### Get session for specific guest
```sql
SELECT gs.* FROM guest_sessions gs
JOIN bookings b ON gs.booking_id = b.booking_id
WHERE b.guest_id = ? AND gs.is_active = 1;
```

### Find guest from PIN
```sql
SELECT guest_id FROM guest_sessions WHERE token_pin = ? AND is_active = 1;
```

### Cleanup expired sessions
```sql
UPDATE guest_sessions 
SET is_active = 0, checked_out_at = NOW() 
WHERE is_active = 1 AND expires_at < NOW();
```

## 🚀 Deployment Checklist

- [ ] Database schema updated with guest_sessions table
- [ ] GuestSession.js model created and tested
- [ ] Booking.js model updated for check-in/out
- [ ] guestSessions.js routes created
- [ ] server.js updated with guest-sessions route
- [ ] guest-portal.js updated with authentication
- [ ] guest-portal.html updated with login screen
- [ ] bookings.js updated with PIN display modal
- [ ] Test check-in process and PIN display
- [ ] Test guest portal access with PIN
- [ ] Test check-out and token deactivation
- [ ] Test token validation on portal reload

## 🎯 Future Enhancements

1. **Token Expiry**: Auto-expire tokens after X hours
2. **Rate Limiting**: Prevent brute-force PIN attempts
3. **SMS Integration**: Send PIN via SMS to guest phone
4. **QR Codes**: Generate QR for easy access
5. **Email Reminders**: Send PIN to guest email
6. **Two-Factor Auth**: PIN + password for extra security
7. **Audit Reports**: Track all guest portal access
8. **Mobile App**: Native app with biometric auth

## 📝 Notes

- Token is 64-character hex string (256-bit)
- PIN is 6-digit number (000000-999999)
- PIN shown only during check-in, token is API-only
- Tokens stored in database, not cookies
- localStorage used for client-side token persistence
- Session tied to booking (one-to-one relationship)
- Automatic cleanup on checkout

---

**Version**: 2.1.0  
**Updated**: February 24, 2026  
**Developed by**: Algolizen
