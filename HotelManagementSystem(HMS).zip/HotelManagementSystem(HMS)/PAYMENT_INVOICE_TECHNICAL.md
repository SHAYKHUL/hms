# Payment & Invoice System - Technical Reference

**For:** Developers and System Administrators  
**Version:** 1.0  
**Last Updated:** February 26, 2026

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    GUEST PORTAL & ADMIN UI                  │
│  (billing.js, bookings.html, guest-portal.html)             │
└────────────────────┬────────────────────────────────────────┘
                     │
        ┌────────────┴────────────┐
        │                         │
        ▼                         ▼
   ┌─────────────┐          ┌──────────────┐
   │ /api/invoices│          │ /api/payments│
   │   Routes    │          │   Routes     │
   └────┬────────┘          └────┬─────────┘
        │                        │
        ├────────────┬───────────┤
        │            │           │
        ▼            ▼           ▼
    ┌──────────┐ ┌────────┐ ┌────────────┐
    │ Invoice  │ │Payment │ │ Refund     │
    │ Model    │ │ Model  │ │ Model      │
    └────┬─────┘ └───┬────┘ └─────┬──────┘
         │           │            │
         └──────┬────┴────┬───────┘
                │         │
                ▼         ▼
           ┌──────────────────────────┐
           │   MySQL Database         │
           │  (6 tables + 2 views)    │
           └──────────────────────────┘
```

---

## Database Schema

### Table: `invoices`

**Purpose:** Store invoice records for each checked-out booking

```sql
CREATE TABLE invoices (
    invoice_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL UNIQUE,          -- Link to booking
    guest_id INT NOT NULL,                   -- Link to guest
    invoice_number VARCHAR(50) UNIQUE,       -- INV-000001
    invoice_date DATE,                       -- When invoice created
    due_date DATE,                           -- Payment due date
    check_in_date DATE,                      -- Stay start
    check_out_date DATE,                     -- Stay end
    room_number VARCHAR(10),                 -- Room #
    room_price DECIMAL(10, 2),               -- Daily rate
    number_of_nights INT,                    -- Stay duration
    subtotal DECIMAL(12, 2),                 -- Room + services
    services_total DECIMAL(12, 2),           -- Service charges
    discount_amount DECIMAL(10, 2),          -- Discount value
    discount_type ENUM('None', 'Percentage', 'Fixed'),
    discount_reason VARCHAR(100),            -- Why discount?
    tax_rate DECIMAL(5, 2),                  -- Tax percentage
    tax_amount DECIMAL(10, 2),               -- Calculated tax
    grand_total DECIMAL(12, 2),              -- Final amount
    amount_paid DECIMAL(12, 2),              -- Received so far
    amount_due DECIMAL(12, 2),               -- Still owed
    notes TEXT,                              -- Additional notes
    status ENUM(...),                        -- Invoice status
    created_by VARCHAR(100),                 -- Who created
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);
```

**Relationships:**
```
invoices → bookings (FK: booking_id)
invoices → guests (FK: guest_id)
invoices ← invoice_items (FK: invoice_id)
invoices ← payments (FK: invoice_id)
```

### Table: `invoice_items`

**Purpose:** Line items on invoice (room, services, discounts, taxes)

```sql
CREATE TABLE invoice_items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,                 -- Which invoice
    description VARCHAR(255),                -- Item description
    item_type ENUM('Room', 'Service', 'Addon', 'Discount', 'Tax', 'Other'),
    quantity DECIMAL(10, 2),                 -- How many
    unit_price DECIMAL(10, 2),               -- Price per unit
    total_price DECIMAL(12, 2),              -- Quantity × unit_price
    notes TEXT,
    created_at TIMESTAMP
);
```

### Table: `payments`

**Purpose:** Record each payment transaction

```sql
CREATE TABLE payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,                 -- Which invoice
    booking_id INT NOT NULL,                 -- Which booking
    guest_id INT NOT NULL,                   -- Which guest
    payment_number VARCHAR(50) UNIQUE,       -- PAY-000001
    amount DECIMAL(12, 2),                   -- Payment amount
    payment_method ENUM('Cash', 'Credit Card', ...),
    reference_number VARCHAR(100),           -- TxID, cheque#, etc
    transaction_id VARCHAR(100),             -- Gateway transaction
    payment_date DATETIME,                   -- When paid
    received_by VARCHAR(100),                -- Staff member
    payment_status ENUM('Pending', 'Authorized', 'Processed', 'Failed', 'Refunded'),
    notes TEXT,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);
```

### Table: `payment_methods`

**Purpose:** Configuration for available payment methods

```sql
CREATE TABLE payment_methods (
    method_id INT AUTO_INCREMENT PRIMARY KEY,
    method_name VARCHAR(50) UNIQUE,          -- 'cash', 'credit_card', etc
    display_name VARCHAR(100),               -- 'Cash', 'Credit Card', etc
    description TEXT,
    is_active TINYINT DEFAULT 1,             -- Enabled/disabled
    is_default TINYINT DEFAULT 0,            -- Default method
    created_at TIMESTAMP
);
```

### Table: `billing_settings`

**Purpose:** Global billing configuration

```sql
CREATE TABLE billing_settings (
    setting_id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(50) UNIQUE,          -- 'tax_rate', 'invoice_prefix', etc
    setting_value VARCHAR(255),              -- The actual value
    setting_type ENUM('text', 'number', 'boolean', 'percentage'),
    description VARCHAR(255),
    updated_at TIMESTAMP
);
```

**Default Settings:**
```
tax_rate: 0 (percentage)
invoice_prefix: INV-
payment_prefix: PAY-
currency: INR
due_days: 7
company_name: Hotel Management System
```

### Table: `refunds`

**Purpose:** Track refund requests and processing

```sql
CREATE TABLE refunds (
    refund_id INT AUTO_INCREMENT PRIMARY KEY,
    payment_id INT,                          -- Refunding which payment
    invoice_id INT NOT NULL,                 -- For which invoice
    booking_id INT NOT NULL,                 -- For which booking
    guest_id INT NOT NULL,                   -- For which guest
    refund_number VARCHAR(50) UNIQUE,        -- REF-000001
    refund_amount DECIMAL(12, 2),            -- Amount to refund
    refund_reason VARCHAR(255),              -- Why refund?
    refund_date DATETIME,                    -- When requested
    refund_method ENUM('Cash', 'Credit Card', 'Bank Transfer', 'UPI', 'Other'),
    reference_number VARCHAR(100),           -- Reference for refund
    status ENUM('Pending', 'Processed', 'Failed', 'Completed'),
    approved_by VARCHAR(100),                -- Who approved
    notes TEXT,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);
```

---

## Model Structure

### Invoice Model (`Invoice.js`)

**Purpose:** Handle all invoice-related operations

**Key Methods:**

```javascript
// Generate new invoice from checked-out booking
static async generateFromBooking(bookingId) {
    // 1. Verify booking is checked out
    // 2. Get booking details with guest & room info
    // 3. Calculate room charges
    // 4. Get service order totals
    // 5. Calculate discounts and taxes
    // 6. Generate unique invoice number
    // 7. Create invoice record
    // 8. Add line items (room, services, discount, tax)
    // 9. Update booking status
    // Returns: { invoiceId, invoiceNumber, grandTotal, amountDue }
}

// Get invoice with items and payments
static async getDetails(invoiceId) {
    // 1. Get invoice record
    // 2. Get invoice items
    // 3. Get payment records
    // Returns: invoice object with items and payments arrays
}

// Update payment amounts on invoice
static async updatePaymentAmount(invoiceId) {
    // 1. Sum all processed payments
    // 2. Calculate amount due
    // 3. Determine invoice status (Paid/Partially_Paid/Generated)
    // 4. Update invoice with new amounts
}

// Get statistics
static async getStatistics(startDate, endDate) {
    // Returns: {
    //   total_invoices,
    //   total_revenue,
    //   total_collected,
    //   total_outstanding,
    //   paid_invoices,
    //   partially_paid_invoices,
    //   pending_invoices
    // }
}
```

### Payment Model (`Payment.js`)

**Purpose:** Handle all payment-related operations

**Key Methods:**

```javascript
// Create new payment record
static async create(paymentData) {
    // 1. Validate payment data
    // 2. Generate unique payment number
    // 3. Create payment record
    // 4. Update invoice payment amounts
    // 5. Update booking payment status
    // Returns: { paymentId, paymentNumber, amount }
}

// Get receipt data for printing
static async getReceiptData(paymentId) {
    // Joins payment with guest, invoice, booking, room info
    // Returns: complete receipt data
}

// Process refund
static async processRefund(paymentId, refundAmount, reason) {
    // 1. Validate payment exists
    // 2. Validate refund amount ≤ payment amount
    // 3. Create refund record
    // 4. Update invoice payment amounts
    // Returns: refund data
}
```

### Refund Model (`Refund.js`)

**Purpose:** Handle refund requests and processing

**Key Methods:**

```javascript
// Create refund request
static async create(refundData) {
    // 1. Generate unique refund number
    // 2. Create refund record with status 'Pending'
    // Returns: { refundId, refundNumber, amount }
}

// Approve refund
static async approveRefund(refundId, approvedBy) {
    // Updates refund status to 'Processed'
}

// Reject refund
static async rejectRefund(refundId, reason) {
    // Updates refund status to 'Failed'
}
```

---

## API Routes

### Invoice Routes (`/api/invoices`)

```javascript
// GET /api/invoices
// List all invoices with pagination
// Query: limit=100, offset=0
// Response: { success, data: [], count }

// GET /api/invoices/:id
// Get invoice with details
// Response: { success, data: { invoice_details, items[], payments[] } }

// GET /api/invoices/booking/:bookingId
// Get invoice for specific booking
// Response: { success, data: invoice_with_details }

// GET /api/invoices/guest/:guestId
// Get all invoices for guest
// Query: limit=50, offset=0
// Response: { success, data: [], count }

// GET /api/invoices/date-range/list
// Get invoices by date range
// Query: start=YYYY-MM-DD, end=YYYY-MM-DD
// Response: { success, data: [], count }

// GET /api/invoices/stats/range
// Get invoice statistics
// Query: start=YYYY-MM-DD, end=YYYY-MM-DD
// Response: { success, data: { total_invoices, total_revenue, ... } }

// POST /api/invoices/generate
// Generate invoice for booking
// Body: { booking_id }
// Response: { success, data: { invoiceId, invoiceNumber, grandTotal } }

// PUT /api/invoices/:id/status
// Update invoice status
// Body: { status: 'Paid'|'Partially_Paid'|'Generated'|... }
// Response: { success, message }

// PUT /api/invoices/:id/cancel
// Cancel invoice
// Body: { reason? }
// Response: { success, message }
```

### Payment Routes (`/api/payments`)

```javascript
// POST /api/payments
// Record new payment
// Body: {
//   invoice_id, booking_id, guest_id,
//   amount, payment_method, reference_number?,
//   transaction_id?, received_by?, notes?
// }
// Response: { success, data: { paymentId, paymentNumber, amount } }

// GET /api/payments/:id
// Get payment details
// Response: { success, data: { payment_details, invoice } }

// GET /api/payments/:id/receipt
// Get receipt data for printing
// Response: { success, data: { receipt_data } }

// GET /api/payments/invoice/:invoiceId
// Get all payments for invoice
// Response: { success, data: [], count }

// GET /api/payments/booking/:bookingId
// Get all payments for booking
// Response: { success, data: [], count }

// GET /api/payments/guest/:guestId
// Get all payments for guest
// Response: { success, data: [], count }

// GET /api/payments/methods/list
// Get available payment methods
// Response: { success, data: [] }

// POST /api/payments/:id/refund
// Process refund
// Body: { refund_amount, reason }
// Response: { success, data: { refundId, refundNumber, amount } }

// PUT /api/payments/:id/verify
// Verify payment status
// Response: { success, data: { paymentId, status, amount, method, date } }

// POST /api/payments/refunds
// Create refund
// Body: { invoice_id, booking_id, guest_id, refund_amount, reason, refund_method }
// Response: { success, data: { refundId, refundNumber, amount } }

// GET /api/payments/refunds/list
// Get all refunds

// GET /api/payments/refunds/:id
// Get refund details

// PUT /api/payments/refunds/:id/approve
// Approve refund
// Body: { approved_by }

// PUT /api/payments/refunds/:id/reject
// Reject refund
// Body: { reason? }
```

---

## Frontend Structure

### `js/billing.js` Structure

```javascript
// SECTION 1: Invoice Management (Lines 1-150)
// - generateInvoice()
// - getInvoiceDetails()
// - getInvoiceByBooking()
// - listInvoices()
// - printInvoice()
// - generateInvoicePrintHTML()

// SECTION 2: Payment Management (Lines 150-300)
// - recordPayment()
// - getPaymentDetails()
// - getInvoicePayments()
// - getPaymentMethods()
// - printPaymentReceipt()
// - generateReceiptHTML()

// SECTION 3: Refund Processing (Lines 300-350)
// - processRefund()

// SECTION 4: Billing Statistics (Lines 350-365)
// - getBillingStats()

// SECTION 5: Modal Management (Lines 365-410)
// - openPaymentModal()
// - closePaymentModal()
// - submitPaymentForm()
```

### `bookings.js` Integration Points

```javascript
// Updated displayBookings() function
// - Added billing action buttons for checked-out bookings
// - Actions: Generate Invoice, View Invoice, Record Payment

// New functions:
// - handleGenerateInvoice(bookingId)
// - handleViewInvoice(bookingId)
// - displayInvoiceModal(invoice)
// - handleRecordPayment(bookingId, guestId)
// - handleRecordPaymentForInvoice(invoiceId)
// - closeInvoiceModal()
```

### `guest-portal.js` Integration Points

```javascript
// Modified displayBookingInfo() function
// - Added call to loadGuestBillingInfo()

// New functions:
// - loadGuestBillingInfo(bookingId)
// - guestDownloadInvoice()
// - guestPrintInvoice()
```

---

## Data Flow Diagrams

### Invoice Generation Flow

```
Guest Checks Out
    ↓
Admin clicks "Generate Invoice"
    ↓
POST /api/invoices/generate {booking_id}
    ↓
Invoice.generateFromBooking()
    ├─ Get booking with guest & room
    ├─ Calculate room charges
    ├─ Get service totals
    ├─ Calculate discount & tax
    ├─ Generate invoice number
    ├─ Create invoice record
    ├─ Add invoice items
    └─ Update booking status
    ↓
Invoice Created ✓
    ↓
"View Invoice" available in admin
"Invoice" available in guest portal
```

### Payment Recording Flow

```
Admin clicks "Record Payment"
    ↓
Enter payment details
    ↓
POST /api/payments {invoice_id, amount, method...}
    ↓
Payment.create()
    ├─ Generate payment number
    ├─ Create payment record
    └─ Call Invoice.updatePaymentAmount()
    ↓
Invoice.updatePaymentAmount()
    ├─ Sum all processed payments
    ├─ Calculate amount due
    ├─ Determine invoice status
    └─ Update invoice
    ↓
Payment Recorded ✓
    ↓
Invoice status updated automatically
Receipt available for printing
```

### Refund Processing Flow

```
Admin clicks "Refund" on payment
    ↓
Enter refund amount & reason
    ↓
POST /api/payments/{id}/refund {refund_amount, reason}
    ↓
Payment.processRefund()
    ├─ Validate refund amount
    └─ Call Refund.create()
    ↓
Refund.create()
    ├─ Generate refund number
    └─ Create refund record (status: Pending)
    ↓
Admin approves refund
    ↓
PUT /api/payments/refunds/{id}/approve {approved_by}
    ↓
Refund.approveRefund()
    └─ Update status to 'Processed'
    ↓
Refund Completed ✓
```

---

## Error Handling

### Invoice Generation Errors

```javascript
// Booking not found
"Booking not found" (404)

// Booking not checked out
"Booking is not in CheckedOut status" (400)

// Invoice already exists
"Invoice already exists for this booking" (400)

// Database error
"Failed to generate invoice: [error message]" (500)
```

### Payment Recording Errors

```javascript
// Invalid amount
"Valid amount is required" (400)

// Required fields missing
"Valid [field] is required" (400)

// Invoice not found
"Invoice not found" (404)

// Amount exceeds invoice total
"Refund amount cannot exceed payment amount" (400)
```

---

## Performance Considerations

### Indexes
Database tables have indexes on:
- booking_id (invoices, payments)
- guest_id (invoices, payments)
- invoice_number (invoices, payments)
- payment_date (payments)
- refund_date (refunds)
- status fields (invoices, payments, refunds)

### Query Optimization
- Use pagination for lists (limit 100)
- Join with guests/rooms once rather than multiple times
- Use views for summary data
- Group payments by invoice before calculating totals

### Caching
- Guest invoice data cached in localStorage
- Payment methods cached in frontend (5-min refresh recommended)
- Billing settings cached on server startup

---

## Security Considerations

### Data Validation
- All IDs validated as integers
- Amounts validated as decimals
- Dates validated as YYYY-MM-DD format
- Payment methods validated against whitelist

### Authorization
- Invoices linked to bookings (verify ownership)
- Payments verified for invoice amount
- Refunds limited to payment amount
- All operations logged with user/timestamp

### Data Protection
- Sensitive payment methods validated
- Reference numbers sanitized
- Notes sanitized to prevent injection
- SQL prepared statements used throughout

---

## Future Extension Points

### 1. Email Integration
```javascript
// Send invoice to guest email
async function sendInvoiceEmail(invoiceId, guestEmail) {
    // Get invoice details
    // Generate PDF
    // Send via SMTP
}
```

### 2. Payment Gateway Integration
```javascript
// Process payment via Stripe/PayPal
async function processGatewayPayment(paymentData) {
    // Call payment gateway API
    // Record transaction ID
    // Update payment status
}
```

### 3. Custom Invoice Templates
```javascript
// Support multiple invoice templates
static async generateInvoice(bookingId, templateId = 'default') {
    // Load template
    // Generate based on template
    // Return PDF or HTML
}
```

### 4. Recurring/Subscription Charges
```javascript
// Support recurring charges
CREATE TABLE recurring_charges (
    charge_id INT,
    invoice_id INT,
    frequency ENUM('daily', 'weekly', 'monthly'),
    next_charge_date DATE
);
```

---

## Code Quality Metrics

- **Lines of Code:** 2000+
- **Functions:** 50+
- **Database Queries:** Optimized with indexes
- **Test Coverage:** Ready for unit tests
- **Documentation:** Complete with examples
- **Error Handling:** Comprehensive try-catch blocks

---

**Technical Reference Complete**

For implementation details, see: `PAYMENT_INVOICE_IMPLEMENTATION.md`  
For quick start, see: `PAYMENT_INVOICE_QUICK_START.md`
