# 🎯 Hotel Management System - API Reference

Base URL: `http://localhost:3000/api`

## 📋 Table of Contents
- [Rooms API](#rooms-api)
- [Guests API](#guests-api)
- [Bookings API](#bookings-api)
- [Response Format](#response-format)
- [Error Codes](#error-codes)

---

## 🛏️ Rooms API

### Get All Rooms
```http
GET /api/rooms
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "room_id": 1,
      "room_number": "101",
      "room_type": "Single",
      "price": 1500.00,
      "status": "Available",
      "description": "Cozy single room",
      "amenities": "WiFi, TV, AC"
    }
  ]
}
```

### Get Room by ID
```http
GET /api/rooms/:id
```

### Get Available Rooms
```http
GET /api/rooms/available/search?checkIn=2026-02-25&checkOut=2026-02-27
```

### Get Room Statistics
```http
GET /api/rooms/stats/overview
```

**Response:**
```json
{
  "success": true,
  "data": {
    "total_rooms": 7,
    "available_rooms": 5,
    "booked_rooms": 1,
    "maintenance_rooms": 1
  }
}
```

### Create New Room
```http
POST /api/rooms
Content-Type: application/json

{
  "room_number": "105",
  "room_type": "Suite",
  "price": 5000.00,
  "status": "Available",
  "description": "Luxury suite",
  "amenities": "WiFi, TV, AC, Jacuzzi"
}
```

### Update Room
```http
PUT /api/rooms/:id
Content-Type: application/json

{
  "room_number": "105",
  "room_type": "Suite",
  "price": 5500.00,
  "status": "Available",
  "description": "Updated description",
  "amenities": "WiFi, TV, AC, Jacuzzi, Mini-bar"
}
```

### Update Room Status
```http
PATCH /api/rooms/:id/status
Content-Type: application/json

{
  "status": "Maintenance"
}
```

### Delete Room
```http
DELETE /api/rooms/:id
```

---

## 👥 Guests API

### Get All Guests
```http
GET /api/guests
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "guest_id": 1,
      "name": "John Doe",
      "phone": "9876543210",
      "email": "john@example.com",
      "id_proof": "AADHAR123456",
      "address": "123 Main St",
      "created_at": "2026-02-24T10:30:00.000Z"
    }
  ]
}
```

### Get Guest by ID
```http
GET /api/guests/:id
```

### Search Guests
```http
GET /api/guests/search/contact?q=john
```

### Get Guest Booking History
```http
GET /api/guests/:id/history
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "booking_id": 1,
      "room_number": "101",
      "room_type": "Single",
      "check_in": "2026-02-25",
      "check_out": "2026-02-27",
      "total_amount": 3540.00,
      "booking_status": "Confirmed"
    }
  ]
}
```

### Create New Guest
```http
POST /api/guests
Content-Type: application/json

{
  "name": "Jane Smith",
  "phone": "9876543211",
  "email": "jane@example.com",
  "id_proof": "PAN12345",
  "address": "456 Oak Ave"
}
```

### Update Guest
```http
PUT /api/guests/:id
Content-Type: application/json

{
  "name": "Jane Smith Updated",
  "phone": "9876543211",
  "email": "jane.new@example.com",
  "id_proof": "PAN12345",
  "address": "456 Oak Ave, Apt 2"
}
```

### Delete Guest
```http
DELETE /api/guests/:id
```

---

## 📅 Bookings API

### Get All Bookings
```http
GET /api/bookings
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "booking_id": 1,
      "guest_name": "John Doe",
      "guest_phone": "9876543210",
      "guest_email": "john@example.com",
      "room_number": "101",
      "room_type": "Single",
      "check_in": "2026-02-25",
      "check_out": "2026-02-27",
      "total_amount": 3540.00,
      "payment_status": "Paid",
      "booking_status": "Confirmed"
    }
  ]
}
```

### Get Booking by ID
```http
GET /api/bookings/:id
```

### Get Active Bookings
```http
GET /api/bookings/active/list
```

### Get Today's Check-ins
```http
GET /api/bookings/today/checkins
```

### Get Today's Check-outs
```http
GET /api/bookings/today/checkouts
```

### Get Dashboard Statistics
```http
GET /api/bookings/stats/dashboard
```

**Response:**
```json
{
  "success": true,
  "data": {
    "confirmed_bookings": 5,
    "checked_in": 3,
    "today_checkins": 2,
    "today_checkouts": 1,
    "today_revenue": 5000.00,
    "available_rooms": 4
  }
}
```

### Get Revenue Statistics
```http
GET /api/bookings/stats/revenue?startDate=2026-02-01&endDate=2026-02-28
```

**Response:**
```json
{
  "success": true,
  "data": {
    "total_bookings": 15,
    "total_revenue": 45000.00,
    "collected_amount": 40000.00,
    "pending_amount": 5000.00,
    "average_booking_value": 3000.00
  }
}
```

### Create New Booking
```http
POST /api/bookings
Content-Type: application/json

{
  "guest_id": 1,
  "room_id": 1,
  "check_in": "2026-02-25",
  "check_out": "2026-02-27",
  "total_amount": 3540.00,
  "advance_payment": 1000.00,
  "payment_method": "UPI",
  "special_requests": "Early check-in if possible"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Booking created successfully",
  "bookingId": 5
}
```

### Update Booking
```http
PUT /api/bookings/:id
Content-Type: application/json

{
  "check_in": "2026-02-26",
  "check_out": "2026-02-28",
  "total_amount": 3540.00,
  "advance_payment": 2000.00,
  "payment_method": "Card",
  "special_requests": "Late check-out needed"
}
```

### Check-in
```http
PATCH /api/bookings/:id/checkin
```

**Response:**
```json
{
  "success": true,
  "message": "Check-in successful"
}
```

### Check-out
```http
PATCH /api/bookings/:id/checkout
```

**Response:**
```json
{
  "success": true,
  "message": "Check-out successful"
}
```

### Cancel Booking
```http
PATCH /api/bookings/:id/cancel
```

### Update Payment
```http
PATCH /api/bookings/:id/payment
Content-Type: application/json

{
  "advance_payment": 3540.00,
  "payment_method": "Cash"
}
```

### Extend Booking
```http
POST /api/bookings/:id/extend
Content-Type: application/json

{
  "new_check_out": "2026-03-15",
  "resolution_type": "same_room"
}
```

### Check Extension Availability
```http
GET /api/bookings/:id/can-extend?new_check_out=2026-03-15
```

---

## 🔄 Room Transfer & Booking Modifications

### Transfer Guest to Different Room
```http
POST /api/bookings/:id/transfer-room
Content-Type: application/json

{
  "new_room_id": 15,
  "reason": "Guest complained about noise - transferred to quieter floor",
  "price_difference": 50.00
}
```

**Response:**
```json
{
  "success": true,
  "message": "Guest successfully transferred from Room 101 to Room 205",
  "data": {
    "booking_id": 123,
    "old_room": {
      "room_id": 10,
      "room_number": "101",
      "price": 100.00
    },
    "new_room": {
      "room_id": 15,
      "room_number": "205",
      "price": 150.00
    },
    "price_adjustment": 50.00,
    "new_total_amount": 750.00,
    "reason": "Guest complained about noise",
    "transfer_date": "2026-03-05T10:30:00.000Z"
  }
}
```

### Modify Booking Dates
```http
PUT /api/bookings/:id/modify-dates
Content-Type: application/json

{
  "new_check_in": "2026-03-10",
  "new_check_out": "2026-03-15"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Booking dates modified successfully",
  "data": {
    "booking_id": 123,
    "old_dates": {
      "check_in": "2026-03-08",
      "check_out": "2026-03-12",
      "nights": 4
    },
    "new_dates": {
      "check_in": "2026-03-10",
      "check_out": "2026-03-15",
      "nights": 5
    },
    "old_amount": 400.00,
    "new_amount": 500.00,
    "price_difference": 100.00
  }
}
```

### Check Room Availability (Detailed)
```http
GET /api/bookings/availability/detailed?room_id=5&check_in=2026-03-10&check_out=2026-03-15&exclude_booking_id=123
```

**Response with Conflicts:**
```json
{
  "success": true,
  "data": {
    "available": false,
    "reason": "Room has conflicting bookings",
    "room": {
      "room_id": 5,
      "room_number": "105",
      "room_type": "Deluxe",
      "price": 150.00,
      "status": "Booked"
    },
    "conflicts": [
      {
        "booking_id": 456,
        "guest_name": "John Smith",
        "guest_phone": "+1234567890",
        "check_in": "2026-03-09",
        "check_out": "2026-03-12",
        "booking_status": "CheckedIn",
        "overlap_days": 2
      }
    ]
  }
}
```

### Get Alternative Rooms
```http
GET /api/bookings/alternatives/rooms?check_in=2026-03-10&check_out=2026-03-15&number_of_guests=2&preferred_type=Deluxe
```

**Response:**
```json
{
  "success": true,
  "count": 3,
  "data": [
    {
      "room_id": 12,
      "room_number": "201",
      "room_type": "Deluxe",
      "price": 150.00,
      "max_guests": 2,
      "amenities": "AC, WiFi, TV, Mini Bar",
      "total_cost_for_period": 750.00,
      "nights": 5,
      "conflicting_bookings": 0
    }
  ]
}
```

### Get Booking Modification Options
```http
GET /api/bookings/:id/modification-options?new_check_in=2026-03-10&new_check_out=2026-03-15
```

**Response:**
```json
{
  "success": true,
  "data": {
    "booking": {
      "booking_id": 123,
      "current_room": "105",
      "current_dates": {
        "check_in": "2026-03-08",
        "check_out": "2026-03-12"
      },
      "requested_dates": {
        "check_in": "2026-03-10",
        "check_out": "2026-03-15"
      }
    },
    "current_room_available": false,
    "alternative_rooms": [...],
    "recommendations": {
      "can_keep_same_room": false,
      "should_transfer": true,
      "no_options_available": false
    }
  }
}
```

---

## 📦 Response Format

### Success Response
```json
{
  "success": true,
  "data": { },
  "message": "Operation successful"
}
```

### Error Response
```json
{
  "success": false,
  "message": "Error description"
}
```

---

## ⚠️ Error Codes

| Status Code | Description |
|-------------|-------------|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request |
| 404 | Not Found |
| 500 | Internal Server Error |

---

## 💡 Usage Examples

### Example 1: Complete Booking Flow

```javascript
// 1. Create guest
const guestResponse = await fetch('http://localhost:3000/api/guests', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: 'John Doe',
    phone: '9876543210',
    email: 'john@example.com',
    id_proof: 'AADHAR123456',
    address: '123 Main St'
  })
});
const guest = await guestResponse.json();

// 2. Check available rooms
const roomsResponse = await fetch(
  'http://localhost:3000/api/rooms/available/search?checkIn=2026-02-25&checkOut=2026-02-27'
);
const rooms = await roomsResponse.json();

// 3. Create booking
const bookingResponse = await fetch('http://localhost:3000/api/bookings', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    guest_id: guest.guestId,
    room_id: rooms.data[0].room_id,
    check_in: '2026-02-25',
    check_out: '2026-02-27',
    total_amount: 3540.00,
    advance_payment: 1000.00,
    payment_method: 'UPI'
  })
});
```

### Example 2: Get Daily Report

```javascript
// Get today's statistics
const dashboard = await fetch('http://localhost:3000/api/bookings/stats/dashboard');
const stats = await dashboard.json();

console.log(`Today's Check-ins: ${stats.data.today_checkins}`);
console.log(`Today's Revenue: ₹${stats.data.today_revenue}`);
console.log(`Available Rooms: ${stats.data.available_rooms}`);
```

---

## 🔐 Notes

- All endpoints return JSON
- Content-Type: application/json for POST/PUT/PATCH requests
- No authentication required (add in production)
- CORS enabled for all origins
- Database transactions used for booking operations
- Row-level locking prevents overbooking in concurrent scenarios

---

**Last Updated:** March 5, 2026

**Recent Updates:**
- ✅ Added Room Transfer functionality (`/api/bookings/:id/transfer-room`)
- ✅ Added Booking Date Modification (`/api/bookings/:id/modify-dates`)
- ✅ Enhanced Room Availability checking with conflict details (`/api/bookings/availability/detailed`)
- ✅ Added Alternative Rooms suggestions (`/api/bookings/alternatives/rooms`)
- ✅ Improved Overbooking Protection with transaction-based locking

📘 For detailed documentation on new features, see [BOOKING_ENHANCEMENTS.md](BOOKING_ENHANCEMENTS.md)

