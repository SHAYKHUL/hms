# Booking Extension & Conflict Resolution Guide

## Scenario Overview

**Situation:**
- Customer A: Room X booked for dates 1-3
- Customer B: Room X booked for dates 4-6
- Date 4 is available between bookings
- Customer A wants to extend their stay on Night 2 (wants more nights)

## Problem Statement

When a customer requests to extend their booking, the system must handle:
1. **Conflict Detection** - Check if the new dates conflict with existing bookings
2. **Customer Communication** - Inform customer about availability issues
3. **Alternative Solutions** - Offer options to resolve the conflict

## Solution Strategies

### Strategy 1: Reject & Suggest Alternatives
If Customer A's new dates (1-5) conflict with Customer B's booking (4-6):

**Option A: Offer Alternative Rooms**
- Check for available rooms for dates 4-5
- Show Customer A available rooms they can book for the extension period
- Create a separate booking for the extension OR move them to the alternative room

**Option B: Offer Alternative Dates**
- Show Customer A when their current room becomes available
- Room X becomes free after Customer B checks out (after date 6)
- Offer to extend starting from date 7 onward

**Option C: Cancel & Rebook**
- Cancel Customer A's original booking
- Book them in a better room for the longer period (1-5)
- Offer incentives (discount, upgrade) for the inconvenience

### Strategy 2: Modify Other Booking
If business rules allow and customer consent obtained:
- Contact Customer B to see if they can shift to different dates
- Offer incentives for date change
- This is complex and requires manual intervention

### Strategy 3: Split Booking
- Keep current booking (1-3) as is
- Create a new booking for the extension period (4-5) on a different room
- Offer seamless experience by marking both bookings as "linked"

## System Handling Steps

### Step 1: Detect Extension Request
```
Customer A requests extension from check_out: 2025-01-03 to new_check_out: 2025-01-05
```

### Step 2: Check for Conflicts
```
Query: SELECT bookings WHERE room_id = X 
       AND booking_status IN ('Confirmed', 'CheckedIn')
       AND check_in < 2025-01-05 AND check_out > 2025-01-03

Result: Customer B's booking (4-6) CONFLICTS with dates 4-5
```

### Step 3: Generate Alternatives
```
A. Alternative Rooms for dates 4-5:
   - Room Y (Double): Available ✓
   - Room Z (Suite): Available ✓

B. Alternative Dates for Room X:
   - Room X available from 2025-01-07 onwards
   - Customer can extend to 2025-01-07 or later

C. Room Upgrade:
   - Customer B's booking ends on date 6
   - Offer Customer A upgrade to Suite for dates 4-6 on different room
```

### Step 4: Customer Decision
Present options to Customer A:
```
❌ Cannot extend in current room (dates 4-5 occupied)

✅ Option 1: Book Alternative Room
   - Get Room Y from Jan 4-5 (2 nights) @ $X
   - Pay difference: $Y
   - Status: Linked bookings

✅ Option 2: Wait for Room X
   - Extend stay from Jan 7-9
   - Same room, same price
   - Current checkout: Jan 3, New checkout: Jan 9

✅ Option 3: Upgrade Offer
   - Move to Suite, dates 1-9 (8 nights total)
   - Upgrade discount: 15% off
   - Total: $Z
```

## API Endpoints to Add

### 1. Check Availability & Get Alternatives
```
GET /api/bookings/:id/extension-options
Query: ?new_check_out=2025-01-05

Response:
{
  "canExtend": false,
  "conflictingBooking": {...},
  "alternatives": [
    {
      "type": "alternative_room",
      "room_id": 5,
      "dates": "2025-01-04 to 2025-01-05",
      "price": 150,
      "room_details": {...}
    },
    {
      "type": "alternative_dates",
      "dates": "2025-01-07 to 2025-01-09",
      "price": 200
    }
  ]
}
```

### 2. Extend With Conflict Resolution
```
POST /api/bookings/:id/extend
Body:
{
  "resolution_type": "alternative_room|alternative_dates|upgrade",
  "new_check_out": "2025-01-05",
  "resolution_details": {...}
}

Response:
{
  "success": true,
  "originalBooking": {...},
  "extensions": [
    { booking_id: 1, dates: "1-3" },
    { booking_id: 2, dates: "4-5" }
  ],
  "totalCharges": {...}
}
```

## Database Considerations

### Linked Bookings
Add to bookings table if needed:
```sql
ALTER TABLE bookings ADD COLUMN linked_booking_id INT;
ALTER TABLE bookings ADD COLUMN is_extension BOOLEAN DEFAULT FALSE;
```

### Track Extension History
```sql
CREATE TABLE booking_extensions (
  extension_id INT PRIMARY KEY AUTO_INCREMENT,
  original_booking_id INT,
  new_booking_id INT,
  requested_dates DATE,
  resolution_type VARCHAR(50),
  status VARCHAR(20),
  created_at TIMESTAMP
);
```

## Frontend Implementation

### Extension Request Form
- Show current booking details
- Input field for new check-out date
- "Check Availability" button
- Display alternatives in modal/card format
- Allow customer to choose resolution option

### Confirmation Screen
- Show all affected bookings
- Display payment summary
- Show any discounts applied
- Require customer confirmation

## Business Rules

1. **Confirmation Status Only**: Only "Confirmed" bookings can be extended
2. **Notice Period**: Minimum X hours notice recommended
3. **Cancellation Window**: If conflict found, customer has X hours to decide
4. **Linked Bookings**: Show as single stay in guest portal
5. **Pricing**: Pro-rata pricing for additional nights
6. **Discounts**: Can offer discounts for inconvenience of extension

## Exception Handling

### Exception 1: Room fully booked
- Show all available alternative rooms
- Show when original room becomes available

### Exception 2: No rooms available for extension dates
- Offer future dates on same room
- Offer waitlist option

### Exception 3: Customer refuses all options
- Confirm original booking stands
- Document refusal
- Suggest contacting support for special requests

## Implementation Priority

**Phase 1 (Essential):**
- Conflict detection in update booking
- Simple rejection with "room unavailable" message
- Show when room next becomes available

**Phase 2 (Important):**
- Get alternative rooms endpoint
- Show alternatives in UI
- Allow booking alternative room

**Phase 3 (Nice to have):**
- Automatic recommendations
- Discount calculations
- Linked booking display
- Extension history tracking

## Testing Scenarios

1. ✅ Extend within available slot (before next booking)
2. ✅ Extend into conflicting booking
3. ✅ Extend beyond all future bookings
4. ✅ Extend to date that conflicts with multiple bookings
5. ✅ Cancel extension request
6. ✅ Select alternative room
7. ✅ Select alternative dates
8. ✅ Multiple extensions on same booking
