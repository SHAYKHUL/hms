# Booking Extension Decision Flow Diagram

## System Decision Flow

```
START: Extension Request
├─ Booking ID: A's booking
├─ Current dates: Jan 1-3
├─ New checkout: Jan 5
└─ Room: 101
        ↓
QUERY DATABASE
├─ Find all bookings for Room 101
├─ Date range: Jan 3 - Jan 5
├─ Status: Confirmed OR CheckedIn
└─ Found: Booking B (Jan 4-6)
        ↓
CONFLICT DETECTED ✗
├─ Booking A: Jan 1-3
├─ Booking B: Jan 4-6 (CONFLICT)
└─ Extension request: Jan 1-5
        ↓
FIND ALTERNATIVES
├─ Alternative 1: Find available rooms for Jan 4-5
│  └─ Query: Rooms NOT booked on Jan 4-5
│     ├─ Room 102 (Double): ✓ Available
│     ├─ Room 103 (Suite): ✓ Available
│     └─ Room 201 (Deluxe): ✓ Available
│
└─ Alternative 2: Find when Room 101 becomes free
   └─ Query: Next checkout after Jan 3 for Room 101
      └─ Room 101 available from Jan 7 (after B checks out)
        ↓
DISPLAY OPTIONS TO MANAGER
├─ ✗ Cannot extend in Room 101 (booked Jan 4-6)
├─ 
├─ ✓ OPTION 1: Alternative Rooms
│  ├─ Room 102 (Double) - Jan 4-5
│  ├─ Price per night: ₹1,500
│  ├─ Additional cost: ₹3,000
│  └─ [BUTTON: Book Room 102]
│
├─ Room 103 (Suite) - Jan 4-5
│  ├─ Price per night: ₹2,500
│  ├─ Additional cost: ₹5,000
│  └─ [BUTTON: Book Room 103]
│
└─ ✓ OPTION 2: Same Room, Different Dates
   ├─ Room 101 available from: Jan 7
   ├─ New checkout: Jan 7 (instead of Jan 5)
   ├─ Wait period: 4 extra days
   ├─ Additional cost: ₹4,000 (2 nights @ ₹2,000)
   └─ [BUTTON: Extend to Jan 7]
        ↓
MANAGER SELECTS: Option 1 - Book Room 102
        ↓
VALIDATION
├─ Check room still available
├─ Check booking status is Confirmed
├─ Calculate new amount
└─ Prepare transaction
        ↓
CREATE LINKED BOOKINGS
├─ Update Booking A
│  └─ Booking_ID: 1, Room 101, Jan 1-3 ✓
│
└─ Create Booking B
   ├─ Booking_ID: 2
   ├─ Room: 102
   ├─ Check-in: Jan 4
   ├─ Check-out: Jan 5
   ├─ is_extension: TRUE
   ├─ parent_booking_id: 1
   ├─ status: Confirmed
   └─ Additional amount: ₹3,000
        ↓
PAYMENT PROCESSING
├─ Original booking total: ₹4,000 (paid)
├─ Extension charge: ₹3,000 (new)
├─ Total cost: ₹7,000
└─ Additional payment due: ₹3,000
        ↓
SUCCESS ✓
├─ System confirmation
├─ Email sent to Customer A
├─ Updated folio
├─ Housekeeping notified
└─ END
```

## Conflict Detection Algorithm

```
FUNCTION checkBookingConflict(room_id, check_in, check_out):
    
    conflicts = DATABASE.query(
        SELECT * FROM bookings 
        WHERE room_id = room_id 
          AND status IN ('Confirmed', 'CheckedIn')
          AND check_in < check_out      // Other's start before my end
          AND check_out > check_in      // Other's end after my start
    )
    
    IF conflicts.count > 0:
        RETURN "Conflict detected"
    ELSE:
        RETURN "No conflict"
END

// Example:
checkBookingConflict(101, '2025-01-04', '2025-01-05')

In Database:
  Booking B: room=101, check_in=2025-01-04, check_out=2025-01-06
  
Condition check:
  2025-01-04 < 2025-01-05  ✓ TRUE   (B starts before extension ends)
  2025-01-06 > 2025-01-04  ✓ TRUE   (B ends after extension starts)
  
Result: CONFLICT FOUND
```

## State Machine: Booking Lifecycle with Extensions

```
PENDING
   ↓ (if not confirmed)
CANCELLED

CONFIRMED
   ├─ [Check-in] → CHECKED_IN
   ├─ [Cancel] → CANCELLED
   └─ [Extend] → EXTENSION_REQUEST
              ├─ (Option 1) → SAME_ROOM_EXTENDED (stays CONFIRMED)
              ├─ (Option 2) → ALTERNATIVE_ROOM_BOOKED
              │             └─ Creates new CONFIRMED booking
              │             └─ Links to parent
              └─ (Option 3) → ALTERNATIVE_DATES_APPROVED
                             └─ Updates dates, stays CONFIRMED

CHECKED_IN
   ├─ [Check-out] → CHECKED_OUT
   └─ [Cancel] → CANCELLED

CHECKED_OUT
   └─ [Complete] → CLOSED
```

## Timeline Visualization

### Scenario: Customer A Extended with Alternative Room

```
ROOM 101 (Original)
Jan  1  2  3  4  5  6  7
     |--A--|  |----B----|
        ↓ Extension request for Jan 5
        (Would overlap with B on Jan 4)

ROOM 102 (Alternative)
Jan  1  2  3  4  5  6  7
              |A-ext|
              
RESOLUTION:
- Booking A: Jan 1-3 in Room 101 ✓
- Booking A*: Jan 4-5 in Room 102 ✓ (linked, marked as extension)
- Booking B: Jan 4-6 in Room 101 ✓ (unchanged)
- RESULT: No conflict, all bookings confirmed
```

### Scenario: Customer A Extended with Alternative Dates

```
ROOM 101 (Same Room, Different Dates)
Jan  1  2  3  4  5  6  7
     |--A--|  |----B----|
        ↓ Extension request for Jan 5
        (Would overlap with B on Jan 4)

AFTER EXTENSION APPROVAL:
Jan  1  2  3  4  5  6  7
     |--------A--------|  |
                       |--B--|
                       
RESOLUTION:
- Booking A: Jan 1-7 in Room 101 ✓ (extended past B)
- Booking B: Jan 4-6 in Room 101 ✗ CONFLICT NOW!
  
WAIT - This won't work. Alternative is to extend AFTER B:

BETTER OPTION:
Jan  1  2  3  4  5  6  7  8  9
     |--A--|  |----B----|  |A++|

- Booking A: Jan 1-3 → Jan 1-9 ✓ (but non-continuous in same room)
          
OR offer customer to wait:
- Booking A remains: Jan 1-3
- Guest checks out on Jan 3
- Guest checks back in Jan 7
- New stay: Jan 7-9 in same room

SYSTEM SHOWS: "Room available from Jan 7 if you can shift dates"
```

## API Response Examples

### Example 1: No Conflict Response

```json
{
  "canExtend": true,
  "currentBooking": {
    "booking_id": 1,
    "check_in": "2025-01-01",
    "check_out": "2025-01-03",
    "room_id": 101,
    "room_number": "101",
    "room_price": 2000
  },
  "extensionRequest": {
    "new_check_out": "2025-01-05",
    "nights_requested": 2
  },
  "conflict": null,
  "message": "Room is available for extension",
  "alternatives": {
    "alternative_rooms": [],
    "alternative_dates": []
  }
}
```

### Example 2: Conflict with Alternatives Response

```json
{
  "canExtend": false,
  "currentBooking": {
    "booking_id": 1,
    "check_in": "2025-01-01",
    "check_out": "2025-01-03",
    "room_id": 101,
    "room_number": "101",
    "room_price": 2000
  },
  "extensionRequest": {
    "new_check_out": "2025-01-05",
    "nights_requested": 2
  },
  "conflict": {
    "conflicting_booking_id": 2,
    "conflicting_dates": {
      "from": "2025-01-04",
      "to": "2025-01-06"
    },
    "message": "Room is booked from 2025-01-04 to 2025-01-06"
  },
  "alternatives": {
    "alternative_rooms": [
      {
        "room_id": 102,
        "room_number": "102",
        "room_type": "Double",
        "price": 1500,
        "max_guests": 2,
        "amenities": "AC, WiFi, TV",
        "extension_cost": 3000
      },
      {
        "room_id": 103,
        "room_number": "103",
        "room_type": "Suite",
        "price": 2500,
        "max_guests": 3,
        "amenities": "AC, WiFi, TV, Jacuzzi",
        "extension_cost": 5000
      }
    ],
    "alternative_dates": {
      "available_from": "2025-01-07",
      "extension_cost": 4000,
      "wait_period_days": 4
    }
  }
}
```

## Processing Flow (Backend)

```
POST /api/bookings/1/extend
├─ Validate booking exists and is Confirmed
├─ Validate new_check_out date
├─ Parse resolution_type
│
├─ IF resolution_type = 'same_room':
│  ├─ Calculate additional cost
│  ├─ Update original booking
│  │  └─ SET check_out = new_check_out
│  │  └─ SET total_amount = old_total + additional_cost
│  └─ Return updated booking
│
├─ IF resolution_type = 'alternative_room':
│  ├─ Validate alternative room exists and is available
│  ├─ Calculate cost for alternative room and dates
│  ├─ Create NEW booking (linked to original)
│  │  ├─ SET guest_id = original_guest
│  │  ├─ SET room_id = alternative_room
│  │  ├─ SET check_in = original_check_out
│  │  ├─ SET check_out = new_check_out
│  │  ├─ SET is_extension = TRUE
│  │  ├─ SET parent_booking_id = 1
│  │  └─ SET status = Confirmed
│  └─ Return {original_booking: {...}, extension_booking: {...}}
│
└─ IF resolution_type = 'alternative_dates':
   ├─ Query when room becomes available
   ├─ Calculate cost based on actual available dates
   ├─ Update original booking with available dates
   │  └─ SET check_out = available_from (next booking's check_out)
   └─ Return updated booking with note
```

---

**Visual Guide Created:** February 24, 2026
**Format:** Markdown with ASCII diagrams and JSON examples
