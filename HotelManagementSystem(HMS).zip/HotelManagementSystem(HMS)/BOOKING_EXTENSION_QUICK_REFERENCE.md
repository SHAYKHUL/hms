# Quick Reference: Booking Extension Conflict Resolution

## The Problem
**Scenario:** Customer A books Room X for dates 1-3. Customer B books same Room X for dates 4-6. On date 2, Customer A wants to extend their stay to date 5.

**Issue:** Extension dates 4-5 conflict with Customer B's booking 4-6.

---

## The Solution

### How It Works

1. **Manager clicks "Extend Stay"** on Customer A's booking
2. **System detects conflict** with Customer B's booking
3. **System suggests alternatives:**
   - Book a different room for dates 4-5
   - Wait and extend to date 7+ when Room X is free
4. **Customer chooses option**
5. **System processes the choice** - either creates linked booking or extends dates

---

## Conflict Resolution Options

### Option 1: Same Room (No Conflict Case)
```
Room available for extension → Direct extend
Cost: Additional nights × room price
Status: Single booking, extended dates
```

### Option 2: Alternative Room
```
Original room conflicts → Book different room for extension period
Creates 2 linked bookings:
  - Booking 1: Room X, dates 1-3
  - Booking 2: Room Y, dates 4-5 (marked as extension)
Cost: Different room's nightly rate × extension nights
Guest sees: One continuous stay, room change on date 4
```

### Option 3: Alternative Dates
```
Original room conflicts → Extend to when room becomes free
Updates original booking:
  - New checkout: date 7 or later
  - Wait period: dates 4-7 skip
Cost: Additional nights × original room price
Guest sees: Same room, longer stay (may have gap)
```

---

## System Workflow

### Backend (What Happens Automatically)

```
Extension Request
    ↓
Check for conflicts (query bookings for same room + date range)
    ↓
Found conflict?
    ├─ YES → Get alternatives
    │   ├─ Available rooms for extension period
    │   └─ Next available date for same room
    │
    └─ NO → Allow direct extension
          → Recalculate costs
          → Update booking
```

### Frontend (What Manager Sees)

```
Bookings List
    ↓
Find Customer A's booking → Click "Extend Stay" button
    ↓
Extension Modal Opens:
    - Show current room & checkout date
    - Input new checkout date
    - Click "Check Available Options"
    ↓
If conflict:
    Display 2-3 option buttons:
    ✓ Option 1: Book Room Y for dates 4-5
    ✓ Option 2: Extend to date 7 in same room
    ✓ Option 3: Talk to support
    ↓
Manager selects option → System processes → Confirmation
```

---

## API Endpoints Added

| Method | Endpoint | Purpose | Example |
|--------|----------|---------|---------|
| GET | `/api/bookings/:id/extension-options` | Check available options | `?new_check_out=2025-01-05` |
| POST | `/api/bookings/:id/extend` | Process extension | Body: `{resolution_type: 'alternative_room'}` |
| GET | `/api/bookings/:id/can-extend` | Quick validation | `?new_check_out=2025-01-05` |

---

## Database Changes

### New Columns in `bookings` table
```sql
is_extension        BOOLEAN         -- Mark extension bookings
parent_booking_id   INT            -- Link to original booking
```

### New Table
```sql
booking_extension_history
├─ extension_id
├─ original_booking_id
├─ new_booking_id
├─ resolution_type     -- 'same_room' | 'alternative_room' | 'alternative_dates'
├─ additional_cost
└─ status              -- 'Pending' | 'Approved' | 'Rejected'
```

---

## Example Scenarios

### Scenario 1: No Conflict ✓
```
Room 101: A (Jan 1-3), B (Jan 5-7) → Gap on Jan 4
Request: A extends to Jan 4
Result:  ✓ Approve direct extension
```

### Scenario 2: Conflict with Next Booking ✗
```
Room 101: A (Jan 1-3), B (Jan 4-6)
Request: A extends to Jan 5
Result:  ✗ CONFLICT
Options:
  1. Room 102 for Jan 4-5 (+₹1000)
  2. Extend Jan 1-7 in Room 101 (wait until B checks out)
```

### Scenario 3: Conflict with Multiple ✗
```
Room 101: A (1-3), B (4-6), C (7-9)
Request: A extends to Jan 7
Result:  ✗ MULTIPLE CONFLICTS
Options:
  1. Room 102 for Jan 4-7
  2. Room 103 for Jan 4-7
  3. Contact support
```

---

## Business Rules

✓ Only "Confirmed" bookings can be extended
✓ Must have valid future checkout date
✓ System checks against "Confirmed" and "CheckedIn" bookings only
✓ Cancelled bookings don't block extensions
✓ Payment adjusted automatically
✓ Discounts can be applied for inconvenience

---

## Common Workflows

### For Hotel Manager

1. **Review pending extension requests**
   - Go to Bookings page
   - Find booking with "Extend Stay" button
   - Click button

2. **Check availability**
   - Select new checkout date
   - Click "Check Available Options"
   - Review alternatives

3. **Approve extension**
   - Click appropriate option button
   - Confirm in popup
   - System updates booking

4. **Inform customer**
   - Email confirmation of new dates/room
   - Adjust if room upgrade offered
   - Update folio with additional charges

### For Guest (Self-Service Portal - Future)

1. Request extension through guest portal
2. System shows available options
3. Guest approves choice
4. System auto-confirms (if room available)
5. Guest receives updated booking

---

## Troubleshooting

| Issue | Cause | Fix |
|-------|-------|-----|
| "Room not available" shown | Conflict exists | Check what's booked next |
| No alternatives | All rooms booked | Offer discount on alternative dates |
| Extension doesn't save | Booking not Confirmed | Check booking status first |
| Wrong date shown | System error | Refresh page and retry |

---

## Notes for Implementation

### Migration Required
Run SQL migration before using:
```bash
mysql -u user -p DATABASE < database/booking_extension_migration.sql
```

### UI Location
Extension button appears in bookings table:
```
[View] [Check-in] [Extend] [Cancel]
```

### Payment Flow
```
Calculate additional cost = (new_checkout - current_checkout) × room_price
Update total_amount in booking
Process payment for difference
```

---

**Ready to use!** ✓ All components implemented and tested.
**Last updated:** February 24, 2026
