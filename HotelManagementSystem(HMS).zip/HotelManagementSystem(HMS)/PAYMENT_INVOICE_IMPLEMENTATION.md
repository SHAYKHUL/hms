# Payment and Invoice Final Billing System - Implementation Guide

**Last Updated:** February 26, 2026  
**Version:** 1.0  
**Status:** Implementation Complete

---

## Overview

A complete payment and invoice management system has been implemented for the Hotel Management System (HMS). This system enables:

- **Invoice Generation** from booking checkout
- **Payment Recording** with multiple payment methods
- **Refund Processing** for guest refunds
- **Guest Portal Access** to view invoices and billing
- **Automated Billing** calculations with tax and discounts
- **Payment Receipts** printing and tracking
- **Comprehensive Reporting** on billing and payments

---

## Database Schema Updates

### New Tables Created

1. **invoices**
   - Stores invoice records for each checked-out booking
   - Tracks invoice status, amounts, and payment information
   - Links between bookings, guests, and payment records

2. **invoice_items**
   - Breakdown of charges on each invoice
   - Supports room charges, services, discounts, taxes
   - Detailed line-item information

3. **payments**
   - Records each payment transaction
   - Multiple payment methods supported
   - Links to invoice and booking for tracking
   - Payment status and reference tracking

4. **payment_methods**
   - Configuration table for available payment methods
   - Includes: Cash, Credit Card, Debit Card, UPI, Net Banking, Cheque

5. **billing_settings**
   - Global billing configuration
   - Tax rates, invoice prefixes, payment terms
   - Company information for invoices
   - Currency and rounding settings

6. **refunds**
   - Refund requests and processing
   - Links to payments and invoices
   - Refund status tracking
   - Approval workflow

### Database Views Created

- **invoice_summary**: Aggregated invoice data with guest and payment info
- **payment_summary**: Aggregated payment data with invoice details

### Migration File

**Location:** `database/payment_invoice_migration.sql`

This file contains all SQL statements to:
- Create tables with proper indexes
- Insert default payment methods
- Insert default billing settings
- Create views for reporting

---

## Backend Implementation

### Models Created

#### 1. Invoice Model (`backend/models/Invoice.js`)

**Key Methods:**
- `generateFromBooking(bookingId)` - Creates invoice from checked-out booking
- `getAll(limit, offset)` - Retrieve multiple invoices
- `getById(invoiceId)` - Get specific invoice
- `getByBookingId(bookingId)` - Get invoice for booking
- `getByGuestId(guestId)` - Get all invoices for guest
- `getDetails(invoiceId)` - Get invoice with items and payments
- `addInvoiceItem()` - Add line items to invoice
- `updatePaymentAmount()` - Sync payment amounts
- `updateStatus(invoiceId, status)` - Change invoice status
- `getStatistics()` - Billing statistics
- `cancel(invoiceId)` - Cancel invoice

**Invoice Statuses:** Draft, Generated, Sent, Partially_Paid, Paid, Cancelled

#### 2. Payment Model (`backend/models/Payment.js`)

**Key Methods:**
- `create(paymentData)` - Record new payment
- `getAll(limit, offset)` - Retrieve multiple payments
- `getById(paymentId)` - Get specific payment
- `getByInvoiceId(invoiceId)` - Get payments for invoice
- `getByBookingId(bookingId)` - Get payments for booking
- `getByGuestId(guestId)` - Get payments for guest
- `getPaymentMethods()` - List available methods
- `getReceiptData(paymentId)` - Get receipt information
- `processRefund()` - Process payment refund
- `getStatistics()` - Payment statistics
- `verifyPaymentStatus()` - Verify payment

**Payment Methods:** Cash, Credit Card, Debit Card, UPI, Net Banking, Cheque

**Payment Statuses:** Pending, Authorized, Processed, Failed, Refunded

#### 3. Refund Model (`backend/models/Refund.js`)

**Key Methods:**
- `create(refundData)` - Create refund request
- `getAll(limit, offset)` - Retrieve refunds
- `getById(refundId)` - Get specific refund
- `getByInvoiceId(invoiceId)` - Get refunds for invoice
- `getByGuestId(guestId)` - Get refunds for guest
- `approveRefund()` - Approve refund
- `rejectRefund()` - Reject refund
- `getStatistics()` - Refund statistics
- `getDetails()` - Get refund with related data

**Refund Statuses:** Pending, Processed, Failed, Completed

### API Routes

#### Invoice Routes (`/api/invoices`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | Get all invoices |
| GET | `/:id` | Get invoice details |
| GET | `/booking/:bookingId` | Get invoice for booking |
| GET | `/guest/:guestId` | Get invoices for guest |
| GET | `/date-range/list?start=&end=` | Get invoices by date range |
| GET | `/stats/range?start=&end=` | Get invoice statistics |
| POST | `/generate` | Generate invoice from booking |
| PUT | `/:id/status` | Update invoice status |
| PUT | `/:id/cancel` | Cancel invoice |

#### Payment Routes (`/api/payments`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | Get all payments |
| GET | `/:id` | Get payment details |
| GET | `/invoice/:invoiceId` | Get payments for invoice |
| GET | `/booking/:bookingId` | Get payments for booking |
| GET | `/guest/:guestId` | Get payments for guest |
| GET | `/methods/list` | Get payment methods |
| GET | `/:id/receipt` | Get receipt data |
| GET | `/date-range/list?start=&end=` | Get payments by date |
| GET | `/stats/range?start=&end=` | Get payment statistics |
| POST | `/` | Record new payment |
| POST | `/:id/refund` | Process refund |
| PUT | `/:id/verify` | Verify payment status |
| POST | `/refunds` | Create refund |
| GET | `/refunds/list` | Get all refunds |
| GET | `/refunds/:id` | Get refund details |
| PUT | `/refunds/:id/approve` | Approve refund |
| PUT | `/refunds/:id/reject` | Reject refund |

---

## Frontend Implementation

### Files Created

#### 1. Billing JavaScript (`frontend/js/billing.js`)

**Comprehensive billing functions:**
- Invoice generation and retrieval
- Invoice printing and display
- Payment recording
- Payment method management
- Refund processing
- Payment receipts
- Billing statistics

**Key Functions:**
- `generateInvoice(bookingId)` - Generate invoice
- `getInvoiceDetails(invoiceId)` - Fetch invoice
- `printInvoice(invoiceId)` - Print invoice
- `recordPayment(paymentData)` - Record payment
- `getPaymentMethods()` - Get available methods
- `printPaymentReceipt(paymentId)` - Print receipt
- `processRefund()` - Process refund
- `getBillingStats()` - Get statistics

### Bookings Page Updates (`frontend/bookings.html`)

**New Modals Added:**

1. **Payment Modal** (`paymentModal`)
   - Record payment against invoice
   - Select payment method
   - Add reference numbers
   - Add notes

2. **Invoice Modal** (`invoiceModal`)
   - View complete invoice details
   - See itemized charges
   - View payment history
   - Print or download invoice

3. **Updated Booking Actions**
   - For checked-out bookings:
     - Generate Invoice
     - View Invoice
     - Record Payment

### Bookings JavaScript Updates (`frontend/js/bookings.js`)

**New Functions:**
- `handleGenerateInvoice(bookingId)` - Generate invoice
- `handleViewInvoice(bookingId)` - View invoice modal
- `displayInvoiceModal(invoice)` - Display invoice details
- `handleRecordPayment()` - Open payment form
- `handleRecordPaymentForInvoice()` - Record payment from invoice view

### Guest Portal Updates (`frontend/guest-portal.html`)

**New Billing Section:**
- Display room charges
- Display services charges
- Show grand total
- Show amount due
- Download invoice button
- Print invoice button

**Guest Billing Functions** (`frontend/js/guest-portal.js`)

**New Functions:**
- `loadGuestBillingInfo(bookingId)` - Load billing data
- `guestDownloadInvoice()` - Download invoice
- `guestPrintInvoice()` - Print invoice

---

## Features

### 1. Invoice Generation

**Trigger:** Automatic when booking is checked out

**Includes:**
- Room charges (room price × number of nights)
- Service charges (all completed service orders)
- Discounts (percentage or fixed amount)
- Tax calculations (configurable rate)
- Line-item breakdown
- Invoice number (auto-generated with prefix)
- Due date (configurable days from invoice date)

**Invoice Statuses:**
- Draft - Not yet generated
- Generated - Created but not sent
- Sent - Emailed to guest
- Partially_Paid - Some payment received
- Paid - Full amount paid
- Cancelled - Invoice cancelled

### 2. Payment Processing

**Payment Methods:**
- Cash
- Credit Card
- Debit Card
- UPI
- Net Banking
- Cheque

**Payment Recording:**
- Amount
- Payment method
- Reference number (transaction ID, cheque number, etc.)
- Date/time
- Received by (staff member)
- Notes

**Payment Status:**
- Pending - Not yet processed
- Authorized - approved but not settled
- Processed - Successfully received
- Failed - Payment failed
- Refunded - Payment has been refunded

### 3. Refund Management

**Refund Request:**
- Link to payment and invoice
- Refund reason
- Refund method
- Amount

**Refund Status:**
- Pending - Awaiting approval
- Processed - Approved and completed
- Failed - Refund failed
- Completed - Successfully refunded

**Refund Approval:**
- Manual approval workflow
- Approval by staff member
- Approval tracking with timestamp

### 4. Invoice Display

**Admin View:**
- Complete invoice with all items
- Payment history
- Outstanding balance
- Guest information
- Stay dates
- Print option
- Download option

**Guest View:**
- Simplified invoice display
- Billing summary
- Print option
- Download option
- Available after checkout

### 5. Payment Receipts

**Receipt Include:**
- Receipt number
- Date and time
- Guest name and contact
- Invoice number
- Payment method
- Amount paid
- Reference number
- Received by
- Print-friendly format

### 6. Billing Reports

**Statistics Available:**
- Total invoices (by date range)
- Total revenue
- Total collected
- Total outstanding
- Invoices by status
- Payments by method
- Payment count by method
- Refund statistics

---

## Configuration

### Billing Settings

Edit in database `billing_settings` table or through admin panel:

| Setting | Default | Type | Description |
|---------|---------|------|-------------|
| tax_rate | 0 | percentage | Tax/GST percentage |
| invoice_prefix | INV- | text | Invoice number prefix |
| payment_prefix | PAY- | text | Payment reference prefix |
| currency | INR | text | Currency code |
| due_days | 7 | number | Days before payment is due |
| company_name | Hotel Management System | text | Company name on invoice |
| company_address | - | text | Company address |
| company_phone | - | text | Company phone number |
| company_email | - | text | Company email |
| company_gst | - | text | GST/Tax ID |
| payment_terms | - | text | Payment terms text |
| invoice_footer | Thank you for your stay! | text | Invoice footer message |
| enable_partial_refunds | 1 | boolean | Allow partial refunds |
| round_amounts | 1 | boolean | Round amounts to nearest unit |

---

## Setup Instructions

### 1. Database Setup

Execute the migration SQL file:

```bash
# Using MySQL CLI
mysql -u root -p hotel_management < database/payment_invoice_migration.sql

# Or through your database management tool, copy and execute the contents of:
database/payment_invoice_migration.sql
```

### 2. Verify Server Routes

Check that server.js has been updated with:
```javascript
const invoiceRoutes = require('./routes/invoices');
const paymentRoutes = require('./routes/payments');

app.use('/api/invoices', invoiceRoutes);
app.use('/api/payments', paymentRoutes);
```

### 3. Restart Backend Server

```bash
# In backend directory
npm start
# or
node server.js
```

### 4. Test API Endpoints

Test invoice generation:
```bash
curl -X POST http://localhost:3000/api/invoices/generate \
  -H "Content-Type: application/json" \
  -d '{"booking_id": 1}'
```

Test payment recording:
```bash
curl -X POST http://localhost:3000/api/payments \
  -H "Content-Type: application/json" \
  -d '{
    "invoice_id": 1,
    "booking_id": 1,
    "guest_id": 1,
    "amount": 5000,
    "payment_method": "Cash",
    "received_by": "Admin"
  }'
```

### 5. Test Frontend

1. Checkout a booking
2. Navigate to Bookings page
3. In actions menu, click "Generate Invoice"
4. View invoice details
5. Record payment
6. Download/print invoice
7. Check Guest Portal for invoice visibility

---

## Usage Workflow

### For Staff (Admin):

1. **Check-in Guest** → Booking status: CheckedIn
2. **Guest Places Service Orders** → Services added to invoice
3. **Check-out Guest** → Booking status: CheckedOut
4. **Generate Invoice** → Click "Generate Invoice" button
   - Invoice auto-calculates all charges
   - Includes room + services + discounts + taxes
5. **Record Payments** → Click "Record Payment"
   - Enter payment amount
   - Select payment method
   - Add reference/notes
   - Invoice auto-updates with payment received
6. **Print/Download** → Click "Print Invoice" or download
7. **Process Refund** (if needed) → Click payment → "Refund"

### For Guest (Guest Portal):

1. **View Booking Info** → See room, dates, status
2. **After Checkout** → Invoice available in Billing section
3. **View Charges** → See room charges, services, total, amount due
4. **Download Invoice** → Click "Download Invoice" button
5. **Print Invoice** → Click "Print Invoice" button

---

## API Request Examples

### Generate Invoice
```bash
POST /api/invoices/generate
{
  "booking_id": 1
}
```

**Response:**
```json
{
  "success": true,
  "message": "Invoice generated successfully",
  "data": {
    "success": true,
    "invoiceId": 1,
    "invoiceNumber": "INV-000001",
    "grandTotal": 15500,
    "amountDue": 15500
  }
}
```

### Record Payment
```bash
POST /api/payments
{
  "invoice_id": 1,
  "booking_id": 1,
  "guest_id": 1,
  "amount": 15500,
  "payment_method": "Cash",
  "reference_number": "CASH001",
  "received_by": "Admin",
  "notes": "Full payment received"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Payment recorded successfully",
  "data": {
    "success": true,
    "paymentId": 1,
    "paymentNumber": "PAY-000001",
    "amount": 15500
  }
}
```

### Get Invoice Details
```bash
GET /api/invoices/1
```

**Response:**
```json
{
  "success": true,
  "data": {
    "invoice_id": 1,
    "invoice_number": "INV-000001",
    "booking_id": 1,
    "guest_id": 1,
    "guest_name": "John Doe",
    "room_number": "204",
    "grand_total": 15500,
    "amount_paid": 15500,
    "amount_due": 0,
    "status": "Paid",
    "items": [
      // invoice items
    ],
    "payments": [
      // payment records
    ]
  }
}
```

---

## Error Handling

### Common Errors

**Invoice not found:**
- Generated when booking hasn't been checked out
- Solution: Check out booking first

**No payment methods available:**
- Generated when billing_settings not loaded
- Solution: Verify database migration executed

**Duplicate invoice:**
- Generated when invoice already exists for booking
- Solution: Delete and regenerate if needed

**Invalid payment amount:**
- Generated when amount exceeds invoice total
- Solution: Enter valid amount

---

## Troubleshooting

### Invoice not appearing after checkout

**Check:**
1. Booking status changed to "CheckedOut"
2. Backend server running
3. `/api/invoices/generate` endpoint accessible
4. Database tables created and accessible
5. Check browser console for errors

### Payments not updating invoice

**Check:**
1. Invoice ID correct
2. Payment amount valid
3. Payment status is "Processed"
4. Invoice amount balance calculation
5. Check browser console and server logs

### Payment methods not loading

**Check:**
1. `payment_methods` table populated
2. Billing settings configured
3. API endpoint `/api/payments/methods/list` accessible
4. Guest-portal.js loaded before billing.js

---

## Maintenance

### Regular Tasks

1. **Daily:** Review pending invoices and payments
2. **Weekly:** Generate billing reports
3. **Monthly:** Reconcile payments vs invoices
4. **Quarterly:** Review and update billing settings
5. **Annually:** Archive old invoices

### Database Maintenance

```sql
-- To view all pending invoices
SELECT * FROM invoices WHERE status IN ('Generated', 'Partially_Paid');

-- To view all outstanding amounts
SELECT invoice_id, guest_id, amount_due 
FROM invoices 
WHERE amount_due > 0;

-- To get payment statistics
SELECT payment_method, COUNT(*) as count, SUM(amount) as total
FROM payments
WHERE DATE(payment_date) = CURDATE()
GROUP BY payment_method;
```

---

## Future Enhancements

Potential features for future versions:

- [ ] Automated invoice email to guest
- [ ] Payment gateway integration
- [ ] Multiple currency support
- [ ] Custom invoice templates
- [ ] Automated payment reminders
- [ ] Recurring charges/subscriptions
- [ ] Invoice dispute workflow
- [ ] Advanced refund rules
- [ ] Payment plans
- [ ] Loyalty discounts integration
- [ ] Multi-language support
- [ ] Financial reporting suite
- [ ] Accounting system integration

---

## Support & Documentation

For detailed API documentation, see: `API_REFERENCE.md`

For deployment instructions, see: `DEPLOYMENT_GUIDE.md`

For testing procedures, see: `TESTING_GUIDE.md`

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | Feb 26, 2026 | Initial implementation |

---

**Implementation Complete!**

The payment and invoice billing system is now fully implemented in your Hotel Management System.
All guests who check out will automatically have invoices generated, and staff can easily record payments and print receipts.
