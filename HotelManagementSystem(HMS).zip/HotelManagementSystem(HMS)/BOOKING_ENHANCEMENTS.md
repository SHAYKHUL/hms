# Booking System Enhancements

## Overview
Enhanced the hotel booking system with real-world business logic to handle common hotel management scenarios:

### 🛡️ 1. Robust Overbooking Protection
**Problem Solved:** Prevents double bookings even with concurrent requests

**Implementation:**
- Database-level row locking using `FOR UPDATE` in transactions
- Enhanced date overlap validation: `new_start < existing_end AND new_end > existing_start`
- Detailed conflict information when booking fails
- Transaction-based booking to ensure data consistency

**Benefits:**
- Prevents race conditions when multiple staff members book simultaneously
- Provides clear error messages with existing booking details
- Ensures data integrity across the booking process

---

### 🔄 2. Room Transfer During Stay
**Problem Solved:** Move guests between rooms during their stay

**Common Use Cases:**
- Room maintenance issues (AC broken, plumbing problems)
- Guest requests for room change
- Room upgrades or downgrades
- Complaint resolution

**API Endpoint:**
```
POST /api/bookings/:id/transfer-room
```

**Request Body:**
```json
{
  "new_room_id": 15,
  "reason": "Guest complained about noise - transferred to quieter floor",
  "price_difference": 50.00
}
```

**Response:**
```json
{
  "success": true,
  "message": "Guest successfully transferred from Room 101 to Room 205",
  "data": {
    "booking_id": 123,
    "old_room": {
      "room_id": 10,
      "room_number": "101",
      "price": 100.00
    },
    "new_room": {
      "room_id": 15,
      "room_number": "205",
      "price": 150.00
    },
    "price_adjustment": 50.00,
    "new_total_amount": 750.00,
    "reason": "Guest complained about noise",
    "transfer_date": "2026-03-05T10:30:00.000Z"
  }
}
```

**Business Logic:**
- ✅ Validates booking is in `Confirmed` or `CheckedIn` status
- ✅ Checks new room availability for remaining nights
- ✅ Calculates automatic price adjustment based on room price difference
- ✅ Updates room statuses (frees old room, books new room)
- ✅ Maintains audit trail in booking notes
- ✅ Transfers guest session if currently checked in
- ✅ Uses database transactions for consistency

---

### 📅 3. Booking Date Modification
**Problem Solved:** Change check-in or check-out dates after booking

**Common Use Cases:**
- Guest extends their stay
- Guest shortens their stay
- Guest reschedules arrival/departure
- Corporate booking adjustments

**API Endpoint:**
```
PUT /api/bookings/:id/modify-dates
```

**Request Body:**
```json
{
  "new_check_in": "2026-03-10",
  "new_check_out": "2026-03-15"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Booking dates modified successfully (check-in: 2026-03-08 → 2026-03-10, check-out: 2026-03-12 → 2026-03-15)",
  "data": {
    "booking_id": 123,
    "old_dates": {
      "check_in": "2026-03-08",
      "check_out": "2026-03-12",
      "nights": 4
    },
    "new_dates": {
      "check_in": "2026-03-10",
      "check_out": "2026-03-15",
      "nights": 5
    },
    "old_amount": 400.00,
    "new_amount": 500.00,
    "price_difference": 100.00
  }
}
```

**Business Logic:**
- ✅ Only allows modification for `Confirmed` bookings (not checked-in guests)
- ✅ Validates new dates don't conflict with other bookings
- ✅ Automatically recalculates total amount based on new night count
- ✅ Maintains proportional discounts
- ✅ Provides detailed change tracking
- ✅ Uses transactions for data consistency

---

### 🔍 4. Enhanced Availability Checking

#### Detailed Room Availability
**API Endpoint:**
```
GET /api/bookings/availability/detailed?room_id=5&check_in=2026-03-10&check_out=2026-03-15
```

**Response with Conflicts:**
```json
{
  "success": true,
  "data": {
    "available": false,
    "reason": "Room has conflicting bookings",
    "room": {
      "room_id": 5,
      "room_number": "105",
      "room_type": "Deluxe",
      "price": 150.00,
      "status": "Booked"
    },
    "conflicts": [
      {
        "booking_id": 456,
        "guest_name": "John Smith",
        "guest_phone": "+1234567890",
        "check_in": "2026-03-09",
        "check_out": "2026-03-12",
        "booking_status": "CheckedIn",
        "overlap_days": 2
      }
    ]
  }
}
```

**Features:**
- Shows exact booking conflicts with guest details
- Calculates overlap days
- Provides room status information
- Supports excluding specific bookings (useful for modifications)

---

#### Alternative Room Suggestions
**API Endpoint:**
```
GET /api/bookings/alternatives/rooms?check_in=2026-03-10&check_out=2026-03-15&number_of_guests=2&preferred_type=Deluxe
```

**Response:**
```json
{
  "success": true,
  "count": 3,
  "data": [
    {
      "room_id": 12,
      "room_number": "201",
      "room_type": "Deluxe",
      "price": 150.00,
      "max_guests": 2,
      "amenities": "AC, WiFi, TV, Mini Bar",
      "total_cost_for_period": 750.00,
      "nights": 5,
      "conflicting_bookings": 0
    },
    {
      "room_id": 18,
      "room_number": "305",
      "room_type": "Deluxe",
      "price": 160.00,
      "max_guests": 3,
      "amenities": "AC, WiFi, TV, Mini Bar, Balcony",
      "total_cost_for_period": 800.00,
      "nights": 5,
      "conflicting_bookings": 0
    }
  ]
}
```

**Use Cases:**
- Finding available rooms when preferred room is booked
- Offering alternatives during room transfer
- Providing upgrade/downgrade options

---

#### Comprehensive Modification Options
**API Endpoint:**
```
GET /api/bookings/:id/modification-options?new_check_in=2026-03-10&new_check_out=2026-03-15
```

**Response:**
```json
{
  "success": true,
  "data": {
    "booking": {
      "booking_id": 123,
      "current_room": "105",
      "current_dates": {
        "check_in": "2026-03-08",
        "check_out": "2026-03-12"
      },
      "requested_dates": {
        "check_in": "2026-03-10",
        "check_out": "2026-03-15"
      }
    },
    "current_room_available": false,
    "current_room_details": {
      "available": false,
      "reason": "Room has conflicting bookings",
      "conflicts": [...]
    },
    "alternative_rooms": [
      {
        "room_id": 12,
        "room_number": "201",
        "room_type": "Deluxe",
        "price": 150.00,
        "total_cost_for_period": 750.00
      }
    ],
    "recommendations": {
      "can_keep_same_room": false,
      "should_transfer": true,
      "no_options_available": false
    }
  }
}
```

**Business Logic:**
- Checks if current room is available for new dates
- Suggests alternative rooms if not available
- Provides actionable recommendations
- Complete information for staff to make decisions

---

## 📊 Database Improvements

### Transaction Safety
All critical operations now use database transactions with row locking:
- Booking creation
- Room transfers
- Date modifications

**Benefits:**
- Prevents race conditions
- Ensures data consistency
- Automatic rollback on errors
- Proper resource cleanup

### Enhanced Validation
- Proper date overlap checking
- Room status validation
- Booking status validation
- Comprehensive error messages

---

## 🎯 Real-World Business Scenarios

### Scenario 1: Guest Extends Stay
```javascript
// Guest wants to stay 2 more nights
// Current booking: Room 105, March 8-12

// Step 1: Check if room available
GET /api/bookings/123/modification-options?new_check_out=2026-03-14

// If available - modify dates
PUT /api/bookings/123/modify-dates
{
  "new_check_out": "2026-03-14"
}

// If not available - transfer to another room
POST /api/bookings/123/transfer-room
{
  "new_room_id": 15,
  "reason": "Extension requested, original room booked"
}
```

### Scenario 2: Room Maintenance Issue
```javascript
// AC breaks in Room 105, guest currently checked in

// Step 1: Find available alternative
GET /api/bookings/alternatives/rooms?check_in=2026-03-05&check_out=2026-03-12&number_of_guests=2&preferred_type=Deluxe

// Step 2: Transfer guest
POST /api/bookings/123/transfer-room
{
  "new_room_id": 15,
  "reason": "AC malfunction in original room",
  "price_difference": -50.00  // Discount for inconvenience
}
```

### Scenario 3: Concurrent Bookings
```javascript
// Two staff members try to book Room 105 simultaneously

// Both execute:
POST /api/bookings
{
  "room_id": 5,
  "check_in": "2026-03-10",
  "check_out": "2026-03-15",
  ...
}

// Result:
// ✅ First request succeeds
// ❌ Second request fails with clear error:
{
  "success": false,
  "message": "Room is already booked from 2026-03-10 to 2026-03-15 (Booking #456 for John Smith). Status: Confirmed"
}
```

---

## 🔧 Technical Implementation

### Key Files Modified
1. **backend/models/Booking.js**
   - Enhanced `create()` with transaction and locking
   - Added `transferRoom()`
   - Added `modifyBookingDates()`
   - Added `checkRoomAvailabilityDetailed()`
   - Added `getAlternativeRooms()`

2. **backend/routes/bookings.js**
   - Added `/api/bookings/:id/transfer-room` endpoint
   - Added `/api/bookings/:id/modify-dates` endpoint
   - Added `/api/bookings/availability/detailed` endpoint
   - Added `/api/bookings/alternatives/rooms` endpoint
   - Added `/api/bookings/:id/modification-options` endpoint

### Database Considerations
- Uses MySQL `FOR UPDATE` for row-level locking
- Requires InnoDB engine for transaction support
- Connection pooling ensures proper resource management
- Automatic rollback on errors

---

## 🚀 Usage Examples

### Frontend Integration Example
```javascript
// Room Transfer Dialog
async function transferGuestRoom(bookingId, newRoomId, reason) {
  try {
    const response = await fetch(`/api/bookings/${bookingId}/transfer-room`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        new_room_id: newRoomId,
        reason: reason
      })
    });
    
    const result = await response.json();
    if (result.success) {
      alert(`Successfully transferred from Room ${result.data.old_room.room_number} to Room ${result.data.new_room.room_number}`);
    } else {
      alert(`Transfer failed: ${result.error}`);
    }
  } catch (error) {
    alert(`Error: ${error.message}`);
  }
}

// Modify Booking Dates
async function modifyBookingDates(bookingId, newCheckIn, newCheckOut) {
  try {
    const response = await fetch(`/api/bookings/${bookingId}/modify-dates`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        new_check_in: newCheckIn,
        new_check_out: newCheckOut
      })
    });
    
    const result = await response.json();
    if (result.success) {
      alert(`Dates modified successfully. New total: $${result.data.new_amount}`);
    } else {
      alert(`Modification failed: ${result.error}`);
    }
  } catch (error) {
    alert(`Error: ${error.message}`);
  }
}

// Find Alternative Rooms
async function findAlternativeRooms(checkIn, checkOut, guests, preferredType) {
  const params = new URLSearchParams({
    check_in: checkIn,
    check_out: checkOut,
    number_of_guests: guests,
    preferred_type: preferredType
  });
  
  const response = await fetch(`/api/bookings/alternatives/rooms?${params}`);
  const result = await response.json();
  
  return result.data; // Array of available rooms
}
```

---

## ✅ Best Practices

### For Hotel Staff
1. **Always check availability before making changes**
   - Use modification-options endpoint to see all possibilities
   
2. **Provide clear reasons for transfers**
   - Helps with audit trails and guest relations
   
3. **Handle price differences transparently**
   - Document upgrades/downgrades properly
   
4. **Use date modifications carefully**
   - Only for Confirmed bookings
   - Check-in guests require different handling

### For Developers
1. **Always use the provided API endpoints**
   - Don't bypass the business logic
   
2. **Handle errors gracefully**
   - Provide clear feedback to users
   
3. **Test concurrent scenarios**
   - Multiple bookings, transfers, modifications
   
4. **Monitor transaction deadlocks**
   - Rare but possible with high concurrency

---

## 🐛 Error Handling

### Common Errors and Solutions

**Error:** "Booking not found"
- **Cause:** Invalid booking ID
- **Solution:** Verify booking exists before operations

**Error:** "Cannot transfer room. Booking status is CheckedOut"
- **Cause:** Trying to transfer completed booking
- **Solution:** Only transfer Confirmed or CheckedIn bookings

**Error:** "Room 205 is already booked from [date] to [date]"
- **Cause:** Target room not available
- **Solution:** Use alternatives endpoint to find other rooms

**Error:** "Cannot modify dates. Booking status is CheckedIn"
- **Cause:** Guest already checked in
- **Solution:** Use room transfer instead, or check out and rebook

**Error:** "Room is under maintenance and cannot be booked"
- **Cause:** Target room status is Maintenance
- **Solution:** Choose different room or wait for maintenance completion

---

## 📈 Future Enhancements (Potential)
- Automated room upgrade suggestions
- Guest notification system for transfers
- Bulk date modifications
- Waiting list for unavailable rooms
- Price optimization based on occupancy
- Integration with housekeeping for transfer coordination

---

## 🔐 Security Considerations
- All operations validated server-side
- Database transactions prevent data corruption
- Proper error messages without exposing sensitive data
- Audit trails maintained for all changes

---

## 📞 Support
For questions or issues with the enhanced booking system:
1. Check error messages for specific guidance
2. Review this documentation
3. Test in a development environment first
4. Contact system administrator for database issues
