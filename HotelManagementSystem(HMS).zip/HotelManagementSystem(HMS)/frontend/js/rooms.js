// Rooms Management JavaScript

let allRooms = [];
let currentRoom = null;

// Load all rooms
async function loadRooms() {
    try {
        const response = await apiCall(`${API_ENDPOINTS.rooms}`);
        if (response.success) {
            allRooms = response.data;
            displayRooms(allRooms);
        }
    } catch (error) {
        document.getElementById('roomsGrid').innerHTML = '<p class="text-danger">Error loading rooms</p>';
    }
}

// Display rooms
function displayRooms(rooms) {
    const container = document.getElementById('roomsGrid');
    
    if (rooms.length === 0) {
        container.innerHTML = '<p class="text-muted">No rooms found</p>';
        return;
    }
    
    container.innerHTML = rooms.map(room => `
        <div class="room-card">
            <div class="room-header">
                <div class="room-number">Room ${room.room_number}</div>
                <div class="room-type">${room.room_type} • ${room.ac_type || 'AC'}</div>
            </div>
            <div class="room-body">
                <div class="room-info">
                    <p><strong>Price:</strong> ${formatCurrency(room.price)}/night</p>
                    <p><strong>Beds:</strong> ${room.bed_count || 1} | <strong>Max Guests:</strong> ${room.max_guests || 2}</p>
                    <p><strong>Status:</strong> <span class="room-status ${room.status.toLowerCase()}">${room.status}</span></p>
                    ${room.amenities ? `<p><strong>Amenities:</strong> ${room.amenities}</p>` : ''}
                    ${room.description ? `<p class="text-muted">${room.description}</p>` : ''}
                </div>
                <div class="room-actions">
                    <button onclick="editRoom(${room.room_id})" class="btn btn-primary btn-sm">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button onclick="deleteRoom(${room.room_id})" class="btn btn-danger btn-sm">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// Filter rooms
function filterRooms() {
    const statusFilter = document.getElementById('statusFilter').value;
    const typeFilter = document.getElementById('typeFilter').value;
    
    let filtered = allRooms;
    
    if (statusFilter) {
        filtered = filtered.filter(room => room.status === statusFilter);
    }
    
    if (typeFilter) {
        filtered = filtered.filter(room => room.room_type === typeFilter);
    }
    
    displayRooms(filtered);
}

// Open Add Room Modal
function openAddRoomModal() {
    currentRoom = null;
    document.getElementById('modalTitle').textContent = 'Add New Room';
    document.getElementById('roomForm').reset();
    document.getElementById('roomId').value = '';
    document.getElementById('roomModal').classList.add('show');
}

// Edit room
async function editRoom(roomId) {
    try {
        const response = await apiCall(`${API_ENDPOINTS.rooms}/${roomId}`);
        if (response.success) {
            currentRoom = response.data;
            
            document.getElementById('modalTitle').textContent = 'Edit Room';
            document.getElementById('roomId').value = currentRoom.room_id;
            document.getElementById('roomNumber').value = currentRoom.room_number;
            document.getElementById('roomType').value = currentRoom.room_type;
            document.getElementById('acType').value = currentRoom.ac_type || 'AC';
            document.getElementById('price').value = currentRoom.price;
            document.getElementById('bedCount').value = currentRoom.bed_count || 1;
            document.getElementById('maxGuests').value = currentRoom.max_guests || 2;
            document.getElementById('status').value = currentRoom.status;
            document.getElementById('amenities').value = currentRoom.amenities || '';
            document.getElementById('description').value = currentRoom.description || '';
            
            document.getElementById('roomModal').classList.add('show');
        }
    } catch (error) {
        console.error('Error loading room:', error);
    }
}

// Close Room Modal
function closeRoomModal() {
    document.getElementById('roomModal').classList.remove('show');
    currentRoom = null;
}

// Handle room form submission
document.getElementById('roomForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Clear previous errors
    clearValidationErrors();
    
    // Get form data
    const roomNumber = document.getElementById('roomNumber').value.trim();
    const roomType = document.getElementById('roomType').value;
    const acType = document.getElementById('acType').value;
    const price = document.getElementById('price').value;
    const bedCount = document.getElementById('bedCount').value;
    const maxGuests = document.getElementById('maxGuests').value;
    const status = document.getElementById('status').value;
    const amenities = document.getElementById('amenities').value;
    const description = document.getElementById('description').value;
    
    // Validate form data
    const errors = validateRoomForm({ roomNumber, roomType, acType, price, bedCount, maxGuests, status });
    if (errors.length > 0) {
        displayValidationErrors(errors);
        return;
    }
    
    const roomData = {
        room_number: roomNumber.toUpperCase(),
        room_type: roomType,
        ac_type: acType,
        price: parseFloat(price),
        bed_count: parseInt(bedCount),
        max_guests: parseInt(maxGuests),
        status: status,
        amenities: amenities,
        description: description
    };
    
    try {
        const roomId = document.getElementById('roomId').value;
        let response;
        
        if (roomId) {
            // Update existing room
            response = await apiCall(`${API_ENDPOINTS.rooms}/${roomId}`, {
                method: 'PUT',
                body: JSON.stringify(roomData)
            });
            
            if (!response.success) {
                if (response.errors && Array.isArray(response.errors)) {
                    displayValidationErrors(response.errors);
                } else {
                    showNotification(response.message || 'Failed to update room', 'error');
                }
                return;
            }
            showNotification('✓ Room updated successfully!', 'success');
        } else {
            // Create new room
            response = await apiCall(`${API_ENDPOINTS.rooms}`, {
                method: 'POST',
                body: JSON.stringify(roomData)
            });
            
            if (!response.success) {
                if (response.errors && Array.isArray(response.errors)) {
                    displayValidationErrors(response.errors);
                } else {
                    showNotification(response.message || 'Failed to create room', 'error');
                }
                return;
            }
            showNotification('✓ Room added successfully!', 'success');
        }
        
        closeRoomModal();
        loadRooms();
    } catch (error) {
        console.error('Error saving room:', error);
        showNotification('Error: ' + (error.message || 'Failed to save room'), 'error');
    }
});

// Validate room form
function validateRoomForm(data) {
    const errors = [];
    
    if (!data.roomNumber) {
        errors.push('Room number is required');
    } else {
        // Validate alphanumeric room number format (e.g., 3A, 6B, 7C)
        const roomNumStr = data.roomNumber.toString().trim().toUpperCase();
        if (!/^[0-9A-Z]{1,10}$/.test(roomNumStr)) {
            errors.push('Room number must be alphanumeric (e.g., 3A, 6B, 7C) and max 10 characters');
        }
    }
    if (!data.roomType) {
        errors.push('Room type is required');
    }
    if (!data.acType) {
        errors.push('AC type is required');
    }
    if (!data.price || isNaN(data.price) || parseFloat(data.price) <= 0) {
        errors.push('Price must be greater than 0');
    }
    if (!data.bedCount || isNaN(data.bedCount) || parseInt(data.bedCount) < 1) {
        errors.push('Bed count must be at least 1');
    }
    if (!data.maxGuests || isNaN(data.maxGuests) || parseInt(data.maxGuests) < 1) {
        errors.push('Max guests must be at least 1');
    }
    
    return errors;
}

// Display validation errors
function displayValidationErrors(errors) {
    const errorContainer = document.getElementById('roomFormErrors');
    if (!errorContainer) {
        // Create error container if it doesn't exist
        const form = document.getElementById('roomForm');
        const div = document.createElement('div');
        div.id = 'roomFormErrors';
        div.className = 'alert alert-danger';
        form.parentNode.insertBefore(div, form);
    }
    
    const errorContainer2 = document.getElementById('roomFormErrors');
    errorContainer2.innerHTML = '<strong>Please fix the following errors:</strong><ul>' +
        errors.map(err => `<li>${err}</li>`).join('') +
        '</ul>';
    errorContainer2.style.display = 'block';
}

// Clear validation errors
function clearValidationErrors() {
    const errorContainer = document.getElementById('roomFormErrors');
    if (errorContainer) {
        errorContainer.style.display = 'none';
        errorContainer.innerHTML = '';
    }
}

// Delete room
async function deleteRoom(roomId) {
    if (!confirm('Are you sure you want to delete this room? This action cannot be undone.')) {
        return;
    }
    
    try {
        const response = await apiCall(`${API_ENDPOINTS.rooms}/${roomId}`, {
            method: 'DELETE'
        });
        
        if (response.success) {
            showNotification('✓ Room deleted successfully!', 'success');
            loadRooms();
        } else {
            showNotification('Error: ' + (response.message || 'Failed to delete room'), 'error');
        }
    } catch (error) {
        console.error('Error deleting room:', error);
        showNotification('Error: ' + (error.message || 'Failed to delete room'), 'error');
    }
}

// Load rooms on page load
window.addEventListener('DOMContentLoaded', loadRooms);

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('roomModal');
    if (event.target === modal) {
        closeRoomModal();
    }
};
