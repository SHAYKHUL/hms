// Rooms Management JavaScript

let allRooms = [];
let filteredRooms = [];
let currentRoom = null;

// Load all rooms with enhanced booking status
async function loadRooms(filters = {}) {
    try {
        // Use enhanced endpoint that includes booking status
        let endpoint = `${API_ENDPOINTS.rooms}/enhanced`;
        const params = new URLSearchParams();
        
        // Add filters to query parameters for backend filtering
        if (filters.status) params.append('status', filters.status);
        if (filters.room_type) params.append('room_type', filters.room_type);
        if (filters.ac_type) params.append('ac_type', filters.ac_type);
        
        if (params.toString()) {
            endpoint += '?' + params.toString();
        }
        
        const response = await apiCall(endpoint);
        if (response.success) {
            allRooms = response.data;
            filteredRooms = allRooms;
            displayRooms(filteredRooms);
            updateResultsSummary();
        }
    } catch (error) {
        console.error('Error loading rooms:', error);
        document.getElementById('roomsGrid').innerHTML = '<p class="text-danger">Error loading rooms. Please try again.</p>';
    }
}

// Display rooms with enhanced status and availability info
function displayRooms(rooms) {
    const container = document.getElementById('roomsGrid');
    
    if (rooms.length === 0) {
        container.innerHTML = '<div style="text-align: center; padding: 40px; color: #999;"><i class="fas fa-search" style="font-size: 48px; margin-bottom: 15px;"></i><p>No rooms found matching your criteria</p></div>';
        return;
    }
    
    container.innerHTML = rooms.map(room => {
        const isAvailable = room.availability_status === 'Available' || room.availability_status === 'Available (Early Checkout)';
        const isOccupied = room.availability_status === 'Occupied';
        const isReserved = room.availability_status && room.availability_status.includes('Reserved');
        
        return `
        <div class="room-card" style="border: 2px solid ${isAvailable ? '#27ae60' : isOccupied ? '#e74c3c' : '#f39c12'}; position: relative;">
            <!-- Availability Badge -->\n            <div style="position: absolute; top: 10px; right: 10px; background: ${isAvailable ? '#27ae60' : isOccupied ? '#e74c3c' : '#f39c12'}; color: white; padding: 5px 12px; border-radius: 20px; font-size: 12px; font-weight: 600;">
                ${room.availability_status || room.status}
            </div>
            
            <div class="room-header" style="padding-top: 15px;">
                <div class="room-number" style="font-size: 24px; font-weight: bold; color: #2c3e50;">Room ${room.room_number}</div>
                <div class="room-type" style="color: #7f8c8d; font-size: 14px;">${room.room_type} • ${room.ac_type || 'AC'}</div>
            </div>
            
            <div class="room-body">
                <div class="room-info">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 15px;">
                        <div>
                            <strong style="color: #2c3e50;">₹${parseFloat(room.price).toFixed(2)}</strong>
                            <span style="color: #7f8c8d; font-size: 12px;">/night</span>
                        </div>
                        <div style="text-align: right;">
                            <i class="fas fa-bed"></i> ${room.bed_count || 1} bed(s)
                            <br>
                            <i class="fas fa-users"></i> Up to ${room.max_guests || 2} guests
                        </div>
                    </div>
                    
                    ${room.amenities ? `
                        <div style="margin-bottom: 10px; padding: 8px; background: #f8f9fa; border-radius: 4px; font-size: 13px;">
                            <i class="fas fa-concierge-bell" style="color: #3498db;"></i> ${room.amenities}
                        </div>
                    ` : ''}
                    
                    ${isOccupied && room.current_guest_name ? `
                        <div style="margin-bottom: 10px; padding: 10px; background: #fff3cd; border-left: 3px solid #ffc107; border-radius: 4px;">
                            <div style="font-weight: 600; color: #856404; margin-bottom: 5px;">
                                <i class="fas fa-user"></i> Current Guest: ${room.current_guest_name}
                            </div>
                            <div style="font-size: 13px; color: #856404;">
                                <i class="fas fa-calendar-check"></i> Check-in: ${formatDate(room.current_checkin)}
                                <br>
                                <i class="fas fa-calendar-times"></i> Check-out: ${formatDate(room.current_checkout)}
                            </div>
                        </div>
                    ` : ''}
                    
                    ${isReserved && room.current_guest_name ? `
                        <div style="margin-bottom: 10px; padding: 10px; background: #d1ecf1; border-left: 3px solid #17a2b8; border-radius: 4px;">
                            <div style="font-weight: 600; color: #0c5460; margin-bottom: 5px;">
                                <i class="fas fa-calendar-alt"></i> Reserved for: ${room.current_guest_name}
                            </div>
                            <div style="font-size: 13px; color: #0c5460;">
                                <i class="fas fa-sign-in-alt"></i> Arriving: ${formatDate(room.current_checkin)}
                            </div>
                        </div>
                    ` : ''}
                    
                    ${room.available_from && !isAvailable ? `
                        <div style="margin-bottom: 10px; padding: 8px; background: #e8f5e9; border-radius: 4px; font-size: 13px; color: #2e7d32;">
                            <i class="fas fa-clock"></i> <strong>Available from:</strong> ${formatDateTime(room.available_from)}
                        </div>
                    ` : ''}
                    
                    ${room.cleaning_status && room.cleaning_status !== 'Clean' ? `
                        <div style="margin-bottom: 10px; padding: 6px; background: #fff; border: 1px solid #dee2e6; border-radius: 4px; font-size: 12px;">
                            <i class="fas fa-broom"></i> Cleaning: <span style="font-weight: 600;">${room.cleaning_status}</span>
                        </div>
                    ` : ''}
                </div>
                
                <div class="room-actions" style="display: grid; grid-template-columns: ${isAvailable ? '1fr 1fr' : '1fr'}; gap: 8px; margin-top: 15px;">
                    ${isAvailable ? `
                        <button onclick="openQuickBooking(${room.room_id}, '${room.room_number}', ${room.price})" class="btn btn-success btn-sm" style="padding: 10px;">
                            <i class="fas fa-calendar-plus"></i> Book Now
                        </button>
                    ` : ''}
                    <button onclick="viewRoomDetails(${room.room_id})" class="btn btn-primary btn-sm" style="padding: 10px;">
                        <i class="fas fa-eye"></i> ${isAvailable ? 'Details' : 'View Details'}
                    </button>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 5px; margin-top: 10px;">
                    <button onclick="editRoom(${room.room_id})" class="btn btn-secondary btn-sm" title="Edit Room">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button onclick="openStatusChangeModal(${room.room_id}, '${room.status}')" class="btn btn-warning btn-sm" title="Change Status">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                    <button onclick="deleteRoom(${room.room_id})" class="btn btn-danger btn-sm" title="Delete Room">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        </div>
        `;
    }).join('');
}

// Get CSS class for room status
function getRoomStatusClass(status) {
    const statusClasses = {
        'Available': 'available',
        'Reserved': 'reserved', 
        'Occupied': 'occupied',
        'Booked': 'booked',
        'Maintenance': 'maintenance',
        'Under_Maintenance': 'under-maintenance',
        'Out_Of_Service': 'out-of-service'
    };
    return statusClasses[status] || status.toLowerCase().replace('_', '-');
}

// Filter rooms using backend filtering for better performance
async function filterRooms() {
    const statusFilter = document.getElementById('statusFilter').value;
    const typeFilter = document.getElementById('typeFilter').value;
    const searchInput = document.getElementById('searchInput').value.trim();
    
    // Build filters object
    const filters = {};
    if (statusFilter) filters.status = statusFilter;
    if (typeFilter) filters.room_type = typeFilter;
    
    // Reload with filters
    await loadRooms(filters);
    
    // Apply client-side search if needed
    if (searchInput) {
        performSearch();
    }
}

// Perform client-side search
function performSearch() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase().trim();
    
    if (!searchTerm) {
        filteredRooms = allRooms;
    } else {
        filteredRooms = allRooms.filter(room => {
            return (
                room.room_number.toLowerCase().includes(searchTerm) ||
                room.room_type.toLowerCase().includes(searchTerm) ||
                (room.amenities && room.amenities.toLowerCase().includes(searchTerm)) ||
                (room.description && room.description.toLowerCase().includes(searchTerm)) ||
                (room.ac_type && room.ac_type.toLowerCase().includes(searchTerm)) ||
                (room.availability_status && room.availability_status.toLowerCase().includes(searchTerm))
            );
        });
    }
    
    displayRooms(filteredRooms);
    updateResultsSummary();
}

// Clear all filters
function clearFilters() {
    document.getElementById('searchInput').value = '';
    document.getElementById('statusFilter').value = '';
    document.getElementById('typeFilter').value = '';
    filteredRooms = allRooms;
    loadRooms();
}

// Update results summary
function updateResultsSummary() {
    const resultsDiv = document.getElementById('searchResults');
    const resultsText = document.getElementById('resultsText');
    const searchTerm = document.getElementById('searchInput').value.trim();
    const statusFilter = document.getElementById('statusFilter').value;
    const typeFilter = document.getElementById('typeFilter').value;
    
    if (searchTerm || statusFilter || typeFilter) {
        resultsDiv.style.display = 'block';
        const filterParts = [];
        if (searchTerm) filterParts.push(`search: "${searchTerm}"`);
        if (statusFilter) filterParts.push(`status: ${statusFilter}`);
        if (typeFilter) filterParts.push(`type: ${typeFilter}`);
        
        resultsText.textContent = `Showing ${filteredRooms.length} of ${allRooms.length} rooms (${filterParts.join(', ')})`;
    } else {
        resultsDiv.style.display = 'none';
    }
}

// Open Add Room Modal
function openAddRoomModal() {
    currentRoom = null;
    document.getElementById('modalTitle').textContent = 'Add New Room';
    document.getElementById('roomForm').reset();
    document.getElementById('roomId').value = '';
    document.getElementById('roomModal').classList.add('show');
}

// Edit room
async function editRoom(roomId) {
    try {
        const response = await apiCall(`${API_ENDPOINTS.rooms}/${roomId}`);
        if (response.success) {
            currentRoom = response.data;
            
            document.getElementById('modalTitle').textContent = 'Edit Room';
            document.getElementById('roomId').value = currentRoom.room_id;
            document.getElementById('roomNumber').value = currentRoom.room_number;
            document.getElementById('roomType').value = currentRoom.room_type;
            document.getElementById('acType').value = currentRoom.ac_type || 'AC';
            document.getElementById('price').value = currentRoom.price;
            document.getElementById('bedCount').value = currentRoom.bed_count || 1;
            document.getElementById('maxGuests').value = currentRoom.max_guests || 2;
            document.getElementById('status').value = currentRoom.status;
            document.getElementById('amenities').value = currentRoom.amenities || '';
            document.getElementById('description').value = currentRoom.description || '';
            
            document.getElementById('roomModal').classList.add('show');
        }
    } catch (error) {
        console.error('Error loading room:', error);
    }
}

// Close Room Modal
function closeRoomModal() {
    document.getElementById('roomModal').classList.remove('show');
    currentRoom = null;
}

// Handle room form submission
document.getElementById('roomForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Clear previous errors
    clearValidationErrors();
    
    // Get form data
    const roomNumber = document.getElementById('roomNumber').value.trim();
    const roomType = document.getElementById('roomType').value;
    const acType = document.getElementById('acType').value;
    const price = document.getElementById('price').value;
    const bedCount = document.getElementById('bedCount').value;
    const maxGuests = document.getElementById('maxGuests').value;
    const status = document.getElementById('status').value;
    const amenities = document.getElementById('amenities').value;
    const description = document.getElementById('description').value;
    
    // Validate form data
    const errors = validateRoomForm({ roomNumber, roomType, acType, price, bedCount, maxGuests, status });
    if (errors.length > 0) {
        displayValidationErrors(errors);
        return;
    }
    
    const roomData = {
        room_number: roomNumber.toUpperCase(),
        room_type: roomType,
        ac_type: acType,
        price: parseFloat(price),
        bed_count: parseInt(bedCount),
        max_guests: parseInt(maxGuests),
        status: status,
        amenities: amenities,
        description: description
    };
    
    try {
        const roomId = document.getElementById('roomId').value;
        let response;
        
        if (roomId) {
            // Update existing room
            response = await apiCall(`${API_ENDPOINTS.rooms}/${roomId}`, {
                method: 'PUT',
                body: JSON.stringify(roomData)
            });
            
            if (!response.success) {
                if (response.errors && Array.isArray(response.errors)) {
                    displayValidationErrors(response.errors);
                } else {
                    showNotification(response.message || 'Failed to update room', 'error');
                }
                return;
            }
            showNotification('✓ Room updated successfully!', 'success');
        } else {
            // Create new room
            response = await apiCall(`${API_ENDPOINTS.rooms}`, {
                method: 'POST',
                body: JSON.stringify(roomData)
            });
            
            if (!response.success) {
                if (response.errors && Array.isArray(response.errors)) {
                    displayValidationErrors(response.errors);
                } else {
                    showNotification(response.message || 'Failed to create room', 'error');
                }
                return;
            }
            showNotification('✓ Room added successfully!', 'success');
        }
        
        closeRoomModal();
        loadRooms();
    } catch (error) {
        console.error('Error saving room:', error);
        showNotification('Error: ' + (error.message || 'Failed to save room'), 'error');
    }
});

// Validate room form
function validateRoomForm(data) {
    const errors = [];
    
    if (!data.roomNumber) {
        errors.push('Room number is required');
    } else {
        // Validate alphanumeric room number format (e.g., 3A, 6B, 7C)
        const roomNumStr = data.roomNumber.toString().trim().toUpperCase();
        if (!/^[0-9A-Z]{1,10}$/.test(roomNumStr)) {
            errors.push('Room number must be alphanumeric (e.g., 3A, 6B, 7C) and max 10 characters');
        }
    }
    if (!data.roomType) {
        errors.push('Room type is required');
    }
    if (!data.acType) {
        errors.push('AC type is required');
    }
    if (!data.price || isNaN(data.price) || parseFloat(data.price) <= 0) {
        errors.push('Price must be greater than 0');
    }
    if (!data.bedCount || isNaN(data.bedCount) || parseInt(data.bedCount) < 1) {
        errors.push('Bed count must be at least 1');
    }
    if (!data.maxGuests || isNaN(data.maxGuests) || parseInt(data.maxGuests) < 1) {
        errors.push('Max guests must be at least 1');
    }
    
    return errors;
}

// Display validation errors
function displayValidationErrors(errors) {
    const errorContainer = document.getElementById('roomFormErrors');
    if (!errorContainer) {
        // Create error container if it doesn't exist
        const form = document.getElementById('roomForm');
        const div = document.createElement('div');
        div.id = 'roomFormErrors';
        div.className = 'alert alert-danger';
        form.parentNode.insertBefore(div, form);
    }
    
    const errorContainer2 = document.getElementById('roomFormErrors');
    errorContainer2.innerHTML = '<strong>Please fix the following errors:</strong><ul>' +
        errors.map(err => `<li>${err}</li>`).join('') +
        '</ul>';
    errorContainer2.style.display = 'block';
}

// Clear validation errors
function clearValidationErrors() {
    const errorContainer = document.getElementById('roomFormErrors');
    if (errorContainer) {
        errorContainer.style.display = 'none';
        errorContainer.innerHTML = '';
    }
}

// Delete room
async function deleteRoom(roomId) {
    if (!confirm('Are you sure you want to delete this room? This action cannot be undone.')) {
        return;
    }
    
    try {
        const response = await apiCall(`${API_ENDPOINTS.rooms}/${roomId}`, {
            method: 'DELETE'
        });
        
        if (response.success) {
            showNotification('✓ Room deleted successfully!', 'success');
            loadRooms();
        } else {
            showNotification('Error: ' + (response.message || 'Failed to delete room'), 'error');
        }
    } catch (error) {
        console.error('Error deleting room:', error);
        showNotification('Error: ' + (error.message || 'Failed to delete room'), 'error');
    }
}

// ====== ROOM STATUS MANAGEMENT ======

// Open status change modal
function openStatusChangeModal(roomId, currentStatus) {
    const validStatuses = [
        'Available',
        'Reserved', 
        'Occupied',
        'Booked',
        'Maintenance',
        'Under_Maintenance',
        'Out_Of_Service'
    ];
    
    const statusDescriptions = {
        'Available': 'Room is clean and ready for new guests',
        'Reserved': 'Room is reserved for incoming guest',
        'Occupied': 'Guest is currently staying in the room',
        'Booked': 'Room is booked but guest has not checked in',
        'Maintenance': 'Room needs general maintenance',
        'Under_Maintenance': 'Room is currently being maintained',
        'Out_Of_Service': 'Room is temporarily out of service'
    };
    
    const statusOptions = validStatuses.map(status => 
        `<option value="${status}" ${status === currentStatus ? 'selected' : ''}>${status.replace('_', ' ')} - ${statusDescriptions[status]}</option>`
    ).join('');
    
    const modalContent = `
        <div class="modal-header">
            <h3>Change Room Status</h3>
            <button type="button" class="close" onclick="closeStatusChangeModal()">&times;</button>
        </div>
        <div class="modal-body">
            <p><strong>Current Status:</strong> <span class="room-status ${getRoomStatusClass(currentStatus)}">${currentStatus.replace('_', ' ')}</span></p>
            
            <div class="form-group">
                <label for="newRoomStatus">New Status:</label>
                <select id="newRoomStatus" class="form-control">
                    ${statusOptions}
                </select>
            </div>
            
            <div class="form-group">
                <label for="statusChangeReason">Reason for Change:</label>
                <select id="statusChangeReason" class="form-control">
                    <option value="Manual">Manual Update</option>
                    <option value="Maintenance">Maintenance Required</option>
                    <option value="Cleaning">Cleaning Status Change</option>
                    <option value="Guest Checkout">Guest Checkout</option>
                    <option value="Guest Checkin">Guest Check-in</option>
                    <option value="Emergency">Emergency</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="statusChangeNotes">Additional Notes:</label>
                <textarea id="statusChangeNotes" placeholder="Optional notes about this status change" rows="3" class="form-control"></textarea>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeStatusChangeModal()">Cancel</button>
            <button type="button" class="btn btn-primary" onclick="processStatusChange(${roomId})">Update Status</button>
        </div>
    `;
    
    // Create/update modal if it doesn't exist
    let modal = document.getElementById('statusChangeModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'statusChangeModal';
        modal.className = 'modal';
        modal.innerHTML = '<div class="modal-content" id="statusChangeModalContent"></div>';
        document.body.appendChild(modal);
    }
    
    document.getElementById('statusChangeModalContent').innerHTML = modalContent;
    modal.classList.add('show');
    document.body.classList.add('modal-open');
}

// Close status change modal
function closeStatusChangeModal() {
    const modal = document.getElementById('statusChangeModal');
    if (modal) {
        modal.classList.remove('show');
        setTimeout(() => {
            if (document.querySelectorAll('.modal.show').length === 0) {
                document.body.classList.remove('modal-open');
            }
        }, 10);
    }
}

// Process status change
async function processStatusChange(roomId) {
    try {
        const newStatus = document.getElementById('newRoomStatus').value;
        const reason = document.getElementById('statusChangeReason').value;
        const notes = document.getElementById('statusChangeNotes').value.trim();
        
        if (!newStatus) {
            showNotification('Please select a new status', 'error');
            return;
        }
        
        const requestData = {
            status: newStatus,
            reason: reason,
            notes: notes || null,
            changedBy: 'Admin' // This could be dynamic based on logged-in user
        };
        
        const response = await apiCall(`${API_ENDPOINTS.rooms}/${roomId}/status`, {
            method: 'PATCH',
            body: JSON.stringify(requestData)
        });
        
        if (response.success) {
            showNotification(`✓ Room status updated to "${newStatus.replace('_', ' ')}"`, 'success');
            closeStatusChangeModal();
            loadRooms();
        } else {
            showNotification('Error: ' + (response.message || 'Failed to update status'), 'error');
        }
        
    } catch (error) {
        console.error('Error updating room status:', error);
        showNotification('Error: ' + (error.message || 'Failed to update status'), 'error');
    }
}

// ====== QUICK BOOKING FUNCTIONALITY ======

// Open quick booking modal for a room
function openQuickBooking(roomId, roomNumber, price) {
    // Redirect to booking page with room pre-selected
    window.location.href = `booking-new.html?room_id=${roomId}&room_number=${roomNumber}&price=${price}`;
}

// View room details in a modal
async function viewRoomDetails(roomId) {
    try {
        const response = await apiCall(`${API_ENDPOINTS.rooms}/${roomId}`);
        if (!response.success) {
            showNotification('Failed to load room details', 'error');
            return;
        }
        
        const room = response.data;
        
        // Get booking information if room is occupied/reserved
        let bookingInfo = '';
        if (room.current_booking_id) {
            try {
                const bookingResponse = await apiCall(`${API_ENDPOINTS.bookings}/${room.current_booking_id}`);
                if (bookingResponse.success) {
                    const booking = bookingResponse.data;
                    bookingInfo = `
                        <div style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                            <h4 style="margin-top: 0; color: #2c3e50;">Current Booking Information</h4>
                            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; font-size: 14px;">
                                <div><strong>Guest:</strong> ${booking.guest_name}</div>
                                <div><strong>Phone:</strong> ${booking.guest_phone || 'N/A'}</div>
                                <div><strong>Check-in:</strong> ${formatDate(booking.check_in)}</div>
                                <div><strong>Check-out:</strong> ${formatDate(booking.check_out)}</div>
                                <div><strong>Guests:</strong> ${booking.number_of_guests}</div>
                                <div><strong>Status:</strong> <span class="badge badge-${booking.booking_status.toLowerCase()}">${booking.booking_status}</span></div>
                            </div>
                        </div>
                    `;
                }
            } catch (err) {
                console.error('Error loading booking info:', err);
            }
        }
        
        const modalContent = `
            <div class="modal-header">
                <h2>Room ${room.room_number} - ${room.room_type}</h2>
                <span class="close" onclick="closeRoomDetailsModal()">&times;</span>
            </div>
            <div class="modal-body" style="max-height: 70vh; overflow-y: auto;">
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin-bottom: 20px;">
                    <div>
                        <h4>Room Information</h4>
                        <p><strong>Room Type:</strong> ${room.room_type}</p>
                        <p><strong>AC Type:</strong> ${room.ac_type || 'AC'}</p>
                        <p><strong>Price:</strong> ₹${parseFloat(room.price).toFixed(2)}/night</p>
                        <p><strong>Bed Count:</strong> ${room.bed_count || 1}</p>
                        <p><strong>Max Guests:</strong> ${room.max_guests || 2}</p>
                    </div>
                    <div>
                        <h4>Status</h4>
                        <p><strong>Room Status:</strong> <span class="room-status ${getRoomStatusClass(room.status)}">${room.status}</span></p>
                        <p><strong>Availability:</strong> <span class="room-status ${getRoomStatusClass(room.availability_status || room.status)}">${room.availability_status || room.status}</span></p>
                        ${room.cleaning_status ? `<p><strong>Cleaning Status:</strong> ${room.cleaning_status}</p>` : ''}
                        ${room.available_from ? `<p><strong>Available From:</strong> ${formatDateTime(room.available_from)}</p>` : ''}
                    </div>
                </div>
                
                ${room.amenities ? `
                    <div style="margin-bottom: 20px;">
                        <h4>Amenities</h4>
                        <p>${room.amenities}</p>
                    </div>
                ` : ''}
                
                ${room.description ? `
                    <div style="margin-bottom: 20px;">
                        <h4>Description</h4>
                        <p>${room.description}</p>
                    </div>
                ` : ''}
                
                ${bookingInfo}
                
                ${room.pending_tasks > 0 ? `
                    <div style="margin-top: 15px; padding: 10px; background: #fff3cd; border-radius: 4px;">
                        <i class="fas fa-tasks"></i> <strong>${room.pending_tasks}</strong> pending cleaning task(s)
                    </div>
                ` : ''}
                
                ${room.pending_maintenance > 0 ? `
                    <div style="margin-top: 10px; padding: 10px; background: #f8d7da; border-radius: 4px;">
                        <i class="fas fa-tools"></i> <strong>${room.pending_maintenance}</strong> pending maintenance issue(s)
                    </div>
                ` : ''}
            </div>
            <div class="modal-footer">
                ${room.availability_status === 'Available' || room.availability_status === 'Available (Early Checkout)' ? `
                    <button class="btn btn-success" onclick="closeRoomDetailsModal(); openQuickBooking(${room.room_id}, '${room.room_number}', ${room.price})">
                        <i class="fas fa-calendar-plus"></i> Book This Room
                    </button>
                ` : ''}
                <button class="btn btn-primary" onclick="closeRoomDetailsModal(); editRoom(${room.room_id})">
                    <i class="fas fa-edit"></i> Edit Room
                </button>
                <button class="btn btn-secondary" onclick="closeRoomDetailsModal()">Close</button>
            </div>
        `;
        
        let modal = document.getElementById('roomDetailsModal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'roomDetailsModal';
            modal.className = 'modal';
            modal.innerHTML = '<div class="modal-content" id="roomDetailsModalContent"></div>';
            document.body.appendChild(modal);
        }
        
        document.getElementById('roomDetailsModalContent').innerHTML = modalContent;
        modal.classList.add('show');
        document.body.classList.add('modal-open');
        
    } catch (error) {
        console.error('Error loading room details:', error);
        showNotification('Error loading room details', 'error');
    }
}

// Close room details modal
function closeRoomDetailsModal() {
    const modal = document.getElementById('roomDetailsModal');
    if (modal) {
        modal.classList.remove('show');
        setTimeout(() => {
            if (document.querySelectorAll('.modal.show').length === 0) {
                document.body.classList.remove('modal-open');
            }
        }, 10);
    }
}

// Helper function to format date and time
function formatDateTime(dateTimeString) {
    if (!dateTimeString) return 'N/A';
    const date = new Date(dateTimeString);
    const options = { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    };
    return date.toLocaleDateString('en-US', options);
}

// Load rooms on page load
window.addEventListener('DOMContentLoaded', loadRooms);

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('roomModal');
    if (event.target === modal) {
        closeRoomModal();
    }
};
