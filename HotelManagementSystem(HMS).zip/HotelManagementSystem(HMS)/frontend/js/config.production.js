// Production API Configuration for cPanel Deployment
const API_BASE_URL = 'https://hms.algolizen.com/api'; // Your subdomain
const TAX_RATE = 0.18; // 18% GST

// API Endpoints
const API_ENDPOINTS = {
    rooms: `${API_BASE_URL}/rooms`,
    guests: `${API_BASE_URL}/guests`,
    bookings: `${API_BASE_URL}/bookings`,
    bookingFlow: `${API_BASE_URL}/booking-flow`,
    services: `${API_BASE_URL}/services`,
    serviceOrders: `${API_BASE_URL}/service-orders`,
    guestSessions: `${API_BASE_URL}/guest-sessions`,
    inventories: `${API_BASE_URL}/inventories`,
    housekeeping: `${API_BASE_URL}/housekeeping`,
    invoices: `${API_BASE_URL}/invoices`,
    payments: `${API_BASE_URL}/payments`
};

// Utility function to make API calls
async function apiCall(url, options = {}) {
    try {
        const response = await fetch(url, {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        });
        
        const data = await response.json();
        
        if (!data.success && response.status >= 400) {
            throw new Error(data.message || 'API request failed');
        }
        
        return data;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// Format currency display
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR'
    }).format(amount);
}

// Format date display  
function formatDate(date) {
    return new Date(date).toLocaleDateString('en-IN');
}

// Format date-time display
function formatDateTime(date) {
    return new Date(date).toLocaleString('en-IN');
}

// Calculate tax amount
function calculateTax(amount) {
    return amount * TAX_RATE;
}

// Calculate total with tax
function calculateTotal(amount) {
    return amount + calculateTax(amount);
}

// Error handling helper
function showError(message) {
    console.error('Error:', message);
    // You can replace this with your preferred error display method
    alert(`Error: ${message}`);
}

// Success message helper  
function showSuccess(message) {
    console.log('Success:', message);
    // You can replace this with your preferred success display method
    alert(`Success: ${message}`);
}

// Loading state helper
function setLoading(element, isLoading) {
    if (isLoading) {
        element.style.opacity = '0.6';
        element.style.pointerEvents = 'none';
    } else {
        element.style.opacity = '1';
        element.style.pointerEvents = 'auto';
    }
}

// Environment configuration
const ENV = {
    isDevelopment: false,
    isProduction: true,
    apiTimeout: 10000, // 10 seconds
    retryAttempts: 3
};

// Export for ES6 modules (if needed)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        API_BASE_URL,
        API_ENDPOINTS, 
        apiCall,
        formatCurrency,
        formatDate,
        formatDateTime,
        calculateTax,
        calculateTotal,
        showError,
        showSuccess,
        setLoading,
        ENV
    };
}