// Payment and Billing Management Functions
// Last Updated: February 26, 2026

// API Configuration
const BILLING_API = {
    invoices: '/api/invoices',
    payments: '/api/payments',
    refunds: '/api/payments/refunds'
};

// ============================================
// INVOICE MANAGEMENT FUNCTIONS
// ============================================

// Generate invoice for a booking
async function generateInvoice(bookingId) {
    try {
        const response = await fetch(`${BILLING_API.invoices}/generate`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ booking_id: bookingId })
        });

        if (!response.ok) {
            const errorData = await response.text();
            throw new Error(errorData || `HTTP ${response.status}: Failed to generate invoice`);
        }

        const result = await response.json();
        alert(`Invoice generated successfully!\nInvoice Number: ${result.data.invoiceNumber}`);
        return result.data;
    } catch (error) {
        console.error('Error generating invoice:', error);
        alert(`Error: ${error.message}`);
        return null;
    }
}

// Get invoice details
async function getInvoiceDetails(invoiceId) {
    try {
        const response = await fetch(`${BILLING_API.invoices}/${invoiceId}`);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: Failed to fetch invoice`);
        }
        
        const result = await response.json();
        return result.data;
    } catch (error) {
        console.error('Error fetching invoice:', error);
        alert(`Error: ${error.message}`);
        return null;
    }
}

// Get invoice for booking
async function getInvoiceByBooking(bookingId) {
    try {
        const response = await fetch(`${BILLING_API.invoices}/booking/${bookingId}`);
        
        if (!response.ok) {
            if (response.status === 404) {
                return null;
            }
            throw new Error(`HTTP ${response.status}: No invoice found for this booking`);
        }
        
        const result = await response.json();
        return result.data;
    } catch (error) {
        console.error('Error fetching invoice:', error);
        return null;
    }
}

// List all invoices
async function listInvoices(limit = 100, offset = 0) {
    try {
        const response = await fetch(`${BILLING_API.invoices}?limit=${limit}&offset=${offset}`);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: Failed to fetch invoices`);
        }
        
        const result = await response.json();
        return result.data;
    } catch (error) {
        console.error('Error fetching invoices:', error);
        alert(`Error: ${error.message}`);
        return [];
    }
}

// Print invoice
async function printInvoice(invoiceId) {
    try {
        const invoice = await getInvoiceDetails(invoiceId);
        if (!invoice) return;

        const printContent = generateInvoicePrintHTML(invoice);
        const printWindow = window.open('', '', 'height=800,width=1000');
        printWindow.document.write(printContent);
        printWindow.document.close();
        
        setTimeout(() => {
            printWindow.print();
            printWindow.close();
        }, 250);
    } catch (error) {
        console.error('Error printing invoice:', error);
        alert('Failed to print invoice');
    }
}

// Generate invoice HTML for printing
function generateInvoicePrintHTML(invoice) {
    const subtotalAfterDiscount = invoice.subtotal - invoice.discount_amount;
    
    return `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Invoice ${invoice.invoice_number}</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                .header { text-align: center; margin-bottom: 30px; border-bottom: 3px solid #333; padding-bottom: 20px; }
                .invoice-title { font-size: 28px; font-weight: bold; color: #333; }
                .invoice-details { display: flex; justify-content: space-between; margin: 20px 0; }
                .detail-section { width: 30%; }
                .detail-section h3 { margin-bottom: 10px; color: #666; }
                .detail-section p { margin: 5px 0; }
                .items-table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                .items-table th { background-color: #f0f0f0; padding: 10px; text-align: left; border-bottom: 2px solid #333; }
                .items-table td { padding: 10px; border-bottom: 1px solid #ddd; }
                .amounts-section { width: 50%; margin-left: auto; margin-top: 20px; }
                .amount-row { display: flex; justify-content: space-between; padding: 8px 0; }
                .total-row { display: flex; justify-content: space-between; padding: 12px 0; border-top: 2px solid #333; font-weight: bold; font-size: 16px; }
                .highlight { color: #00a86b; background-color: #f0f0f0; padding: 10px; border-radius: 5px; margin-top: 20px; }
                .footer { text-align: center; margin-top: 40px; color: #666; font-size: 12px; }
                @media print { body { margin: 0; } page-break-after: avoid; }
            </style>
        </head>
        <body>
            <div class="header">
                <div class="invoice-title">INVOICE</div>
                <div style="font-size: 14px; color: #666;">${invoice.invoice_number}</div>
            </div>

            <div class="invoice-details">
                <div class="detail-section">
                    <h3>Bill To:</h3>
                    <p><strong>${invoice.guest_name}</strong></p>
                    <p>Phone: ${invoice.guest_phone || 'N/A'}</p>
                    <p>Room: ${invoice.room_number}</p>
                </div>
                <div class="detail-section">
                    <h3>Invoice Details:</h3>
                    <p>Invoice #: ${invoice.invoice_number}</p>
                    <p>Date: ${new Date(invoice.invoice_date).toLocaleDateString()}</p>
                    <p>Due Date: ${new Date(invoice.due_date).toLocaleDateString()}</p>
                </div>
                <div class="detail-section">
                    <h3>Stay Details:</h3>
                    <p>Check-in: ${new Date(invoice.check_in_date).toLocaleDateString()}</p>
                    <p>Check-out: ${new Date(invoice.check_out_date).toLocaleDateString()}</p>
                    <p>Nights: ${invoice.number_of_nights}</p>
                </div>
            </div>

            <table class="items-table">
                <thead>
                    <tr>
                        <th>Description</th>
                        <th style="text-align: right;">Quantity</th>
                        <th style="text-align: right;">Unit Price</th>
                        <th style="text-align: right;">Total</th>
                    </tr>
                </thead>
                <tbody>
                    ${invoice.items.map(item => `
                        <tr>
                            <td>${item.description}</td>
                            <td style="text-align: right;">${parseFloat(item.quantity).toFixed(2)}</td>
                            <td style="text-align: right;">₹${parseFloat(item.unit_price).toFixed(2)}</td>
                            <td style="text-align: right;">₹${parseFloat(item.total_price).toFixed(2)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>

            <div class="amounts-section">
                <div class="amount-row">
                    <span>Subtotal:</span>
                    <span>₹${parseFloat(invoice.subtotal).toFixed(2)}</span>
                </div>
                ${invoice.discount_amount > 0 ? `
                    <div class="amount-row">
                        <span>Discount (${invoice.discount_type}):</span>
                        <span>-₹${parseFloat(invoice.discount_amount).toFixed(2)}</span>
                    </div>
                ` : ''}
                ${invoice.tax_amount > 0 ? `
                    <div class="amount-row">
                        <span>Tax (${invoice.tax_rate}%):</span>
                        <span>₹${parseFloat(invoice.tax_amount).toFixed(2)}</span>
                    </div>
                ` : ''}
                <div class="total-row">
                    <span>Grand Total:</span>
                    <span>₹${parseFloat(invoice.grand_total).toFixed(2)}</span>
                </div>
                <div class="amount-row">
                    <span>Amount Paid:</span>
                    <span>₹${parseFloat(invoice.amount_paid).toFixed(2)}</span>
                </div>
                <div class="total-row">
                    <span>Amount Due:</span>
                    <span>₹${parseFloat(invoice.amount_due).toFixed(2)}</span>
                </div>
            </div>

            <div class="highlight">
                Status: <strong>${invoice.status.replace(/_/g, ' ')}</strong>
            </div>

            <div class="footer">
                <p>Thank you for your stay!</p>
                <p>This is a computer-generated invoice. No signature is required.</p>
            </div>
        </body>
        </html>
    `;
}

// ============================================
// PAYMENT MANAGEMENT FUNCTIONS
// ============================================

// Record payment
async function recordPayment(paymentData) {
    try {
        const response = await fetch(BILLING_API.payments, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(paymentData)
        });

        if (!response.ok) {
            const errorData = await response.text();
            throw new Error(errorData || `HTTP ${response.status}: Failed to record payment`);
        }

        const result = await response.json();
        alert(`Payment recorded successfully!\nPayment Number: ${result.data.paymentNumber}\nAmount: ₹${paymentData.amount}`);
        return result.data;
    } catch (error) {
        console.error('Error recording payment:', error);
        alert(`Error: ${error.message}`);
        return null;
    }
}

// Get payment details
async function getPaymentDetails(paymentId) {
    try {
        const response = await fetch(`${BILLING_API.payments}/${paymentId}`);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: Failed to fetch payment`);
        }
        
        const result = await response.json();
        return result.data;
    } catch (error) {
        console.error('Error fetching payment:', error);
        alert(`Error: ${error.message}`);
        return null;
    }
}

// Get payments for invoice
async function getInvoicePayments(invoiceId) {
    try {
        const response = await fetch(`${BILLING_API.payments}/invoice/${invoiceId}`);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: Failed to fetch payments`);
        }
        
        const result = await response.json();
        return result.data;
    } catch (error) {
        console.error('Error fetching payments:', error);
        alert(`Error: ${error.message}`);
        return [];
    }
}

// Get payment methods
async function getPaymentMethods() {
    try {
        const response = await fetch(`${BILLING_API.payments}/methods/list`);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: Failed to fetch payment methods`);
        }
        
        const result = await response.json();
        return result.data;
    } catch (error) {
        console.error('Error fetching payment methods:', error);
        return [];
    }
}

// Print payment receipt
async function printPaymentReceipt(paymentId) {
    try {
        const response = await fetch(`${BILLING_API.payments}/${paymentId}/receipt`);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: Failed to fetch receipt data`);
        }
        
        const result = await response.json();

        const receipt = result.data;
        const receiptHTML = generateReceiptHTML(receipt);
        const printWindow = window.open('', '', 'height=800,width=1000');
        printWindow.document.write(receiptHTML);
        printWindow.document.close();
        
        setTimeout(() => {
            printWindow.print();
            printWindow.close();
        }, 250);
    } catch (error) {
        console.error('Error printing receipt:', error);
        alert('Failed to print receipt');
    }
}

// Generate receipt HTML for printing
function generateReceiptHTML(receipt) {
    return `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Payment Receipt ${receipt.payment_number}</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; text-align: center; }
                .receipt-box { max-width: 400px; margin: 0 auto; border: 2px solid #333; padding: 20px; }
                .receipt-header { font-size: 24px; font-weight: bold; margin-bottom: 20px; }
                .divider { border-top: 2px solid #333; margin: 15px 0; }
                .receipt-row { display: flex; justify-content: space-between; padding: 8px 0; }
                .receipt-row.highlight { font-weight: bold; font-size: 16px; padding: 10px 0; background-color: #f0f0f0; }
                .text-center { text-align: center; }
                .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
                @media print { body { margin: 0; } }
            </style>
        </head>
        <body>
            <div class="receipt-box">
                <div class="receipt-header">
                    <i class="fas fa-check-circle" style="color: #00a86b;"></i>
                    <br>Payment Receipt
                </div>

                <div class="divider"></div>

                <div class="receipt-row">
                    <span>Receipt #:</span>
                    <span>${receipt.payment_number}</span>
                </div>
                <div class="receipt-row">
                    <span>Date & Time:</span>
                    <span>${new Date(receipt.payment_date).toLocaleString()}</span>
                </div>
                <div class="receipt-row">
                    <span>Guest Name:</span>
                    <span>${receipt.guest_name}</span>
                </div>
                <div class="receipt-row">
                    <span>Invoice #:</span>
                    <span>${receipt.invoice_number}</span>
                </div>

                <div class="divider"></div>

                <div class="receipt-row">
                    <span>Payment Method:</span>
                    <span>${receipt.payment_method}</span>
                </div>
                <div class="receipt-row">
                    <span>Reference #:</span>
                    <span>${receipt.reference_number || 'N/A'}</span>
                </div>
                <div class="receipt-row">
                    <span>Received By:</span>
                    <span>${receipt.received_by}</span>
                </div>

                <div class="divider"></div>

                <div class="receipt-row highlight">
                    <span>Amount Paid:</span>
                    <span>₹${parseFloat(receipt.amount).toFixed(2)}</span>
                </div>

                <div class="divider"></div>

                <div class="text-center" style="color: #00a86b; font-weight: bold; margin-top: 20px;">
                    PAYMENT SUCCESSFUL
                </div>

                <div class="footer">
                    <p>Thank you for your payment!</p>
                    <p>This is a computer-generated receipt.</p>
                    <p>For inquiries, please contact reception.</p>
                </div>
            </div>
        </body>
        </html>
    `;
}

// Process refund
async function processRefund(paymentId, refundAmount, reason) {
    try {
        const response = await fetch(`${BILLING_API.payments}/${paymentId}/refund`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                refund_amount: refundAmount,
                reason: reason
            })
        });

        if (!response.ok) {
            const errorData = await response.text();
            throw new Error(errorData || `HTTP ${response.status}: Failed to process refund`);
        }

        const result = await response.json();


        alert(`Refund processed successfully!\nRefund Number: ${result.data.refundNumber}`);
        return result.data;
    } catch (error) {
        console.error('Error processing refund:', error);
        alert(`Error: ${error.message}`);
        return null;
    }
}

// Get billing statistics
async function getBillingStats(startDate, endDate) {
    try {
        const invoiceStatsResponse = await fetch(`${BILLING_API.invoices}/stats/range?start=${startDate}&end=${endDate}`);
        const paymentStatsResponse = await fetch(`${BILLING_API.payments}/stats/range?start=${startDate}&end=${endDate}`);

        if (!invoiceStatsResponse.ok) {
            throw new Error(`HTTP ${invoiceStatsResponse.status}: Failed to fetch invoice stats`);
        }
        if (!paymentStatsResponse.ok) {
            throw new Error(`HTTP ${paymentStatsResponse.status}: Failed to fetch payment stats`);
        }

        const invoiceStats = await invoiceStatsResponse.json();
        const paymentStats = await paymentStatsResponse.json();

        return {
            invoices: invoiceStats.data,
            payments: paymentStats.data
        };
    } catch (error) {
        console.error('Error fetching statistics:', error);
        return null;
    }
}

// ============================================
// PAYMENT FORM MODAL FUNCTIONS
// ============================================

// Open payment modal
async function openPaymentModal(bookingId, invoiceId) {
    const modal = document.getElementById('paymentModal');
    if (!modal) return;

    // Populate hidden fields
    document.getElementById('paymentBookingId').value = bookingId;
    document.getElementById('paymentInvoiceId').value = invoiceId;

    // Load available payment methods
    const methods = await getPaymentMethods();
    const methodSelect = document.getElementById('paymentMethod');
    if (methodSelect) {
        methodSelect.innerHTML = methods.map(m => 
            `<option value="${m.method_name}">${m.display_name}</option>`
        ).join('');
    }

    modal.style.display = 'flex';
}

// Close payment modal
function closePaymentModal() {
    const modal = document.getElementById('paymentModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

// Submit payment form
async function submitPaymentForm() {
    const bookingId = document.getElementById('paymentBookingId').value;
    const invoiceId = document.getElementById('paymentInvoiceId').value;
    const guestId = document.getElementById('paymentGuestId').value;
    const amount = parseFloat(document.getElementById('paymentAmount').value);
    const method = document.getElementById('paymentMethod').value;
    const reference = document.getElementById('paymentReference').value;
    const notes = document.getElementById('paymentNotes').value;

    if (!amount || amount <= 0) {
        alert('Please enter a valid amount');
        return;
    }

    const result = await recordPayment({
        invoice_id: parseInt(invoiceId),
        booking_id: parseInt(bookingId),
        guest_id: parseInt(guestId),
        amount: amount,
        payment_method: method,
        reference_number: reference,
        received_by: 'Admin',
        notes: notes
    });

    if (result) {
        closePaymentModal();
        location.reload();
    }
}
