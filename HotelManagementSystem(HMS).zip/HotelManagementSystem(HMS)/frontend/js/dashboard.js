// Dashboard JavaScript

// Display current date
document.getElementById('currentDate').textContent = new Date().toLocaleDateString('en-IN', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
});

// Load dashboard data
async function loadDashboard() {
    try {
        // Load dashboard statistics
        const statsResponse = await apiCall(`${API_ENDPOINTS.bookings}/stats/dashboard`);
        if (statsResponse.success) {
            const stats = statsResponse.data;
            
            // Update stats cards
            document.getElementById('availableRooms').textContent = stats.available_rooms || 0;
            document.getElementById('confirmedBookings').textContent = stats.confirmed_bookings || 0;
            document.getElementById('todayCheckIns').textContent = stats.today_checkins || 0;
            document.getElementById('todayRevenue').textContent = formatCurrency(stats.today_revenue || 0);
        }
        
        // Load room statistics
        const roomStatsResponse = await apiCall(`${API_ENDPOINTS.rooms}/stats/overview`);
        if (roomStatsResponse.success) {
            const roomStats = roomStatsResponse.data;
            
            document.getElementById('totalRooms').textContent = roomStats.total_rooms || 0;
            document.getElementById('availableRoomsCount').textContent = roomStats.available_rooms || 0;
            document.getElementById('bookedRooms').textContent = roomStats.booked_rooms || 0;
            document.getElementById('maintenanceRooms').textContent = roomStats.maintenance_rooms || 0;
            
            // Calculate occupancy rate
            const occupancyRate = roomStats.total_rooms > 0 
                ? ((roomStats.booked_rooms / roomStats.total_rooms) * 100).toFixed(1)
                : 0;
            
            document.getElementById('occupancyRate').textContent = `${occupancyRate}%`;
            document.getElementById('occupancyFill').style.width = `${occupancyRate}%`;
        }
        
        // Load today's check-ins
        const checkInsResponse = await apiCall(`${API_ENDPOINTS.bookings}/today/checkins`);
        if (checkInsResponse.success) {
            displayCheckIns(checkInsResponse.data);
        }
        
        // Load today's check-outs
        const checkOutsResponse = await apiCall(`${API_ENDPOINTS.bookings}/today/checkouts`);
        if (checkOutsResponse.success) {
            displayCheckOuts(checkOutsResponse.data);
        }
        
        // Load pending service orders
        const pendingOrdersResponse = await fetch(`${API_BASE_URL}/service-orders/pending`);
        if (pendingOrdersResponse.ok) {
            const result = await pendingOrdersResponse.json();
            if (result.success) {
                document.getElementById('pendingOrders').textContent = result.data.length;
            }
        }
        
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

// Display today's check-ins
function displayCheckIns(checkIns) {
    const container = document.getElementById('todayCheckInsList');
    
    if (checkIns.length === 0) {
        container.innerHTML = '<p class="text-muted">No check-ins scheduled for today</p>';
        return;
    }
    
    container.innerHTML = checkIns.map(booking => `
        <div class="list-item">
            <h4>${booking.guest_name}</h4>
            <p><i class="fas fa-bed"></i> Room ${booking.room_number} (${booking.room_type})</p>
            <p><i class="fas fa-phone"></i> ${booking.guest_phone}</p>
        </div>
    `).join('');
}

// Display today's check-outs
function displayCheckOuts(checkOuts) {
    const container = document.getElementById('todayCheckOutsList');
    
    if (checkOuts.length === 0) {
        container.innerHTML = '<p class="text-muted">No check-outs scheduled for today</p>';
        return;
    }
    
    container.innerHTML = checkOuts.map(booking => `
        <div class="list-item">
            <h4>${booking.guest_name}</h4>
            <p><i class="fas fa-bed"></i> Room ${booking.room_number} (${booking.room_type})</p>
            <p><i class="fas fa-rupee-sign"></i> ${formatCurrency(booking.total_amount)}</p>
        </div>
    `).join('');
}

// Load dashboard on page load
window.addEventListener('DOMContentLoaded', loadDashboard);

// Refresh dashboard every 30 seconds
setInterval(loadDashboard, 30000);
