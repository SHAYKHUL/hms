// Financial Management - Frontend Logic
// Manage income, expenses, and staff salary payments

let allStaff = [];

// Initialize on page load
document.addEventListener('DOMContentLoaded', async function() {
    console.log('Financial Management loaded');
    await loadStaffForSalary();
    await loadFinancialOverview();
    
    // Load data for the active tab
    const activeTab = document.querySelector('.tab-button.active');
    if (activeTab) {
        const tabName = activeTab.textContent.toLowerCase().includes('income') ? 'income' : 
                       activeTab.textContent.toLowerCase().includes('expense') ? 'expense' : 'salary';
        switchTab(tabName);
    } else {
        loadIncomes();
    }
});

// ============ STAFF DATA LOADING (for salary dropdown) ============

async function loadStaffForSalary() {
    try {
        console.log('Loading staff for salary management...');
        const response = await fetch(`${API_BASE_URL}/housekeeping/staff`);
        if (!response.ok) throw new Error('Failed to load staff');
        
        const result = await response.json();
        if (result.success) {
            allStaff = result.data || [];
            console.log(`Loaded ${allStaff.length} staff members`);
        }
    } catch (error) {
        console.error('Error loading staff:', error);
        showError('Failed to load staff data');
    }
}

// ============ FINANCIAL OVERVIEW ============

async function loadFinancialOverview() {
    try {
        const response = await fetch(`${API_BASE_URL}/financial/overview`);
        const result = await response.json();
        
        if (result.success && result.data) {
            displayFinancialOverview(result.data);
        }
    } catch (error) {
        console.error('Error loading financial overview:', error);
    }
}

function displayFinancialOverview(data) {
    const container = document.getElementById('financialStatsContainer');
    if (!container) return;
    
    const totalIncome = parseFloat(data.total_income || 0);
    const totalExpense = parseFloat(data.total_expenses || 0);
    const netProfit = totalIncome - totalExpense;
    
    container.innerHTML = `
        <div class="stat-card" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%);">
            <h4>Total Income</h4>
            <div class="value">₹${totalIncome.toFixed(2)}</div>
        </div>
        <div class="stat-card" style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);">
            <h4>Total Expenses</h4>
            <div class="value">₹${totalExpense.toFixed(2)}</div>
        </div>
        <div class="stat-card" style="background: linear-gradient(135deg, ${netProfit >= 0 ? '#3b82f6 0%, #2563eb' : '#f59e0b 0%, #d97706'} 100%);">
            <h4>Net Profit/Loss</h4>
            <div class="value">₹${netProfit.toFixed(2)}</div>
        </div>
        <div class="stat-card" style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);">
            <h4>Pending Salaries</h4>
            <div class="value">${data.pending_salaries || 0}</div>
        </div>
    `;
}

// ============ TAB SWITCHING ============

function switchTab(tabName) {
    // Remove active class from all tabs and contents
    document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    
    // Add active class to clicked tab and content
    const tabButton = Array.from(document.querySelectorAll('.tab-button')).find(btn => 
        btn.onclick.toString().includes(`'${tabName}'`)
    );
    if (tabButton) tabButton.classList.add('active');
    
    const content = document.getElementById(tabName);
    if (content) content.classList.add('active');
    
    // Load data for the specific tab
    if (tabName === 'salary') {
        loadSalaries();
    } else if (tabName === 'income') {
        loadIncomes();
    } else if (tabName === 'expense') {
        loadExpenses();
    }
}

// ============ SALARY MANAGEMENT ============

async function loadSalaries() {
    try {
        const monthFilter = document.getElementById('salaryMonthFilter')?.value || '';
        let url = `${API_BASE_URL}/financial/salaries`;
        if (monthFilter) {
            url += `?payment_month=${monthFilter}`;
        }
        
        const response = await fetch(url);
        const result = await response.json();
        
        if (result.success) {
            displaySalaries(result.data || []);
            populateSalaryMonthFilter();
        }
    } catch (error) {
        console.error('Error loading salaries:', error);
        showError('Failed to load salary records');
    }
}

function displaySalaries(salaries) {
    const tbody = document.getElementById('salaryTableBody');
    if (!tbody) return;
    
    if (salaries.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; color: #999;">No salary records found</td></tr>';
        return;
    }
    
    let html = '';
    salaries.forEach(salary => {
        const netAmount = parseFloat(salary.base_salary) + parseFloat(salary.bonus || 0) - parseFloat(salary.deduction || 0);
        const statusClass = salary.status === 'Paid' ? 'badge-success' : 'badge-warning';
        
        html += `
            <tr>
                <td>${salary.staff_name}</td>
                <td>${salary.payment_month}</td>
                <td>₹${parseFloat(salary.base_salary).toFixed(2)}</td>
                <td>₹${parseFloat(salary.bonus || 0).toFixed(2)}</td>
                <td>₹${parseFloat(salary.deduction || 0).toFixed(2)}</td>
                <td><strong>₹${netAmount.toFixed(2)}</strong></td>
                <td><span class="badge ${statusClass}">${salary.status}</span></td>
                <td>
                    <button class="btn-sm btn-edit" onclick="viewSalaryDetails(${salary.salary_id})">
                        <i class="fas fa-eye"></i>
                    </button>
                    ${salary.status === 'Pending' ? `
                    <button class="btn-sm btn-delete" onclick="deleteSalary(${salary.salary_id})">
                        <i class="fas fa-trash"></i>
                    </button>` : ''}
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

function populateSalaryMonthFilter() {
    const select = document.getElementById('salaryMonthFilter');
    if (!select || select.options.length > 1) return;
    
    const months = [];
    const today = new Date();
    for (let i = 0; i < 12; i++) {
        const date = new Date(today.getFullYear(), today.getMonth() - i, 1);
        const monthStr = date.toISOString().substring(0, 7);
        months.push(monthStr);
    }
    
    months.forEach(month => {
        const option = document.createElement('option');
        option.value = month;
        option.textContent = new Date(month + '-01').toLocaleDateString('en-US', { year: 'numeric', month: 'long' });
        select.appendChild(option);
    });
}

function openSalaryModal() {
    document.getElementById('salaryForm').reset();
    document.getElementById('salaryModal').style.display = 'block';
    populateSalaryStaffDropdown();
    
    // Set default date and month
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('salaryPaymentDate').value = today;
    document.getElementById('salaryMonth').value = new Date().toISOString().substring(0, 7);
}

function closeSalaryModal() {
    document.getElementById('salaryModal').style.display = 'none';
}

function populateSalaryStaffDropdown() {
    const select = document.getElementById('salaryStaff');
    if (!select) return;
    
    select.innerHTML = '<option value="">Select Staff</option>';
    allStaff.filter(s => s.status === 'Active').forEach(staff => {
        const option = document.createElement('option');
        option.value = staff.staff_id;
        option.textContent = `${staff.staff_name} - ${staff.role}`;
        option.dataset.salary = staff.monthly_salary || 0;
        select.appendChild(option);
    });
    
    // Auto-fill salary when staff is selected
    select.addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        const baseSalary = selectedOption.dataset.salary || 0;
        document.getElementById('salaryBase').value = baseSalary;
    });
}

async function saveSalary(event) {
    event.preventDefault();
    
    const formData = {
        staff_id: document.getElementById('salaryStaff').value,
        payment_month: document.getElementById('salaryMonth').value,
        base_salary: document.getElementById('salaryBase').value,
        bonus: document.getElementById('salaryBonus').value || 0,
        deduction: document.getElementById('salaryDeduction').value || 0,
        payment_date: document.getElementById('salaryPaymentDate').value,
        payment_method: document.getElementById('salaryPaymentMethod').value,
        notes: document.getElementById('salaryNotes').value
    };
    
    try {
        const response = await fetch(`${API_BASE_URL}/financial/salaries`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });
        
        const result = await response.json();
        if (result.success) {
            showSuccess('Salary payment recorded successfully');
            closeSalaryModal();
            loadSalaries();
            loadFinancialOverview();
        } else {
            showError(result.message || 'Failed to record salary payment');
        }
    } catch (error) {
        console.error('Error saving salary:', error);
        showError('Failed to record salary payment');
    }
}

async function deleteSalary(salaryId) {
    if (!confirm('Are you sure you want to delete this salary record?')) return;
    
    try {
        const response = await fetch(`${API_BASE_URL}/financial/salaries/${salaryId}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        if (result.success) {
            showSuccess('Salary record deleted');
            loadSalaries();
            loadFinancialOverview();
        } else {
            showError(result.message || 'Failed to delete salary record');
        }
    } catch (error) {
        console.error('Error deleting salary:', error);
        showError('Failed to delete salary record');
    }
}

function viewSalaryDetails(salaryId) {
    // Future implementation for viewing detailed salary information
    showInfo('Salary details view coming soon');
}

// ============ INCOME MANAGEMENT ============

async function loadIncomes() {
    try {
        const fromDate = document.getElementById('incomeFromDate')?.value || '';
        const toDate = document.getElementById('incomeToDate')?.value || '';
        
        let url = `${API_BASE_URL}/financial/income`;
        const params = new URLSearchParams();
        if (fromDate) params.append('from_date', fromDate);
        if (toDate) params.append('to_date', toDate);
        if (params.toString()) url += `?${params.toString()}`;
        
        const response = await fetch(url);
        const result = await response.json();
        
        if (result.success) {
            displayIncomes(result.data || []);
            updateIncomeStats(result.data || []);
        }
    } catch (error) {
        console.error('Error loading incomes:', error);
        showError('Failed to load income records');
    }
}

function displayIncomes(incomes) {
    const tbody = document.getElementById('incomeTableBody');
    if (!tbody) return;
    
    if (incomes.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; color: #999;">No income records found</td></tr>';
        return;
    }
    
    let html = '';
    incomes.forEach(income => {
        html += `
            <tr>
                <td>${new Date(income.income_date).toLocaleDateString()}</td>
                <td>${income.income_type}</td>
                <td>${income.source}</td>
                <td><strong>₹${parseFloat(income.amount).toFixed(2)}</strong></td>
                <td>${income.payment_method}</td>
                <td>${income.description || '-'}</td>
                <td>
                    <button class="btn-sm btn-edit" onclick="editIncome(${income.income_id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-sm btn-delete" onclick="deleteIncome(${income.income_id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

function updateIncomeStats(incomes) {
    let total = 0;
    let roomIncome = 0;
    let serviceIncome = 0;
    
    incomes.forEach(income => {
        const amount = parseFloat(income.amount);
        total += amount;
        if (income.income_type === 'Room Booking') roomIncome += amount;
        if (income.income_type === 'Service') serviceIncome += amount;
    });
    
    const totalEl = document.getElementById('totalIncome');
    const roomEl = document.getElementById('roomIncome');
    const serviceEl = document.getElementById('serviceIncome');
    
    if (totalEl) totalEl.textContent = `₹${total.toFixed(2)}`;
    if (roomEl) roomEl.textContent = `₹${roomIncome.toFixed(2)}`;
    if (serviceEl) serviceEl.textContent = `₹${serviceIncome.toFixed(2)}`;
}

function openIncomeModal() {
    document.getElementById('incomeForm').reset();
    document.getElementById('incomeModal').style.display = 'block';
    document.getElementById('incomeDate').value = new Date().toISOString().split('T')[0];
}

function closeIncomeModal() {
    document.getElementById('incomeModal').style.display = 'none';
}

async function saveIncome(event) {
    event.preventDefault();
    
    const formData = {
        income_date: document.getElementById('incomeDate').value,
        income_type: document.getElementById('incomeType').value,
        source: document.getElementById('incomeSource').value,
        amount: document.getElementById('incomeAmount').value,
        payment_method: document.getElementById('incomePaymentMethod').value,
        description: document.getElementById('incomeDescription').value
    };
    
    try {
        const response = await fetch(`${API_BASE_URL}/financial/income`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });
        
        const result = await response.json();
        if (result.success) {
            showSuccess('Income recorded successfully');
            closeIncomeModal();
            loadIncomes();
            loadExpenses(); // Refresh net profit
            loadFinancialOverview();
        } else {
            showError(result.message || 'Failed to record income');
        }
    } catch (error) {
        console.error('Error saving income:', error);
        showError('Failed to record income');
    }
}

function editIncome(incomeId) {
    // Future implementation for editing income
    showInfo('Edit income feature coming soon');
}

async function deleteIncome(incomeId) {
    if (!confirm('Are you sure you want to delete this income record?')) return;
    
    try {
        const response = await fetch(`${API_BASE_URL}/financial/income/${incomeId}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        if (result.success) {
            showSuccess('Income record deleted');
            loadIncomes();
            loadExpenses(); // Refresh net profit
            loadFinancialOverview();
        } else {
            showError(result.message || 'Failed to delete income record');
        }
    } catch (error) {
        console.error('Error deleting income:', error);
        showError('Failed to delete income record');
    }
}

// ============ EXPENSE MANAGEMENT ============

async function loadExpenses() {
    try {
        const fromDate = document.getElementById('expenseFromDate')?.value || '';
        const toDate = document.getElementById('expenseToDate')?.value || '';
        const category = document.getElementById('expenseCategoryFilter')?.value || '';
        
        let url = `${API_BASE_URL}/financial/expenses`;
        const params = new URLSearchParams();
        if (fromDate) params.append('from_date', fromDate);
        if (toDate) params.append('to_date', toDate);
        if (category) params.append('category', category);
        if (params.toString()) url += `?${params.toString()}`;
        
        const response = await fetch(url);
        const result = await response.json();
        
        if (result.success) {
            displayExpenses(result.data || []);
            await updateExpenseStats(result.data || []);
        }
    } catch (error) {
        console.error('Error loading expenses:', error);
        showError('Failed to load expense records');
    }
}

function displayExpenses(expenses) {
    const tbody = document.getElementById('expenseTableBody');
    if (!tbody) return;
    
    if (expenses.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; color: #999;">No expense records found</td></tr>';
        return;
    }
    
    let html = '';
    expenses.forEach(expense => {
        html += `
            <tr>
                <td>${new Date(expense.expense_date).toLocaleDateString()}</td>
                <td><span class="badge badge-secondary">${expense.category}</span></td>
                <td>${expense.description}</td>
                <td><strong>₹${parseFloat(expense.amount).toFixed(2)}</strong></td>
                <td>${expense.payment_method}</td>
                <td>${expense.vendor || '-'}</td>
                <td>
                    <button class="btn-sm btn-edit" onclick="editExpense(${expense.expense_id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-sm btn-delete" onclick="deleteExpense(${expense.expense_id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

async function updateExpenseStats(expenses) {
    let total = 0;
    let thisMonth = 0;
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    expenses.forEach(expense => {
        const amount = parseFloat(expense.amount);
        total += amount;
        
        const expenseDate = new Date(expense.expense_date);
        if (expenseDate.getMonth() === currentMonth && expenseDate.getFullYear() === currentYear) {
            thisMonth += amount;
        }
    });
    
    const totalEl = document.getElementById('totalExpense');
    const monthEl = document.getElementById('monthExpense');
    
    if (totalEl) totalEl.textContent = `₹${total.toFixed(2)}`;
    if (monthEl) monthEl.textContent = `₹${thisMonth.toFixed(2)}`;
    
    // Calculate net profit
    try {
        const incomeResponse = await fetch(`${API_BASE_URL}/financial/income`);
        const incomeResult = await incomeResponse.json();
        if (incomeResult.success) {
            const totalIncome = incomeResult.data.reduce((sum, inc) => sum + parseFloat(inc.amount), 0);
            const netProfit = totalIncome - total;
            const profitEl = document.getElementById('netProfit');
            if (profitEl) {
                profitEl.textContent = `₹${netProfit.toFixed(2)}`;
                profitEl.style.color = netProfit >= 0 ? 'inherit' : '#ef4444';
            }
        }
    } catch (error) {
        console.error('Error calculating net profit:', error);
    }
}

function openExpenseModal() {
    document.getElementById('expenseForm').reset();
    document.getElementById('expenseModal').style.display = 'block';
    document.getElementById('expenseDate').value = new Date().toISOString().split('T')[0];
}

function closeExpenseModal() {
    document.getElementById('expenseModal').style.display = 'none';
}

async function saveExpense(event) {
    event.preventDefault();
    
    const formData = {
        expense_date: document.getElementById('expenseDate').value,
        category: document.getElementById('expenseCategory').value,
        description: document.getElementById('expenseDescription').value,
        amount: document.getElementById('expenseAmount').value,
        payment_method: document.getElementById('expensePaymentMethod').value,
        vendor: document.getElementById('expenseVendor').value,
        receipt_number: document.getElementById('expenseReceipt').value,
        notes: document.getElementById('expenseNotes').value
    };
    
    try {
        const response = await fetch(`${API_BASE_URL}/financial/expenses`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });
        
        const result = await response.json();
        if (result.success) {
            showSuccess('Expense recorded successfully');
            closeExpenseModal();
            loadExpenses();
            loadFinancialOverview();
        } else {
            showError(result.message || 'Failed to record expense');
        }
    } catch (error) {
        console.error('Error saving expense:', error);
        showError('Failed to record expense');
    }
}

function editExpense(expenseId) {
    // Future implementation for editing expense
    showInfo('Edit expense feature coming soon');
}

async function deleteExpense(expenseId) {
    if (!confirm('Are you sure you want to delete this expense record?')) return;
    
    try {
        const response = await fetch(`${API_BASE_URL}/financial/expenses/${expenseId}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        if (result.success) {
            showSuccess('Expense record deleted');
            loadExpenses();
            loadFinancialOverview();
        } else {
            showError(result.message || 'Failed to delete expense record');
        }
    } catch (error) {
        console.error('Error deleting expense:', error);
        showError('Failed to delete expense record');
    }
}

// ============ UTILITY FUNCTIONS ============

function showSuccess(message) {
    alert(message); // Simple implementation, can be enhanced with toast notifications
}

function showError(message) {
    alert('Error: ' + message);
}

function showInfo(message) {
    alert(message);
}

// Close modals when clicking outside
window.onclick = function(event) {
    const modals = ['salaryModal', 'incomeModal', 'expenseModal'];
    modals.forEach(modalId => {
        const modal = document.getElementById(modalId);
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
}
