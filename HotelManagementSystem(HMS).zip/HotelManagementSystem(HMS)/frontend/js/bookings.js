// Bookings Management JavaScript

let allBookings = [];
let currentStep = 1;
let selectedGuest = null;
let selectedRoom = null;

// Load all bookings
async function loadBookings() {
    try {
        const response = await apiCall(`${API_ENDPOINTS.bookings}`);
        if (response.success) {
            allBookings = response.data;
            displayBookings(allBookings);
        }
    } catch (error) {
        document.getElementById('bookingsTable').innerHTML = '<tr><td colspan="9" class="text-danger">Error loading bookings</td></tr>';
    }
}

// Display bookings
function displayBookings(bookings) {
    const tbody = document.getElementById('bookingsTable');
    
    if (bookings.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No bookings found</td></tr>';
        return;
    }
    
    tbody.innerHTML = bookings.map(booking => {
        let menuItems = `
            <button class="action-item" onclick="viewBooking(${booking.booking_id})">
                <i class="fas fa-eye"></i> View
            </button>
        `;
        
        if (booking.booking_status === 'Confirmed') {
            menuItems += `
                <button class="action-item" onclick="checkIn(${booking.booking_id})">
                    <i class="fas fa-sign-in-alt"></i> Check-in
                </button>
                <button class="action-item" onclick="openExtensionModal(${booking.booking_id})">
                    <i class="fas fa-arrow-right"></i> Extend Stay
                </button>
            `;
        } else if (booking.booking_status === 'CheckedIn') {
            menuItems += `
                <button class="action-item" onclick="checkOut(${booking.booking_id})">
                    <i class="fas fa-sign-out-alt"></i> Check-out
                </button>
            `;
        }
        
        if (booking.booking_status === 'Confirmed' || booking.booking_status === 'CheckedIn') {
            menuItems += `
                <button class="action-item danger" onclick="cancelBooking(${booking.booking_id})">
                    <i class="fas fa-times"></i> Cancel
                </button>
            `;
        }
        
        return `
            <tr>
                <td>#${booking.booking_id}</td>
                <td>${booking.guest_name}</td>
                <td>Room ${booking.room_number}</td>
                <td>${formatDate(booking.check_in)}</td>
                <td>${formatDate(booking.check_out)}</td>
                <td>${formatCurrency(booking.total_amount)}</td>
                <td><span class="badge badge-${getPaymentBadge(booking.payment_status)}">${booking.payment_status}</span></td>
                <td><span class="badge badge-${getStatusBadge(booking.booking_status)}">${booking.booking_status}</span></td>
                <td>
                    <div class="action-menu">
                        <button class="action-btn" onclick="toggleActionMenu(this)">
                            <i class="fas fa-ellipsis-v"></i>
                        </button>
                        <div class="action-dropdown">
                            ${menuItems}
                        </div>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
    
    // Close dropdowns when clicking outside (attach once)
    if (!window._bookingActionListenerAdded) {
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.action-menu')) {
                document.querySelectorAll('.action-dropdown').forEach(d => d.classList.remove('show'));
            }
        });
        window._bookingActionListenerAdded = true;
    }
}

function getPaymentBadge(status) {
    const badges = {
        'Paid': 'success',
        'Partial': 'warning',
        'Pending': 'danger'
    };
    return badges[status] || 'secondary';
}

function getStatusBadge(status) {
    const badges = {
        'Confirmed': 'info',
        'CheckedIn': 'success',
        'CheckedOut': 'secondary',
        'Cancelled': 'danger'
    };
    return badges[status] || 'secondary';
}

// Toggle action menu dropdown
function toggleActionMenu(btn) {
    const dropdown = btn.nextElementSibling;
    const allDropdowns = document.querySelectorAll('.action-dropdown');
    
    allDropdowns.forEach(d => {
        if (d !== dropdown) d.classList.remove('show');
    });
    
    dropdown.classList.toggle('show');
}

// Filter bookings
function filterBookings() {
    const statusFilter = document.getElementById('statusFilter').value;
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    
    let filtered = allBookings;
    
    if (statusFilter) {
        filtered = filtered.filter(b => b.booking_status === statusFilter);
    }
    
    if (searchTerm) {
        filtered = filtered.filter(b => 
            b.guest_name.toLowerCase().includes(searchTerm) ||
            b.room_number.toLowerCase().includes(searchTerm)
        );
    }
    
    displayBookings(filtered);
}

// Open New Booking Modal
function openNewBookingModal() {
    currentStep = 1;
    selectedGuest = null;
    selectedRoom = null;
    document.getElementById('bookingForm').reset();
    showStep(1);
    document.getElementById('bookingModal').classList.add('show');
    // focus first input in modal for accessibility
    setTimeout(() => {
        const guestSearch = document.getElementById('guestSearch');
        const guestName = document.getElementById('guestName');
        if (guestSearch) guestSearch.focus(); else if (guestName) guestName.focus();
    }, 50);
    // prevent body scroll while modal open
    document.body.classList.add('modal-open');
}

// Close Booking Modal
function closeBookingModal() {
    document.getElementById('bookingModal').classList.remove('show');
    // remove body lock if no other modal open
    setTimeout(() => {
        if (document.querySelectorAll('.modal.show').length === 0) document.body.classList.remove('modal-open');
    }, 10);
}

// Navigation between steps
function showStep(step) {
    document.querySelectorAll('.booking-step').forEach(el => el.classList.remove('active'));
    document.getElementById(`step${step}`).classList.add('active');
    currentStep = step;
}

function nextStep(step) {
    if (step === 2) {
        // Validate guest details
        const guestId = document.getElementById('selectedGuestId').value;
        const guestName = document.getElementById('guestName').value;
        
        if (!guestId && !guestName) {
            showNotification('Please select or add guest details', 'error');
            return;
        }
    } else if (step === 3) {
        // Validate room selection
        const roomId = document.getElementById('selectedRoomId').value;
        const checkIn = document.getElementById('checkIn').value;
        const checkOut = document.getElementById('checkOut').value;
        
        if (!checkIn || !checkOut) {
            showNotification('Please select check-in and check-out dates', 'error');
            return;
        }
        
        if (!roomId) {
            showNotification('Please select a room', 'error');
            return;
        }
        
        // Show booking summary
        showBookingSummary();
    }
    
    showStep(step);
}

function prevStep(step) {
    showStep(step);
}

// Handle discount type change
function updateDiscountDisplay() {
    const discountType = document.getElementById('discountType').value;
    const discountValueGroup = document.getElementById('discountValueGroup');
    
    if (discountType === 'None') {
        discountValueGroup.style.display = 'none';
        document.getElementById('discountValue').value = 0;
    } else {
        discountValueGroup.style.display = 'block';
    }
    
    updateBookingSummary();
}

// Update booking summary with discount
function updateBookingSummary() {
    showBookingSummary();
}

// Search guests
let searchTimeout;
async function searchGuests() {
    clearTimeout(searchTimeout);
    const searchTerm = document.getElementById('guestSearch').value;
    
    if (searchTerm.length < 2) {
        document.getElementById('guestResults').innerHTML = '';
        return;
    }
    
    searchTimeout = setTimeout(async () => {
        try {
            const response = await apiCall(`${API_ENDPOINTS.guests}/search/contact?q=${searchTerm}`);
            if (response.success) {
                displayGuestResults(response.data);
            }
        } catch (error) {
            console.error('Error searching guests:', error);
        }
    }, 300);
}

function displayGuestResults(guests) {
    const container = document.getElementById('guestResults');

    container.innerHTML = '';
    if (!guests || guests.length === 0) {
        container.innerHTML = '<div class="search-result-item">No guests found</div>';
        return;
    }

    guests.forEach(guest => {
        const div = document.createElement('div');
        div.className = 'search-result-item';
        const name = document.createElement('strong');
        name.textContent = guest.name;
        const br = document.createElement('br');
        const small = document.createElement('small');
        small.textContent = guest.phone + (guest.email ? ' | ' + guest.email : '');

        div.appendChild(name);
        div.appendChild(br);
        div.appendChild(small);

        div.addEventListener('click', () => {
            selectGuest(guest.guest_id, guest.name.replace(/'/g, "\'"), guest.phone.replace(/'/g, "\'"), (guest.email||'').replace(/'/g, "\'"), (guest.id_proof||'').replace(/'/g, "\\'"), (guest.address||'').replace(/'/g, "\\'"));
        });

        container.appendChild(div);
    });
}

function selectGuest(id, name, phone, email, idProof, address) {
    document.getElementById('selectedGuestId').value = id;
    document.getElementById('guestName').value = name;
    document.getElementById('guestPhone').value = phone;
    document.getElementById('guestEmail').value = email;
    document.getElementById('guestIdProof').value = idProof;
    document.getElementById('guestAddress').value = address;
    document.getElementById('guestResults').innerHTML = '';
    document.getElementById('guestSearch').value = name;
}

// Search available rooms
async function searchAvailableRooms() {
    const checkIn = document.getElementById('checkIn').value;
    const checkOut = document.getElementById('checkOut').value;
    const acType = document.getElementById('acTypeFilter').value;
    
    if (!checkIn || !checkOut) {
        return;
    }
    
    if (new Date(checkOut) <= new Date(checkIn)) {
        showNotification('Check-out date must be after check-in date', 'error');
        return;
    }
    
    try {
        let url = `${API_ENDPOINTS.rooms}/available/search?checkIn=${checkIn}&checkOut=${checkOut}`;
        if (acType) {
            url += `&acType=${encodeURIComponent(acType)}`;
        }
        const response = await apiCall(url);
        if (response.success) {
            displayAvailableRooms(response.data);
        }
    } catch (error) {
        console.error('Error loading available rooms:', error);
    }
}

function displayAvailableRooms(rooms) {
    const container = document.getElementById('availableRooms');
    
    if (rooms.length === 0) {
        container.innerHTML = '<p class="text-muted">No rooms available for selected dates</p>';
        return;
    }
    
    container.innerHTML = rooms.map(room => `
        <div class="available-room-item" onclick="selectRoom(${room.room_id}, '${room.room_number}', '${room.room_type}', '${room.ac_type}', ${room.price}, this)">
            <strong>Room ${room.room_number}</strong><br>
            <small>${room.room_type} • ${room.ac_type}</small><br>
            <strong>${formatCurrency(room.price)}/night</strong>
        </div>
    `).join('');
}

function selectRoom(id, number, type, acType, price, el) {
    document.getElementById('selectedRoomId').value = id;
    document.getElementById('roomPrice').value = price;
    selectedRoom = { id, number, type, acType, price };
    
    // Highlight selected room
    document.querySelectorAll('.available-room-item').forEach(el => el.classList.remove('selected'));
    if (el && el.classList) el.classList.add('selected');
}

// Show booking summary
function showBookingSummary() {
    const checkIn = document.getElementById('checkIn').value;
    const checkOut = document.getElementById('checkOut').value;
    const roomPrice = parseFloat(document.getElementById('roomPrice').value);
    const guestName = document.getElementById('guestName').value;
    const numberOfGuests = parseInt(document.getElementById('numberOfGuests').value) || 1;
    
    const days = calculateDays(checkIn, checkOut);
    const subtotal = roomPrice * days;
    
    // Calculate discount
    const discountType = document.getElementById('discountType').value;
    const discountValue = parseFloat(document.getElementById('discountValue').value) || 0;
    let discount = 0;
    if (discountType === 'Percentage') {
        discount = subtotal * (discountValue / 100);
    } else if (discountType === 'Fixed') {
        discount = discountValue;
    }
    
    const afterDiscount = Math.max(0, subtotal - discount);
    const tax = afterDiscount * TAX_RATE;
    const total = afterDiscount + tax;
    
    const summaryHTML = `
        <h4>Booking Summary</h4>
        <div class="summary-item">
            <span>Guest:</span>
            <strong>${guestName}</strong>
        </div>
        <div class="summary-item">
            <span>Room:</span>
            <strong>${selectedRoom ? `${selectedRoom.number} (${selectedRoom.type} • ${selectedRoom.acType})` : 'Not selected'}</strong>
        </div>
        <div class="summary-item">
            <span>Number of Guests:</span>
            <strong>${numberOfGuests}</strong>
        </div>
        <div class="summary-item">
            <span>Check-in:</span>
            <strong>${formatDate(checkIn)}</strong>
        </div>
        <div class="summary-item">
            <span>Check-out:</span>
            <strong>${formatDate(checkOut)}</strong>
        </div>
        <div class="summary-item">
            <span>Number of Nights:</span>
            <strong>${days}</strong>
        </div>
        <div class="summary-item">
            <span>Room Rate:</span>
            <strong>${formatCurrency(roomPrice)}/night</strong>
        </div>
        <div class="summary-item">
            <span>Subtotal:</span>
            <strong>${formatCurrency(subtotal)}</strong>
        </div>
        ${discount > 0 ? `
        <div class="summary-item" style="color: green;">
            <span>Discount (${discountType === 'Percentage' ? discountValue + '%' : formatCurrency(discountValue)}):</span>
            <strong>-${formatCurrency(discount)}</strong>
        </div>
        ` : ''}
        <div class="summary-item">
            <span>Subtotal after Discount:</span>
            <strong>${formatCurrency(afterDiscount)}</strong>
        </div>
        <div class="summary-item">
            <span>Tax (18% GST):</span>
            <strong>${formatCurrency(tax)}</strong>
        </div>
        <div class="summary-item summary-total">
            <span>Total Amount:</span>
            <strong>${formatCurrency(total)}</strong>
        </div>
    `;
    
    document.getElementById('bookingSummary').innerHTML = summaryHTML;
}

// Handle booking form submission
document.getElementById('bookingForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    try {
        // Validate step 1: Guest details
        const guestName = document.getElementById('guestName').value.trim();
        const guestPhone = document.getElementById('guestPhone').value.trim();
        const guestIdProof = document.getElementById('guestIdProof').value.trim();
        
        const guestErrors = [];
        if (!guestName) guestErrors.push('Guest name is required');
        if (!guestPhone) guestErrors.push('Phone number is required');
        if (!guestIdProof) guestErrors.push('ID proof is required');
        
        if (guestErrors.length > 0) {
            showNotification('Please fix guest details:\n• ' + guestErrors.join('\n• '), 'error');
            return;
        }
        
        // Validate step 2: Room and date selection
        const checkIn = document.getElementById('checkIn').value;
        const checkOut = document.getElementById('checkOut').value;
        const roomId = document.getElementById('selectedRoomId').value;
        const numberOfGuests = document.getElementById('numberOfGuests').value;
        
        const roomErrors = [];
        if (!checkIn) roomErrors.push('Check-in date is required');
        if (!checkOut) roomErrors.push('Check-out date is required');
        if (!roomId) roomErrors.push('Please select a room');
        if (!numberOfGuests || numberOfGuests < 1) roomErrors.push('Invalid number of guests');
        
        if (roomErrors.length > 0) {
            showNotification('Please fix booking details:\n• ' + roomErrors.join('\n• '), 'error');
            return;
        }
        
        if (new Date(checkOut) <= new Date(checkIn)) {
            showNotification('Check-out date must be after check-in date', 'error');
            return;
        }
        
        // Create guest if new
        let guestId = document.getElementById('selectedGuestId').value;
        
        if (!guestId) {
            const guestData = {
                name: guestName,
                phone: guestPhone,
                email: document.getElementById('guestEmail').value.trim(),
                id_proof: guestIdProof,
                address: document.getElementById('guestAddress').value.trim()
            };
            
            const guestResponse = await apiCall(`${API_ENDPOINTS.guests}`, {
                method: 'POST',
                body: JSON.stringify(guestData)
            });
            
            if (!guestResponse.success) {
                showNotification('Error: ' + (guestResponse.message || 'Failed to create guest'), 'error');
                return;
            }
            
            guestId = guestResponse.guestId;
        }
        
        // Calculate total amount
        const roomPrice = parseFloat(document.getElementById('roomPrice').value);
        const days = calculateDays(checkIn, checkOut);
        const subtotal = roomPrice * days;
        
        // Calculate discount
        const discountType = document.getElementById('discountType').value;
        const discountValue = parseFloat(document.getElementById('discountValue').value) || 0;
        let discount = 0;
        if (discountType === 'Percentage') {
            if (discountValue < 0 || discountValue > 100) {
                showNotification('Discount percentage must be between 0 and 100', 'error');
                return;
            }
            discount = subtotal * (discountValue / 100);
        } else if (discountType === 'Fixed') {
            discount = discountValue;
        }
        
        const afterDiscount = Math.max(0, subtotal - discount);
        const tax = afterDiscount * TAX_RATE;
        const total = afterDiscount + tax;
        
        // Create booking
        const bookingData = {
            guest_id: guestId,
            room_id: roomId,
            check_in: checkIn,
            check_out: checkOut,
            number_of_guests: parseInt(numberOfGuests),
            room_price: roomPrice,
            total_amount: total,
            discount_type: discountType,
            discount_value: discountValue,
            discount_reason: document.getElementById('discountReason').value.trim(),
            advance_payment: parseFloat(document.getElementById('advancePayment').value) || 0,
            payment_method: document.getElementById('paymentMethod').value,
            special_requests: document.getElementById('specialRequests').value.trim()
        };
        
        const bookingResponse = await apiCall(`${API_ENDPOINTS.bookings}`, {
            method: 'POST',
            body: JSON.stringify(bookingData)
        });
        
        if (!bookingResponse.success) {
            if (bookingResponse.errors && Array.isArray(bookingResponse.errors)) {
                showNotification('Booking Error:\n• ' + bookingResponse.errors.join('\n• '), 'error');
            } else {
                showNotification('Error: ' + (bookingResponse.message || 'Failed to create booking'), 'error');
            }
            return;
        }
        
        showNotification('✓ Booking created successfully!', 'success');
        closeBookingModal();
        loadBookings();
    } catch (error) {
        console.error('Error creating booking:', error);
        showNotification('Error: ' + (error.message || 'Failed to create booking'), 'error');
    }
});

// View booking details
async function viewBooking(bookingId) {
    try {
        const response = await apiCall(`${API_ENDPOINTS.bookings}/${bookingId}`);
        if (response.success) {
            const booking = response.data;
            
            const detailsHTML = `
                <div style="padding: 20px;">
                    <h3>Booking #${booking.booking_id}</h3>
                    <div style="margin-top: 20px;">
                        <h4>Guest Details</h4>
                        <p><strong>Name:</strong> ${booking.guest_name}</p>
                        <p><strong>Phone:</strong> ${booking.guest_phone}</p>
                        ${booking.guest_email ? `<p><strong>Email:</strong> ${booking.guest_email}</p>` : ''}
                    </div>
                    <div style="margin-top: 20px;">
                        <h4>Booking Details</h4>
                        <p><strong>Room:</strong> ${booking.room_number} (${booking.room_type})</p>
                        <p><strong>Check-in:</strong> ${formatDate(booking.check_in)}</p>
                        <p><strong>Check-out:</strong> ${formatDate(booking.check_out)}</p>
                        <p><strong>Status:</strong> <span class="badge badge-${getStatusBadge(booking.booking_status)}">${booking.booking_status}</span></p>
                    </div>
                    <div style="margin-top: 20px;">
                        <h4>Payment Details</h4>
                        <p><strong>Total Amount:</strong> ${formatCurrency(booking.total_amount)}</p>
                        <p><strong>Payment Status:</strong> <span class="badge badge-${getPaymentBadge(booking.payment_status)}">${booking.payment_status}</span></p>
                    </div>
                </div>
            `;
            
            document.getElementById('bookingDetailsContent').innerHTML = detailsHTML;
                    document.getElementById('bookingDetailsModal').classList.add('show');
                    // lock body scroll while details modal open
                    document.body.classList.add('modal-open');
        }
    } catch (error) {
        console.error('Error loading booking details:', error);
    }
}

function closeDetailsModal() {
    document.getElementById('bookingDetailsModal').classList.remove('show');
    setTimeout(() => {
        if (document.querySelectorAll('.modal.show').length === 0) document.body.classList.remove('modal-open');
    }, 10);
}

// Check-in
async function checkIn(bookingId) {
    if (!confirm('Confirm check-in for this booking?')) return;
    
    try {
        const response = await apiCall(`${API_ENDPOINTS.bookings}/${bookingId}/checkin`, {
            method: 'PATCH'
        });
        
        if (response.success) {
            if (response.data && response.data.pin) {
                // Show guest access token
                showGuestAccessToken(response.data);
            } else {
                showNotification('✓ Check-in successful!', 'success');
            }
            loadBookings();
        } else {
            showNotification('Error: ' + (response.message || 'Failed to check-in'), 'error');
        }
    } catch (error) {
        console.error('Error checking in:', error);
        showNotification('Error: ' + (error.message || 'Failed to check-in'), 'error');
    }
}

// Show Guest Access Token Modal
function showGuestAccessToken(sessionData) {
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.7);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
    `;
    
    modal.innerHTML = `
        <div style="background: white; padding: 2rem; border-radius: 10px; max-width: 500px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
            <div style="text-align: center; margin-bottom: 1.5rem;">
                <i class="fas fa-key" style="font-size: 3rem; color: #667eea; margin-bottom: 1rem;"></i>
                <h2 style="color: #333; margin: 0;">Guest Access PIN</h2>
                <p style="color: #666; margin-top: 0.5rem;">Share this PIN with the guest for portal access</p>
            </div>
            
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 1.5rem; border-radius: 10px; text-align: center; margin-bottom: 1.5rem;">
                <p style="margin: 0; font-size: 0.875rem; opacity: 0.9;">PIN Code</p>
                <h1 style="margin: 0.5rem 0 0 0; font-size: 2.5rem; letter-spacing: 5px; font-weight: bold;">${sessionData.pin}</h1>
            </div>
            
            <div style="background: #f8f9fa; padding: 1rem; border-radius: 5px; margin-bottom: 1.5rem;">
                <p style="margin: 0 0 0.5rem 0; color: #333; font-weight: bold;">Instructions:</p>
                <ol style="margin: 0; padding-left: 1.5rem; color: #666; font-size: 0.875rem;">
                    <li>Give this PIN to the guest</li>
                    <li>Guest enters PIN on Guest Portal page</li>
                    <li>PIN automatically expires at check-out</li>
                </ol>
            </div>
            
            <button onclick="copyToClipboard('${sessionData.pin}')" style="width: 100%; padding: 0.75rem; background: #667eea; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: bold; margin-bottom: 0.5rem;">
                <i class="fas fa-copy"></i> Copy PIN to Clipboard
            </button>
            <button onclick="this.closest('[style*=position]').remove();" style="width: 100%; padding: 0.75rem; background: #e0e0e0; color: #333; border: none; border-radius: 5px; cursor: pointer; font-weight: bold;">
                OK, Done
            </button>
        </div>
    `;
    
    document.body.appendChild(modal);
}

// Copy to Clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showNotification('PIN copied to clipboard!', 'success');
    }).catch(() => {
        alert('PIN: ' + text);
    });
}

// Check-out
async function checkOut(bookingId) {
    if (!confirm('Confirm check-out for this booking?')) return;
    
    try {
        const response = await apiCall(`${API_ENDPOINTS.bookings}/${bookingId}/checkout`, {
            method: 'PATCH'
        });
        
        if (response.success) {
            showNotification('✓ Check-out successful!', 'success');
            loadBookings();
        } else {
            showNotification('Error: ' + (response.message || 'Failed to check-out'), 'error');
        }
    } catch (error) {
        console.error('Error checking out:', error);
        showNotification('Error: ' + (error.message || 'Failed to check-out'), 'error');
    }
}

// Cancel booking
async function cancelBooking(bookingId) {
    if (!confirm('Are you sure you want to cancel this booking? This action cannot be undone.')) return;
    
    try {
        const response = await apiCall(`${API_ENDPOINTS.bookings}/${bookingId}/cancel`, {
            method: 'PATCH'
        });
        
        if (response.success) {
            showNotification('✓ Booking cancelled successfully!', 'success');
            loadBookings();
        } else {
            showNotification('Error: ' + (response.message || 'Failed to cancel booking'), 'error');
        }
    } catch (error) {
        console.error('Error cancelling booking:', error);
        showNotification('Error: ' + (error.message || 'Failed to cancel booking'), 'error');
    }
}

// ====== BOOKING EXTENSION FUNCTIONS ======

// Open extension request modal
async function openExtensionModal(bookingId) {
    const booking = allBookings.find(b => b.booking_id == bookingId);
    if (!booking) return;
    
    document.getElementById('extensionBookingId').value = bookingId;
    document.getElementById('extensionCurrentCheckout').innerText = formatDate(booking.check_out);
    document.getElementById('currentRoomInfo').innerText = `Room ${booking.room_number} (${booking.room_type})`;
    // Set extension date input min/default to one day after current check-out (local date)
    const currentCheckout = new Date(booking.check_out);
    const nextDay = new Date(currentCheckout);
    nextDay.setDate(currentCheckout.getDate() + 1);
    const toYMD = (d) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
    const minDateStr = toYMD(nextDay);
    const extensionInput = document.getElementById('extensionNewCheckout');
    if (extensionInput) {
        extensionInput.min = minDateStr;
        // Pre-fill with next available date to avoid accidental past selections
        extensionInput.value = minDateStr;
    }
    document.getElementById('extensionResults').innerHTML = '';
    document.getElementById('extensionModal').classList.add('show');
    document.body.classList.add('modal-open');
}

function closeExtensionModal() {
    document.getElementById('extensionModal').classList.remove('show');
    setTimeout(() => {
        if (document.querySelectorAll('.modal.show').length === 0) document.body.classList.remove('modal-open');
    }, 10);
}

// Check extension options
async function checkExtensionOptions() {
    try {
        const bookingId = document.getElementById('extensionBookingId').value;
        const newCheckout = document.getElementById('extensionNewCheckout').value;
        
        if (!newCheckout) {
            showNotification('Please select a new check-out date', 'warning');
            return;
        }
        
        const response = await apiCall(`${API_ENDPOINTS.bookings}/${bookingId}/extension-options?new_check_out=${newCheckout}`);
        
        if (response.success) {
            displayExtensionOptions(response.data);
        } else {
            showNotification('Error: ' + (response.message || 'Failed to check options'), 'error');
        }
    } catch (error) {
        console.error('Error checking extension:', error);
        showNotification('Error: ' + (error.message || 'Failed to check extension options'), 'error');
    }
}

// Display extension options
function displayExtensionOptions(options) {
    const resultsDiv = document.getElementById('extensionResults');
    resultsDiv.innerHTML = '';
    
    // Show current status
    const statusHtml = `
        <div class="alert ${options.canExtend ? 'alert-success' : 'alert-danger'}" style="margin-bottom: 15px;">
            <strong>${options.canExtend ? '✓ Extension Available' : '✗ Conflict Detected'}</strong>
            <p style="margin: 5px 0 0 0;">${options.message || options.conflict?.message}</p>
        </div>
    `;
    resultsDiv.innerHTML += statusHtml;
    
    if (options.canExtend) {
        // Simple extension case
        const simpleHtml = `
            <div class="extension-option card" style="margin-bottom: 15px; padding: 15px;">
                <h5 style="margin: 0 0 10px 0;">✓ Same Room Extension</h5>
                <p style="font-size: 14px; margin: 5px 0;">
                    <strong>Period:</strong> ${formatDate(options.currentBooking.check_out)} to ${options.extensionRequest.new_check_out}
                    (${options.extensionRequest.nights_requested} nights)
                </p>
                <p style="font-size: 14px; margin: 5px 0;">
                    <strong>Cost:</strong> ${formatCurrency(options.currentBooking.room_price * options.extensionRequest.nights_requested)}
                </p>
                <button class="btn btn-success btn-sm" onclick="proceedWithExtension('${options.currentBooking.booking_id}', 'same_room')">
                    Approve Extension
                </button>
            </div>
        `;
        resultsDiv.innerHTML += simpleHtml;
    } else {
        // Show alternatives
        if (options.alternatives.alternative_rooms && options.alternatives.alternative_rooms.length > 0) {
            resultsDiv.innerHTML += '<h5 style="margin-top: 20px; margin-bottom: 10px;">Alternative Rooms Available:</h5>';
            
            options.alternatives.alternative_rooms.forEach(room => {
                const altHtml = `
                    <div class="extension-option card" style="margin-bottom: 10px; padding: 12px;">
                        <h6 style="margin: 0 0 5px 0;">Room ${room.room_number} - ${room.room_type}</h6>
                        <p style="font-size: 13px; margin: 3px 0;">
                            Amenities: ${room.amenities || 'N/A'}
                        </p>
                        <p style="font-size: 13px; margin: 3px 0;">
                            <strong>Extension Cost:</strong> ${formatCurrency(room.extension_cost)}
                        </p>
                        <button class="btn btn-info btn-sm" onclick="proceedWithExtension('${options.currentBooking.booking_id}', 'alternative_room', ${room.room_id})">
                            Book This Room
                        </button>
                    </div>
                `;
                resultsDiv.innerHTML += altHtml;
            });
        }
        
        if (options.alternatives.alternative_dates) {
            const altDatesHtml = `
                <div class="extension-option card" style="margin: 15px 0; padding: 12px; border-left: 4px solid #ffc107;">
                    <h5 style="margin: 0 0 10px 0; color: #ff6b6b;">⏳ Alternative Dates</h5>
                    <p style="font-size: 13px; margin: 3px 0;">
                        Current room will be available from: <strong>${formatDate(options.alternatives.alternative_dates.available_from)}</strong>
                    </p>
                    <p style="font-size: 13px; margin: 3px 0;">
                        Wait: <strong>${options.alternatives.alternative_dates.wait_period_days} days</strong>
                    </p>
                    <button class="btn btn-warning btn-sm" onclick="proceedWithExtension('${options.currentBooking.booking_id}', 'alternative_dates')">
                        Book Alternative Dates
                    </button>
                </div>
            `;
            resultsDiv.innerHTML += altDatesHtml;
        }
        
        if (options.alternatives.alternative_rooms.length === 0 && !options.alternatives.alternative_dates) {
            resultsDiv.innerHTML += `
                <div class="alert alert-warning" style="margin-top: 15px;">
                    <strong>No alternatives available</strong> - Please contact support for special requests.
                </div>
            `;
        }
    }
}

// Proceed with extension
async function proceedWithExtension(bookingId, resolutionType, alternativeRoomId = null) {
    try {
        const newCheckout = document.getElementById('extensionNewCheckout').value;
        
        const payload = {
            new_check_out: newCheckout,
            resolution_type: resolutionType
        };
        
        if (alternativeRoomId) {
            payload.resolution_details = {
                alternative_room_id: alternativeRoomId
            };
        }
        
        const response = await apiCall(`${API_ENDPOINTS.bookings}/${bookingId}/extend`, {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        
        if (response.success) {
            showNotification('✓ Booking extended successfully!', 'success');
            closeExtensionModal();
            loadBookings();
        } else {
            showNotification('Error: ' + (response.message || 'Failed to extend booking'), 'error');
        }
    } catch (error) {
        console.error('Error extending booking:', error);
        showNotification('Error: ' + (error.message || 'Failed to extend booking'), 'error');
    }
}

// Load bookings and attach global modal handlers on page load
window.addEventListener('DOMContentLoaded', function() {
    if (typeof loadBookings === 'function') loadBookings();

    // Close modals with Escape
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            // close any open modal by removing .show
            document.querySelectorAll('.modal.show').forEach(m => m.classList.remove('show'));
            // close any open action dropdowns
            document.querySelectorAll('.action-dropdown.show').forEach(d => d.classList.remove('show'));
        }
    });

    // Click outside to close modals (keeps existing behavior)
    window.addEventListener('click', function(event) {
        if (event.target.id === 'bookingModal') closeBookingModal();
        if (event.target.id === 'bookingDetailsModal') closeDetailsModal();
        if (event.target.id === 'extensionModal') closeExtensionModal();
    });

    // Sync guestSearch to guestName so single input works for search and entry
    const guestSearchEl = document.getElementById('guestSearch');
    const guestNameEl = document.getElementById('guestName');
    const selectedGuestIdEl = document.getElementById('selectedGuestId');
    if (guestSearchEl && guestNameEl) {
        guestSearchEl.addEventListener('input', function() {
            // if user types, clear any previously selected guest
            if (selectedGuestIdEl && selectedGuestIdEl.value) selectedGuestIdEl.value = '';
            guestNameEl.value = this.value;
        });
    }
});
