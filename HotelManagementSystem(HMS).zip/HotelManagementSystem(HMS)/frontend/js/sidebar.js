// Sidebar toggle functionality
(function() {
    const container = document.querySelector('.container');
    const toggle = document.getElementById('sidebarToggle');
    const closeBtn = document.getElementById('sidebarClose');

    // Add tooltips to nav links for compact mode
    const links = document.querySelectorAll('.nav-link');
    links.forEach(link => {
        const label = link.querySelector('.nav-label');
        if (label) link.setAttribute('title', label.innerText.trim());
    });

    function setSidebarMode(mode) {
        if (!container) return;
        container.classList.remove('sidebar-compact', 'sidebar-hidden');
        if (mode === 'compact') container.classList.add('sidebar-compact');
        else if (mode === 'hidden') container.classList.add('sidebar-hidden');
        try {
            localStorage.setItem('sidebarMode', mode);
        } catch (e) {}
    }

    // Toggle: expanded <-> compact. If hidden, go to compact.
    if (toggle) {
        toggle.addEventListener('click', () => {
            if (container.classList.contains('sidebar-hidden')) setSidebarMode('compact');
            else if (container.classList.contains('sidebar-compact')) setSidebarMode('expanded');
            else setSidebarMode('compact');
        });
    }

    if (closeBtn) {
        closeBtn.addEventListener('click', () => setSidebarMode('hidden'));
    }

    // Restore previous state
    try {
        const saved = localStorage.getItem('sidebarMode');
        if (saved === 'compact') setSidebarMode('compact');
        else if (saved === 'hidden') setSidebarMode('hidden');
        else setSidebarMode('expanded');
    } catch (e) {}
})();
