const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Import routes
const roomRoutes = require('./routes/rooms');
const guestRoutes = require('./routes/guests');
const bookingRoutes = require('./routes/bookings');
const bookingFlowRoutes = require('./routes/bookingFlow');
const serviceRoutes = require('./routes/services');
const serviceOrderRoutes = require('./routes/serviceOrders');
const guestSessionRoutes = require('./routes/guestSessions');
const inventoryRoutes = require('./routes/inventories');
const housekeepingRoutes = require('./routes/housekeepings');

// Use routes
app.use('/api/rooms', roomRoutes);
app.use('/api/guests', guestRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api/booking-flow', bookingFlowRoutes);
app.use('/api/services', serviceRoutes);
app.use('/api/service-orders', serviceOrderRoutes);
app.use('/api/guest-sessions', guestSessionRoutes);
app.use('/api/inventories', inventoryRoutes);
app.use('/api/housekeeping', housekeepingRoutes);

// Root route
app.get('/', (req, res) => {
    res.json({ 
        message: 'Hotel Management System API',
        version: '2.4.0',
        endpoints: {
            rooms: '/api/rooms',
            guests: '/api/guests',
            bookings: '/api/bookings',
            bookingFlow: '/api/booking-flow',
            services: '/api/services',
            serviceOrders: '/api/service-orders',
            guestSessions: '/api/guest-sessions',
            inventories: '/api/inventories',
            housekeeping: '/api/housekeeping'
        }
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ 
        success: false, 
        message: 'Something went wrong!',
        error: err.message 
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Server is running on http://localhost:${PORT}`);
    console.log(`📚 API Documentation available at http://localhost:${PORT}`);
});

module.exports = app;
