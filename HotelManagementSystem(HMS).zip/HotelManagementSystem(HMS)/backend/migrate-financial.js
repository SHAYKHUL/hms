const db = require('./config/database');
const fs = require('fs');
const path = require('path');

async function runMigration() {
    try {
        console.log('🚀 Starting financial management migration...\n');

        // First, add columns to housekeeping_staff table
        console.log('📝 Adding salary fields to housekeeping_staff table...');
        try {
            await db.query(`
                ALTER TABLE housekeeping_staff 
                ADD COLUMN monthly_salary DECIMAL(10, 2) DEFAULT 0 AFTER assigned_floors,
                ADD COLUMN bank_account VARCHAR(50) AFTER monthly_salary,
                ADD COLUMN emergency_contact VARCHAR(15) AFTER bank_account,
                ADD COLUMN address TEXT AFTER emergency_contact
            `);
            console.log('✅ Salary fields added to housekeeping_staff\n');
        } catch (err) {
            if (err.code === 'ER_DUP_FIELDNAME') {
                console.log('⚠️  Columns already exist, skipping...\n');
            } else {
                throw err;
            }
        }

        // Create staff_salaries table
        console.log('📝 Creating staff_salaries table...');
        await db.query(`
            CREATE TABLE IF NOT EXISTS staff_salaries (
                salary_id INT AUTO_INCREMENT PRIMARY KEY,
                staff_id INT NOT NULL,
                payment_month VARCHAR(7) NOT NULL,
                base_salary DECIMAL(10, 2) NOT NULL,
                bonus DECIMAL(10, 2) DEFAULT 0,
                deductions DECIMAL(10, 2) DEFAULT 0,
                overtime_hours INT DEFAULT 0,
                overtime_amount DECIMAL(10, 2) DEFAULT 0,
                total_amount DECIMAL(10, 2) NOT NULL,
                payment_date DATE NOT NULL,
                payment_method ENUM('Cash', 'Bank Transfer', 'Cheque', 'UPI') DEFAULT 'Bank Transfer',
                payment_status ENUM('Pending', 'Paid', 'Failed') DEFAULT 'Pending',
                payment_reference VARCHAR(100),
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (staff_id) REFERENCES housekeeping_staff(staff_id) ON DELETE CASCADE,
                INDEX idx_staff (staff_id),
                INDEX idx_payment_month (payment_month),
                INDEX idx_payment_status (payment_status),
                INDEX idx_payment_date (payment_date),
                UNIQUE KEY unique_staff_month (staff_id, payment_month)
            )
        `);
        console.log('✅ staff_salaries table created\n');

        // Create income_records table
        console.log('📝 Creating income_records table...');
        await db.query(`
            CREATE TABLE IF NOT EXISTS income_records (
                income_id INT AUTO_INCREMENT PRIMARY KEY,
                income_type ENUM('Room Booking', 'Service', 'Food & Beverage', 'Laundry', 'Event', 'Other') NOT NULL,
                description VARCHAR(255) NOT NULL,
                amount DECIMAL(10, 2) NOT NULL,
                income_date DATE NOT NULL,
                payment_method ENUM('Cash', 'Card', 'UPI', 'Online', 'Bank Transfer') DEFAULT 'Cash',
                booking_id INT NULL,
                service_order_id INT NULL,
                invoice_number VARCHAR(50),
                guest_name VARCHAR(100),
                category VARCHAR(50),
                notes TEXT,
                created_by VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE SET NULL,
                FOREIGN KEY (service_order_id) REFERENCES service_orders(order_id) ON DELETE SET NULL,
                INDEX idx_income_type (income_type),
                INDEX idx_income_date (income_date),
                INDEX idx_payment_method (payment_method),
                INDEX idx_booking (booking_id)
            )
        `);
        console.log('✅ income_records table created\n');

        // Create expense_records table
        console.log('📝 Creating expense_records table...');
        await db.query(`
            CREATE TABLE IF NOT EXISTS expense_records (
                expense_id INT AUTO_INCREMENT PRIMARY KEY,
                expense_type ENUM('Salary', 'Maintenance', 'Inventory', 'Utilities', 'Marketing', 'Insurance', 'Rent', 'Taxes', 'Supplies', 'Equipment', 'Other') NOT NULL,
                description VARCHAR(255) NOT NULL,
                amount DECIMAL(10, 2) NOT NULL,
                expense_date DATE NOT NULL,
                payment_method ENUM('Cash', 'Card', 'UPI', 'Bank Transfer', 'Cheque') DEFAULT 'Bank Transfer',
                vendor_name VARCHAR(100),
                invoice_number VARCHAR(50),
                category VARCHAR(50),
                staff_id INT NULL,
                maintenance_log_id INT NULL,
                inventory_item_id INT NULL,
                payment_status ENUM('Pending', 'Paid') DEFAULT 'Pending',
                approved_by VARCHAR(100),
                notes TEXT,
                receipt_path VARCHAR(255),
                created_by VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (staff_id) REFERENCES housekeeping_staff(staff_id) ON DELETE SET NULL,
                FOREIGN KEY (maintenance_log_id) REFERENCES maintenance_logs(log_id) ON DELETE SET NULL,
                FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(item_id) ON DELETE SET NULL,
                INDEX idx_expense_type (expense_type),
                INDEX idx_expense_date (expense_date),
                INDEX idx_payment_status (payment_status),
                INDEX idx_vendor (vendor_name),
                INDEX idx_staff (staff_id)
            )
        `);
        console.log('✅ expense_records table created\n');

        // Create staff_attendance table
        console.log('📝 Creating staff_attendance table...');
        await db.query(`
            CREATE TABLE IF NOT EXISTS staff_attendance (
                attendance_id INT AUTO_INCREMENT PRIMARY KEY,
                staff_id INT NOT NULL,
                attendance_date DATE NOT NULL,
                check_in_time TIME,
                check_out_time TIME,
                status ENUM('Present', 'Absent', 'Half Day', 'On Leave', 'Holiday') DEFAULT 'Present',
                work_hours DECIMAL(4, 2) DEFAULT 0,
                overtime_hours DECIMAL(4, 2) DEFAULT 0,
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (staff_id) REFERENCES housekeeping_staff(staff_id) ON DELETE CASCADE,
                INDEX idx_staff (staff_id),
                INDEX idx_date (attendance_date),
                INDEX idx_status (status),
                UNIQUE KEY unique_staff_date (staff_id, attendance_date)
            )
        `);
        console.log('✅ staff_attendance table created\n');

        // Insert sample data
        console.log('📝 Inserting sample financial data...');
        
        // Sample income records
        await db.query(`
            INSERT INTO income_records (income_type, description, amount, income_date, payment_method, category, notes) VALUES
            ('Room Booking', 'February Room Bookings', 250000.00, CURDATE(), 'Online', 'Accommodation', 'Monthly room revenue'),
            ('Service', 'Room Service Orders', 45000.00, CURDATE(), 'Cash', 'Food & Beverage', 'February room service'),
            ('Laundry', 'Laundry Services', 12000.00, CURDATE(), 'Cash', 'Ancillary', 'Monthly laundry revenue'),
            ('Other', 'Event Booking', 75000.00, CURDATE(), 'Bank Transfer', 'Events', 'Corporate event booking')
        `);
        console.log('✅ Sample income records inserted\n');

        // Sample expense records
        await db.query(`
            INSERT INTO expense_records (expense_type, description, amount, expense_date, payment_method, vendor_name, payment_status, category) VALUES
            ('Utilities', 'Electricity Bill - February', 35000.00, CURDATE(), 'Bank Transfer', 'City Electricity Board', 'Paid', 'Utilities'),
            ('Utilities', 'Water Bill - February', 8000.00, CURDATE(), 'Bank Transfer', 'City Water Board', 'Paid', 'Utilities'),
            ('Maintenance', 'AC Repair & Servicing', 15000.00, CURDATE(), 'Cash', 'Cool Breeze Services', 'Paid', 'Maintenance'),
            ('Supplies', 'Cleaning Supplies', 12000.00, CURDATE(), 'Cash', 'Clean & Shine Supplies', 'Paid', 'Housekeeping'),
            ('Inventory', 'Toiletries Stock', 25000.00, CURDATE(), 'Bank Transfer', 'Premium Supplies Co.', 'Paid', 'Inventory'),
            ('Marketing', 'Online Advertisement', 8000.00, CURDATE(), 'Card', 'Google Ads', 'Paid', 'Marketing'),
            ('Equipment', 'Vacuum Cleaner Purchase', 18000.00, CURDATE(), 'Card', 'Home Electronics', 'Paid', 'Equipment')
        `);
        console.log('✅ Sample expense records inserted\n');

        console.log('✨ Migration completed successfully!\n');
        console.log('📊 Summary:');
        console.log('   - Updated housekeeping_staff table with salary fields');
        console.log('   - Created staff_salaries table');
        console.log('   - Created income_records table');
        console.log('   - Created expense_records table');
        console.log('   - Created staff_attendance table');
        console.log('   - Inserted sample financial data\n');

        process.exit(0);
    } catch (error) {
        console.error('❌ Migration error:', error.message);
        console.error(error);
        process.exit(1);
    }
}

runMigration();
