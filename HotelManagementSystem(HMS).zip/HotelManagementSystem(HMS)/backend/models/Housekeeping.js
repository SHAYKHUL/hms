const db = require('../config/database');

class Housekeeping {
    // ============ STAFF MANAGEMENT ============

    // Get all housekeeping staff
    static async getAllStaff() {
        const [rows] = await db.query(`
            SELECT 
                staff_id,
                staff_name,
                phone,
                email,
                role,
                shift,
                status,
                assigned_floors,
                monthly_salary,
                hire_date,
                created_at,
                updated_at
            FROM housekeeping_staff
            ORDER BY role DESC, staff_name ASC
        `);
        return rows;
    }

    // Get staff by ID
    static async getStaffById(staffId) {
        const [rows] = await db.query(
            `SELECT * FROM housekeeping_staff WHERE staff_id = ?`,
            [staffId]
        );
        return rows[0];
    }

    // Get active staff
    static async getActiveStaff() {
        const [rows] = await db.query(`
            SELECT 
                staff_id,
                staff_name,
                phone,
                role,
                shift,
                assigned_floors
            FROM housekeeping_staff
            WHERE status = 'Active'
            ORDER BY role DESC, staff_name ASC
        `);
        return rows;
    }

    // Get staff by role
    static async getStaffByRole(role) {
        if (!['Housekeeper', 'Supervisor', 'Manager'].includes(role)) {
            throw new Error('Invalid role');
        }

        const [rows] = await db.query(
            `SELECT * FROM housekeeping_staff WHERE role = ? ORDER BY staff_name ASC`,
            [role]
        );
        return rows;
    }

    // Create new staff
    static async createStaff(staffName, phone, email, role, shift, assignedFloors, hireDate, monthlySalary, bankAccount, emergencyContact, address) {
        if (!staffName || !phone || !role) {
            throw new Error('Staff name, phone, and role are required');
        }

        if (staffName.length < 2 || staffName.length > 100) {
            throw new Error('Staff name must be between 2 and 100 characters');
        }

        if (!['Housekeeper', 'Supervisor', 'Manager'].includes(role)) {
            throw new Error('Invalid role');
        }

        if (shift && !['Morning', 'Afternoon', 'Night'].includes(shift)) {
            throw new Error('Invalid shift');
        }

        const [result] = await db.query(
            `INSERT INTO housekeeping_staff 
            (staff_name, phone, email, role, shift, assigned_floors, hire_date, monthly_salary, bank_account, emergency_contact, address)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [staffName, phone, email || null, role, shift || 'Morning', assignedFloors || null, hireDate || null,
             monthlySalary || 0, bankAccount || null, emergencyContact || null, address || null]
        );

        return { staff_id: result.insertId, staffName, phone, role };
    }

    // Update staff details
    static async updateStaff(staffId, staffData) {
        const staff = await this.getStaffById(staffId);
        if (!staff) {
            throw new Error('Staff not found');
        }

        const { staffName, phone, email, role, shift, assignedFloors, status, 
                monthly_salary, bank_account, emergency_contact, address } = staffData;

        if (role && !['Housekeeper', 'Supervisor', 'Manager'].includes(role)) {
            throw new Error('Invalid role');
        }

        if (shift && !['Morning', 'Afternoon', 'Night'].includes(shift)) {
            throw new Error('Invalid shift');
        }

        if (status && !['Active', 'Inactive', 'On Leave'].includes(status)) {
            throw new Error('Invalid status');
        }

        await db.query(
            `UPDATE housekeeping_staff 
             SET staff_name = COALESCE(?, staff_name),
                 phone = COALESCE(?, phone),
                 email = COALESCE(?, email),
                 role = COALESCE(?, role),
                 shift = COALESCE(?, shift),
                 assigned_floors = COALESCE(?, assigned_floors),
                 status = COALESCE(?, status),
                 monthly_salary = COALESCE(?, monthly_salary),
                 bank_account = COALESCE(?, bank_account),
                 emergency_contact = COALESCE(?, emergency_contact),
                 address = COALESCE(?, address),
                 updated_at = CURRENT_TIMESTAMP
             WHERE staff_id = ?`,
            [staffName || null, phone || null, email || null, role || null, shift || null, 
             assignedFloors || null, status || null, monthly_salary || null, bank_account || null,
             emergency_contact || null, address || null, staffId]
        );

        return { success: true, message: 'Staff updated successfully' };
    }

    // Delete staff
    static async deleteStaff(staffId) {
        const staff = await this.getStaffById(staffId);
        if (!staff) {
            throw new Error('Staff not found');
        }

        await db.query(`DELETE FROM housekeeping_staff WHERE staff_id = ?`, [staffId]);
        return { success: true, message: 'Staff deleted successfully' };
    }

    // Update staff status
    static async updateStaffStatus(staffId, status) {
        if (!['Active', 'Inactive', 'On Leave'].includes(status)) {
            throw new Error('Invalid status');
        }

        const [result] = await db.query(
            `UPDATE housekeeping_staff SET status = ? WHERE staff_id = ?`,
            [status, staffId]
        );

        return { success: result.affectedRows > 0, message: 'Status updated' };
    }

    // ============ STATISTICS ============

    // Get housekeeping statistics
    static async getStatistics() {
        // Total staff
        const [staffCount] = await db.query(`SELECT COUNT(*) as count FROM housekeeping_staff WHERE status = 'Active'`);
        const totalStaff = staffCount[0]?.count || 0;

        // Staff by role
        const [staffByRole] = await db.query(`
            SELECT role, COUNT(*) as count 
            FROM housekeeping_staff 
            WHERE status = 'Active'
            GROUP BY role
        `);

        // Cleaning tasks today
        const [tasksToday] = await db.query(`
            SELECT status, COUNT(*) as count 
            FROM cleaning_tasks 
            WHERE scheduled_date = CURDATE()
            GROUP BY status
        `);

        // Pending maintenance
        const [pendingMaint] = await db.query(`
            SELECT COUNT(*) as count 
            FROM maintenance_logs 
            WHERE status IN ('Reported', 'Assigned', 'In Progress')
        `);

        return {
            totalStaff,
            staffByRole: staffByRole || [],
            tasksToday: tasksToday || [],
            pendingMaintenance: pendingMaint[0]?.count || 0
        };
    }

    // Get shift statistics
    static async getShiftStatistics() {
        const [rows] = await db.query(`
            SELECT 
                shift,
                role,
                COUNT(*) as count,
                SUM(CASE WHEN status = 'Active' THEN 1 ELSE 0 END) as active_count
            FROM housekeeping_staff
            GROUP BY shift, role
            ORDER BY shift ASC
        `);
        return rows;
    }

    // Get busy staff (count of assigned tasks)
    static async getStaffWorkload() {
        const [rows] = await db.query(`
            SELECT 
                s.staff_id,
                s.staff_name,
                s.role,
                COUNT(t.task_id) as assigned_tasks,
                SUM(CASE WHEN t.status != 'Completed' THEN 1 ELSE 0 END) as pending_tasks
            FROM housekeeping_staff s
            LEFT JOIN cleaning_tasks t ON s.staff_id = t.staff_id
            WHERE s.status = 'Active'
            GROUP BY s.staff_id, s.staff_name, s.role
            ORDER BY pending_tasks DESC
        `);
        return rows;
    }
}

module.exports = Housekeeping;
