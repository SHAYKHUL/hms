const db = require('../config/database');
const GuestSession = require('./GuestSession');

class Booking {
    // Get all bookings
    static async getAll() {
        const [rows] = await db.query('SELECT * FROM booking_details ORDER BY created_at DESC');
        return rows;
    }

    // Get booking by ID
    static async getById(id) {
        const [rows] = await db.query('SELECT * FROM booking_details WHERE booking_id = ?', [id]);
        return rows[0];
    }

    // Get active bookings
    static async getActive() {
        const [rows] = await db.query(`
            SELECT * FROM booking_details 
            WHERE booking_status IN ('Confirmed', 'CheckedIn')
            ORDER BY check_in
        `);
        return rows;
    }

    // Create new booking
    static async create(bookingData) {
        const { guest_id, room_id, check_in, check_out, number_of_guests, room_price, total_amount, discount_type, discount_value, discount_reason, advance_payment, payment_method, special_requests } = bookingData;
        
        // Validate dates
        const checkInDate = new Date(check_in);
        const checkOutDate = new Date(check_out);
        if (checkInDate >= checkOutDate) {
            throw new Error('Check-out date must be after check-in date');
        }
        
        // Check for existing bookings
        const [conflicts] = await db.query(
            `SELECT COUNT(*) as count FROM bookings 
             WHERE room_id = ? 
             AND booking_status IN ('Confirmed', 'CheckedIn')
             AND check_in < ? AND check_out > ?`,
            [room_id, check_out, check_in]
        );
        
        if (conflicts[0].count > 0) {
            throw new Error('Room is not available for selected dates');
        }
        
        const payment_status = advance_payment >= total_amount ? 'Paid' : (advance_payment > 0 ? 'Partial' : 'Pending');
        const nights = Math.ceil((checkOutDate - checkInDate) / (1000 * 60 * 60 * 24));
        
        const [result] = await db.query(
            `INSERT INTO bookings 
            (guest_id, room_id, check_in, check_out, number_of_guests, room_price, total_amount, discount_type, discount_value, discount_reason, advance_payment, payment_status, payment_method, special_requests) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [guest_id, room_id, check_in, check_out, number_of_guests || 1, room_price, total_amount, discount_type || 'None', discount_value || 0, discount_reason, advance_payment || 0, payment_status, payment_method || 'Cash', special_requests]
        );
        
        // Update room status to Booked
        await db.query('UPDATE rooms SET status = ? WHERE room_id = ?', ['Booked', room_id]);
        
        return result.insertId;
    }

    // Update booking
    static async update(id, bookingData) {
        const { check_in, check_out, total_amount, advance_payment, payment_method, special_requests } = bookingData;
        
        const payment_status = advance_payment >= total_amount ? 'Paid' : (advance_payment > 0 ? 'Partial' : 'Pending');
        
        const [result] = await db.query(
            `UPDATE bookings 
            SET check_in = ?, check_out = ?, total_amount = ?, advance_payment = ?, 
                payment_status = ?, payment_method = ?, special_requests = ?
            WHERE booking_id = ?`,
            [check_in, check_out, total_amount, advance_payment, payment_status, payment_method, special_requests, id]
        );
        return result.affectedRows;
    }

    // Check-in
    static async checkIn(bookingId) {
        try {
            // Get booking with guest info
            const [booking] = await db.query(
                'SELECT guest_id FROM bookings WHERE booking_id = ?',
                [bookingId]
            );
            
            if (booking.length === 0) {
                throw new Error('Booking not found');
            }
            
            const guestId = booking[0].guest_id;
            
            // Update booking status
            const [result] = await db.query(
                'UPDATE bookings SET booking_status = ? WHERE booking_id = ?',
                ['CheckedIn', bookingId]
            );
            
            // Generate guest access token
            const session = await GuestSession.create(bookingId, guestId);
            
            return {
                affectedRows: result.affectedRows,
                session: {
                    pin: session.pin,
                    token: session.token,
                    bookingId: session.bookingId,
                    guestId: session.guestId
                }
            };
        } catch (error) {
            throw error;
        }
    }

    // Check-out
    static async checkOut(bookingId) {
        try {
            // Remove guest session
            await GuestSession.removeSession(bookingId);
            
            // Update booking status
            const [result] = await db.query(
                'UPDATE bookings SET booking_status = ? WHERE booking_id = ?',
                ['CheckedOut', bookingId]
            );
            
            // Get room_id for this booking
            const [booking] = await db.query('SELECT room_id FROM bookings WHERE booking_id = ?', [bookingId]);
            if (booking.length > 0) {
                // Update room status to Available
                await db.query('UPDATE rooms SET status = ? WHERE room_id = ?', ['Available', booking[0].room_id]);
            }
            
            return result.affectedRows;
        } catch (error) {
            throw error;
        }
    }

    // Cancel booking
    static async cancel(bookingId) {
        const [result] = await db.query(
            'UPDATE bookings SET booking_status = ? WHERE booking_id = ?',
            ['Cancelled', bookingId]
        );
        
        // Get room_id for this booking
        const [booking] = await db.query('SELECT room_id FROM bookings WHERE booking_id = ?', [bookingId]);
        if (booking.length > 0) {
            // Update room status to Available
            await db.query('UPDATE rooms SET status = ? WHERE room_id = ?', ['Available', booking[0].room_id]);
        }
        
        return result.affectedRows;
    }

    // Update payment
    static async updatePayment(bookingId, paymentData) {
        const { advance_payment, payment_method } = paymentData;
        
        // Get total amount
        const [booking] = await db.query('SELECT total_amount FROM bookings WHERE booking_id = ?', [bookingId]);
        const total_amount = booking[0].total_amount;
        
        const payment_status = advance_payment >= total_amount ? 'Paid' : (advance_payment > 0 ? 'Partial' : 'Pending');
        
        const [result] = await db.query(
            'UPDATE bookings SET advance_payment = ?, payment_method = ?, payment_status = ? WHERE booking_id = ?',
            [advance_payment, payment_method, payment_status, bookingId]
        );
        return result.affectedRows;
    }

    // Apply discount to booking
    static async applyDiscount(bookingId, discountType, discountValue, discountReason) {
        const validTypes = ['None', 'Percentage', 'Fixed'];
        if (!validTypes.includes(discountType)) {
            throw new Error('Invalid discount type');
        }

        // Get booking details
        const [bookings] = await db.query('SELECT room_price, number_of_nights FROM bookings WHERE booking_id = ?', [bookingId]);
        if (bookings.length === 0) throw new Error('Booking not found');

        const { room_price, number_of_nights } = bookings[0];
        const baseAmount = room_price * number_of_nights;
        let finalAmount = baseAmount;

        if (discountType === 'Percentage') {
            finalAmount = baseAmount - (baseAmount * discountValue / 100);
        } else if (discountType === 'Fixed') {
            finalAmount = Math.max(0, baseAmount - discountValue);
        }

        const [result] = await db.query(
            `UPDATE bookings 
             SET discount_type = ?, discount_value = ?, discount_reason = ?, total_amount = ?
             WHERE booking_id = ?`,
            [discountType, discountValue, discountReason, finalAmount, bookingId]
        );

        return result.affectedRows;
    }

    // Get today's check-ins
    static async getTodayCheckIns() {
        const [rows] = await db.query(`
            SELECT * FROM booking_details 
            WHERE DATE(check_in) = CURDATE() 
            AND booking_status = 'Confirmed'
            ORDER BY check_in
        `);
        return rows;
    }

    // Get today's check-outs
    static async getTodayCheckOuts() {
        const [rows] = await db.query(`
            SELECT * FROM booking_details 
            WHERE DATE(check_out) = CURDATE() 
            AND booking_status = 'CheckedIn'
            ORDER BY check_out
        `);
        return rows;
    }

    // Get revenue statistics
    static async getRevenueStats(startDate, endDate) {
        const [rows] = await db.query(`
            SELECT 
                COUNT(*) as total_bookings,
                SUM(total_amount) as total_revenue,
                SUM(advance_payment) as collected_amount,
                SUM(total_amount - advance_payment) as pending_amount,
                AVG(total_amount) as average_booking_value
            FROM bookings 
            WHERE check_in BETWEEN ? AND ?
            AND booking_status != 'Cancelled'
        `, [startDate, endDate]);
        return rows[0];
    }

    // Get dashboard statistics
    static async getDashboardStats() {
        const [stats] = await db.query(`
            SELECT 
                (SELECT COUNT(*) FROM bookings WHERE booking_status = 'Confirmed') as confirmed_bookings,
                (SELECT COUNT(*) FROM bookings WHERE booking_status = 'CheckedIn') as checked_in,
                (SELECT COUNT(*) FROM bookings WHERE DATE(check_in) = CURDATE() AND booking_status = 'Confirmed') as today_checkins,
                (SELECT COUNT(*) FROM bookings WHERE DATE(check_out) = CURDATE() AND booking_status = 'CheckedIn') as today_checkouts,
                (SELECT SUM(total_amount) FROM bookings WHERE DATE(created_at) = CURDATE()) as today_revenue,
                (SELECT COUNT(*) FROM rooms WHERE status = 'Available') as available_rooms
        `);
        return stats[0];
    }

    // Check extension options for a booking
    static async getExtensionOptions(bookingId, newCheckOut) {
        try {
            // Get current booking details
            const booking = await this.getById(bookingId);
            if (!booking) {
                throw new Error('Booking not found');
            }

            // Validate new check-out date
            const newCheckOutDate = new Date(newCheckOut);
            const currentCheckOut = new Date(booking.check_out);
            const checkInDate = new Date(booking.check_in);

            if (newCheckOutDate <= currentCheckOut) {
                throw new Error('New check-out date must be after current check-out date');
            }

            // Check for conflicting bookings
            const [conflicts] = await db.query(
                `SELECT * FROM bookings 
                 WHERE room_id = ? 
                 AND booking_id != ?
                 AND booking_status IN ('Confirmed', 'CheckedIn')
                 AND check_in < ? AND check_out > ?`,
                [booking.room_id, bookingId, newCheckOut, booking.check_out]
            );

            const result = {
                currentBooking: {
                    booking_id: booking.booking_id,
                    check_in: booking.check_in,
                    check_out: booking.check_out,
                    room_id: booking.room_id,
                    room_number: booking.room_number,
                    room_price: booking.room_price
                },
                extensionRequest: {
                    new_check_out: newCheckOut,
                    nights_requested: Math.ceil((newCheckOutDate - currentCheckOut) / (1000 * 60 * 60 * 24))
                },
                conflict: null,
                alternatives: {
                    alternative_rooms: [],
                    alternative_dates: [],
                    room_upgrade: null
                }
            };

            // If no conflict, return success
            if (conflicts.length === 0) {
                result.canExtend = true;
                result.message = 'Room is available for extension';
                return result;
            }

            // Conflict exists
            result.canExtend = false;
            result.conflict = {
                conflicting_booking_id: conflicts[0].booking_id,
                conflicting_dates: {
                    from: conflicts[0].check_in,
                    to: conflicts[0].check_out
                },
                message: `Room is booked from ${conflicts[0].check_in} to ${conflicts[0].check_out}`
            };

            // Get alternative rooms for the extension period
            const [alternativeRooms] = await db.query(
                `SELECT DISTINCT r.* FROM rooms r
                 WHERE r.room_id != ?
                 AND r.status = 'Available'
                 AND r.room_id NOT IN (
                    SELECT room_id FROM bookings 
                    WHERE booking_status IN ('Confirmed', 'CheckedIn')
                    AND check_in < ? AND check_out > ?
                 )
                 LIMIT 5`,
                [booking.room_id, newCheckOut, booking.check_out]
            );

            result.alternatives.alternative_rooms = alternativeRooms.map(room => ({
                room_id: room.room_id,
                room_number: room.room_number,
                room_type: room.room_type,
                price: room.price,
                max_guests: room.max_guests,
                amenities: room.amenities,
                extension_cost: parseFloat(room.price) * result.extensionRequest.nights_requested
            }));

            // Get alternative dates - when the current room becomes available
            const [nextAvailable] = await db.query(
                `SELECT MIN(check_out) as available_from FROM bookings
                 WHERE room_id = ? 
                 AND check_out > ?
                 AND booking_status IN ('Confirmed', 'CheckedIn')
                 ORDER BY check_out LIMIT 1`,
                [booking.room_id, booking.check_out]
            );

            if (nextAvailable.length > 0 && nextAvailable[0].available_from) {
                const availableFromDate = new Date(nextAvailable[0].available_from);
                const extensionNights = Math.ceil((newCheckOutDate - availableFromDate) / (1000 * 60 * 60 * 24));
                result.alternatives.alternative_dates = {
                    available_from: nextAvailable[0].available_from,
                    extension_cost: parseFloat(booking.room_price) * extensionNights,
                    wait_period_days: Math.ceil((availableFromDate - currentCheckOut) / (1000 * 60 * 60 * 24))
                };
            }

            return result;
        } catch (error) {
            throw error;
        }
    }

    // Extend booking with conflict resolution
    static async extendBooking(bookingId, extensionData) {
        try {
            const { new_check_out, resolution_type, resolution_details } = extensionData;
            const booking = await this.getById(bookingId);

            if (!booking) {
                throw new Error('Booking not found');
            }

            const newCheckOutDate = new Date(new_check_out);
            const currentCheckOut = new Date(booking.check_out);
            const checkInDate = new Date(booking.check_in);

            const additionalNights = Math.ceil((newCheckOutDate - currentCheckOut) / (1000 * 60 * 60 * 24));
            const additionalCost = parseFloat(booking.room_price) * additionalNights;

            let result = {
                success: true,
                originalBookingId: bookingId,
                extensions: []
            };

            switch (resolution_type) {
                case 'same_room':
                    // Extend in the same room (no conflict)
                    const newTotalAmount = parseFloat(booking.total_amount) + additionalCost;
                    await db.query(
                        'UPDATE bookings SET check_out = ?, total_amount = ? WHERE booking_id = ?',
                        [new_check_out, newTotalAmount, bookingId]
                    );
                    result.extensions.push({
                        type: 'extended',
                        booking_id: bookingId,
                        new_check_out,
                        additional_cost: additionalCost,
                        new_total: newTotalAmount
                    });
                    break;

                case 'alternative_room':
                    // Book additional nights in alternative room
                    const alternativeRoom = await db.query(
                        'SELECT * FROM rooms WHERE room_id = ?',
                        [resolution_details.alternative_room_id]
                    );

                    if (alternativeRoom[0].length === 0) {
                        throw new Error('Alternative room not found');
                    }

                    const altRoomPrice = alternativeRoom[0][0].price;
                    const altBookingAmount = parseFloat(altRoomPrice) * additionalNights;

                    // Create new booking for extension
                    const [altResult] = await db.query(
                        `INSERT INTO bookings 
                        (guest_id, room_id, check_in, check_out, number_of_guests, room_price, total_amount, 
                         discount_type, discount_value, discount_reason, advance_payment, payment_status, 
                         payment_method, special_requests, is_extension, parent_booking_id) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                        [
                            booking.guest_id, resolution_details.alternative_room_id, booking.check_out, 
                            new_check_out, booking.number_of_guests, altRoomPrice, altBookingAmount,
                            'None', 0, 'Extension - Alternative Room', 0, 'Pending', 'Cash', 
                            `Extension of booking #${bookingId}`, true, bookingId
                        ]
                    );

                    result.extensions.push({
                        type: 'new_booking_alternative_room',
                        original_booking_id: bookingId,
                        new_booking_id: altResult.insertId,
                        room_id: resolution_details.alternative_room_id,
                        dates: `${booking.check_out} to ${new_check_out}`,
                        cost: altBookingAmount
                    });
                    break;

                case 'alternative_dates':
                    // Extend to alternative dates on same room
                    const [nextAvailable] = await db.query(
                        `SELECT MIN(check_out) as available_from FROM bookings
                         WHERE room_id = ? 
                         AND check_out > ?
                         AND booking_status IN ('Confirmed', 'CheckedIn')
                         ORDER BY check_out LIMIT 1`,
                        [booking.room_id, booking.check_out]
                    );

                    let newExtensionCheckOut;
                    if (nextAvailable.length > 0 && nextAvailable[0].available_from) {
                        newExtensionCheckOut = nextAvailable[0].available_from;
                    } else {
                        newExtensionCheckOut = new_check_out;
                    }

                    const altNights = Math.ceil((new Date(newExtensionCheckOut) - currentCheckOut) / (1000 * 60 * 60 * 24));
                    const altNightsCost = parseFloat(booking.room_price) * altNights;
                    const newTotalAlt = parseFloat(booking.total_amount) + altNightsCost;

                    await db.query(
                        'UPDATE bookings SET check_out = ?, total_amount = ? WHERE booking_id = ?',
                        [newExtensionCheckOut, newTotalAlt, bookingId]
                    );

                    result.extensions.push({
                        type: 'extended_alternative_dates',
                        booking_id: bookingId,
                        original_requested: new_check_out,
                        approved_until: newExtensionCheckOut,
                        additional_cost: altNightsCost,
                        new_total: newTotalAlt,
                        note: 'Extended to next available date'
                    });
                    break;

                default:
                    throw new Error('Invalid resolution type');
            }

            return result;
        } catch (error) {
            throw error;
        }
    }

    // Check if room can be extended until specific date
    static async canExtendUntil(bookingId, newCheckOut) {
        try {
            const booking = await this.getById(bookingId);
            if (!booking) throw new Error('Booking not found');

            const [conflicts] = await db.query(
                `SELECT COUNT(*) as count FROM bookings 
                 WHERE room_id = ? 
                 AND booking_id != ?
                 AND booking_status IN ('Confirmed', 'CheckedIn')
                 AND check_in < ? AND check_out > ?`,
                [booking.room_id, bookingId, newCheckOut, booking.check_out]
            );

            return conflicts[0].count === 0;
        } catch (error) {
            throw error;
        }
    }

    // ============================================
    // DAILY ROOM COUNTING & OCCUPANCY ANALYTICS
    // Based on Hotel Industry Standards
    // ============================================

    /**
     * Get occupied rooms count for a specific date
     * Hotel Day: check_in <= date < check_out
     * @param {string} date - Date in YYYY-MM-DD format
     */
    static async getDailyRoomCount(date) {
        const [rows] = await db.query(`
            SELECT 
                COUNT(*) as occupied_rooms,
                SUM(number_of_guests) as total_guests
            FROM bookings 
            WHERE check_in <= ? 
            AND check_out > ?
            AND booking_status IN ('Confirmed', 'CheckedIn')
        `, [date, date]);
        return rows[0];
    }

    /**
     * Get daily occupancy metrics including percentage and rates
     * @param {string} date - Date in YYYY-MM-DD format
     */
    static async getDailyOccupancyMetrics(date) {
        // Get total available rooms (excluding maintenance)
        const [availableRooms] = await db.query(`
            SELECT COUNT(*) as total_available
            FROM rooms 
            WHERE status != 'Maintenance'
        `);

        // Get occupied rooms and revenue for this date
        const [occupancyData] = await db.query(`
            SELECT 
                COUNT(*) as occupied_rooms,
                COUNT(DISTINCT room_id) as rooms_sold,
                SUM(b.total_amount) as room_revenue,
                AVG(b.total_amount) as avg_daily_rate,
                SUM(b.number_of_guests) as total_guests
            FROM bookings b
            WHERE b.check_in <= ? 
            AND b.check_out > ?
            AND b.booking_status IN ('Confirmed', 'CheckedIn')
        `, [date, date]);

        const totalAvailable = availableRooms[0].total_available;
        const occupied = occupancyData[0].occupied_rooms || 0;
        const roomRevenue = occupancyData[0].room_revenue || 0;
        const adr = occupancyData[0].avg_daily_rate || 0;

        // Calculate metrics
        const occupancyPercentage = totalAvailable > 0 ? ((occupied / totalAvailable) * 100).toFixed(2) : 0;
        const revpar = totalAvailable > 0 ? (roomRevenue / totalAvailable).toFixed(2) : 0;

        return {
            date: date,
            occupied_rooms: occupied,
            available_rooms: totalAvailable,
            rooms_sold: occupancyData[0].rooms_sold || 0,
            total_guests: occupancyData[0].total_guests || 0,
            occupancy_percentage: parseFloat(occupancyPercentage),
            room_revenue: parseFloat(roomRevenue).toFixed(2),
            adr: parseFloat(adr).toFixed(2), // Average Daily Rate
            revpar: parseFloat(revpar), // Revenue Per Available Room
            available_capacity: totalAvailable - occupied
        };
    }

    /**
     * Get occupancy analysis for a date range
     * @param {string} startDate - Start date in YYYY-MM-DD format
     * @param {string} endDate - End date in YYYY-MM-DD format
     */
    static async getPeriodOccupancyAnalysis(startDate, endDate) {
        // Get total available rooms
        const [availableRooms] = await db.query(`
            SELECT COUNT(*) as total_available
            FROM rooms 
            WHERE status != 'Maintenance'
        `);

        const totalAvailable = availableRooms[0].total_available;

        // Get booking data for period
        const [bookingData] = await db.query(`
            SELECT 
                COUNT(DISTINCT DATE(b.check_in)) as booking_days,
                COUNT(DISTINCT b.room_id) as unique_rooms_booked,
                SUM(b.total_amount) as total_revenue,
                AVG(b.total_amount) as average_booking_value,
                SUM(DATEDIFF(b.check_out, b.check_in)) as total_room_nights
            FROM bookings b
            WHERE b.check_in >= ?
            AND b.check_in <= ?
            AND b.booking_status IN ('Confirmed', 'CheckedIn', 'CheckedOut')
        `, [startDate, endDate]);

        const totalRoomNights = bookingData[0].total_room_nights || 0;
        const totalRevenue = bookingData[0].total_revenue || 0;
        const availableRoomNights = totalAvailable * Math.ceil((new Date(endDate) - new Date(startDate)) / (1000 * 60 * 60 * 24));

        const occupancyPercentage = availableRoomNights > 0 ? ((totalRoomNights / availableRoomNights) * 100).toFixed(2) : 0;
        const avgNightlyRevenue = availableRoomNights > 0 ? (totalRevenue / (availableRoomNights / totalAvailable)).toFixed(2) : 0;

        return {
            period: {
                start_date: startDate,
                end_date: endDate,
                days: Math.ceil((new Date(endDate) - new Date(startDate)) / (1000 * 60 * 60 * 24))
            },
            rooms: {
                total_available: totalAvailable,
                unique_rooms_booked: bookingData[0].unique_rooms_booked || 0,
                total_available_nights: availableRoomNights
            },
            bookings: {
                total_room_nights: totalRoomNights,
                total_bookings: bookingData[0].booking_days || 0,
                average_booking_value: parseFloat(bookingData[0].average_booking_value || 0).toFixed(2)
            },
            metrics: {
                occupancy_percentage: parseFloat(occupancyPercentage),
                total_revenue: parseFloat(totalRevenue).toFixed(2),
                average_nightly_revenue: parseFloat(avgNightlyRevenue),
                revpar: (totalRevenue / (totalAvailable * Math.ceil((new Date(endDate) - new Date(startDate)) / (1000 * 60 * 60 * 24)))).toFixed(2)
            }
        };
    }

    /**
     * Get daily occupancy data for a date range
     * Returns data for each day to create occupancy charts
     * @param {string} startDate - Start date in YYYY-MM-DD format
     * @param {string} endDate - End date in YYYY-MM-DD format
     */
    static async getDailyOccupancyTrend(startDate, endDate) {
        const [avgRooms] = await db.query(`
            SELECT COUNT(*) as total_available
            FROM rooms 
            WHERE status != 'Maintenance'
        `);

        const totalAvailable = avgRooms[0].total_available;

        const [dailyData] = await db.query(`
            SELECT 
                DATE(b.check_in) as date,
                COUNT(DISTINCT b.room_id) as occupied_rooms,
                COUNT(DISTINCT CASE WHEN b.booking_status = 'CheckedIn' THEN b.booking_id END) as checked_in,
                COUNT(DISTINCT CASE WHEN b.booking_status = 'Confirmed' THEN b.booking_id END) as confirmed,
                SUM(b.total_amount) as daily_revenue,
                SUM(b.number_of_guests) as total_guests
            FROM bookings b
            WHERE DATE(b.check_in) >= ?
            AND DATE(b.check_in) <= ?
            AND b.booking_status IN ('Confirmed', 'CheckedIn')
            GROUP BY DATE(b.check_in)
            ORDER BY DATE(b.check_in) ASC
        `, [startDate, endDate]);

        return dailyData.map(day => ({
            date: day.date,
            occupied_rooms: day.occupied_rooms,
            checked_in: day.checked_in,
            confirmed: day.confirmed,
            available_rooms: totalAvailable,
            occupancy_percentage: ((day.occupied_rooms / totalAvailable) * 100).toFixed(2),
            daily_revenue: parseFloat(day.daily_revenue || 0).toFixed(2),
            adr: day.occupied_rooms > 0 ? (day.daily_revenue / day.occupied_rooms).toFixed(2) : 0,
            total_guests: day.total_guests || 0
        }));
    }

    /**
     * Get room-wise occupancy for a specific date
     * Shows which rooms are occupied and which are available
     * @param {string} date - Date in YYYY-MM-DD format
     */
    static async getDailyRoomStatus(date) {
        const [roomData] = await db.query(`
            SELECT 
                r.room_id,
                r.room_number,
                r.room_type,
                r.price,
                COALESCE(b.booking_id, NULL) as booking_id,
                COALESCE(b.guest_id, NULL) as guest_id,
                COALESCE(g.guest_name, 'Vacant') as guest_name,
                COALESCE(b.check_in, NULL) as check_in,
                COALESCE(b.check_out, NULL) as check_out,
                COALESCE(b.booking_status, 'Vacant') as status,
                COALESCE(rc.cleaning_status, 'Pending') as cleaning_status
            FROM rooms r
            LEFT JOIN bookings b ON r.room_id = b.room_id 
                AND b.check_in <= ?
                AND b.check_out > ?
                AND b.booking_status IN ('Confirmed', 'CheckedIn')
            LEFT JOIN guests g ON b.guest_id = g.guest_id
            LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
            ORDER BY r.room_number
        `, [date, date]);

        return roomData;
    }

    /**
     * Get occupancy summary by room type
     * @param {string} startDate - Start date in YYYY-MM-DD format
     * @param {string} endDate - End date in YYYY-MM-DD format
     */
    static async getOccupancyByRoomType(startDate, endDate) {
        const [typeData] = await db.query(`
            SELECT 
                r.room_type,
                COUNT(DISTINCT r.room_id) as total_rooms,
                COUNT(DISTINCT b.room_id) as rooms_booked,
                SUM(DATEDIFF(b.check_out, b.check_in)) as total_nights_booked,
                SUM(b.total_amount) as total_revenue
            FROM rooms r
            LEFT JOIN bookings b ON r.room_id = b.room_id
                AND b.check_in >= ?
                AND b.check_out <= ?
                AND b.booking_status IN ('Confirmed', 'CheckedIn', 'CheckedOut')
            GROUP BY r.room_type
        `, [startDate, endDate]);

        return typeData.map(type => ({
            room_type: type.room_type,
            total_rooms: type.total_rooms,
            rooms_booked: type.rooms_booked,
            occupancy_rate: ((type.rooms_booked / type.total_rooms) * 100).toFixed(2),
            total_nights_booked: type.total_nights_booked || 0,
            total_revenue: parseFloat(type.total_revenue || 0).toFixed(2)
        }));
    }
}

module.exports = Booking;
