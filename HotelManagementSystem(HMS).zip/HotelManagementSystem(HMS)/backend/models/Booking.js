const db = require('../config/database');
const GuestSession = require('./GuestSession');

class Booking {
    // Get all bookings with pagination and enhanced details
    static async getAll(page = 1, limit = 20, filters = {}) {
        const offset = (page - 1) * limit;

        // Build dynamic WHERE clauses for server-side filtering
        const where = [];
        const params = [];

        if (filters.startDate) {
            where.push('check_in >= ?');
            params.push(filters.startDate);
        }

        if (filters.endDate) {
            where.push('check_out <= ?');
            params.push(filters.endDate);
        }

        const whereSql = where.length ? ('WHERE ' + where.join(' AND ')) : '';

        const [rows] = await db.query(
            `SELECT * FROM booking_details_enhanced ${whereSql} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
            [...params, limit, offset]
        );

        const countParams = [...params];
        const countSql = `SELECT COUNT(*) as total FROM bookings ${whereSql}`;
        const [countResult] = await db.query(countSql, countParams);

        return {
            data: rows,
            pagination: {
                page,
                limit,
                total: countResult[0].total,
                pages: Math.ceil(countResult[0].total / limit)
            }
        };
    }

    // Get booking by ID with enhanced details
    static async getById(id) {
        const [rows] = await db.query('SELECT * FROM booking_details_enhanced WHERE booking_id = ?', [id]);
        return rows[0];
    }

    // Get active bookings with pagination
    static async getActive(page = 1, limit = 20) {
        const offset = (page - 1) * limit;
        const [rows] = await db.query(`
            SELECT * FROM booking_details 
            WHERE booking_status IN ('Confirmed', 'CheckedIn')
            ORDER BY check_in
            LIMIT ? OFFSET ?
        `, [limit, offset]);
        
        const [countResult] = await db.query(
            `SELECT COUNT(*) as total FROM booking_details 
             WHERE booking_status IN ('Confirmed', 'CheckedIn')`
        );
        
        return {
            data: rows,
            pagination: {
                page,
                limit,
                total: countResult[0].total,
                pages: Math.ceil(countResult[0].total / limit)
            }
        };
    }

    // Create new booking with robust overbooking protection
    static async create(bookingData) {
        const { guest_id, room_id, check_in, check_out, number_of_guests, room_price, total_amount, discount_type, discount_value, discount_reason, advance_payment, payment_method, special_requests } = bookingData;
        
        // Validate dates
        const checkInDate = new Date(check_in);
        const checkOutDate = new Date(check_out);
        if (checkInDate >= checkOutDate) {
            throw new Error('Check-out date must be after check-in date');
        }
        
        // Use transaction to ensure data consistency and prevent race conditions
        const connection = await db.getConnection();
        try {
            await connection.beginTransaction();
            
            // Lock the room row to prevent concurrent bookings (FOR UPDATE)
            const [roomLock] = await connection.query(
                'SELECT room_id, status FROM rooms WHERE room_id = ? FOR UPDATE',
                [room_id]
            );
            
            if (roomLock.length === 0) {
                throw new Error('Room not found');
            }
            
            if (roomLock[0].status === 'Maintenance') {
                throw new Error('Room is under maintenance and cannot be booked');
            }
            
            // Enhanced conflict check with proper date overlap logic
            // A booking conflicts if: new_start < existing_end AND new_end > existing_start
            const [conflicts] = await connection.query(
                `SELECT b.booking_id, b.check_in, b.check_out, g.name as guest_name, b.booking_status
                 FROM bookings b
                 LEFT JOIN guests g ON b.guest_id = g.guest_id
                 WHERE b.room_id = ? 
                 AND b.booking_status IN ('Confirmed', 'CheckedIn')
                 AND b.check_in < ? 
                 AND b.check_out > ?
                 FOR UPDATE`,
                [room_id, check_out, check_in]
            );
            
            if (conflicts.length > 0) {
                const conflict = conflicts[0];
                throw new Error(
                    `Room is already booked from ${conflict.check_in} to ${conflict.check_out} ` +
                    `(Booking #${conflict.booking_id} for ${conflict.guest_name || 'Guest'}). ` +
                    `Status: ${conflict.booking_status}`
                );
            }
            
            const payment_status = advance_payment >= total_amount ? 'Paid' : (advance_payment > 0 ? 'Partial' : 'Pending');
            const nights = Math.ceil((checkOutDate - checkInDate) / (1000 * 60 * 60 * 24));
            
            const [result] = await connection.query(
                `INSERT INTO bookings 
                (guest_id, room_id, check_in, check_out, number_of_guests, room_price, total_amount, discount_type, discount_value, discount_reason, advance_payment, payment_status, payment_method, special_requests) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [guest_id, room_id, check_in, check_out, number_of_guests || 1, room_price, total_amount, discount_type || 'None', discount_value || 0, discount_reason, advance_payment || 0, payment_status, payment_method || 'Cash', special_requests]
            );
            
            // Don't update room status here - it will be updated when checking in
            // Room status should only be 'Booked' when guest is actually checked in
            
            await connection.commit();
            connection.release();
            
            return result.insertId;
        } catch (error) {
            await connection.rollback();
            connection.release();
            throw error;
        }
    }

    // Update booking
    static async update(id, bookingData) {
        const { check_in, check_out, total_amount, advance_payment, payment_method, special_requests } = bookingData;
        
        const payment_status = advance_payment >= total_amount ? 'Paid' : (advance_payment > 0 ? 'Partial' : 'Pending');
        
        const [result] = await db.query(
            `UPDATE bookings 
            SET check_in = ?, check_out = ?, total_amount = ?, advance_payment = ?, 
                payment_status = ?, payment_method = ?, special_requests = ?
            WHERE booking_id = ?`,
            [check_in, check_out, total_amount, advance_payment, payment_status, payment_method, special_requests, id]
        );
        return result.affectedRows;
    }

    // Check-in
    static async checkIn(bookingId) {
        try {
            // Get booking with guest info
            const [booking] = await db.query(
                'SELECT guest_id FROM bookings WHERE booking_id = ?',
                [bookingId]
            );
            
            if (booking.length === 0) {
                throw new Error('Booking not found');
            }
            
            const guestId = booking[0].guest_id;
            
            // Update booking status
            const [result] = await db.query(
                'UPDATE bookings SET booking_status = ? WHERE booking_id = ?',
                ['CheckedIn', bookingId]
            );
            
            // Generate guest access token
            const session = await GuestSession.create(bookingId, guestId);
            
            return {
                affectedRows: result.affectedRows,
                session: {
                    pin: session.pin,
                    token: session.token,
                    bookingId: session.bookingId,
                    guestId: session.guestId
                }
            };
        } catch (error) {
            throw error;
        }
    }

    // Check-out with automatic early/late detection
    static async checkOut(bookingId) {
        try {
            // Get current booking details
            const [bookingData] = await db.query('SELECT * FROM bookings WHERE booking_id = ?', [bookingId]);
            if (bookingData.length === 0) {
                throw new Error('Booking not found');
            }

            const booking = bookingData[0];
            const currentDateTime = new Date();
            const checkoutDate = new Date(booking.check_out);
            const standardCheckoutTime = new Date(checkoutDate);
            standardCheckoutTime.setHours(12, 0, 0, 0); // Set to 12:00 PM

            // Determine checkout type based on current time vs standard checkout time
            let checkoutType = 'Standard';
            let isEarlyCheckout = false;
            let lateCheckoutFee = 0;

            if (currentDateTime < standardCheckoutTime) {
                checkoutType = 'Early';
                isEarlyCheckout = true;
            } else if (currentDateTime.getHours() > 18) { // After 6 PM considered late
                checkoutType = 'Late';
                lateCheckoutFee = booking.room_price * 0.20; // 20% of room price as late fee
            }

            // Remove guest session
            await GuestSession.removeSession(bookingId);
            
            // Update booking with checkout details
            const [result] = await db.query(
                `UPDATE bookings SET 
                    booking_status = ?, 
                    actual_checkout_time = ?,
                    checkout_type = ?,
                    is_early_checkout = ?,
                    late_checkout_fee = ?
                WHERE booking_id = ?`,
                ['CheckedOut', currentDateTime, checkoutType, isEarlyCheckout, lateCheckoutFee, bookingId]
            );
            
            // Update room status to Available immediately (especially important for early checkout)
            if (booking.room_id) {
                await db.query('UPDATE rooms SET status = ? WHERE room_id = ?', ['Available', booking.room_id]);
            }

            // Return checkout details for notification
            return {
                affectedRows: result.affectedRows,
                checkoutDetails: {
                    type: checkoutType,
                    time: currentDateTime,
                    isEarly: isEarlyCheckout,
                    lateFee: lateCheckoutFee,
                    roomAvailable: true
                }
            };
        } catch (error) {
            throw error;
        }
    }

    // Cancel booking
    static async cancel(bookingId) {
        const [result] = await db.query(
            'UPDATE bookings SET booking_status = ? WHERE booking_id = ?',
            ['Cancelled', bookingId]
        );
        
        // Get room_id for this booking
        const [booking] = await db.query('SELECT room_id FROM bookings WHERE booking_id = ?', [bookingId]);
        if (booking.length > 0) {
            // Update room status to Available
            await db.query('UPDATE rooms SET status = ? WHERE room_id = ?', ['Available', booking[0].room_id]);
        }
        
        return result.affectedRows;
    }

    // Update payment
    static async updatePayment(bookingId, paymentData) {
        const { advance_payment, payment_method } = paymentData;
        
        // Get total amount
        const [booking] = await db.query('SELECT total_amount FROM bookings WHERE booking_id = ?', [bookingId]);
        const total_amount = booking[0].total_amount;
        
        const payment_status = advance_payment >= total_amount ? 'Paid' : (advance_payment > 0 ? 'Partial' : 'Pending');
        
        const [result] = await db.query(
            'UPDATE bookings SET advance_payment = ?, payment_method = ?, payment_status = ? WHERE booking_id = ?',
            [advance_payment, payment_method, payment_status, bookingId]
        );
        return result.affectedRows;
    }

    // Apply discount to booking
    static async applyDiscount(bookingId, discountType, discountValue, discountReason) {
        const validTypes = ['None', 'Percentage', 'Fixed'];
        if (!validTypes.includes(discountType)) {
            throw new Error('Invalid discount type');
        }

        // Get booking details
        const [bookings] = await db.query('SELECT room_price, number_of_nights FROM bookings WHERE booking_id = ?', [bookingId]);
        if (bookings.length === 0) throw new Error('Booking not found');

        const { room_price, number_of_nights } = bookings[0];
        const baseAmount = room_price * number_of_nights;
        let finalAmount = baseAmount;

        if (discountType === 'Percentage') {
            finalAmount = baseAmount - (baseAmount * discountValue / 100);
        } else if (discountType === 'Fixed') {
            finalAmount = Math.max(0, baseAmount - discountValue);
        }

        const [result] = await db.query(
            `UPDATE bookings 
             SET discount_type = ?, discount_value = ?, discount_reason = ?, total_amount = ?
             WHERE booking_id = ?`,
            [discountType, discountValue, discountReason, finalAmount, bookingId]
        );

        return result.affectedRows;
    }

    // Check room availability with early checkout consideration - OPTIMIZED for SQL
    static async checkRoomAvailability(roomId, startDate, endDate, excludeBookingId = null) {
        let query = `
            SELECT booking_id, check_in, check_out, booking_status, actual_checkout_time 
            FROM bookings 
            WHERE room_id = ? 
            AND (
                (booking_status IN ('Confirmed', 'CheckedIn')) OR
                (booking_status = 'CheckedOut' AND actual_checkout_time > ?)
            )
            AND (
                (check_in <= ? AND check_out >= ?) OR
                (check_in >= ? AND check_in < ?)
            )
        `;
        let params = [roomId, startDate, startDate, endDate, startDate, endDate];
        
        if (excludeBookingId) {
            query += ' AND booking_id != ?';
            params.push(excludeBookingId);
        }

        const [conflicts] = await db.query(query, params);

        return {
            available: conflicts.length === 0,
            conflicts: conflicts
        };
    }

    // Get hotel policy values
    static async getHotelPolicy(policyName) {
        const [rows] = await db.query('SELECT policy_value FROM hotel_policies WHERE policy_name = ?', [policyName]);
        return rows[0] ? rows[0].policy_value : null;
    }

    // Get rooms that become available due to early checkouts
    static async getEarlyCheckoutAvailableRooms(date) {
        const [rows] = await db.query(`
            SELECT b.room_id, r.room_number, r.room_type, b.actual_checkout_time, b.checkout_type
            FROM bookings b
            JOIN rooms r ON b.room_id = r.room_id  
            WHERE DATE(b.actual_checkout_time) = ?
            AND b.is_early_checkout = TRUE
            AND b.booking_status = 'CheckedOut'
            ORDER BY b.actual_checkout_time
        `, [date]);
        return rows;
    }

    // Handle early checkout for new booking availability
    static async handleEarlyCheckout(roomId, customerId) {
        const [booking] = await db.query(`
            SELECT * FROM bookings 
            WHERE room_id = ? AND guest_id = ? AND booking_status = 'CheckedIn'
        `, [roomId, customerId]);

        if (booking.length > 0) {
            const currentBooking = booking[0];
            const now = new Date();
            const checkoutDate = new Date(currentBooking.check_out);
            const standardCheckoutTime = new Date(checkoutDate);
            standardCheckoutTime.setHours(12, 0, 0, 0);

            // If checking out before expected checkout date or before standard time
            if (now < checkoutDate || now < standardCheckoutTime) {
                // Process as early checkout
                const result = await this.checkOut(currentBooking.booking_id);
                return {
                    success: true,
                    message: 'Early checkout processed successfully',
                    details: result.checkoutDetails
                };
            }
        }
        return { success: false, message: 'No active booking found for early checkout' };
    }

    // Get today's check-ins
    static async getTodayCheckIns() {
        const [rows] = await db.query(`
            SELECT * FROM booking_details 
            WHERE DATE(check_in) = CURDATE() 
            AND booking_status = 'Confirmed'
            ORDER BY check_in
        `);
        return rows;
    }

    // Get today's check-outs
    static async getTodayCheckOuts() {
        const [rows] = await db.query(`
            SELECT * FROM booking_details 
            WHERE DATE(check_out) = CURDATE() 
            AND booking_status = 'CheckedIn'
            ORDER BY check_out
        `);
        return rows;
    }

    // Get revenue statistics
    static async getRevenueStats(startDate, endDate) {
        const [rows] = await db.query(`
            SELECT 
                COUNT(*) as total_bookings,
                SUM(total_amount) as total_revenue,
                SUM(advance_payment) as collected_amount,
                SUM(total_amount - advance_payment) as pending_amount,
                AVG(total_amount) as average_booking_value
            FROM bookings 
            WHERE check_in BETWEEN ? AND ?
            AND booking_status != 'Cancelled'
        `, [startDate, endDate]);
        return rows[0];
    }

    // Get dashboard statistics
    static async getDashboardStats() {
        const [stats] = await db.query(`
            SELECT 
                (SELECT COUNT(*) FROM bookings WHERE booking_status = 'Confirmed') as confirmed_bookings,
                (SELECT COUNT(*) FROM bookings WHERE booking_status = 'CheckedIn') as checked_in,
                (SELECT COUNT(*) FROM bookings WHERE DATE(check_in) = CURDATE() AND booking_status = 'Confirmed') as today_checkins,
                (SELECT COUNT(*) FROM bookings WHERE DATE(check_out) = CURDATE() AND booking_status = 'CheckedIn') as today_checkouts,
                (SELECT SUM(total_amount) FROM bookings WHERE DATE(created_at) = CURDATE()) as today_revenue,
                (SELECT COUNT(*) FROM rooms WHERE status = 'Available') as available_rooms
        `);
        return stats[0];
    }

    // Check extension options for a booking
    static async getExtensionOptions(bookingId, newCheckOut) {
        try {
            // Get current booking details
            const booking = await this.getById(bookingId);
            if (!booking) {
                throw new Error('Booking not found');
            }

            // Validate new check-out date
            const newCheckOutDate = new Date(newCheckOut);
            const currentCheckOut = new Date(booking.check_out);
            const checkInDate = new Date(booking.check_in);

            if (newCheckOutDate <= currentCheckOut) {
                throw new Error('New check-out date must be after current check-out date');
            }

            // Check for conflicting bookings
            const [conflicts] = await db.query(
                `SELECT * FROM bookings 
                 WHERE room_id = ? 
                 AND booking_id != ?
                 AND booking_status IN ('Confirmed', 'CheckedIn')
                 AND check_in <= ? AND check_out >= ?`,
                [booking.room_id, bookingId, newCheckOut, booking.check_out]
            );

            const result = {
                currentBooking: {
                    booking_id: booking.booking_id,
                    check_in: booking.check_in,
                    check_out: booking.check_out,
                    room_id: booking.room_id,
                    room_number: booking.room_number,
                    room_price: booking.room_price
                },
                extensionRequest: {
                    new_check_out: newCheckOut,
                    nights_requested: Math.ceil((newCheckOutDate - currentCheckOut) / (1000 * 60 * 60 * 24))
                },
                conflict: null,
                alternatives: {
                    alternative_rooms: [],
                    alternative_dates: [],
                    room_upgrade: null
                }
            };

            // If no conflict, return success
            if (conflicts.length === 0) {
                result.canExtend = true;
                result.message = 'Room is available for extension';
                return result;
            }

            // Conflict exists
            result.canExtend = false;
            result.conflict = {
                conflicting_booking_id: conflicts[0].booking_id,
                conflicting_dates: {
                    from: conflicts[0].check_in,
                    to: conflicts[0].check_out
                },
                message: `Room is booked from ${conflicts[0].check_in} to ${conflicts[0].check_out}`
            };

            // Get alternative rooms for the extension period
            const [alternativeRooms] = await db.query(
                `SELECT DISTINCT r.* FROM rooms r
                 WHERE r.room_id != ?
                 AND r.status = 'Available'
                 AND r.room_id NOT IN (
                    SELECT room_id FROM bookings 
                    WHERE booking_status IN ('Confirmed', 'CheckedIn')
                    AND check_in < ? AND check_out > ?
                 )
                 LIMIT 5`,
                [booking.room_id, newCheckOut, booking.check_out]
            );

            result.alternatives.alternative_rooms = alternativeRooms.map(room => ({
                room_id: room.room_id,
                room_number: room.room_number,
                room_type: room.room_type,
                price: room.price,
                max_guests: room.max_guests,
                amenities: room.amenities,
                extension_cost: parseFloat(room.price) * result.extensionRequest.nights_requested
            }));

            // Get alternative dates - when the current room becomes available
            const [nextAvailable] = await db.query(
                `SELECT MIN(check_out) as available_from FROM bookings
                 WHERE room_id = ? 
                 AND check_out > ?
                 AND booking_status IN ('Confirmed', 'CheckedIn')
                 ORDER BY check_out LIMIT 1`,
                [booking.room_id, booking.check_out]
            );

            if (nextAvailable.length > 0 && nextAvailable[0].available_from) {
                const availableFromDate = new Date(nextAvailable[0].available_from);
                const extensionNights = Math.ceil((newCheckOutDate - availableFromDate) / (1000 * 60 * 60 * 24));
                result.alternatives.alternative_dates = {
                    available_from: nextAvailable[0].available_from,
                    extension_cost: parseFloat(booking.room_price) * extensionNights,
                    wait_period_days: Math.ceil((availableFromDate - currentCheckOut) / (1000 * 60 * 60 * 24))
                };
            }

            return result;
        } catch (error) {
            throw error;
        }
    }

    // Extend booking with conflict resolution
    static async extendBooking(bookingId, extensionData) {
        try {
            const { new_check_out, resolution_type, resolution_details } = extensionData;
            const booking = await this.getById(bookingId);

            if (!booking) {
                throw new Error('Booking not found');
            }

            const newCheckOutDate = new Date(new_check_out);
            const currentCheckOut = new Date(booking.check_out);
            const checkInDate = new Date(booking.check_in);

            const additionalNights = Math.ceil((newCheckOutDate - currentCheckOut) / (1000 * 60 * 60 * 24));
            const additionalCost = parseFloat(booking.room_price) * additionalNights;

            let result = {
                success: true,
                originalBookingId: bookingId,
                extensions: []
            };

            switch (resolution_type) {
                case 'same_room':
                    // Extend in the same room (no conflict)
                    const newTotalAmount = parseFloat(booking.total_amount) + additionalCost;
                    await db.query(
                        'UPDATE bookings SET check_out = ?, total_amount = ? WHERE booking_id = ?',
                        [new_check_out, newTotalAmount, bookingId]
                    );
                    result.extensions.push({
                        type: 'extended',
                        booking_id: bookingId,
                        new_check_out,
                        additional_cost: additionalCost,
                        new_total: newTotalAmount
                    });
                    break;

                case 'alternative_room':
                    // Book additional nights in alternative room
                    const alternativeRoom = await db.query(
                        'SELECT * FROM rooms WHERE room_id = ?',
                        [resolution_details.alternative_room_id]
                    );

                    if (alternativeRoom[0].length === 0) {
                        throw new Error('Alternative room not found');
                    }

                    const altRoomPrice = alternativeRoom[0][0].price;
                    const altBookingAmount = parseFloat(altRoomPrice) * additionalNights;

                    // Create new booking for extension
                    const [altResult] = await db.query(
                        `INSERT INTO bookings 
                        (guest_id, room_id, check_in, check_out, number_of_guests, room_price, total_amount, 
                         discount_type, discount_value, discount_reason, advance_payment, payment_status, 
                         payment_method, special_requests, is_extension, parent_booking_id) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                        [
                            booking.guest_id, resolution_details.alternative_room_id, booking.check_out, 
                            new_check_out, booking.number_of_guests, altRoomPrice, altBookingAmount,
                            'None', 0, 'Extension - Alternative Room', 0, 'Pending', 'Cash', 
                            `Extension of booking #${bookingId}`, true, bookingId
                        ]
                    );

                    result.extensions.push({
                        type: 'new_booking_alternative_room',
                        original_booking_id: bookingId,
                        new_booking_id: altResult.insertId,
                        room_id: resolution_details.alternative_room_id,
                        dates: `${booking.check_out} to ${new_check_out}`,
                        cost: altBookingAmount
                    });
                    break;

                case 'alternative_dates':
                    // Extend to alternative dates on same room
                    const [nextAvailable] = await db.query(
                        `SELECT MIN(check_out) as available_from FROM bookings
                         WHERE room_id = ? 
                         AND check_out > ?
                         AND booking_status IN ('Confirmed', 'CheckedIn')
                         ORDER BY check_out LIMIT 1`,
                        [booking.room_id, booking.check_out]
                    );

                    let newExtensionCheckOut;
                    if (nextAvailable.length > 0 && nextAvailable[0].available_from) {
                        newExtensionCheckOut = nextAvailable[0].available_from;
                    } else {
                        newExtensionCheckOut = new_check_out;
                    }

                    const altNights = Math.ceil((new Date(newExtensionCheckOut) - currentCheckOut) / (1000 * 60 * 60 * 24));
                    const altNightsCost = parseFloat(booking.room_price) * altNights;
                    const newTotalAlt = parseFloat(booking.total_amount) + altNightsCost;

                    await db.query(
                        'UPDATE bookings SET check_out = ?, total_amount = ? WHERE booking_id = ?',
                        [newExtensionCheckOut, newTotalAlt, bookingId]
                    );

                    result.extensions.push({
                        type: 'extended_alternative_dates',
                        booking_id: bookingId,
                        original_requested: new_check_out,
                        approved_until: newExtensionCheckOut,
                        additional_cost: altNightsCost,
                        new_total: newTotalAlt,
                        note: 'Extended to next available date'
                    });
                    break;

                default:
                    throw new Error('Invalid resolution type');
            }

            return result;
        } catch (error) {
            throw error;
        }
    }

    // Check if room can be extended until specific date
    static async canExtendUntil(bookingId, newCheckOut) {
        try {
            const booking = await this.getById(bookingId);
            if (!booking) throw new Error('Booking not found');

            const [conflicts] = await db.query(
                `SELECT COUNT(*) as count FROM bookings 
                 WHERE room_id = ? 
                 AND booking_id != ?
                 AND booking_status IN ('Confirmed', 'CheckedIn')
                 AND check_in < ? AND check_out > ?`,
                [booking.room_id, bookingId, newCheckOut, booking.check_out]
            );

            return conflicts[0].count === 0;
        } catch (error) {
            throw error;
        }
    }

    // Check extension conflicts and provide resolution options
    static async checkExtensionConflicts(bookingId, newCheckOut) {
        try {
            const booking = await this.getById(bookingId);
            if (!booking) throw new Error('Booking not found');

            // Check if extension is possible in same room
            const [conflicts] = await db.query(
                `SELECT b.*, g.name as guest_name, r.room_number, r.room_type, r.ac_type
                 FROM bookings b
                 JOIN guests g ON b.guest_id = g.guest_id
                 JOIN rooms r ON b.room_id = r.room_id
                 WHERE b.room_id = ? 
                 AND b.booking_id != ?
                 AND b.booking_status IN ('Confirmed', 'CheckedIn')
                 AND b.check_in < ? AND b.check_out > ?
                 ORDER BY b.check_in`,
                [booking.room_id, bookingId, newCheckOut, booking.check_out]
            );

            const result = {
                canExtendInSameRoom: conflicts.length === 0,
                conflictingBookings: conflicts,
                solutions: []
            };

            if (result.canExtendInSameRoom) {
                // No conflict - can extend in same room
                result.solutions.push({
                    type: 'same_room',
                    description: 'Extend in the same room',
                    cost: this.calculateExtensionCost(booking, newCheckOut),
                    recommended: true
                });
            } else {
                // There's a conflict - provide alternative solutions
                const currentGuest = await db.query(
                    'SELECT name FROM guests WHERE guest_id = ?',
                    [booking.guest_id]
                );

                // Solution 1: Move current guest (Mr. B) to another room for extension period
                const [alternativeForCurrentGuest] = await db.query(
                    `SELECT r.*, 
                     (SELECT COUNT(*) FROM bookings 
                      WHERE room_id = r.room_id 
                      AND booking_status IN ('Confirmed', 'CheckedIn')
                      AND NOT (check_out <= ? OR check_in >= ?)) as has_conflict
                     FROM rooms r
                     WHERE r.room_type = ? 
                     AND r.ac_type = ?
                     AND r.room_id != ?
                     AND r.status != 'Out of Order'
                     HAVING has_conflict = 0
                     ORDER BY r.price, r.room_number
                     LIMIT 5`,
                    [booking.check_out, newCheckOut, booking.room_type, booking.ac_type, booking.room_id]
                );

                if (alternativeForCurrentGuest.length > 0) {
                    result.solutions.push({
                        type: 'move_current_guest',
                        description: `Move ${currentGuest[0][0].name} to another room for the extension period`,
                        action: 'Current guest moves',
                        alternativeRooms: alternativeForCurrentGuest.map(room => ({
                            room_id: room.room_id,
                            room_number: room.room_number,
                            room_type: room.room_type,
                            ac_type: room.ac_type,
                            price: room.price,
                            cost: this.calculateExtensionCostByPrice(room.price, booking.check_out, newCheckOut)
                        })),
                        recommended: false
                    });
                }

                // Solution 2: Move conflicting guest (Mr. A) to another room
                if (conflicts.length > 0) {
                    const conflictingBooking = conflicts[0];
                    
                    const [alternativeForConflictingGuest] = await db.query(
                        `SELECT r.*, 
                         (SELECT COUNT(*) FROM bookings 
                          WHERE room_id = r.room_id 
                          AND booking_status IN ('Confirmed', 'CheckedIn')
                          AND NOT (check_out <= ? OR check_in >= ?)) as has_conflict
                         FROM rooms r
                         WHERE r.room_type = ? 
                         AND r.ac_type = ?
                         AND r.room_id != ?
                         AND r.status != 'Out of Order'
                         HAVING has_conflict = 0
                         ORDER BY r.price, r.room_number
                         LIMIT 5`,
                        [conflictingBooking.check_in, conflictingBooking.check_out, 
                         conflictingBooking.room_type, conflictingBooking.ac_type, 
                         conflictingBooking.room_id]
                    );

                    if (alternativeForConflictingGuest.length > 0) {
                        result.solutions.push({
                            type: 'move_conflicting_guest',
                            description: `Move ${conflictingBooking.guest_name} to another room (allow current guest to extend)`,
                            action: 'Conflicting guest moves',
                            conflictingGuest: {
                                name: conflictingBooking.guest_name,
                                booking_id: conflictingBooking.booking_id,
                                check_in: conflictingBooking.check_in,
                                check_out: conflictingBooking.check_out
                            },
                            alternativeRooms: alternativeForConflictingGuest.map(room => ({
                                room_id: room.room_id,
                                room_number: room.room_number,
                                room_type: room.room_type,
                                ac_type: room.ac_type,
                                price: room.price
                            })),
                            extensionCostForCurrent: this.calculateExtensionCost(booking, newCheckOut),
                            recommended: true
                        });
                    }
                }

                // Solution 3: Extend until conflict date only
                const maxExtensionDate = conflicts[0].check_in;
                const maxExtensionDateStr = new Date(maxExtensionDate).toISOString().split('T')[0];
                
                result.solutions.push({
                    type: 'partial_extension',
                    description: `Extend only until ${maxExtensionDateStr} (before ${conflicts[0].guest_name}'s check-in)`,
                    action: 'Partial extension',
                    max_date: maxExtensionDateStr,
                    cost: this.calculateExtensionCost(booking, maxExtensionDateStr),
                    recommended: false
                });
            }

            return result;
        } catch (error) {
            throw error;
        }
    }

    // Helper: Calculate extension cost
    static calculateExtensionCost(booking, newCheckOut) {
        const currentCheckOut = new Date(booking.check_out);
        const newCheckOutDate = new Date(newCheckOut);
        const additionalNights = Math.ceil((newCheckOutDate - currentCheckOut) / (1000 * 60 * 60 * 24));
        return parseFloat(booking.room_price) * additionalNights;
    }

    // Helper: Calculate extension cost by price
    static calculateExtensionCostByPrice(pricePerNight, fromDate, toDate) {
        const from = new Date(fromDate);
        const to = new Date(toDate);
        const nights = Math.ceil((to - from) / (1000 * 60 * 60 * 24));
        return parseFloat(pricePerNight) * nights;
    }


    // ============================================
    // DAILY ROOM COUNTING & OCCUPANCY ANALYTICS
    // Based on Hotel Industry Standards
    // ============================================

    /**
     * Get occupied rooms count for a specific date
     * Hotel Day: check_in <= date < check_out
     * @param {string} date - Date in YYYY-MM-DD format
     */
    static async getDailyRoomCount(date) {
        const [rows] = await db.query(`
            SELECT 
                COUNT(*) as occupied_rooms,
                SUM(number_of_guests) as total_guests
            FROM bookings 
            WHERE check_in <= ? 
            AND check_out > ?
            AND booking_status IN ('Confirmed', 'CheckedIn')
        `, [date, date]);
        return rows[0];
    }

    /**
     * Get daily occupancy metrics including percentage and rates
     * @param {string} date - Date in YYYY-MM-DD format
     */
    static async getDailyOccupancyMetrics(date) {
        // Get total available rooms (excluding maintenance)
        const [availableRooms] = await db.query(`
            SELECT COUNT(*) as total_available
            FROM rooms 
            WHERE status != 'Maintenance'
        `);

        // Get occupied rooms and revenue for this date
        const [occupancyData] = await db.query(`
            SELECT 
                COUNT(*) as occupied_rooms,
                COUNT(DISTINCT room_id) as rooms_sold,
                SUM(b.total_amount) as room_revenue,
                AVG(b.total_amount) as avg_daily_rate,
                SUM(b.number_of_guests) as total_guests
            FROM bookings b
            WHERE b.check_in <= ? 
            AND b.check_out > ?
            AND b.booking_status IN ('Confirmed', 'CheckedIn')
        `, [date, date]);

        const totalAvailable = availableRooms[0].total_available;
        const occupied = occupancyData[0].occupied_rooms || 0;
        const roomRevenue = occupancyData[0].room_revenue || 0;
        const adr = occupancyData[0].avg_daily_rate || 0;

        // Calculate metrics
        const occupancyPercentage = totalAvailable > 0 ? ((occupied / totalAvailable) * 100).toFixed(2) : 0;
        const revpar = totalAvailable > 0 ? (roomRevenue / totalAvailable).toFixed(2) : 0;

        return {
            date: date,
            occupied_rooms: occupied,
            available_rooms: totalAvailable,
            rooms_sold: occupancyData[0].rooms_sold || 0,
            total_guests: occupancyData[0].total_guests || 0,
            occupancy_percentage: parseFloat(occupancyPercentage),
            room_revenue: parseFloat(roomRevenue).toFixed(2),
            adr: parseFloat(adr).toFixed(2), // Average Daily Rate
            revpar: parseFloat(revpar), // Revenue Per Available Room
            available_capacity: totalAvailable - occupied
        };
    }

    /**
     * Get occupancy analysis for a date range
     * @param {string} startDate - Start date in YYYY-MM-DD format
     * @param {string} endDate - End date in YYYY-MM-DD format
     */
    static async getPeriodOccupancyAnalysis(startDate, endDate) {
        // Get total available rooms
        const [availableRooms] = await db.query(`
            SELECT COUNT(*) as total_available
            FROM rooms 
            WHERE status != 'Maintenance'
        `);

        const totalAvailable = availableRooms[0].total_available;

        // Get booking data for period
        const [bookingData] = await db.query(`
            SELECT 
                COUNT(DISTINCT DATE(b.check_in)) as booking_days,
                COUNT(DISTINCT b.room_id) as unique_rooms_booked,
                SUM(b.total_amount) as total_revenue,
                AVG(b.total_amount) as average_booking_value,
                SUM(DATEDIFF(b.check_out, b.check_in)) as total_room_nights
            FROM bookings b
            WHERE b.check_in >= ?
            AND b.check_in <= ?
            AND b.booking_status IN ('Confirmed', 'CheckedIn', 'CheckedOut')
        `, [startDate, endDate]);

        const totalRoomNights = bookingData[0].total_room_nights || 0;
        const totalRevenue = bookingData[0].total_revenue || 0;
        const availableRoomNights = totalAvailable * Math.ceil((new Date(endDate) - new Date(startDate)) / (1000 * 60 * 60 * 24));

        const occupancyPercentage = availableRoomNights > 0 ? ((totalRoomNights / availableRoomNights) * 100).toFixed(2) : 0;
        const avgNightlyRevenue = availableRoomNights > 0 ? (totalRevenue / (availableRoomNights / totalAvailable)).toFixed(2) : 0;

        return {
            period: {
                start_date: startDate,
                end_date: endDate,
                days: Math.ceil((new Date(endDate) - new Date(startDate)) / (1000 * 60 * 60 * 24))
            },
            rooms: {
                total_available: totalAvailable,
                unique_rooms_booked: bookingData[0].unique_rooms_booked || 0,
                total_available_nights: availableRoomNights
            },
            bookings: {
                total_room_nights: totalRoomNights,
                total_bookings: bookingData[0].booking_days || 0,
                average_booking_value: parseFloat(bookingData[0].average_booking_value || 0).toFixed(2)
            },
            metrics: {
                occupancy_percentage: parseFloat(occupancyPercentage),
                total_revenue: parseFloat(totalRevenue).toFixed(2),
                average_nightly_revenue: parseFloat(avgNightlyRevenue),
                revpar: (totalRevenue / (totalAvailable * Math.ceil((new Date(endDate) - new Date(startDate)) / (1000 * 60 * 60 * 24)))).toFixed(2)
            }
        };
    }

    /**
     * Get daily occupancy data for a date range
     * Returns data for each day to create occupancy charts
     * @param {string} startDate - Start date in YYYY-MM-DD format
     * @param {string} endDate - End date in YYYY-MM-DD format
     */
    static async getDailyOccupancyTrend(startDate, endDate) {
        const [avgRooms] = await db.query(`
            SELECT COUNT(*) as total_available
            FROM rooms 
            WHERE status != 'Maintenance'
        `);

        const totalAvailable = avgRooms[0].total_available;

        const [dailyData] = await db.query(`
            SELECT 
                DATE(b.check_in) as date,
                COUNT(DISTINCT b.room_id) as occupied_rooms,
                COUNT(DISTINCT CASE WHEN b.booking_status = 'CheckedIn' THEN b.booking_id END) as checked_in,
                COUNT(DISTINCT CASE WHEN b.booking_status = 'Confirmed' THEN b.booking_id END) as confirmed,
                SUM(b.total_amount) as daily_revenue,
                SUM(b.number_of_guests) as total_guests
            FROM bookings b
            WHERE DATE(b.check_in) >= ?
            AND DATE(b.check_in) <= ?
            AND b.booking_status IN ('Confirmed', 'CheckedIn')
            GROUP BY DATE(b.check_in)
            ORDER BY DATE(b.check_in) ASC
        `, [startDate, endDate]);

        return dailyData.map(day => ({
            date: day.date,
            occupied_rooms: day.occupied_rooms,
            checked_in: day.checked_in,
            confirmed: day.confirmed,
            available_rooms: totalAvailable,
            occupancy_percentage: ((day.occupied_rooms / totalAvailable) * 100).toFixed(2),
            daily_revenue: parseFloat(day.daily_revenue || 0).toFixed(2),
            adr: day.occupied_rooms > 0 ? (day.daily_revenue / day.occupied_rooms).toFixed(2) : 0,
            total_guests: day.total_guests || 0
        }));
    }

    /**
     * Get room-wise occupancy for a specific date
     * Shows which rooms are occupied and which are available
     * @param {string} date - Date in YYYY-MM-DD format
     */
    static async getDailyRoomStatus(date) {
        const [roomData] = await db.query(`
            SELECT 
                r.room_id,
                r.room_number,
                r.room_type,
                r.price,
                COALESCE(b.booking_id, NULL) as booking_id,
                COALESCE(b.guest_id, NULL) as guest_id,
                COALESCE(g.guest_name, 'Vacant') as guest_name,
                COALESCE(b.check_in, NULL) as check_in,
                COALESCE(b.check_out, NULL) as check_out,
                COALESCE(b.booking_status, 'Vacant') as status,
                COALESCE(rc.cleaning_status, 'Pending') as cleaning_status
            FROM rooms r
            LEFT JOIN bookings b ON r.room_id = b.room_id 
                AND b.check_in <= ?
                AND b.check_out > ?
                AND b.booking_status IN ('Confirmed', 'CheckedIn')
            LEFT JOIN guests g ON b.guest_id = g.guest_id
            LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
            ORDER BY r.room_number
        `, [date, date]);

        return roomData;
    }

    /**
     * Handle early checkout for a booking
     * @param {number} bookingId - The booking ID
     * @param {string} reason - Reason for early checkout
     */
    static async handleEarlyCheckout(bookingId, reason = null) {
        try {
            // Use the database function to handle early checkout
            const [result] = await db.query(
                'SELECT handle_early_checkout(?, ?) as result',
                [bookingId, reason]
            );
            
            if (result.length > 0 && result[0].result) {
                const checkoutResult = JSON.parse(result[0].result);
                
                if (checkoutResult.success) {
                    return {
                        success: true,
                        message: checkoutResult.message,
                        room_id: checkoutResult.room_id,
                        checkout_time: checkoutResult.checkout_time,
                        booking_id: bookingId,
                        early_checkout: true
                    };
                } else {
                    throw new Error(checkoutResult.message);
                }
            } else {
                throw new Error('Failed to process early checkout');
            }
        } catch (error) {
            console.error('Early checkout error:', error);
            throw error;
        }
    }

    /**
     * Calculate refund for early checkout
     * @param {number} bookingId - The booking ID
     */
    static async calculateEarlyCheckoutRefund(bookingId) {
        try {
            const booking = await this.getById(bookingId);
            if (!booking) {
                throw new Error('Booking not found');
            }

            // Check if booking is actually checked in
            if (booking.booking_status !== 'CheckedIn') {
                throw new Error('Cannot calculate refund for booking that is not checked in');
            }

            const checkInDate = new Date(booking.check_in);
            const originalCheckOutDate = new Date(booking.check_out);
            const actualCheckoutDate = new Date(); // Current time as early checkout
            
            // If actual_checkin_time exists, use it; otherwise use the scheduled check-in date
            const actualCheckinDate = booking.actual_checkin_time ? 
                new Date(booking.actual_checkin_time) : 
                checkInDate;

            // Calculate nights based on actual dates
            const totalNights = Math.ceil((originalCheckOutDate - checkInDate) / (1000 * 60 * 60 * 24));
            const stayedNights = Math.max(1, Math.ceil((actualCheckoutDate - actualCheckinDate) / (1000 * 60 * 60 * 24)));
            const unusedNights = Math.max(0, totalNights - stayedNights);

            const nightlyRate = parseFloat(booking.room_price);
            const totalPaid = parseFloat(booking.total_amount);
            const usedAmount = nightlyRate * stayedNights;
            const refundAmount = nightlyRate * unusedNights;

            // Apply early checkout penalty (10% of unused amount, configurable)
            const penaltyPercentage = 0.10; // 10%
            const penalty = refundAmount * penaltyPercentage;
            const finalRefund = Math.max(0, refundAmount - penalty);

            return {
                booking_details: {
                    booking_id: bookingId,
                    original_checkin: booking.check_in,
                    original_checkout: booking.check_out,
                    actual_checkin: actualCheckinDate.toISOString().split('T')[0],
                    actual_checkout: actualCheckoutDate.toISOString().split('T')[0]
                },
                nights_calculation: {
                    total_nights: totalNights,
                    stayed_nights: stayedNights,
                    unused_nights: unusedNights
                },
                financial_breakdown: {
                    nightly_rate: nightlyRate,
                    total_amount: totalPaid,
                    used_amount: usedAmount.toFixed(2),
                    gross_refund: refundAmount.toFixed(2),
                    penalty_percentage: (penaltyPercentage * 100) + '%',
                    penalty_amount: penalty.toFixed(2),
                    net_refund: finalRefund.toFixed(2)
                }
            };
        } catch (error) {
            throw error;
        }
    }

    /**
     * Process early checkout with refund
     * @param {number} bookingId - The booking ID
     * @param {string} reason - Reason for early checkout
     * @param {boolean} processRefund - Whether to process the refund
     */
    static async processEarlyCheckoutWithRefund(bookingId, reason = null, processRefund = true) {
        try {
            // Get booking details first
            const booking = await this.getById(bookingId);
            if (!booking) {
                throw new Error('Booking not found');
            }
            
            if (booking.booking_status !== 'CheckedIn') {
                throw new Error('Guest is not currently checked in');
            }
            
            // Calculate refund first
            const refundDetails = processRefund ? await this.calculateEarlyCheckoutRefund(bookingId) : null;
            
            // Process the early checkout by updating the booking status and setting checkout time
            const now = new Date();
            const checkoutTime = now.toISOString().slice(0, 19).replace('T', ' ');
            
            const checkoutType = now.getHours() < 12 ? 'Early' : 
                                now.getHours() > 18 ? 'Late' : 'Standard';
            
            await db.query(`
                UPDATE bookings 
                SET actual_checkout_time = ?, 
                    booking_status = 'CheckedOut',
                    is_early_checkout = ?,
                    checkout_type = ?,
                    early_checkout_reason = ?
                WHERE booking_id = ?
            `, [
                checkoutTime,
                checkoutType === 'Early' ? 1 : 0,
                checkoutType,
                reason || 'Early checkout requested',
                bookingId
            ]);
            
            // Update room status to Available
            await db.query('UPDATE rooms SET status = "Available" WHERE room_id = ?', [booking.room_id]);
            
            if (processRefund && refundDetails) {
                // Create refund record
                const refundAmount = parseFloat(refundDetails.financial_breakdown.net_refund);
                if (refundAmount > 0) {
                    await db.query(
                        `INSERT INTO refunds (booking_id, amount, reason, status, refund_method, created_at)
                         VALUES (?, ?, ?, 'Pending', 'Original Payment Method', NOW())`,
                        [bookingId, refundAmount, `Early checkout: ${reason || 'No reason provided'}`]
                    );
                }
            }
            
            return {
                booking_id: bookingId,
                checkout_time: checkoutTime,
                checkout_type: checkoutType,
                room_id: booking.room_id,
                refund_details: refundDetails
            };
        } catch (error) {
            throw error;
        }
    }

    /**
     * Get all early checkouts for a date range
     * @param {string} startDate - Start date
     * @param {string} endDate - End date
     */
    static async getEarlyCheckouts(startDate = null, endDate = null) {
        let query = `
            SELECT 
                b.*,
                g.name as guest_name,
                g.phone as guest_phone,
                r.room_number,
                r.room_type,
                DATEDIFF(b.check_out, b.actual_checkout_time) as days_early
            FROM booking_details b
            JOIN guests g ON b.guest_id = g.guest_id
            JOIN rooms r ON b.room_id = r.room_id
            WHERE b.is_early_checkout = TRUE
        `;
        
        const params = [];
        
        if (startDate && endDate) {
            query += ` AND DATE(b.actual_checkout_time) BETWEEN ? AND ?`;
            params.push(startDate, endDate);
        } else if (startDate) {
            query += ` AND DATE(b.actual_checkout_time) >= ?`;
            params.push(startDate);
        }
        
        query += ` ORDER BY b.actual_checkout_time DESC`;
        
        const [rows] = await db.query(query, params);
        return rows;
    }

    /**
     * Get rooms that became available due to early checkout
     * @param {string} date - Specific date (optional, defaults to today)
     */
    static async getRoomsFromEarlyCheckout(date = null) {
        const checkDate = date || new Date().toISOString().split('T')[0];
        
        const [rows] = await db.query(`
            SELECT 
                r.*,
                b.booking_id,
                b.actual_checkout_time,
                b.early_checkout_reason,
                g.name as guest_name,
                COALESCE(rc.cleaning_status, 'Pending') as cleaning_status,
                b.check_out as original_checkout,
                DATEDIFF(b.check_out, b.actual_checkout_time) as days_gained
            FROM rooms r
            JOIN bookings b ON r.room_id = b.room_id
            JOIN guests g ON b.guest_id = g.guest_id
            LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
            WHERE b.is_early_checkout = TRUE
            AND DATE(b.actual_checkout_time) = ?
            AND r.status = 'Available'
            ORDER BY b.actual_checkout_time DESC
        `, [checkDate]);
        
        return rows;
    }

    /**
     * Check if a booking is eligible for early checkout
     * @param {number} bookingId - The booking ID
     */
    static async isEligibleForEarlyCheckout(bookingId) {
        try {
            const booking = await this.getById(bookingId);
            if (!booking) {
                return { eligible: false, reason: 'Booking not found' };
            }
            
            if (booking.booking_status !== 'CheckedIn') {
                return { eligible: false, reason: 'Guest is not currently checked in' };
            }
            
            const checkOutDate = new Date(booking.check_out);
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            checkOutDate.setHours(0, 0, 0, 0);
            
            if (checkOutDate <= today) {
                return { eligible: false, reason: 'Checkout date has already passed' };
            }
            
            return { 
                eligible: true, 
                reason: 'Eligible for early checkout',
                days_remaining: Math.ceil((checkOutDate - today) / (1000 * 60 * 60 * 24))
            };
        } catch (error) {
            return { eligible: false, reason: error.message };
        }
    }

    /**
     * Enhanced room availability checking that considers early checkouts
     * @param {number} roomId - The room ID
     * @param {string} checkIn - Check-in date
     * @param {string} checkOut - Check-out date
     */
    static async checkRoomAvailabilityEnhanced(roomId, checkIn, checkOut) {
        try {
            const [result] = await db.query(
                'SELECT check_room_availability_enhanced(?, ?, ?) as availability_result',
                [roomId, checkIn, checkOut]
            );
            
            if (result.length > 0 && result[0].availability_result) {
                const availabilityData = JSON.parse(result[0].availability_result);
                
                // Get conflicting bookings if any
                if (!availabilityData.available) {
                    const [conflicts] = await db.query(`
                        SELECT 
                            b.*,
                            g.name as guest_name
                        FROM bookings b
                        JOIN guests g ON b.guest_id = g.guest_id
                        WHERE b.room_id = ?
                        AND b.booking_status IN ('Confirmed', 'CheckedIn')
                        AND b.check_in <= ? AND b.check_out >= ?
                        AND (b.actual_checkout_time IS NULL OR b.actual_checkout_time >= ?)
                        ORDER BY b.check_in
                    `, [roomId, checkOut, checkIn, checkIn]);
                    
                    availabilityData.conflicts = conflicts;
                }
                
                return availabilityData;
            }
            
            return { available: false, conflicts: 1, early_checkout_available: false };
        } catch (error) {
            console.error('Error checking enhanced availability:', error);
            return { available: false, conflicts: 1, early_checkout_available: false, error: error.message };
        }
    }

    /**
     * Get occupancy summary by room type
     * @param {string} startDate - Start date in YYYY-MM-DD format
     * @param {string} endDate - End date in YYYY-MM-DD format
     */
    static async getOccupancyByRoomType(startDate, endDate) {
        const [typeData] = await db.query(`
            SELECT 
                r.room_type,
                COUNT(DISTINCT r.room_id) as total_rooms,
                COUNT(DISTINCT b.room_id) as rooms_booked,
                SUM(DATEDIFF(b.check_out, b.check_in)) as total_nights_booked,
                SUM(b.total_amount) as total_revenue
            FROM rooms r
            LEFT JOIN bookings b ON r.room_id = b.room_id
                AND b.check_in >= ?
                AND b.check_out <= ?
                AND b.booking_status IN ('Confirmed', 'CheckedIn', 'CheckedOut')
            GROUP BY r.room_type
        `, [startDate, endDate]);

        return typeData.map(type => ({
            room_type: type.room_type,
            total_rooms: type.total_rooms,
            rooms_booked: type.rooms_booked,
            occupancy_rate: ((type.rooms_booked / type.total_rooms) * 100).toFixed(2),
            total_nights_booked: type.total_nights_booked || 0,
            total_revenue: parseFloat(type.total_revenue || 0).toFixed(2)
        }));
    }

    // ============================================
    // ROOM TRANSFER & BOOKING MODIFICATION
    // Real-world hotel business logic
    // ============================================

    /**
     * Transfer guest to a different room during their stay
     * Handles cases like: room issues, upgrades, guest requests, maintenance
     * @param {number} bookingId - The booking ID to transfer
     * @param {number} newRoomId - The new room ID
     * @param {string} reason - Reason for transfer
     * @param {number} priceDifference - Price adjustment (can be positive or negative)
     */
    static async transferRoom(bookingId, newRoomId, reason, priceDifference = 0) {
        const connection = await db.getConnection();
        try {
            await connection.beginTransaction();
            
            // Get current booking with lock
            const [currentBooking] = await connection.query(
                `SELECT b.*, r.room_number as current_room_number, r.price as current_room_price
                 FROM bookings b
                 JOIN rooms r ON b.room_id = r.room_id
                 WHERE b.booking_id = ? FOR UPDATE`,
                [bookingId]
            );
            
            if (currentBooking.length === 0) {
                throw new Error('Booking not found');
            }
            
            const booking = currentBooking[0];
            
            // Validate booking status
            if (!['Confirmed', 'CheckedIn'].includes(booking.booking_status)) {
                throw new Error(`Cannot transfer room. Booking status is ${booking.booking_status}`);
            }
            
            // Lock new room
            const [newRoom] = await connection.query(
                'SELECT * FROM rooms WHERE room_id = ? FOR UPDATE',
                [newRoomId]
            );
            
            if (newRoom.length === 0) {
                throw new Error('New room not found');
            }
            
            if (newRoom[0].status === 'Maintenance') {
                throw new Error('Cannot transfer to a room under maintenance');
            }
            
            // Check if new room is available for the remaining dates
            const today = new Date().toISOString().split('T')[0];
            const transferCheckIn = booking.booking_status === 'CheckedIn' ? today : booking.check_in;
            
            const [conflicts] = await connection.query(
                `SELECT b.booking_id, b.check_in, b.check_out, g.name as guest_name
                 FROM bookings b
                 LEFT JOIN guests g ON b.guest_id = g.guest_id
                 WHERE b.room_id = ? 
                 AND b.booking_id != ?
                 AND b.booking_status IN ('Confirmed', 'CheckedIn')
                 AND b.check_in < ? 
                 AND b.check_out > ?`,
                [newRoomId, bookingId, booking.check_out, transferCheckIn]
            );
            
            if (conflicts.length > 0) {
                const conflict = conflicts[0];
                throw new Error(
                    `Room ${newRoom[0].room_number} is already booked from ${conflict.check_in} to ${conflict.check_out} ` +
                    `(Booking #${conflict.booking_id} for ${conflict.guest_name || 'Guest'})`
                );
            }
            
            // Calculate price adjustment if not provided
            let finalPriceDifference = priceDifference;
            if (priceDifference === 0 && newRoom[0].price !== booking.room_price) {
                const remainingNights = Math.ceil(
                    (new Date(booking.check_out) - new Date(transferCheckIn)) / (1000 * 60 * 60 * 24)
                );
                finalPriceDifference = (parseFloat(newRoom[0].price) - parseFloat(booking.room_price)) * remainingNights;
            }
            
            const newTotalAmount = parseFloat(booking.total_amount) + finalPriceDifference;
            const oldRoomId = booking.room_id;
            
            // Update booking with new room
            await connection.query(
                `UPDATE bookings 
                 SET room_id = ?, 
                     room_price = ?, 
                     total_amount = ?,
                     special_requests = CONCAT(COALESCE(special_requests, ''), 
                                              '\n[Room Transfer: ', NOW(), '] From Room ', ?, 
                                              ' to Room ', ?, '. Reason: ', ?, 
                                              '. Price adjustment: ', ?, ')')
                 WHERE booking_id = ?`,
                [
                    newRoomId, 
                    newRoom[0].price, 
                    newTotalAmount,
                    booking.current_room_number,
                    newRoom[0].room_number,
                    reason,
                    finalPriceDifference.toFixed(2),
                    bookingId
                ]
            );
            
            // Update old room status - check if there are other active bookings
            const [oldRoomBookings] = await connection.query(
                `SELECT COUNT(*) as count FROM bookings 
                 WHERE room_id = ? AND booking_status IN ('Confirmed', 'CheckedIn')`,
                [oldRoomId]
            );
            
            if (oldRoomBookings[0].count === 0) {
                await connection.query(
                    'UPDATE rooms SET status = ? WHERE room_id = ?',
                    ['Available', oldRoomId]
                );
            }
            
            // Update new room status
            await connection.query(
                'UPDATE rooms SET status = ? WHERE room_id = ?',
                ['Booked', newRoomId]
            );
            
            // Transfer guest session if checked in
            if (booking.booking_status === 'CheckedIn') {
                await connection.query(
                    `UPDATE guest_sessions 
                     SET special_requests = CONCAT(COALESCE(special_requests, ''), 
                                                  '\n[Room transferred from ', ?, ' to ', ?, ']')
                     WHERE booking_id = ?`,
                    [booking.current_room_number, newRoom[0].room_number, bookingId]
                );
            }
            
            await connection.commit();
            connection.release();
            
            return {
                success: true,
                booking_id: bookingId,
                old_room: {
                    room_id: oldRoomId,
                    room_number: booking.current_room_number,
                    price: booking.room_price
                },
                new_room: {
                    room_id: newRoomId,
                    room_number: newRoom[0].room_number,
                    price: newRoom[0].price
                },
                price_adjustment: finalPriceDifference,
                new_total_amount: newTotalAmount,
                reason: reason,
                transfer_date: new Date().toISOString()
            };
        } catch (error) {
            await connection.rollback();
            connection.release();
            throw error;
        }
    }

    /**
     * Modify booking dates (check-in and/or check-out)
     * @param {number} bookingId - The booking ID to modify
     * @param {object} newDates - Object containing new_check_in and/or new_check_out
     */
    static async modifyBookingDates(bookingId, newDates) {
        const { new_check_in, new_check_out } = newDates;
        const connection = await db.getConnection();
        
        try {
            await connection.beginTransaction();
            
            // Get current booking with lock
            const [currentBooking] = await connection.query(
                `SELECT b.*, r.room_number, r.price as room_price
                 FROM bookings b
                 JOIN rooms r ON b.room_id = r.room_id
                 WHERE b.booking_id = ? FOR UPDATE`,
                [bookingId]
            );
            
            if (currentBooking.length === 0) {
                throw new Error('Booking not found');
            }
            
            const booking = currentBooking[0];
            
            // Only allow date modification for Confirmed bookings
            if (booking.booking_status !== 'Confirmed') {
                throw new Error(`Cannot modify dates. Booking status is ${booking.booking_status}. Only Confirmed bookings can be modified.`);
            }
            
            const finalCheckIn = new_check_in || booking.check_in;
            const finalCheckOut = new_check_out || booking.check_out;
            
            // Validate dates
            const checkInDate = new Date(finalCheckIn);
            const checkOutDate = new Date(finalCheckOut);
            
            if (checkInDate >= checkOutDate) {
                throw new Error('Check-out date must be after check-in date');
            }
            
            // Check for conflicts with new dates
            const [conflicts] = await connection.query(
                `SELECT b.booking_id, b.check_in, b.check_out, g.name as guest_name, b.booking_status
                 FROM bookings b
                 LEFT JOIN guests g ON b.guest_id = g.guest_id
                 WHERE b.room_id = ? 
                 AND b.booking_id != ?
                 AND b.booking_status IN ('Confirmed', 'CheckedIn')
                 AND b.check_in < ? 
                 AND b.check_out > ?`,
                [booking.room_id, bookingId, finalCheckOut, finalCheckIn]
            );
            
            if (conflicts.length > 0) {
                const conflict = conflicts[0];
                throw new Error(
                    `Room ${booking.room_number} is not available for the new dates. ` +
                    `Conflict with Booking #${conflict.booking_id} (${conflict.guest_name || 'Guest'}) ` +
                    `from ${conflict.check_in} to ${conflict.check_out}`
                );
            }
            
            // Recalculate total amount
            const newNights = Math.ceil((checkOutDate - checkInDate) / (1000 * 60 * 60 * 24));
            const oldNights = booking.number_of_nights;
            const newRoomTotal = parseFloat(booking.room_price) * newNights;
            
            // Keep discount proportional
            const discountAmount = parseFloat(booking.discount_value) || 0;
            const newTotalAmount = newRoomTotal - discountAmount;
            
            // Update booking
            await connection.query(
                `UPDATE bookings 
                 SET check_in = ?, 
                     check_out = ?,
                     total_amount = ?,
                     special_requests = CONCAT(COALESCE(special_requests, ''), 
                                              '\n[Date Modified: ', NOW(), '] From ', ?, ' - ', ?, 
                                              ' to ', ?, ' - ', ?, ' (', ?, ' nights to ', ?, ' nights)')
                 WHERE booking_id = ?`,
                [
                    finalCheckIn,
                    finalCheckOut,
                    newTotalAmount,
                    booking.check_in,
                    booking.check_out,
                    finalCheckIn,
                    finalCheckOut,
                    oldNights,
                    newNights,
                    bookingId
                ]
            );
            
            await connection.commit();
            connection.release();
            
            return {
                success: true,
                booking_id: bookingId,
                old_dates: {
                    check_in: booking.check_in,
                    check_out: booking.check_out,
                    nights: oldNights
                },
                new_dates: {
                    check_in: finalCheckIn,
                    check_out: finalCheckOut,
                    nights: newNights
                },
                old_amount: parseFloat(booking.total_amount),
                new_amount: newTotalAmount,
                price_difference: newTotalAmount - parseFloat(booking.total_amount)
            };
        } catch (error) {
            await connection.rollback();
            connection.release();
            throw error;
        }
    }

    /**
     * Check room availability for specific dates (enhanced with conflict details)
     * @param {number} roomId - Room ID to check
     * @param {string} checkIn - Check-in date (YYYY-MM-DD)
     * @param {string} checkOut - Check-out date (YYYY-MM-DD)
     * @param {number} excludeBookingId - Optional booking ID to exclude from conflict check
     */
    static async checkRoomAvailabilityDetailed(roomId, checkIn, checkOut, excludeBookingId = null) {
        try {
            // Get room details
            const [room] = await db.query(
                'SELECT * FROM rooms WHERE room_id = ?',
                [roomId]
            );
            
            if (room.length === 0) {
                return { available: false, error: 'Room not found' };
            }
            
            if (room[0].status === 'Maintenance') {
                return { 
                    available: false, 
                    reason: 'Room is under maintenance',
                    room: room[0]
                };
            }
            
            // Check for conflicts
            let query = `
                SELECT b.*, g.name as guest_name, g.phone as guest_phone
                FROM bookings b
                LEFT JOIN guests g ON b.guest_id = g.guest_id
                WHERE b.room_id = ? 
                AND b.booking_status IN ('Confirmed', 'CheckedIn')
                AND b.check_in < ? 
                AND b.check_out > ?
            `;
            
            const params = [roomId, checkOut, checkIn];
            
            if (excludeBookingId) {
                query += ' AND b.booking_id != ?';
                params.push(excludeBookingId);
            }
            
            const [conflicts] = await db.query(query, params);
            
            if (conflicts.length === 0) {
                return {
                    available: true,
                    room: room[0],
                    conflicts: []
                };
            }
            
            return {
                available: false,
                reason: 'Room has conflicting bookings',
                room: room[0],
                conflicts: conflicts.map(c => ({
                    booking_id: c.booking_id,
                    guest_name: c.guest_name,
                    guest_phone: c.guest_phone,
                    check_in: c.check_in,
                    check_out: c.check_out,
                    booking_status: c.booking_status,
                    overlap_days: this._calculateOverlapDays(checkIn, checkOut, c.check_in, c.check_out)
                }))
            };
        } catch (error) {
            return { available: false, error: error.message };
        }
    }

    /**
     * Helper to calculate overlap days between two date ranges
     */
    static _calculateOverlapDays(start1, end1, start2, end2) {
        const s1 = new Date(start1);
        const e1 = new Date(end1);
        const s2 = new Date(start2);
        const e2 = new Date(end2);
        
        const overlapStart = s1 > s2 ? s1 : s2;
        const overlapEnd = e1 < e2 ? e1 : e2;
        
        if (overlapStart >= overlapEnd) return 0;
        
        return Math.ceil((overlapEnd - overlapStart) / (1000 * 60 * 60 * 24));
    }

    /**
     * Get alternative rooms for booking modification/transfer
     * @param {string} checkIn - Check-in date
     * @param {string} checkOut - Check-out date
     * @param {number} numberOfGuests - Number of guests
     * @param {string} preferredType - Preferred room type (optional)
     */
    static async getAlternativeRooms(checkIn, checkOut, numberOfGuests, preferredType = null) {
        let query = `
            SELECT DISTINCT r.*,
                   (SELECT COUNT(*) FROM bookings b 
                    WHERE b.room_id = r.room_id 
                    AND b.booking_status IN ('Confirmed', 'CheckedIn')
                    AND b.check_in < ? 
                    AND b.check_out > ?) as conflicting_bookings
            FROM rooms r
            WHERE r.status != 'Maintenance'
            AND r.max_guests >= ?
            AND r.room_id NOT IN (
                SELECT room_id FROM bookings 
                WHERE booking_status IN ('Confirmed', 'CheckedIn')
                AND check_in < ? 
                AND check_out > ?
            )
        `;
        
        const params = [checkOut, checkIn, numberOfGuests, checkOut, checkIn];
        
        if (preferredType) {
            query += ' AND r.room_type = ?';
            params.push(preferredType);
        }
        
        query += ' ORDER BY r.room_type, r.price, r.room_number LIMIT 10';
        
        const [rooms] = await db.query(query, params);
        
        // Calculate cost for the period
        const nights = Math.ceil((new Date(checkOut) - new Date(checkIn)) / (1000 * 60 * 60 * 24));
        
        return rooms.map(room => ({
            ...room,
            total_cost_for_period: parseFloat(room.price) * nights,
            nights: nights
        }));
    }
}

module.exports = Booking;
