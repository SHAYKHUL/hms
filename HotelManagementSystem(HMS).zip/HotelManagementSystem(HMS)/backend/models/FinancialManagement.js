const db = require('../config/database');

class FinancialManagement {
    // ============ STAFF SALARY MANAGEMENT ============

    // Get all salary records
    static async getAllSalaries(filters = {}) {
        let query = `
            SELECT 
                ss.*,
                ss.payment_status as status,
                hs.staff_name,
                hs.role,
                hs.phone
            FROM staff_salaries ss
            JOIN housekeeping_staff hs ON ss.staff_id = hs.staff_id
            WHERE 1=1
        `;
        const params = [];

        if (filters.staff_id) {
            query += ` AND ss.staff_id = ?`;
            params.push(filters.staff_id);
        }

        if (filters.payment_month) {
            query += ` AND ss.payment_month = ?`;
            params.push(filters.payment_month);
        }

        if (filters.payment_status) {
            query += ` AND ss.payment_status = ?`;
            params.push(filters.payment_status);
        }

        query += ` ORDER BY ss.payment_month DESC, hs.staff_name ASC`;

        const [rows] = await db.query(query, params);
        return rows;
    }

    // Get salary by ID
    static async getSalaryById(salaryId) {
        const [rows] = await db.query(
            `SELECT ss.*, hs.staff_name, hs.role 
             FROM staff_salaries ss 
             JOIN housekeeping_staff hs ON ss.staff_id = hs.staff_id
             WHERE ss.salary_id = ?`,
            [salaryId]
        );
        return rows[0];
    }

    // Get salaries for a specific staff member
    static async getSalariesByStaff(staffId) {
        const [rows] = await db.query(
            `SELECT * FROM staff_salaries WHERE staff_id = ? ORDER BY payment_month DESC`,
            [staffId]
        );
        return rows;
    }

    // Create salary record
    static async createSalary(salaryData) {
        const {
            staff_id, payment_month, base_salary, bonus = 0, deductions = 0,
            overtime_hours = 0, overtime_amount = 0, payment_date,
            payment_method = 'Bank Transfer', payment_reference, notes
        } = salaryData;

        if (!staff_id || !payment_month || !base_salary || !payment_date) {
            throw new Error('Staff ID, payment month, base salary, and payment date are required');
        }

        const total_amount = parseFloat(base_salary) + parseFloat(bonus) + parseFloat(overtime_amount) - parseFloat(deductions);

        const [result] = await db.query(
            `INSERT INTO staff_salaries 
            (staff_id, payment_month, base_salary, bonus, deductions, overtime_hours, 
             overtime_amount, total_amount, payment_date, payment_method, payment_reference, notes, payment_status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')`,
            [staff_id, payment_month, base_salary, bonus, deductions, overtime_hours,
             overtime_amount, total_amount, payment_date, payment_method, payment_reference, notes]
        );

        return { salary_id: result.insertId, total_amount };
    }

    // Update salary record
    static async updateSalary(salaryId, salaryData) {
        const {
            base_salary, bonus, deductions, overtime_hours, overtime_amount,
            payment_date, payment_method, payment_reference, payment_status, notes
        } = salaryData;

        const total_amount = parseFloat(base_salary || 0) + parseFloat(bonus || 0) + 
                           parseFloat(overtime_amount || 0) - parseFloat(deductions || 0);

        await db.query(
            `UPDATE staff_salaries 
            SET base_salary = ?, bonus = ?, deductions = ?, overtime_hours = ?, 
                overtime_amount = ?, total_amount = ?, payment_date = ?, 
                payment_method = ?, payment_reference = ?, payment_status = ?, notes = ?
            WHERE salary_id = ?`,
            [base_salary, bonus, deductions, overtime_hours, overtime_amount, total_amount,
             payment_date, payment_method, payment_reference, payment_status, notes, salaryId]
        );
    }

    // Mark salary as paid
    static async markSalaryPaid(salaryId, paymentReference) {
        await db.query(
            `UPDATE staff_salaries 
            SET payment_status = 'Paid', payment_reference = ? 
            WHERE salary_id = ?`,
            [paymentReference, salaryId]
        );
    }

    // Get salary statistics
    static async getSalaryStatistics(month = null) {
        let query = `
            SELECT 
                COUNT(*) as total_records,
                SUM(CASE WHEN payment_status = 'Paid' THEN 1 ELSE 0 END) as paid_count,
                SUM(CASE WHEN payment_status = 'Pending' THEN 1 ELSE 0 END) as pending_count,
                SUM(total_amount) as total_amount,
                SUM(CASE WHEN payment_status = 'Paid' THEN total_amount ELSE 0 END) as paid_amount,
                SUM(CASE WHEN payment_status = 'Pending' THEN total_amount ELSE 0 END) as pending_amount
            FROM staff_salaries
        `;
        const params = [];

        if (month) {
            query += ` WHERE payment_month = ?`;
            params.push(month);
        }

        const [rows] = await db.query(query, params);
        return rows[0];
    }

    // ============ INCOME MANAGEMENT ============

    // Get all income records
    static async getAllIncome(filters = {}) {
        let query = `
            SELECT *,
                COALESCE(
                    guest_name,
                    CONCAT('Booking #', booking_id),
                    CONCAT('Service Order #', service_order_id),
                    'N/A'
                ) as source
            FROM income_records 
            WHERE 1=1
        `;
        const params = [];

        if (filters.income_type) {
            query += ` AND income_type = ?`;
            params.push(filters.income_type);
        }

        if (filters.start_date) {
            query += ` AND income_date >= ?`;
            params.push(filters.start_date);
        }

        if (filters.end_date) {
            query += ` AND income_date <= ?`;
            params.push(filters.end_date);
        }

        if (filters.payment_method) {
            query += ` AND payment_method = ?`;
            params.push(filters.payment_method);
        }

        query += ` ORDER BY income_date DESC, created_at DESC`;

        const [rows] = await db.query(query, params);
        return rows;
    }

    // Get income by ID
    static async getIncomeById(incomeId) {
        const [rows] = await db.query(
            `SELECT * FROM income_records WHERE income_id = ?`,
            [incomeId]
        );
        return rows[0];
    }

    // Create income record
    static async createIncome(incomeData) {
        const {
            income_type, description, amount, income_date,
            payment_method = 'Cash', booking_id, service_order_id,
            invoice_number, guest_name, category, notes, created_by
        } = incomeData;

        if (!income_type || !description || !amount || !income_date) {
            throw new Error('Income type, description, amount, and date are required');
        }

        if (parseFloat(amount) <= 0) {
            throw new Error('Amount must be greater than zero');
        }

        const [result] = await db.query(
            `INSERT INTO income_records 
            (income_type, description, amount, income_date, payment_method, booking_id,
             service_order_id, invoice_number, guest_name, category, notes, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [income_type, description, amount, income_date, payment_method, booking_id,
             service_order_id, invoice_number, guest_name, category, notes, created_by]
        );

        return { income_id: result.insertId };
    }

    // Update income record
    static async updateIncome(incomeId, incomeData) {
        const {
            income_type, description, amount, income_date, payment_method,
            invoice_number, guest_name, category, notes
        } = incomeData;

        await db.query(
            `UPDATE income_records 
            SET income_type = ?, description = ?, amount = ?, income_date = ?,
                payment_method = ?, invoice_number = ?, guest_name = ?, category = ?, notes = ?
            WHERE income_id = ?`,
            [income_type, description, amount, income_date, payment_method,
             invoice_number, guest_name, category, notes, incomeId]
        );
    }

    // Delete income record
    static async deleteIncome(incomeId) {
        await db.query(`DELETE FROM income_records WHERE income_id = ?`, [incomeId]);
    }

    // Get income statistics
    static async getIncomeStatistics(startDate = null, endDate = null) {
        let query = `
            SELECT 
                COUNT(*) as total_records,
                SUM(amount) as total_amount,
                AVG(amount) as average_amount,
                income_type,
                SUM(amount) as type_total
            FROM income_records
        `;
        const params = [];

        if (startDate && endDate) {
            query += ` WHERE income_date BETWEEN ? AND ?`;
            params.push(startDate, endDate);
        }

        query += ` GROUP BY income_type ORDER BY type_total DESC`;

        const [rows] = await db.query(query, params);

        // Also get grand totals
        let totalQuery = `SELECT COUNT(*) as count, SUM(amount) as total FROM income_records`;
        if (startDate && endDate) {
            totalQuery += ` WHERE income_date BETWEEN ? AND ?`;
        }

        const [totals] = await db.query(totalQuery, params);

        return {
            by_type: rows,
            grand_total: totals[0]
        };
    }

    // ============ EXPENSE MANAGEMENT ============

    // Get all expense records
    static async getAllExpenses(filters = {}) {
        let query = `SELECT * FROM expense_records WHERE 1=1`;
        const params = [];

        if (filters.expense_type) {
            query += ` AND expense_type = ?`;
            params.push(filters.expense_type);
        }

        if (filters.start_date) {
            query += ` AND expense_date >= ?`;
            params.push(filters.start_date);
        }

        if (filters.end_date) {
            query += ` AND expense_date <= ?`;
            params.push(filters.end_date);
        }

        if (filters.payment_status) {
            query += ` AND payment_status = ?`;
            params.push(filters.payment_status);
        }

        if (filters.vendor_name) {
            query += ` AND vendor_name LIKE ?`;
            params.push(`%${filters.vendor_name}%`);
        }

        query += ` ORDER BY expense_date DESC, created_at DESC`;

        const [rows] = await db.query(query, params);
        return rows;
    }

    // Get expense by ID
    static async getExpenseById(expenseId) {
        const [rows] = await db.query(
            `SELECT * FROM expense_records WHERE expense_id = ?`,
            [expenseId]
        );
        return rows[0];
    }

    // Create expense record
    static async createExpense(expenseData) {
        const {
            expense_type, description, amount, expense_date,
            payment_method = 'Bank Transfer', vendor_name, invoice_number,
            category, staff_id, maintenance_log_id, inventory_item_id,
            payment_status = 'Pending', approved_by, notes, created_by
        } = expenseData;

        if (!expense_type || !description || !amount || !expense_date) {
            throw new Error('Expense type, description, amount, and date are required');
        }

        if (parseFloat(amount) <= 0) {
            throw new Error('Amount must be greater than zero');
        }

        const [result] = await db.query(
            `INSERT INTO expense_records 
            (expense_type, description, amount, expense_date, payment_method, vendor_name,
             invoice_number, category, staff_id, maintenance_log_id, inventory_item_id,
             payment_status, approved_by, notes, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [expense_type, description, amount, expense_date, payment_method, vendor_name,
             invoice_number, category, staff_id, maintenance_log_id, inventory_item_id,
             payment_status, approved_by, notes, created_by]
        );

        return { expense_id: result.insertId };
    }

    // Update expense record
    static async updateExpense(expenseId, expenseData) {
        const {
            expense_type, description, amount, expense_date, payment_method,
            vendor_name, invoice_number, category, payment_status, approved_by, notes
        } = expenseData;

        await db.query(
            `UPDATE expense_records 
            SET expense_type = ?, description = ?, amount = ?, expense_date = ?,
                payment_method = ?, vendor_name = ?, invoice_number = ?, category = ?,
                payment_status = ?, approved_by = ?, notes = ?
            WHERE expense_id = ?`,
            [expense_type, description, amount, expense_date, payment_method,
             vendor_name, invoice_number, category, payment_status, approved_by, notes, expenseId]
        );
    }

    // Mark expense as paid
    static async markExpensePaid(expenseId) {
        await db.query(
            `UPDATE expense_records SET payment_status = 'Paid' WHERE expense_id = ?`,
            [expenseId]
        );
    }

    // Delete expense record
    static async deleteExpense(expenseId) {
        await db.query(`DELETE FROM expense_records WHERE expense_id = ?`, [expenseId]);
    }

    // Get expense statistics
    static async getExpenseStatistics(startDate = null, endDate = null) {
        let query = `
            SELECT 
                COUNT(*) as total_records,
                SUM(amount) as total_amount,
                AVG(amount) as average_amount,
                expense_type,
                SUM(amount) as type_total,
                SUM(CASE WHEN payment_status = 'Paid' THEN amount ELSE 0 END) as paid_amount,
                SUM(CASE WHEN payment_status = 'Pending' THEN amount ELSE 0 END) as pending_amount
            FROM expense_records
        `;
        const params = [];

        if (startDate && endDate) {
            query += ` WHERE expense_date BETWEEN ? AND ?`;
            params.push(startDate, endDate);
        }

        query += ` GROUP BY expense_type ORDER BY type_total DESC`;

        const [rows] = await db.query(query, params);

        // Also get grand totals
        let totalQuery = `
            SELECT 
                COUNT(*) as count, 
                SUM(amount) as total,
                SUM(CASE WHEN payment_status = 'Paid' THEN amount ELSE 0 END) as paid,
                SUM(CASE WHEN payment_status = 'Pending' THEN amount ELSE 0 END) as pending
            FROM expense_records
        `;
        if (startDate && endDate) {
            totalQuery += ` WHERE expense_date BETWEEN ? AND ?`;
        }

        const [totals] = await db.query(totalQuery, params);

        return {
            by_type: rows,
            grand_total: totals[0]
        };
    }

    // ============ FINANCIAL REPORTS ============

    // Get profit & loss summary
    static async getProfitLossSummary(startDate = null, endDate = null) {
        const params = [];
        let dateFilter = '';

        if (startDate && endDate) {
            dateFilter = ` WHERE income_date BETWEEN ? AND ?`;
            params.push(startDate, endDate);
        }

        // Get total income
        const [incomeResult] = await db.query(
            `SELECT COALESCE(SUM(amount), 0) as total FROM income_records${dateFilter}`,
            params
        );

        // Get total expenses
        const expenseParams = [];
        let expenseDateFilter = '';
        if (startDate && endDate) {
            expenseDateFilter = ` WHERE expense_date BETWEEN ? AND ?`;
            expenseParams.push(startDate, endDate);
        }

        const [expenseResult] = await db.query(
            `SELECT COALESCE(SUM(amount), 0) as total FROM expense_records${expenseDateFilter}`,
            expenseParams
        );

        const totalIncome = parseFloat(incomeResult[0].total);
        const totalExpense = parseFloat(expenseResult[0].total);
        const netProfit = totalIncome - totalExpense;

        return {
            total_income: totalIncome,
            total_expense: totalExpense,
            net_profit: netProfit,
            profit_margin: totalIncome > 0 ? ((netProfit / totalIncome) * 100).toFixed(2) : 0
        };
    }

    // Get monthly summary
    static async getMonthlySummary(year, month) {
        const startDate = `${year}-${month.toString().padStart(2, '0')}-01`;
        const endDate = new Date(year, month, 0).toISOString().split('T')[0]; // Last day of month

        const profitLoss = await this.getProfitLossSummary(startDate, endDate);
        const incomeStats = await this.getIncomeStatistics(startDate, endDate);
        const expenseStats = await this.getExpenseStatistics(startDate, endDate);

        return {
            period: `${year}-${month.toString().padStart(2, '0')}`,
            profit_loss: profitLoss,
            income: incomeStats,
            expense: expenseStats
        };
    }
}

module.exports = FinancialManagement;
