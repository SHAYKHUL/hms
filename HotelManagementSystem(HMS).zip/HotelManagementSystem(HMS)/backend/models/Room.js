const db = require('../config/database');

class Room {
    // Get all rooms
    static async getAll() {
        const [rows] = await db.query('SELECT * FROM rooms ORDER BY room_number');
        return rows;
    }

    // Get room by ID
    static async getById(id) {
        const [rows] = await db.query('SELECT * FROM rooms WHERE room_id = ?', [id]);
        return rows[0];
    }

    // Get all rooms with cleaning status
    static async getAllWithCleaningStatus() {
        const [rows] = await db.query(`
            SELECT 
                r.*,
                COALESCE(rc.cleaning_status, 'Pending') as cleaning_status,
                COALESCE(rc.last_cleaned_by, null) as last_cleaned_by,
                COALESCE(rc.last_cleaned_date, null) as last_cleaned_date,
                COALESCE(rc.next_cleaning_scheduled, null) as next_cleaning_scheduled,
                s.staff_name as last_cleaned_by_name,
                (SELECT COUNT(*) FROM cleaning_tasks WHERE room_id = r.room_id AND status != 'Completed' AND scheduled_date <= CURDATE()) as pending_tasks,
                (SELECT COUNT(*) FROM maintenance_logs WHERE room_id = r.room_id AND status IN ('Reported', 'Assigned', 'In Progress')) as pending_maintenance
            FROM rooms r
            LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
            LEFT JOIN housekeeping_staff s ON rc.last_cleaned_by = s.staff_id
            ORDER BY r.room_number
        `);
        return rows;
    }

    // Get room cleaning status
    static async getCleaningStatus(roomId) {
        const [rows] = await db.query(`
            SELECT 
                r.*,
                COALESCE(rc.cleaning_status, 'Pending') as cleaning_status,
                rc.last_cleaned_by,
                rc.last_cleaned_date,
                rc.next_cleaning_scheduled,
                s.staff_name as last_cleaned_by_name,
                (SELECT COUNT(*) FROM cleaning_tasks WHERE room_id = r.room_id AND status != 'Completed' AND scheduled_date <= CURDATE()) as pending_tasks,
                (SELECT COUNT(*) FROM maintenance_logs WHERE room_id = r.room_id AND status IN ('Reported', 'Assigned', 'In Progress')) as pending_maintenance
            FROM rooms r
            LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
            LEFT JOIN housekeeping_staff s ON rc.last_cleaned_by = s.staff_id
            WHERE r.room_id = ?
        `, [roomId]);
        return rows[0];
    }

    // Update room cleaning status
    static async updateCleaningStatus(roomId, cleaningStatus, staffId = null) {
        const validStatuses = ['Dirty', 'Cleaning in Progress', 'Cleaned', 'Ready for Guest', 'Pending', 'Inspecting'];
        if (!validStatuses.includes(cleaningStatus)) {
            throw new Error('Invalid cleaning status');
        }

        // Check if status record exists
        const [exists] = await db.query(
            'SELECT room_id FROM room_cleaning_status WHERE room_id = ?',
            [roomId]
        );

        if (exists.length > 0) {
            // Update existing record
            if (cleaningStatus === 'Cleaned' && staffId) {
                await db.query(
                    `UPDATE room_cleaning_status 
                     SET cleaning_status = ?, last_cleaned_by = ?, last_cleaned_date = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
                     WHERE room_id = ?`,
                    [cleaningStatus, staffId, roomId]
                );
            } else {
                await db.query(
                    `UPDATE room_cleaning_status 
                     SET cleaning_status = ?, updated_at = CURRENT_TIMESTAMP
                     WHERE room_id = ?`,
                    [cleaningStatus, roomId]
                );
            }
        } else {
            // Insert new record
            await db.query(
                `INSERT INTO room_cleaning_status (room_id, cleaning_status, last_cleaned_by)
                 VALUES (?, ?, ?)`,
                [roomId, cleaningStatus, staffId || null]
            );
        }

        return { success: true, cleaning_status: cleaningStatus };
    }

    // Get available rooms with optional AC/Non-AC filtering
    static async getAvailable(checkIn, checkOut, acType = null) {
        let query = `
            SELECT * FROM rooms 
            WHERE status = 'Available' 
            AND room_id NOT IN (
                SELECT room_id FROM bookings 
                WHERE booking_status IN ('Confirmed', 'CheckedIn')
                AND (
                    (check_in <= ? AND check_out >= ?) OR
                    (check_in <= ? AND check_out >= ?) OR
                    (check_in >= ? AND check_out <= ?)
                )
            )
        `;
        
        let params = [checkIn, checkIn, checkOut, checkOut, checkIn, checkOut];
        
        // Add AC/Non-AC filtering if specified
        if (acType && ['AC', 'Non-AC'].includes(acType)) {
            query += ` AND ac_type = ?`;
            params.push(acType);
        }
        
        query += ` ORDER BY room_type, ac_type, price`;
        
        const [rows] = await db.query(query, params);
        return rows;
    }

    // Create new room
    static async create(roomData) {
        const { room_number, room_type, ac_type, price, bed_count, max_guests, status, description, amenities } = roomData;
        // Normalize room number to uppercase for consistency
        const normalizedRoomNumber = (room_number || '').toString().trim().toUpperCase();
        
        const [result] = await db.query(
            'INSERT INTO rooms (room_number, room_type, ac_type, price, bed_count, max_guests, status, description, amenities) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [normalizedRoomNumber, room_type, ac_type || 'AC', price, bed_count || 1, max_guests || 2, status || 'Available', description, amenities]
        );
        
        // Initialize cleaning status for new room
        const roomId = result.insertId;
        await db.query(
            'INSERT INTO room_cleaning_status (room_id, cleaning_status) VALUES (?, ?)',
            [roomId, 'Pending']
        );
        
        return roomId;
    }

    // Update room
    static async update(id, roomData) {
        const { room_number, room_type, ac_type, price, bed_count, max_guests, status, description, amenities } = roomData;
        // Normalize room number to uppercase for consistency
        const normalizedRoomNumber = (room_number || '').toString().trim().toUpperCase();
        
        const [result] = await db.query(
            'UPDATE rooms SET room_number = ?, room_type = ?, ac_type = ?, price = ?, bed_count = ?, max_guests = ?, status = ?, description = ?, amenities = ? WHERE room_id = ?',
            [normalizedRoomNumber, room_type, ac_type || 'AC', price, bed_count || 1, max_guests || 2, status, description, amenities, id]
        );
        return result.affectedRows;
    }

    // Update room status
    static async updateStatus(id, status) {
        const [result] = await db.query(
            'UPDATE rooms SET status = ? WHERE room_id = ?',
            [status, id]
        );
        return result.affectedRows;
    }

    // Delete room
    static async delete(id) {
        const [result] = await db.query('DELETE FROM rooms WHERE room_id = ?', [id]);
        return result.affectedRows;
    }

    // Get room statistics with cleaning status
    static async getStatistics() {
        const [stats] = await db.query(`
            SELECT 
                COUNT(distinct r.room_id) as total_rooms,
                SUM(CASE WHEN r.status = 'Available' THEN 1 ELSE 0 END) as available_rooms,
                SUM(CASE WHEN r.status = 'Booked' THEN 1 ELSE 0 END) as booked_rooms,
                SUM(CASE WHEN r.status = 'Maintenance' THEN 1 ELSE 0 END) as maintenance_rooms,
                SUM(CASE WHEN rc.cleaning_status = 'Cleaned' THEN 1 ELSE 0 END) as cleaned_rooms,
                SUM(CASE WHEN rc.cleaning_status = 'Dirty' THEN 1 ELSE 0 END) as dirty_rooms,
                SUM(CASE WHEN rc.cleaning_status = 'Cleaning in Progress' THEN 1 ELSE 0 END) as cleaning_in_progress
            FROM rooms r
            LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
        `);
        return stats[0];
    }

    // Get rooms by cleaning status
    static async getRoomsByCleaningStatus(cleaningStatus) {
        const validStatuses = ['Dirty', 'Cleaning in Progress', 'Cleaned', 'Ready for Guest', 'Pending', 'Inspecting'];
        if (!validStatuses.includes(cleaningStatus)) {
            throw new Error('Invalid cleaning status');
        }

        const [rows] = await db.query(`
            SELECT 
                r.*,
                rc.cleaning_status,
                rc.last_cleaned_by,
                rc.last_cleaned_date,
                s.staff_name as last_cleaned_by_name
            FROM rooms r
            LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
            LEFT JOIN housekeeping_staff s ON rc.last_cleaned_by = s.staff_id
            WHERE rc.cleaning_status = ?
            ORDER BY r.room_number
        `, [cleaningStatus]);
        return rows;
    }

    // Schedule next cleaning for room
    static async scheduleNextCleaning(roomId, scheduledDate) {
        const [result] = await db.query(
            `UPDATE room_cleaning_status 
             SET next_cleaning_scheduled = ?, updated_at = CURRENT_TIMESTAMP
             WHERE room_id = ?`,
            [scheduledDate, roomId]
        );
        return result.affectedRows > 0;
    }

    // Get rooms needing cleaning
    static async getRoomsNeedingCleaning() {
        const [rows] = await db.query(`
            SELECT 
                r.*,
                rc.cleaning_status,
                rc.last_cleaned_date,
                s.staff_name as last_cleaned_by_name,
                COUNT(ct.task_id) as pending_tasks
            FROM rooms r
            LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
            LEFT JOIN housekeeping_staff s ON rc.last_cleaned_by = s.staff_id
            LEFT JOIN cleaning_tasks ct ON r.room_id = ct.room_id AND ct.status != 'Completed'
            WHERE rc.cleaning_status IN ('Dirty', 'Pending') OR r.status = 'Available'
            GROUP BY r.room_id
            ORDER BY rc.cleaning_status DESC, r.room_number ASC
        `);
        return rows;
    }

    // Get occupancy rate for a date range
    static async getOccupancyRate(startDate, endDate) {
        const [result] = await db.query(`
            SELECT 
                COUNT(DISTINCT r.room_id) as total_rooms,
                SUM(
                    DATEDIFF(
                        LEAST(b.check_out, ? + INTERVAL 1 DAY),
                        GREATEST(b.check_in, ?)
                    )
                ) as total_room_nights_booked,
                COUNT(DISTINCT r.room_id) * DATEDIFF(? + INTERVAL 1 DAY, ?) as total_room_nights_available,
                ROUND(
                    SUM(
                        DATEDIFF(
                            LEAST(b.check_out, ? + INTERVAL 1 DAY),
                            GREATEST(b.check_in, ?)
                        )
                    ) * 100.0 / (COUNT(DISTINCT r.room_id) * DATEDIFF(? + INTERVAL 1 DAY, ?)),
                    2
                ) as occupancy_percentage
            FROM rooms r
            LEFT JOIN bookings b ON r.room_id = b.room_id 
                AND b.booking_status IN ('Confirmed', 'CheckedIn', 'CheckedOut')
                AND b.check_in < ? + INTERVAL 1 DAY
                AND b.check_out > ?
        `, [endDate, startDate, endDate, startDate, endDate, startDate, endDate, startDate, endDate, startDate]);
        
        return result[0];
    }

    // Check room availability for specific dates
    static async isAvailableForDates(roomId, checkIn, checkOut) {
        const [result] = await db.query(`
            SELECT COUNT(*) as conflicts FROM bookings 
            WHERE room_id = ? 
            AND booking_status IN ('Confirmed', 'CheckedIn')
            AND check_in < ? 
            AND check_out > ?
        `, [roomId, checkOut, checkIn]);
        
        return result[0].conflicts === 0;
    }

    // Get revenue by room for date range
    static async getRevenueByRoom(startDate, endDate) {
        const [rows] = await db.query(`
            SELECT 
                r.room_id,
                r.room_number,
                r.room_type,
                COUNT(b.booking_id) as total_bookings,
                SUM(b.total_amount) as total_revenue,
                ROUND(AVG(b.total_amount), 2) as avg_booking_value
            FROM rooms r
            LEFT JOIN bookings b ON r.room_id = b.room_id 
                AND b.check_in >= ?
                AND b.check_out <= ?
                AND b.booking_status != 'Cancelled'
            GROUP BY r.room_id
            ORDER BY total_revenue DESC
        `, [startDate, endDate]);
        
        return rows;
    }
}

module.exports = Room;
