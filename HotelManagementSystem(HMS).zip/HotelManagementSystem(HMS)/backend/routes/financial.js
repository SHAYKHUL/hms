const express = require('express');
const router = express.Router();
const FinancialManagement = require('../models/FinancialManagement');

// Response format helper
const sendResponse = (res, success, message, data = null, statusCode = 200) => {
    res.status(statusCode).json({
        success,
        message,
        data,
        timestamp: new Date().toISOString()
    });
};

// ============ STAFF SALARY ROUTES ============

// Get all salary records
router.get('/salaries', async (req, res) => {
    try {
        const filters = {
            staff_id: req.query.staff_id,
            payment_month: req.query.payment_month,
            payment_status: req.query.payment_status
        };
        const salaries = await FinancialManagement.getAllSalaries(filters);
        sendResponse(res, true, 'Salary records retrieved', salaries);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Get salary by ID
router.get('/salaries/:id', async (req, res) => {
    try {
        const salary = await FinancialManagement.getSalaryById(req.params.id);
        if (!salary) {
            return sendResponse(res, false, 'Salary record not found', null, 404);
        }
        sendResponse(res, true, 'Salary record retrieved', salary);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Get salaries for specific staff
router.get('/salaries/staff/:staffId', async (req, res) => {
    try {
        const salaries = await FinancialManagement.getSalariesByStaff(req.params.staffId);
        sendResponse(res, true, 'Staff salary history retrieved', salaries);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Create salary record
router.post('/salaries', async (req, res) => {
    try {
        const result = await FinancialManagement.createSalary(req.body);
        sendResponse(res, true, 'Salary record created', result, 201);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Update salary record
router.put('/salaries/:id', async (req, res) => {
    try {
        await FinancialManagement.updateSalary(req.params.id, req.body);
        sendResponse(res, true, 'Salary record updated');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Mark salary as paid
router.patch('/salaries/:id/pay', async (req, res) => {
    try {
        const { payment_reference } = req.body;
        await FinancialManagement.markSalaryPaid(req.params.id, payment_reference);
        sendResponse(res, true, 'Salary marked as paid');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Get salary statistics
router.get('/salaries/stats/summary', async (req, res) => {
    try {
        const { month } = req.query;
        const stats = await FinancialManagement.getSalaryStatistics(month);
        sendResponse(res, true, 'Salary statistics retrieved', stats);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// ============ INCOME ROUTES ============

// Get all income records
router.get('/income', async (req, res) => {
    try {
        const filters = {
            income_type: req.query.income_type,
            start_date: req.query.start_date,
            end_date: req.query.end_date,
            payment_method: req.query.payment_method
        };
        const income = await FinancialManagement.getAllIncome(filters);
        sendResponse(res, true, 'Income records retrieved', income);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Get income by ID
router.get('/income/:id', async (req, res) => {
    try {
        const income = await FinancialManagement.getIncomeById(req.params.id);
        if (!income) {
            return sendResponse(res, false, 'Income record not found', null, 404);
        }
        sendResponse(res, true, 'Income record retrieved', income);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Create income record
router.post('/income', async (req, res) => {
    try {
        const result = await FinancialManagement.createIncome(req.body);
        sendResponse(res, true, 'Income record created', result, 201);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Update income record
router.put('/income/:id', async (req, res) => {
    try {
        await FinancialManagement.updateIncome(req.params.id, req.body);
        sendResponse(res, true, 'Income record updated');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Delete income record
router.delete('/income/:id', async (req, res) => {
    try {
        await FinancialManagement.deleteIncome(req.params.id);
        sendResponse(res, true, 'Income record deleted');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Get income statistics
router.get('/income/stats/summary', async (req, res) => {
    try {
        const { start_date, end_date } = req.query;
        const stats = await FinancialManagement.getIncomeStatistics(start_date, end_date);
        sendResponse(res, true, 'Income statistics retrieved', stats);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// ============ EXPENSE ROUTES ============

// Get all expense records
router.get('/expenses', async (req, res) => {
    try {
        const filters = {
            expense_type: req.query.expense_type,
            start_date: req.query.start_date,
            end_date: req.query.end_date,
            payment_status: req.query.payment_status,
            vendor_name: req.query.vendor_name
        };
        const expenses = await FinancialManagement.getAllExpenses(filters);
        sendResponse(res, true, 'Expense records retrieved', expenses);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Get expense by ID
router.get('/expenses/:id', async (req, res) => {
    try {
        const expense = await FinancialManagement.getExpenseById(req.params.id);
        if (!expense) {
            return sendResponse(res, false, 'Expense record not found', null, 404);
        }
        sendResponse(res, true, 'Expense record retrieved', expense);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Create expense record
router.post('/expenses', async (req, res) => {
    try {
        const result = await FinancialManagement.createExpense(req.body);
        sendResponse(res, true, 'Expense record created', result, 201);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Update expense record
router.put('/expenses/:id', async (req, res) => {
    try {
        await FinancialManagement.updateExpense(req.params.id, req.body);
        sendResponse(res, true, 'Expense record updated');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Mark expense as paid
router.patch('/expenses/:id/pay', async (req, res) => {
    try {
        await FinancialManagement.markExpensePaid(req.params.id);
        sendResponse(res, true, 'Expense marked as paid');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Delete expense record
router.delete('/expenses/:id', async (req, res) => {
    try {
        await FinancialManagement.deleteExpense(req.params.id);
        sendResponse(res, true, 'Expense record deleted');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Get expense statistics
router.get('/expenses/stats/summary', async (req, res) => {
    try {
        const { start_date, end_date } = req.query;
        const stats = await FinancialManagement.getExpenseStatistics(start_date, end_date);
        sendResponse(res, true, 'Expense statistics retrieved', stats);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// ============ FINANCIAL REPORTS ROUTES ============

// Get profit & loss summary
router.get('/reports/profit-loss', async (req, res) => {
    try {
        const { start_date, end_date } = req.query;
        const report = await FinancialManagement.getProfitLossSummary(start_date, end_date);
        sendResponse(res, true, 'Profit & loss report retrieved', report);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Get monthly summary
router.get('/reports/monthly/:year/:month', async (req, res) => {
    try {
        const { year, month } = req.params;
        const report = await FinancialManagement.getMonthlySummary(parseInt(year), parseInt(month));
        sendResponse(res, true, 'Monthly summary retrieved', report);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Get dashboard statistics
router.get('/dashboard/stats', async (req, res) => {
    try {
        const today = new Date().toISOString().split('T')[0];
        const thisMonth = new Date().toISOString().slice(0, 7);
        
        // Get today's income & expenses
        const [todayIncome] = await FinancialManagement.getAllIncome({ 
            start_date: today, 
            end_date: today 
        });
        const [todayExpenses] = await FinancialManagement.getAllExpenses({ 
            start_date: today, 
            end_date: today 
        });
        
        // Get month's summary
        const profitLoss = await FinancialManagement.getProfitLossSummary(
            `${thisMonth}-01`, 
            today
        );
        
        // Get pending salaries
        const pendingSalaries = await FinancialManagement.getSalaryStatistics(thisMonth);
        
        sendResponse(res, true, 'Dashboard statistics retrieved', {
            today: {
                income_count: todayIncome?.length || 0,
                expense_count: todayExpenses?.length || 0
            },
            month: profitLoss,
            salaries: pendingSalaries
        });
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

module.exports = router;
