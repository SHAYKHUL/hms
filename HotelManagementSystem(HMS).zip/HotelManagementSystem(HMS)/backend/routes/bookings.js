const express = require('express');
const router = express.Router();
const Booking = require('../models/Booking');
const Guest = require('../models/Guest');
const Room = require('../models/Room');

// Validation helper for booking data
function validateBookingData(data) {
    const errors = [];
    
    if (!data.guest_id || isNaN(data.guest_id)) {
        errors.push('Valid guest ID is required');
    }
    if (!data.room_id || isNaN(data.room_id)) {
        errors.push('Valid room ID is required');
    }
    if (!data.check_in || new Date(data.check_in).toString() === 'Invalid Date') {
        errors.push('Valid check-in date is required');
    }
    if (!data.check_out || new Date(data.check_out).toString() === 'Invalid Date') {
        errors.push('Valid check-out date is required');
    }
    
    if (data.check_in && data.check_out) {
        const checkIn = new Date(data.check_in);
        const checkOut = new Date(data.check_out);
        if (checkOut <= checkIn) {
            errors.push('Check-out date must be after check-in date');
        }
    }
    
    if (!data.number_of_guests || isNaN(data.number_of_guests) || parseInt(data.number_of_guests) < 1) {
        errors.push('Number of guests must be at least 1');
    }
    if (!data.total_amount || isNaN(data.total_amount) || parseFloat(data.total_amount) <= 0) {
        errors.push('Valid total amount is required');
    }
    
    return errors;
}

// GET all bookings
router.get('/', async (req, res) => {
    try {
        const bookings = await Booking.getAll();
        res.json({ 
            success: true, 
            data: bookings,
            count: bookings.length
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch bookings', error: error.message });
    }
});

// GET active bookings
router.get('/active/list', async (req, res) => {
    try {
        const bookings = await Booking.getActive();
        res.json({ 
            success: true, 
            data: bookings,
            count: bookings.length
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch active bookings', error: error.message });
    }
});

// GET booking by ID
router.get('/:id', async (req, res) => {
    try {
        if (!req.params.id || isNaN(req.params.id)) {
            return res.status(400).json({ success: false, message: 'Invalid booking ID' });
        }
        
        const booking = await Booking.getById(req.params.id);
        if (!booking) {
            return res.status(404).json({ success: false, message: 'Booking not found' });
        }
        res.json({ success: true, data: booking });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch booking', error: error.message });
    }
});

// GET today's check-ins
router.get('/today/checkins', async (req, res) => {
    try {
        const bookings = await Booking.getTodayCheckIns();
        res.json({ 
            success: true, 
            data: bookings,
            count: bookings.length
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch check-ins', error: error.message });
    }
});

// GET today's check-outs
router.get('/today/checkouts', async (req, res) => {
    try {
        const bookings = await Booking.getTodayCheckOuts();
        res.json({ 
            success: true, 
            data: bookings,
            count: bookings.length
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch check-outs', error: error.message });
    }
});

// GET dashboard statistics
router.get('/stats/dashboard', async (req, res) => {
    try {
        const stats = await Booking.getDashboardStats();
        res.json({ success: true, data: stats });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch dashboard stats', error: error.message });
    }
});

// GET revenue statistics
router.get('/stats/revenue', async (req, res) => {
    try {
        const { startDate, endDate } = req.query;
        if (!startDate || !endDate) {
            return res.status(400).json({ success: false, message: 'Start date and end date are required' });
        }
        const stats = await Booking.getRevenueStats(startDate, endDate);
        res.json({ success: true, data: stats });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch revenue stats', error: error.message });
    }
});

// POST create new booking
router.post('/', async (req, res) => {
    try {
        // Validate input
        const validationErrors = validateBookingData(req.body);
        if (validationErrors.length > 0) {
            return res.status(400).json({ 
                success: false, 
                message: 'Validation failed',
                errors: validationErrors
            });
        }
        
        // Check if guest exists
        const guest = await Guest.getById(req.body.guest_id);
        if (!guest) {
            return res.status(400).json({ success: false, message: 'Guest not found' });
        }
        
        // Check if room exists
        const room = await Room.getById(req.body.room_id);
        if (!room) {
            return res.status(400).json({ success: false, message: 'Room not found' });
        }
        
        // Check availability
        const isAvailable = await Room.isAvailableForDates(req.body.room_id, req.body.check_in, req.body.check_out);
        if (!isAvailable) {
            return res.status(409).json({ success: false, message: 'Room is not available for selected dates' });
        }
        
        const bookingId = await Booking.create(req.body);
        res.status(201).json({ 
            success: true, 
            message: 'Booking created successfully',
            bookingId,
            data: await Booking.getById(bookingId)
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to create booking', error: error.message });
    }
});

// PUT update booking
router.put('/:id', async (req, res) => {
    try {
        if (!req.params.id || isNaN(req.params.id)) {
            return res.status(400).json({ success: false, message: 'Invalid booking ID' });
        }
        
        const booking = await Booking.getById(req.params.id);
        if (!booking) {
            return res.status(404).json({ success: false, message: 'Booking not found' });
        }
        
        const affected = await Booking.update(req.params.id, req.body);
        res.json({ 
            success: true, 
            message: 'Booking updated successfully',
            data: await Booking.getById(req.params.id)
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to update booking', error: error.message });
    }
});

// PATCH check-in
router.patch('/:id/checkin', async (req, res) => {
    try {
        if (!req.params.id || isNaN(req.params.id)) {
            return res.status(400).json({ success: false, message: 'Invalid booking ID' });
        }
        
        const booking = await Booking.getById(req.params.id);
        if (!booking) {
            return res.status(404).json({ success: false, message: 'Booking not found' });
        }
        
        const result = await Booking.checkIn(req.params.id);
        res.json({ 
            success: true, 
            message: 'Check-in successful',
            data: result.session
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to check-in', error: error.message });
    }
});

// PATCH check-out
router.patch('/:id/checkout', async (req, res) => {
    try {
        if (!req.params.id || isNaN(req.params.id)) {
            return res.status(400).json({ success: false, message: 'Invalid booking ID' });
        }
        
        const booking = await Booking.getById(req.params.id);
        if (!booking) {
            return res.status(404).json({ success: false, message: 'Booking not found' });
        }
        
        const affected = await Booking.checkOut(req.params.id);
        res.json({ success: true, message: 'Check-out successful' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to check-out', error: error.message });
    }
});

// PATCH cancel booking
router.patch('/:id/cancel', async (req, res) => {
    try {
        if (!req.params.id || isNaN(req.params.id)) {
            return res.status(400).json({ success: false, message: 'Invalid booking ID' });
        }
        
        const booking = await Booking.getById(req.params.id);
        if (!booking) {
            return res.status(404).json({ success: false, message: 'Booking not found' });
        }
        
        const affected = await Booking.cancel(req.params.id);
        res.json({ success: true, message: 'Booking cancelled successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to cancel booking', error: error.message });
    }
});

// PATCH update payment
router.patch('/:id/payment', async (req, res) => {
    try {
        if (!req.params.id || isNaN(req.params.id)) {
            return res.status(400).json({ success: false, message: 'Invalid booking ID' });
        }
        
        const { paymentStatus, paymentMethod, advancePayment } = req.body;
        if (!paymentStatus) {
            return res.status(400).json({ success: false, message: 'Payment status is required' });
        }
        
        const booking = await Booking.getById(req.params.id);
        if (!booking) {
            return res.status(404).json({ success: false, message: 'Booking not found' });
        }
        
        const affected = await Booking.updatePayment(req.params.id, req.body);
        res.json({ success: true, message: 'Payment updated successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to update payment', error: error.message });
    }
});

// PATCH apply discount to booking
router.patch('/:id/discount', async (req, res) => {
    try {
        if (!req.params.id || isNaN(req.params.id)) {
            return res.status(400).json({ success: false, message: 'Invalid booking ID' });
        }
        
        const { discountType, discountValue, discountReason } = req.body;
        if (!discountType) {
            return res.status(400).json({ success: false, message: 'Discount type is required' });
        }
        if (discountValue === undefined || isNaN(discountValue) || parseFloat(discountValue) < 0) {
            return res.status(400).json({ success: false, message: 'Valid discount value is required' });
        }
        if (!['None', 'Percentage', 'Fixed'].includes(discountType)) {
            return res.status(400).json({ success: false, message: 'Invalid discount type' });
        }
        
        const booking = await Booking.getById(req.params.id);
        if (!booking) {
            return res.status(404).json({ success: false, message: 'Booking not found' });
        }
        
        const affected = await Booking.applyDiscount(req.params.id, discountType, discountValue, discountReason);
        res.json({ success: true, message: 'Discount applied successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to apply discount', error: error.message });
    }
});

// GET extension options for a booking
router.get('/:id/extension-options', async (req, res) => {
    try {
        if (!req.params.id || isNaN(req.params.id)) {
            return res.status(400).json({ success: false, message: 'Invalid booking ID' });
        }
        
        const { new_check_out } = req.query;
        if (!new_check_out) {
            return res.status(400).json({ success: false, message: 'new_check_out date is required' });
        }
        
        const booking = await Booking.getById(req.params.id);
        if (!booking) {
            return res.status(404).json({ success: false, message: 'Booking not found' });
        }

        // Validate new_check_out is after current check-out and return 400 for bad request
        const newCheckOutDate = new Date(new_check_out);
        const currentCheckOutDate = new Date(booking.check_out);
        if (isNaN(newCheckOutDate.getTime())) {
            return res.status(400).json({ success: false, message: 'Invalid new_check_out date' });
        }
        if (newCheckOutDate <= currentCheckOutDate) {
            return res.status(400).json({ success: false, message: 'New check-out date must be after current check-out date' });
        }

        const options = await Booking.getExtensionOptions(req.params.id, new_check_out);
        res.json({ success: true, data: options });
    } catch (error) {
        console.error('Error in GET /:id/extension-options', error);
        res.status(500).json({ success: false, message: 'Failed to get extension options', error: error.message });
    }
});

// POST extend booking with conflict resolution
router.post('/:id/extend', async (req, res) => {
    try {
        if (!req.params.id || isNaN(req.params.id)) {
            return res.status(400).json({ success: false, message: 'Invalid booking ID' });
        }
        
        const { new_check_out, resolution_type, resolution_details } = req.body;
        if (!new_check_out) {
            return res.status(400).json({ success: false, message: 'new_check_out date is required' });
        }
        if (!resolution_type) {
            return res.status(400).json({ success: false, message: 'resolution_type is required' });
        }
        
        const validResolutions = ['same_room', 'alternative_room', 'alternative_dates'];
        if (!validResolutions.includes(resolution_type)) {
            return res.status(400).json({ success: false, message: 'Invalid resolution type' });
        }
        
        const booking = await Booking.getById(req.params.id);
        if (!booking) {
            return res.status(404).json({ success: false, message: 'Booking not found' });
        }
        
        if (booking.booking_status !== 'Confirmed') {
            return res.status(400).json({ success: false, message: 'Only Confirmed bookings can be extended' });
        }
        
        const result = await Booking.extendBooking(req.params.id, {
            new_check_out,
            resolution_type,
            resolution_details
        });
        
        res.json({ success: true, message: 'Booking extended successfully', data: result });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to extend booking', error: error.message });
    }
});

// GET check if room can be extended
router.get('/:id/can-extend', async (req, res) => {
    try {
        if (!req.params.id || isNaN(req.params.id)) {
            return res.status(400).json({ success: false, message: 'Invalid booking ID' });
        }
        
        const { new_check_out } = req.query;
        if (!new_check_out) {
            return res.status(400).json({ success: false, message: 'new_check_out date is required' });
        }
        
        const canExtend = await Booking.canExtendUntil(req.params.id, new_check_out);
        res.json({ success: true, data: { canExtend, message: canExtend ? 'Room is available for extension' : 'Room is not available for extension' } });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to check extension availability', error: error.message });
    }
});

// ============================================
// DAILY ROOM COUNTING & OCCUPANCY ANALYTICS
// ============================================

// GET daily room count for a specific date
router.get('/analytics/daily-count', async (req, res) => {
    try {
        const { date } = req.query;
        
        if (!date) {
            return res.status(400).json({ 
                success: false, 
                message: 'Date parameter is required (YYYY-MM-DD format)' 
            });
        }
        
        const count = await Booking.getDailyRoomCount(date);
        res.json({ 
            success: true, 
            date: date,
            data: count 
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: 'Failed to fetch daily room count', 
            error: error.message 
        });
    }
});

// GET daily occupancy metrics (occupancy %, ADR, RevPAR)
router.get('/analytics/daily-metrics', async (req, res) => {
    try {
        const { date } = req.query;
        
        if (!date) {
            return res.status(400).json({ 
                success: false, 
                message: 'Date parameter is required (YYYY-MM-DD format)' 
            });
        }
        
        const metrics = await Booking.getDailyOccupancyMetrics(date);
        res.json({ 
            success: true, 
            data: metrics 
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: 'Failed to fetch daily metrics', 
            error: error.message 
        });
    }
});

// GET period occupancy analysis
router.get('/analytics/period-analysis', async (req, res) => {
    try {
        const { startDate, endDate } = req.query;
        
        if (!startDate || !endDate) {
            return res.status(400).json({ 
                success: false, 
                message: 'Both startDate and endDate parameters are required (YYYY-MM-DD format)' 
            });
        }
        
        const analysis = await Booking.getPeriodOccupancyAnalysis(startDate, endDate);
        res.json({ 
            success: true, 
            data: analysis 
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: 'Failed to fetch period analysis', 
            error: error.message 
        });
    }
});

// GET daily occupancy trend (for charting)
router.get('/analytics/occupancy-trend', async (req, res) => {
    try {
        const { startDate, endDate } = req.query;
        
        if (!startDate || !endDate) {
            return res.status(400).json({ 
                success: false, 
                message: 'Both startDate and endDate parameters are required (YYYY-MM-DD format)' 
            });
        }
        
        const trend = await Booking.getDailyOccupancyTrend(startDate, endDate);
        res.json({ 
            success: true, 
            count: trend.length,
            data: trend 
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: 'Failed to fetch occupancy trend', 
            error: error.message 
        });
    }
});

// GET room-by-room status for a specific date
router.get('/analytics/room-status', async (req, res) => {
    try {
        const { date } = req.query;
        
        if (!date) {
            return res.status(400).json({ 
                success: false, 
                message: 'Date parameter is required (YYYY-MM-DD format)' 
            });
        }
        
        const roomStatus = await Booking.getDailyRoomStatus(date);
        
        // Summary statistics
        const occupied = roomStatus.filter(r => r.status !== 'Vacant').length;
        const vacant = roomStatus.filter(r => r.status === 'Vacant').length;
        
        res.json({ 
            success: true, 
            date: date,
            summary: {
                occupied_rooms: occupied,
                vacant_rooms: vacant,
                total_rooms: roomStatus.length,
                occupancy_percentage: ((occupied / roomStatus.length) * 100).toFixed(2)
            },
            data: roomStatus 
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: 'Failed to fetch room status', 
            error: error.message 
        });
    }
});

// GET occupancy by room type
router.get('/analytics/by-room-type', async (req, res) => {
    try {
        const { startDate, endDate } = req.query;
        
        if (!startDate || !endDate) {
            return res.status(400).json({ 
                success: false, 
                message: 'Both startDate and endDate parameters are required (YYYY-MM-DD format)' 
            });
        }
        
        const typeOccupancy = await Booking.getOccupancyByRoomType(startDate, endDate);
        res.json({ 
            success: true, 
            data: typeOccupancy 
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: 'Failed to fetch occupancy by room type', 
            error: error.message 
        });
    }
});

module.exports = router;
