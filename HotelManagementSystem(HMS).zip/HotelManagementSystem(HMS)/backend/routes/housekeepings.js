const express = require('express');
const router = express.Router();
const Housekeeping = require('../models/Housekeeping');
const CleaningTask = require('../models/CleaningTask');
const MaintenanceLog = require('../models/MaintenanceLog');
const Room = require('../models/Room');

// Response format helper
const sendResponse = (res, success, message, data = null, statusCode = 200) => {
    res.status(statusCode).json({
        success,
        message,
        data,
        timestamp: new Date().toISOString()
    });
};

// ============ HOUSEKEEPING STAFF ROUTES ============

// Get all staff
router.get('/staff', async (req, res) => {
    try {
        const staff = await Housekeeping.getAllStaff();
        sendResponse(res, true, 'Staff retrieved successfully', staff);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Get active staff only
router.get('/staff/active', async (req, res) => {
    try {
        const staff = await Housekeeping.getActiveStaff();
        sendResponse(res, true, 'Active staff retrieved', staff);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Get staff by role
router.get('/staff/role/:role', async (req, res) => {
    try {
        const staff = await Housekeeping.getStaffByRole(req.params.role);
        sendResponse(res, true, `${req.params.role} staff retrieved`, staff);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Get staff by ID
router.get('/staff/:id', async (req, res) => {
    try {
        const staff = await Housekeeping.getStaffById(req.params.id);
        if (!staff) {
            return sendResponse(res, false, 'Staff not found', null, 404);
        }
        sendResponse(res, true, 'Staff details retrieved', staff);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Add new staff
router.post('/staff', async (req, res) => {
    try {
        const { staffName, phone, email, role, shift, assignedFloors, hireDate, 
                monthly_salary, bank_account, emergency_contact, address } = req.body;
        const result = await Housekeeping.createStaff(staffName, phone, email, role, shift, 
                                                       assignedFloors, hireDate, monthly_salary,
                                                       bank_account, emergency_contact, address);
        sendResponse(res, true, 'Staff added successfully', result, 201);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Update staff
router.put('/staff/:id', async (req, res) => {
    try {
        await Housekeeping.updateStaff(req.params.id, req.body);
        sendResponse(res, true, 'Staff updated successfully');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Update staff status
router.patch('/staff/:id/status', async (req, res) => {
    try {
        const { status } = req.body;
        await Housekeeping.updateStaffStatus(req.params.id, status);
        sendResponse(res, true, `Staff status updated to ${status}`);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Delete staff
router.delete('/staff/:id', async (req, res) => {
    try {
        await Housekeeping.deleteStaff(req.params.id);
        sendResponse(res, true, 'Staff deleted successfully');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Get staff workload
router.get('/staff/workload/stats', async (req, res) => {
    try {
        const workload = await Housekeeping.getStaffWorkload();
        sendResponse(res, true, 'Staff workload retrieved', workload);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// ============ CLEANING TASKS ROUTES ============

// Get all cleaning tasks
router.get('/tasks', async (req, res) => {
    try {
        const limit = Math.min(parseInt(req.query.limit) || 100, 500);
        const offset = parseInt(req.query.offset) || 0;
        const tasks = await CleaningTask.getAllTasks(limit, offset);
        sendResponse(res, true, 'Cleaning tasks retrieved', tasks);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Get tasks by date
router.get('/tasks/date/:date', async (req, res) => {
    try {
        const tasks = await CleaningTask.getTasksByDate(req.params.date);
        sendResponse(res, true, 'Tasks for date retrieved', tasks);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Get tasks by status
router.get('/tasks/status/:status', async (req, res) => {
    try {
        const tasks = await CleaningTask.getTasksByStatus(req.params.status);
        sendResponse(res, true, `${req.params.status} tasks retrieved`, tasks);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Get staff's tasks
router.get('/tasks/staff/:staffId', async (req, res) => {
    try {
        const tasks = await CleaningTask.getStaffTasks(req.params.staffId);
        sendResponse(res, true, 'Staff tasks retrieved', tasks);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Get room cleaning history
router.get('/tasks/room/:roomId/history', async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 20;
        const history = await CleaningTask.getRoomCleaningHistory(req.params.roomId, limit);
        sendResponse(res, true, 'Room cleaning history retrieved', history);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Get task by ID
router.get('/tasks/:id', async (req, res) => {
    try {
        const task = await CleaningTask.getTaskById(req.params.id);
        if (!task) {
            return sendResponse(res, false, 'Task not found', null, 404);
        }
        sendResponse(res, true, 'Task details retrieved', task);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Create cleaning task
router.post('/tasks', async (req, res) => {
    try {
        const { roomId, taskType, priority, scheduledDate, scheduledTime, notes, assignedBy, staffId } = req.body;
        const result = await CleaningTask.createTask(roomId, taskType, priority, scheduledDate, scheduledTime, notes, assignedBy, staffId);
        sendResponse(res, true, 'Cleaning task created', result, 201);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Update task
router.put('/tasks/:id', async (req, res) => {
    try {
        const { staffId, status, notes, priority } = req.body;
        await CleaningTask.updateTask(req.params.id, staffId, status, notes, priority);
        sendResponse(res, true, 'Task updated successfully');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Start task
router.patch('/tasks/:id/start', async (req, res) => {
    try {
        await CleaningTask.startTask(req.params.id);
        sendResponse(res, true, 'Task started');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Complete task
router.patch('/tasks/:id/complete', async (req, res) => {
    try {
        const { notes } = req.body;
        await CleaningTask.completeTask(req.params.id, notes);
        sendResponse(res, true, 'Task completed successfully');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Assign task to staff
router.patch('/tasks/:id/assign', async (req, res) => {
    try {
        const { staffId } = req.body;
        await CleaningTask.assignTask(req.params.id, staffId);
        sendResponse(res, true, 'Task assigned successfully');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Delete task
router.delete('/tasks/:id', async (req, res) => {
    try {
        await CleaningTask.deleteTask(req.params.id);
        sendResponse(res, true, 'Task deleted successfully');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// ============ MAINTENANCE ROUTES ============

// Get all maintenance logs
router.get('/maintenance', async (req, res) => {
    try {
        const limit = Math.min(parseInt(req.query.limit) || 100, 500);
        const offset = parseInt(req.query.offset) || 0;
        const logs = await MaintenanceLog.getAllLogs(limit, offset);
        sendResponse(res, true, 'Maintenance logs retrieved', logs);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Get logs by status
router.get('/maintenance/status/:status', async (req, res) => {
    try {
        const logs = await MaintenanceLog.getLogsByStatus(req.params.status);
        sendResponse(res, true, `${req.params.status} maintenance logs retrieved`, logs);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Get logs by severity
router.get('/maintenance/severity/:severity', async (req, res) => {
    try {
        const logs = await MaintenanceLog.getLogsBySeverity(req.params.severity);
        sendResponse(res, true, `${req.params.severity} severity issues retrieved`, logs);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Get logs by type
router.get('/maintenance/type/:type', async (req, res) => {
    try {
        const logs = await MaintenanceLog.getLogsByType(req.params.type);
        sendResponse(res, true, `${req.params.type} maintenance issues retrieved`, logs);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Get room maintenance history
router.get('/maintenance/room/:roomId/history', async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 20;
        const history = await MaintenanceLog.getRoomMaintenanceHistory(req.params.roomId, limit);
        sendResponse(res, true, 'Room maintenance history retrieved', history);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Get critical issues
router.get('/maintenance/critical', async (req, res) => {
    try {
        const issues = await MaintenanceLog.getCriticalIssues();
        sendResponse(res, true, 'Critical maintenance issues retrieved', issues);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Get log by ID
router.get('/maintenance/:id', async (req, res) => {
    try {
        const log = await MaintenanceLog.getLogById(req.params.id);
        if (!log) {
            return sendResponse(res, false, 'Maintenance log not found', null, 404);
        }
        sendResponse(res, true, 'Maintenance log retrieved', log);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Report new maintenance issue
router.post('/maintenance', async (req, res) => {
    try {
        const { roomId, maintenanceType, issueDescription, severity, reportedBy, costEstimate, partsRequired } = req.body;
        const result = await MaintenanceLog.reportIssue(roomId, maintenanceType, issueDescription, severity, reportedBy, costEstimate, partsRequired);
        sendResponse(res, true, 'Issue reported successfully', result, 201);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Assign maintenance
router.patch('/maintenance/:id/assign', async (req, res) => {
    try {
        const { assignedTo } = req.body;
        await MaintenanceLog.assignMaintenance(req.params.id, assignedTo);
        sendResponse(res, true, 'Maintenance assigned successfully');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Start maintenance work
router.patch('/maintenance/:id/start', async (req, res) => {
    try {
        await MaintenanceLog.startWork(req.params.id);
        sendResponse(res, true, 'Maintenance work started');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Complete maintenance
router.patch('/maintenance/:id/complete', async (req, res) => {
    try {
        const { actualCost, notes } = req.body;
        await MaintenanceLog.completeMaintenance(req.params.id, actualCost, notes);
        sendResponse(res, true, 'Maintenance completed successfully');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Hold maintenance
router.patch('/maintenance/:id/hold', async (req, res) => {
    try {
        const { reason } = req.body;
        await MaintenanceLog.holdMaintenance(req.params.id, reason);
        sendResponse(res, true, 'Maintenance put on hold');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Update maintenance details
router.put('/maintenance/:id', async (req, res) => {
    try {
        const { costEstimate, actualCost, notes, partsRequired } = req.body;
        await MaintenanceLog.updateLog(req.params.id, costEstimate, actualCost, notes, partsRequired);
        sendResponse(res, true, 'Maintenance details updated');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Delete maintenance log
router.delete('/maintenance/:id', async (req, res) => {
    try {
        await MaintenanceLog.deleteLog(req.params.id);
        sendResponse(res, true, 'Maintenance log deleted');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// ============ STATISTICS & REPORTS ============

// Get housekeeping statistics
router.get('/stats/overview', async (req, res) => {
    try {
        const staffStats = await Housekeeping.getStatistics();
        const cleaningStats = await CleaningTask.getStatistics();
        const maintStats = await MaintenanceLog.getStatistics();
        const roomStats = await Room.getStatistics();
        
        // Get critical maintenance issues
        const criticalMaint = await MaintenanceLog.getCriticalIssues();
        
        sendResponse(res, true, 'Statistics retrieved', {
            staffStats,
            cleaningStats,
            maintStats,
            roomStats,
            criticalMaintenance: criticalMaint || []
        });
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Get shift statistics
router.get('/stats/shifts', async (req, res) => {
    try {
        const shifts = await Housekeeping.getShiftStatistics();
        sendResponse(res, true, 'Shift statistics retrieved', shifts);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// ============ ROOM CLEANING STATUS ROUTES ============

// Get all rooms with cleaning status
router.get('/rooms', async (req, res) => {
    try {
        const rooms = await Room.getAllWithCleaningStatus();
        sendResponse(res, true, 'Rooms with cleaning status retrieved', rooms);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Get room cleaning status
router.get('/rooms/:roomId/status', async (req, res) => {
    try {
        const roomStatus = await Room.getCleaningStatus(req.params.roomId);
        if (!roomStatus) {
            return sendResponse(res, false, 'Room not found', null, 404);
        }
        sendResponse(res, true, 'Room cleaning status retrieved', roomStatus);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Update room cleaning status
router.patch('/rooms/:roomId/status', async (req, res) => {
    try {
        const { cleaningStatus, staffId } = req.body;
        if (!cleaningStatus) {
            return sendResponse(res, false, 'Cleaning status is required', null, 400);
        }
        const result = await Room.updateCleaningStatus(req.params.roomId, cleaningStatus, staffId);
        sendResponse(res, true, 'Room cleaning status updated', result);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Get rooms by cleaning status
router.get('/rooms/status/:cleaningStatus', async (req, res) => {
    try {
        const rooms = await Room.getRoomsByCleaningStatus(req.params.cleaningStatus);
        sendResponse(res, true, `Rooms with ${req.params.cleaningStatus} status retrieved`, rooms);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Get rooms needing cleaning
router.get('/rooms/needs/cleaning', async (req, res) => {
    try {
        const rooms = await Room.getRoomsNeedingCleaning();
        sendResponse(res, true, 'Rooms needing cleaning retrieved', rooms);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Schedule next cleaning
router.patch('/rooms/:roomId/schedule-cleaning', async (req, res) => {
    try {
        const { scheduledDate } = req.body;
        if (!scheduledDate) {
            return sendResponse(res, false, 'Scheduled date is required', null, 400);
        }
        const result = await Room.scheduleNextCleaning(req.params.roomId, scheduledDate);
        if (!result) {
            return sendResponse(res, false, 'Failed to schedule cleaning', null, 400);
        }
        sendResponse(res, true, 'Cleaning scheduled successfully');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Get room statistics with cleaning data
router.get('/stats/rooms', async (req, res) => {
    try {
        const stats = await Room.getStatistics();
        sendResponse(res, true, 'Room statistics retrieved', stats);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// ============ ENHANCED MAINTENANCE WITH ROOM STATUS TRACKING ============

// Report maintenance and update room status
router.post('/maintenance/report-with-room-update', async (req, res) => {
    try {
        const { roomId, maintenanceType, issueDescription, severity, reportedBy, costEstimate, partsRequired } = req.body;
        
        // Report issue
        const result = await MaintenanceLog.reportIssue(roomId, maintenanceType, issueDescription, severity, reportedBy, costEstimate, partsRequired);
        
        // Update room status to maintenance if not already
        if (severity === 'Critical' || severity === 'High') {
            await Room.updateStatus(roomId, 'Maintenance');
            await Room.updateCleaningStatus(roomId, 'Inspecting');
        }
        
        sendResponse(res, true, 'Maintenance reported and room status updated', result, 201);
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Complete maintenance and update room status
router.patch('/maintenance/:id/complete-with-room-update', async (req, res) => {
    try {
        const { actualCost, notes } = req.body;
        
        // Get maintenance log to find room ID
        const log = await MaintenanceLog.getLogById(req.params.id);
        if (!log) {
            return sendResponse(res, false, 'Maintenance log not found', null, 404);
        }
        
        // Complete maintenance
        await MaintenanceLog.completeMaintenance(req.params.id, actualCost, notes);
        
        // Check if there are other pending maintenance issues for this room
        const [pendingIssues] = await require('../config/database').query(
            `SELECT COUNT(*) as count FROM maintenance_logs WHERE room_id = ? AND status IN ('Reported', 'Assigned', 'In Progress')`,
            [log.room_id]
        );
        
        // If no other pending issues, update room status back to available
        if (pendingIssues[0].count === 0) {
            await Room.updateStatus(log.room_id, 'Available');
            await Room.updateCleaningStatus(log.room_id, 'Dirty');
        }
        
        sendResponse(res, true, 'Maintenance completed and room status updated');
    } catch (error) {
        sendResponse(res, false, error.message, null, 400);
    }
});

// Get comprehensive housekeeping dashboard
router.get('/dashboard/comprehensive', async (req, res) => {
    try {
        const db = require('../config/database');
        
        // Get overall stats
        const staffStats = await Housekeeping.getStatistics();
        const cleaningStats = await CleaningTask.getStatistics();
        const maintStats = await MaintenanceLog.getStatistics();
        const roomStats = await Room.getStatistics();
        
        // Get rooms needing attention
        const [roomsNeedingAttn] = await db.query(`
            SELECT 
                r.room_id,
                r.room_number,
                r.room_type,
                rc.cleaning_status,
                COUNT(ct.task_id) as pending_tasks,
                COUNT(ml.log_id) as pending_maintenance
            FROM rooms r
            LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
            LEFT JOIN cleaning_tasks ct ON r.room_id = ct.room_id AND ct.status != 'Completed'
            LEFT JOIN maintenance_logs ml ON r.room_id = ml.room_id AND ml.status IN ('Reported', 'Assigned', 'In Progress')
            WHERE r.status != 'Booked' AND (r.status = 'Maintenance' OR rc.cleaning_status IN ('Dirty', 'Pending'))
            GROUP BY r.room_id
        `);
        
        // Get staff efficiency
        const staffWorkload = await Housekeeping.getStaffWorkload();
        
        // Get critical maintenance
        const criticalMaint = await MaintenanceLog.getCriticalIssues();
        
        sendResponse(res, true, 'Comprehensive dashboard data retrieved', {
            staffStats,
            cleaningStats,
            maintStats,
            roomStats,
            roomsNeedingAttention: roomsNeedingAttn || [],
            staffWorkload,
            criticalMaintenance: criticalMaint || []
        });
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Get cleaning efficiency report
router.get('/reports/cleaning-efficiency', async (req, res) => {
    try {
        const db = require('../config/database');
        const days = parseInt(req.query.days) || 30;
        
        const [report] = await db.query(`
            SELECT 
                s.staff_id,
                s.staff_name,
                s.role,
                COUNT(ct.task_id) as total_tasks,
                SUM(CASE WHEN ct.status = 'Completed' THEN 1 ELSE 0 END) as completed_tasks,
                SUM(CASE WHEN ct.status = 'Completed' THEN 1 ELSE 0 END) / COUNT(ct.task_id) * 100 as completion_rate,
                AVG(TIMESTAMPDIFF(MINUTE, ct.start_time, ct.completion_time)) as avg_time_minutes,
                SUM(CASE WHEN ct.priority = 'Urgent' THEN 1 ELSE 0 END) as urgent_tasks_handled
            FROM housekeeping_staff s
            LEFT JOIN cleaning_tasks ct ON s.staff_id = ct.staff_id 
                AND ct.created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
            WHERE s.role = 'Housekeeper'
            GROUP BY s.staff_id, s.staff_name, s.role
            ORDER BY completion_rate DESC, completed_tasks DESC
        `, [days]);
        
        sendResponse(res, true, `Cleaning efficiency report (last ${days} days)`, report);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Get maintenance tracking report
router.get('/reports/maintenance-tracking', async (req, res) => {
    try {
        const db = require('../config/database');
        const days = parseInt(req.query.days) || 30;
        
        const [report] = await db.query(`
            SELECT 
                m.maintenance_type,
                COUNT(m.log_id) as total_issues,
                SUM(CASE WHEN m.status = 'Completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN m.status IN ('Reported', 'Assigned', 'In Progress') THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN m.severity = 'Critical' THEN 1 ELSE 0 END) as critical_count,
                AVG(m.cost_estimate) as avg_estimated_cost,
                SUM(m.actual_cost) as total_actual_cost,
                AVG(TIMESTAMPDIFF(DAY, m.reported_date, m.completed_date)) as avg_days_to_resolve
            FROM maintenance_logs m
            WHERE m.created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
            GROUP BY m.maintenance_type
            ORDER BY total_issues DESC
        `, [days]);
        
        sendResponse(res, true, `Maintenance tracking report (last ${days} days)`, report);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

// Get daily cleaning summary
router.get('/reports/daily-summary', async (req, res) => {
    try {
        const db = require('../config/database');
        const date = req.query.date || new Date().toISOString().split('T')[0];
        
        const [summary] = await db.query(`
            SELECT 
                DATE(ct.scheduled_date) as date,
                COUNT(ct.task_id) as total_tasks,
                SUM(CASE WHEN ct.status = 'Completed' THEN 1 ELSE 0 END) as completed_tasks,
                SUM(CASE WHEN ct.status = 'In Progress' THEN 1 ELSE 0 END) as in_progress,
                SUM(CASE WHEN ct.status = 'Not Started' THEN 1 ELSE 0 END) as not_started,
                COUNT(DISTINCT ct.staff_id) as staff_involved,
                COUNT(DISTINCT ct.room_id) as rooms_scheduled
            FROM cleaning_tasks ct
            WHERE DATE(ct.scheduled_date) = ?
            GROUP BY DATE(ct.scheduled_date)
        `, [date]);
        
        sendResponse(res, true, `Daily cleaning summary for ${date}`, summary);
    } catch (error) {
        sendResponse(res, false, error.message, null, 500);
    }
});

module.exports = router;
