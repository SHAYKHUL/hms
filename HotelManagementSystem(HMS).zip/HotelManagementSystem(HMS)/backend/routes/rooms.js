const express = require('express');
const router = express.Router();
const Room = require('../models/Room');

// Validation helper
function validateRoomData(data) {
    const errors = [];
    
    if (!data.room_number || data.room_number.toString().trim() === '') {
        errors.push('Room number is required');
    } else {
        // Allow alphanumeric room numbers (e.g., 3A, 6B, 7C)
        const roomNumberStr = data.room_number.toString().trim().toUpperCase();
        if (!/^[0-9A-Z]{1,10}$/.test(roomNumberStr)) {
            errors.push('Room number must be alphanumeric (e.g., 3A, 6B, 7C) and max 10 characters');
        }
    }
    if (!data.room_type) {
        errors.push('Room type is required');
    } else if (!['Single', 'Double', 'Suite', 'Deluxe'].includes(data.room_type)) {
        errors.push('Invalid room type');
    }
    if (data.ac_type && !['AC', 'Non-AC'].includes(data.ac_type)) {
        errors.push('AC type must be AC or Non-AC');
    }
    if (!data.price || isNaN(data.price) || parseFloat(data.price) <= 0) {
        errors.push('Valid price is required');
    }
    if (!data.bed_count || isNaN(data.bed_count) || parseInt(data.bed_count) < 1) {
        errors.push('Bed count must be at least 1');
    }
    if (!data.max_guests || isNaN(data.max_guests) || parseInt(data.max_guests) < 1) {
        errors.push('Max guests must be at least 1');
    }
    if (data.status && !['Available', 'Booked', 'Maintenance'].includes(data.status)) {
        errors.push('Invalid status');
    }
    
    return errors;
}

// GET all rooms
router.get('/', async (req, res) => {
    try {
        const rooms = await Room.getAll();
        res.json({ 
            success: true, 
            data: rooms,
            count: rooms.length
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch rooms', error: error.message });
    }
});

// GET room by ID
router.get('/:id', async (req, res) => {
    try {
        if (!req.params.id || isNaN(req.params.id)) {
            return res.status(400).json({ success: false, message: 'Invalid room ID' });
        }
        
        const room = await Room.getById(req.params.id);
        if (!room) {
            return res.status(404).json({ success: false, message: 'Room not found' });
        }
        res.json({ success: true, data: room });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch room', error: error.message });
    }
});

// GET available rooms
router.get('/available/search', async (req, res) => {
    try {
        const { checkIn, checkOut, acType } = req.query;
        let rooms;
        
        if (!checkIn || !checkOut) {
            rooms = await Room.getAll();
            rooms = rooms.filter(room => room.status === 'Available');
            // Filter by AC type if provided
            if (acType && ['AC', 'Non-AC'].includes(acType)) {
                rooms = rooms.filter(room => room.ac_type === acType);
            }
        } else {
            rooms = await Room.getAvailable(checkIn, checkOut, acType || null);
        }
        
        res.json({ 
            success: true, 
            data: rooms,
            count: rooms.length
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch available rooms', error: error.message });
    }
});

// GET room statistics
router.get('/stats/overview', async (req, res) => {
    try {
        const stats = await Room.getStatistics();
        res.json({ success: true, data: stats });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch statistics', error: error.message });
    }
});

// GET occupancy rate for date range
router.get('/stats/occupancy', async (req, res) => {
    try {
        const { startDate, endDate } = req.query;
        if (!startDate || !endDate) {
            return res.status(400).json({ success: false, message: 'Start and end dates are required' });
        }
        const occupancy = await Room.getOccupancyRate(startDate, endDate);
        res.json({ success: true, data: occupancy });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch occupancy data', error: error.message });
    }
});

// GET revenue by room for date range
router.get('/stats/revenue', async (req, res) => {
    try {
        const { startDate, endDate } = req.query;
        if (!startDate || !endDate) {
            return res.status(400).json({ success: false, message: 'Start and end dates are required' });
        }
        const revenue = await Room.getRevenueByRoom(startDate, endDate);
        res.json({ success: true, data: revenue });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch revenue data', error: error.message });
    }
});

// POST check availability for dates
router.post('/check-availability', async (req, res) => {
    try {
        const { roomId, checkIn, checkOut } = req.body;
        if (!roomId || !checkIn || !checkOut) {
            return res.status(400).json({ success: false, message: 'Room ID and dates are required' });
        }
        if (isNaN(roomId)) {
            return res.status(400).json({ success: false, message: 'Invalid room ID' });
        }
        const isAvailable = await Room.isAvailableForDates(roomId, checkIn, checkOut);
        res.json({ success: true, data: { available: isAvailable, roomId, checkIn, checkOut } });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to check availability', error: error.message });
    }
});

// POST create new room
router.post('/', async (req, res) => {
    try {
        // Validate input
        const validationErrors = validateRoomData(req.body);
        if (validationErrors.length > 0) {
            return res.status(400).json({ 
                success: false, 
                message: 'Validation failed',
                errors: validationErrors
            });
        }
        
        const roomId = await Room.create(req.body);
        res.status(201).json({ 
            success: true, 
            message: 'Room created successfully',
            roomId,
            data: await Room.getById(roomId)
        });
    } catch (error) {
        // Check for duplicate room number
        if (error.message.includes('Duplicate entry')) {
            return res.status(409).json({ 
                success: false, 
                message: 'Room number already exists'
            });
        }
        res.status(500).json({ success: false, message: 'Failed to create room', error: error.message });
    }
});

// PUT update room
router.put('/:id', async (req, res) => {
    try {
        if (!req.params.id || isNaN(req.params.id)) {
            return res.status(400).json({ success: false, message: 'Invalid room ID' });
        }
        
        // Validate input
        const validationErrors = validateRoomData(req.body);
        if (validationErrors.length > 0) {
            return res.status(400).json({ 
                success: false, 
                message: 'Validation failed',
                errors: validationErrors
            });
        }
        
        // Check if room exists
        const existingRoom = await Room.getById(req.params.id);
        if (!existingRoom) {
            return res.status(404).json({ success: false, message: 'Room not found' });
        }
        
        const affected = await Room.update(req.params.id, req.body);
        res.json({ 
            success: true, 
            message: 'Room updated successfully',
            data: await Room.getById(req.params.id)
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to update room', error: error.message });
    }
});

// PATCH update room status
router.patch('/:id/status', async (req, res) => {
    try {
        if (!req.params.id || isNaN(req.params.id)) {
            return res.status(400).json({ success: false, message: 'Invalid room ID' });
        }
        
        const { status } = req.body;
        if (!status || !['Available', 'Booked', 'Maintenance'].includes(status)) {
            return res.status(400).json({ success: false, message: 'Invalid or missing status' });
        }
        
        const existingRoom = await Room.getById(req.params.id);
        if (!existingRoom) {
            return res.status(404).json({ success: false, message: 'Room not found' });
        }
        
        const affected = await Room.updateStatus(req.params.id, status);
        res.json({ 
            success: true, 
            message: 'Room status updated successfully',
            data: { roomId: req.params.id, status }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to update room status', error: error.message });
    }
});

// DELETE room
router.delete('/:id', async (req, res) => {
    try {
        if (!req.params.id || isNaN(req.params.id)) {
            return res.status(400).json({ success: false, message: 'Invalid room ID' });
        }
        
        const existingRoom = await Room.getById(req.params.id);
        if (!existingRoom) {
            return res.status(404).json({ success: false, message: 'Room not found' });
        }
        
        const affected = await Room.delete(req.params.id);
        res.json({ success: true, message: 'Room deleted successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to delete room', error: error.message });
    }
});

module.exports = router;
