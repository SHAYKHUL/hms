# Booking Extension Implementation Guide

## Summary of Changes

Your Hotel Management System now has full support for booking extensions with automatic conflict detection and alternative suggestions.

## Implementation Components

### 1. **Backend Model Changes** (`backend/models/Booking.js`)

Added four new methods to the Booking class:

#### `getExtensionOptions(bookingId, newCheckOut)`
- Analyzes if a booking can be extended to a new check-out date
- Detects conflicts with other confirmed bookings
- If conflict found, suggests:
  - Alternative rooms available for the extension period
  - Alternative dates when the same room becomes free
- Returns detailed analysis for customer decision-making

**Response Structure:**
```json
{
  "currentBooking": {...},
  "extensionRequest": {...},
  "canExtend": true/false,
  "conflict": {...},  // If conflict exists
  "alternatives": {
    "alternative_rooms": [...],
    "alternative_dates": {...}
  }
}
```

#### `extendBooking(bookingId, extensionData)`
- Processes the chosen extension strategy
- Supports three resolution types:
  - **same_room**: Direct extension (room available)
  - **alternative_room**: Creates new booking for alternative room
  - **alternative_dates**: Extends to when original room becomes available
- Updates booking amounts and creates linked bookings when needed

#### `canExtendUntil(bookingId, newCheckOut)`
- Quick boolean check if extension is possible
- Used for validation before showing options

#### Updated Schema Support
- Added `is_extension` flag to mark extension bookings
- Added `parent_booking_id` to link related bookings
- Added `booking_extension_history` table for audit trail

### 2. **Backend API Routes** (`backend/routes/bookings.js`)

Added four new endpoints:

#### `GET /api/bookings/:id/extension-options?new_check_out=YYYY-MM-DD`
Returns all available extension options
```bash
curl "http://localhost:3000/api/bookings/1/extension-options?new_check_out=2025-01-05"
```

#### `POST /api/bookings/:id/extend`
Process extension with chosen resolution
```bash
curl -X POST http://localhost:3000/api/bookings/1/extend \
  -H "Content-Type: application/json" \
  -d '{
    "new_check_out": "2025-01-05",
    "resolution_type": "same_room"
  }'
```

#### `GET /api/bookings/:id/can-extend?new_check_out=YYYY-MM-DD`
Quick validation check
```bash
curl "http://localhost:3000/api/bookings/1/can-extend?new_check_out=2025-01-05"
```

### 3. **Frontend UI Changes** (`frontend/bookings.html` & `frontend/js/bookings.js`)

#### New Modal: Extension Request Form
- Shows current booking details
- Date picker for new check-out date
- "Check Available Options" button
- Displays alternatives dynamically

#### New JavaScript Functions

1. **`openExtensionModal(bookingId)`** - Opens extension request form
2. **`checkExtensionOptions()`** - Calls API to check options
3. **`displayExtensionOptions(options)`** - Shows alternatives to customer
4. **`proceedWithExtension(bookingId, resolutionType)`** - Processes chosen option
5. **`closeExtensionModal()`** - Closes the modal

#### Updated Display
- Added "Extend Stay" button (arrow icon) to Confirmed bookings
- Positioned alongside Check-in action button

### 4. **Database Migration** (`database/booking_extension_migration.sql`)

Run this to prepare database:
```sql
ALTER TABLE bookings ADD COLUMN is_extension BOOLEAN DEFAULT FALSE;
ALTER TABLE bookings ADD COLUMN parent_booking_id INT;
CREATE TABLE booking_extension_history {...};
CREATE INDEX idx_room_dates ON bookings(room_id, check_in, check_out);
```

## Usage Workflow

### Scenario: Customer A wants to extend stay during Night 2

**Step 1: Request Extension**
```
Manager opens bookings page
Finds Customer A's booking (ID: 1)
Status = "Confirmed"
Current stay: Jan 1-3
Clicks "Extend Stay" button
```

**Step 2: System Checks Availability**
```
New check-out date: Jan 5 (wants 2 more nights)
System queries: Any bookings for same room Jan 3-5?
Result: Customer B booked Jan 4-6 → CONFLICT
```

**Step 3: Display Alternatives**
```
❌ Cannot extend in Room 103 (occupied Jan 4-6)

✅ OPTION 1: Alternative Rooms
   - Room 204 (Suite): Available Jan 4-5
   - Cost: ₹2,000
   - Button: "Book This Room"
   
✅ OPTION 2: Wait for Same Room
   - Room 103 available from: Jan 7
   - Extend to Jan 7 (wait 3 days)
   - Cost: ₹1,000
   - Button: "Book Alternative Dates"
```

**Step 4: Customer Choice**
- Option A: Books Room 204 for 4-5
  - Creates new booking linked to original
  - Two separate bookings, one stay experience
  - Charges additional ₹2,000
  
- Option B: Waits for same room
  - Extends original booking to Jan 7
  - Charges for additional 3 nights
  - No room change

## Code Examples

### Check Extension Options
```javascript
// Frontend
const response = await apiCall('/api/bookings/1/extension-options?new_check_out=2025-01-05');

if (response.data.canExtend) {
    console.log('✓ Can extend directly');
} else {
    console.log('✗ Conflict detected, showing alternatives');
    console.log(response.data.alternatives);
}
```

### Process Extension
```javascript
// Book alternative room
await apiCall('/api/bookings/1/extend', {
    method: 'POST',
    body: JSON.stringify({
        new_check_out: '2025-01-05',
        resolution_type: 'alternative_room',
        resolution_details: {
            alternative_room_id: 204
        }
    })
});

// Or extend to alternative dates
await apiCall('/api/bookings/1/extend', {
    method: 'POST',
    body: JSON.stringify({
        new_check_out: '2025-01-07',
        resolution_type: 'alternative_dates'
    })
});
```

## Testing Scenarios

### Test 1: No Conflict (Simple Extension)
```
Setup:
- Customer A: Room 101, Jan 1-3 (Confirmed)
- No other bookings for Jan 4+

Action:
- Request extension to Jan 5
Result: ✓ Same room option shown
```

### Test 2: Conflict with Next Booking
```
Setup:
- Customer A: Room 101, Jan 1-3 (Confirmed)
- Customer B: Room 101, Jan 4-6 (Confirmed)

Action:
- Request extension to Jan 5
Result: ✗ Conflict, show alternatives
- Alternative rooms for Jan 4-5
- Alternative dates: available from Jan 7
```

### Test 3: Multiple Conflicts
```
Setup:
- Customer A: Room 101, Jan 1-3
- Customer B: Room 101, Jan 4-6
- Customer C: Room 101, Jan 7-9

Action:
- Request extension to Jan 7
Result: ✗ Multiple conflicts
Shows only alternative rooms OR far future dates
```

### Test 4: No Rooms Available
```
Setup:
- All rooms booked for extension period
- Original room also booked

Action:
- Request extension
Result: ✗ No alternatives
Shows message: "No alternatives available - Contact support"
```

## Database Considerations

### Linked Bookings
When extension uses alternative room:
```
Booking 1 (Original)
├─ booking_id: 1
├─ check_in: 2025-01-01
├─ check_out: 2025-01-03
└─ status: Confirmed

Booking 2 (Extension) 
├─ booking_id: 2
├─ check_in: 2025-01-04
├─ check_out: 2025-01-05
├─ is_extension: true
├─ parent_booking_id: 1
└─ status: Confirmed
```

### Guest Perspective
In guest portal, show as single journey:
```
Visit: Jan 1 - Jan 5
Rooms: 103 → 204 (room change on Jan 4)
Total Stay: 4 nights
```

## Payment Handling

### Same Room Extension
- Recalculate total based on new dates
- Update `total_amount` in existing booking
- Calculate and process additional payment

Example:
```
Original booking: Jan 1-3, 2 nights, ₹2,000
Extension: +2 nights to Jan 5, ₹2,000
New total: ₹4,000
Additional payment: ₹2,000
```

### Alternative Room Extension
- Create separate booking for new period
- Track as extension in system
- Two payments recorded (or one combined)
- Show customer combined invoice option

## Validation Rules

1. **Date Validation**
   - New check-out must be after current check-out
   - New check-out must be in future

2. **Status Validation**
   - Only "Confirmed" bookings can be extended
   - CheckedIn bookings cannot be extended (must checkout first)

3. **Conflict Detection**
   - Check against "Confirmed" and "CheckedIn" bookings only
   - Ignore "Cancelled" and "CheckedOut" bookings

4. **Room Availability**
   - Must have available rooms in alternative suggestions
   - Must check cleaning status if applicable

## Error Handling

| Error | Cause | Solution |
|-------|-------|----------|
| "Booking not found" | Booking ID invalid | Verify booking exists |
| "Only Confirmed bookings can be extended" | CheckedIn/CheckedOut status | Complete check-out first |
| "New check-out must be after current checkout" | Invalid date | Select future date |
| "Room is not available for extension" | Conflict detected | Show alternatives |
| "Invalid resolution type" | Wrong type parameter | Use: same_room, alternative_room, alternative_dates |

## Future Enhancements

1. **Automatic Recommendations**
   - ML-based preference matching
   - Suggest room types guest prefers

2. **Incentive Discounts**
   - Offer discounts for inconvenience
   - "We're sorry - enjoy 10% off your extension"

3. **Overbooking Resolution**
   - VIP guest priority logic
   - Compensation automation

4. **Real-time Availability**
   - WebSocket updates for dynamic inventory
   - Block calendar integration

5. **Guest Self-Service**
   - Guest portal extension requests
   - Automatic approval for available rooms

6. **Analytics**
   - Track extension patterns
   - Identify high-extension periods
   - Optimize pricing

## Support Commands

### Reset Extension Features (if needed)
```sql
-- View all extensions
SELECT * FROM booking_extension_history;

-- View linked bookings
SELECT * FROM bookings WHERE is_extension = true;

-- Revert an extension
DELETE FROM bookings WHERE booking_id = X AND is_extension = true;
```

## Files Modified

1. ✅ `backend/models/Booking.js` - Added 4 new methods
2. ✅ `backend/routes/bookings.js` - Added 4 new API endpoints
3. ✅ `frontend/bookings.html` - Added extension modal
4. ✅ `frontend/js/bookings.js` - Added extension functions + UI button
5. ✅ `database/booking_extension_migration.sql` - New migration script
6. ✅ `BOOKING_EXTENSION_GUIDE.md` - Detailed business guide

## Next Steps

1. **Database Setup**
   - Run migration script: `booking_extension_migration.sql`
   - Verify new columns and table created

2. **Testing**
   - Test all scenarios from "Testing Scenarios" section
   - Verify conflict detection works correctly
   - Test alternative suggestions display

3. **Integration**
   - Deploy to staging environment
   - User acceptance testing with hotel staff
   - Train staff on new extension workflow

4. **Monitoring**
   - Track extension request patterns
   - Monitor error logs
   - Gather feedback from users

---

**Implementation Date:** February 24, 2026
**Status:** Ready for Testing
**Version:** 1.0
