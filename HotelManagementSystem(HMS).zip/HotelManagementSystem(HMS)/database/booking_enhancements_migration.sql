-- Booking System Enhancements Migration
-- Adds support for room transfers, booking modifications, and extension tracking
-- Date: March 5, 2026

-- Add columns to bookings table for tracking extensions and parent bookings
ALTER TABLE bookings 
ADD COLUMN IF NOT EXISTS is_extension BOOLEAN DEFAULT FALSE 
    COMMENT 'Indicates if this booking is an extension of another booking',
ADD COLUMN IF NOT EXISTS parent_booking_id INT DEFAULT NULL 
    COMMENT 'Reference to the original booking if this is an extension',
ADD COLUMN IF NOT EXISTS transfer_history TEXT DEFAULT NULL 
    COMMENT 'JSON array of room transfer history',
ADD COLUMN IF NOT EXISTS modification_history TEXT DEFAULT NULL
    COMMENT 'JSON array of booking modification history';

-- Add foreign key constraint for parent_booking_id
ALTER TABLE bookings
ADD CONSTRAINT fk_parent_booking 
FOREIGN KEY (parent_booking_id) REFERENCES bookings(booking_id) 
ON DELETE SET NULL;

-- Add indexes for better query performance
ALTER TABLE bookings
ADD INDEX idx_is_extension (is_extension),
ADD INDEX idx_parent_booking (parent_booking_id);

-- Create view for booking with transfer and modification history
CREATE OR REPLACE VIEW booking_details_with_history AS
SELECT 
    b.*,
    g.name as guest_name,
    g.phone as guest_phone,
    g.email as guest_email,
    r.room_number,
    r.room_type,
    r.price as current_room_price,
    r.status as room_status,
    pb.booking_id as parent_booking_number,
    pb.room_id as original_room_id,
    CASE 
        WHEN b.is_extension = TRUE THEN 'Extension Booking'
        WHEN b.transfer_history IS NOT NULL THEN 'Transferred'
        WHEN b.modification_history IS NOT NULL THEN 'Modified'
        ELSE 'Original'
    END as booking_type
FROM bookings b
JOIN guests g ON b.guest_id = g.guest_id
JOIN rooms r ON b.room_id = r.room_id
LEFT JOIN bookings pb ON b.parent_booking_id = pb.booking_id;

-- Sample queries to verify migration

-- Check if columns were added successfully
-- SELECT COLUMN_NAME, DATA_TYPE, COLUMN_COMMENT 
-- FROM INFORMATION_SCHEMA.COLUMNS 
-- WHERE TABLE_NAME = 'bookings' 
-- AND COLUMN_NAME IN ('is_extension', 'parent_booking_id', 'transfer_history', 'modification_history');

-- Test the new view
-- SELECT * FROM booking_details_with_history LIMIT 5;

-- Migration completed successfully
SELECT 'Booking enhancements migration completed successfully!' as status;
