# Housekeeping Management - Quick API Reference

## Base URL
```
http://localhost:3000/api/housekeeping
```

## Room Cleaning Status Endpoints

### Get Rooms with Cleaning Status
- **Endpoint**: `GET /rooms`
- **Returns**: Array of all rooms with current cleaning status
- **Example**: `GET /rooms`

### Get Room Cleaning Status
- **Endpoint**: `GET /rooms/{roomId}/status`
- **Returns**: Single room with detailed cleaning status
- **Example**: `GET /rooms/5/status`

### Update Room Cleaning Status
- **Endpoint**: `PATCH /rooms/{roomId}/status`
- **Body**: 
  ```json
  {
    "cleaningStatus": "Cleaned",
    "staffId": 2
  }
  ```
- **Example**: Update room 5 to cleaned status

### Get Rooms by Cleaning Status
- **Endpoint**: `GET /rooms/status/{cleaningStatus}`
- **Status Options**: `Dirty`, `Cleaning in Progress`, `Cleaned`, `Ready for Guest`, `Pending`, `Inspecting`
- **Example**: `GET /rooms/status/Dirty` (get all dirty rooms)

### Get Rooms Needing Cleaning
- **Endpoint**: `GET /rooms/needs/cleaning`
- **Returns**: Rooms with dirty or pending cleaning status
- **Example**: `GET /rooms/needs/cleaning`

### Schedule Next Cleaning
- **Endpoint**: `PATCH /rooms/{roomId}/schedule-cleaning`
- **Body**:
  ```json
  {
    "scheduledDate": "2026-02-25"
  }
  ```
- **Example**: Schedule cleaning for room 5 on Feb 25

### Get Room Statistics
- **Endpoint**: `GET /stats/rooms`
- **Returns**: Total cleanings, cleaned count, dirty count, in-progress count

---

## Cleaning Task Endpoints

### Get All Cleaning Tasks
- **Endpoint**: `GET /tasks?limit=50&offset=0`
- **Parameters**: limit (max 500), offset for pagination
- **Example**: `GET /tasks?limit=20&offset=0`

### Get Tasks by Status
- **Endpoint**: `GET /tasks/status/{status}`
- **Status Options**: `Not Started`, `In Progress`, `Completed`, `Cancelled`, `Pending Approval`
- **Example**: `GET /tasks/status/Not%20Started`

### Get Tasks by Date
- **Endpoint**: `GET /tasks/date/{date}`
- **Date Format**: YYYY-MM-DD
- **Example**: `GET /tasks/date/2026-02-24`

### Get Staff Tasks
- **Endpoint**: `GET /tasks/staff/{staffId}`
- **Returns**: All tasks assigned to specific staff
- **Example**: `GET /tasks/staff/2`

### Get Room Cleaning History
- **Endpoint**: `GET /tasks/room/{roomId}/history?limit=20`
- **Returns**: Cleaning tasks history for room
- **Example**: `GET /tasks/room/5/history?limit=10`

### Get Task Details
- **Endpoint**: `GET /tasks/{taskId}`
- **Example**: `GET /tasks/15`

### Create Cleaning Task
- **Endpoint**: `POST /tasks`
- **Body**:
  ```json
  {
    "roomId": 1,
    "taskType": "Turnover",
    "priority": "High",
    "scheduledDate": "2026-02-24",
    "scheduledTime": "09:00:00",
    "notes": "Full deep clean",
    "assignedBy": 1,
    "staffId": 2
  }
  ```
- **Task Types**: `Deep Clean`, `Regular Clean`, `Quick Clean`, `Turnover`, `Spot Clean`
- **Priorities**: `Low`, `Medium`, `High`, `Urgent`

### Update Task
- **Endpoint**: `PUT /tasks/{taskId}`
- **Body**: 
  ```json
  {
    "staffId": 2,
    "status": "In Progress",
    "notes": "Currently cleaning",
    "priority": "High"
  }
  ```

### Start Task
- **Endpoint**: `PATCH /tasks/{taskId}/start`
- **Updates**: status to "In Progress", records start time

### Complete Task
- **Endpoint**: `PATCH /tasks/{taskId}/complete`
- **Body**:
  ```json
  {
    "notes": "Task completed successfully"
  }
  ```

### Assign Task to Staff
- **Endpoint**: `PATCH /tasks/{taskId}/assign`
- **Body**:
  ```json
  {
    "staffId": 2
  }
  ```

### Delete Task
- **Endpoint**: `DELETE /tasks/{taskId}`

---

## Maintenance Endpoints

### Get All Maintenance Logs
- **Endpoint**: `GET /maintenance?limit=100&offset=0`
- **Parameters**: limit (max 500), offset for pagination

### Get Maintenance by Status
- **Endpoint**: `GET /maintenance/status/{status}`
- **Status Options**: `Reported`, `Assigned`, `In Progress`, `Completed`, `On Hold`
- **Example**: `GET /maintenance/status/In%20Progress`

### Get Maintenance by Severity
- **Endpoint**: `GET /maintenance/severity/{severity}`
- **Severity Options**: `Low`, `Medium`, `High`, `Critical`
- **Example**: `GET /maintenance/severity/Critical`

### Get Maintenance by Type
- **Endpoint**: `GET /maintenance/type/{type}`
- **Types**: `Plumbing`, `Electrical`, `HVAC`, `Furniture`, `Appliance`, `Paint`, `Flooring`, `Other`
- **Example**: `GET /maintenance/type/Plumbing`

### Get Room Maintenance History
- **Endpoint**: `GET /maintenance/room/{roomId}/history?limit=20`
- **Example**: `GET /maintenance/room/5/history?limit=10`

### Get Critical Issues
- **Endpoint**: `GET /maintenance/critical`
- **Returns**: All critical unresolved issues

### Get Maintenance Details
- **Endpoint**: `GET /maintenance/{logId}`

### Report Maintenance (With Auto Room Update)
- **Endpoint**: `POST /maintenance/report-with-room-update`
- **Body**:
  ```json
  {
    "roomId": 2,
    "maintenanceType": "Plumbing",
    "issueDescription": "Sink leaking",
    "severity": "High",
    "reportedBy": "Staff Name",
    "costEstimate": 500.00,
    "partsRequired": "new washer"
  }
  ```
- **Auto-Updates**: Sets room to "Maintenance" if Critical/High

### Assign Maintenance
- **Endpoint**: `PATCH /maintenance/{logId}/assign`
- **Body**:
  ```json
  {
    "assignedTo": "Ali Hassan"
  }
  ```

### Start Maintenance
- **Endpoint**: `PATCH /maintenance/{logId}/start`
- **Updates**: status to "In Progress"

### Complete Maintenance (With Auto Room Update)
- **Endpoint**: `PATCH /maintenance/{logId}/complete-with-room-update`
- **Body**:
  ```json
  {
    "actualCost": 480.00,
    "notes": "Fixed washer, sink working properly"
  }
  ```
- **Auto-Updates**: Reverts room to "Available" if no other issues

### Hold Maintenance
- **Endpoint**: `PATCH /maintenance/{logId}/hold`
- **Body**:
  ```json
  {
    "reason": "Waiting for spare parts"
  }
  ```

### Update Maintenance Details
- **Endpoint**: `PUT /maintenance/{logId}`
- **Body**:
  ```json
  {
    "costEstimate": 600.00,
    "actualCost": 550.00,
    "notes": "Updated notes",
    "partsRequired": "new part X"
  }
  ```

### Delete Maintenance Log
- **Endpoint**: `DELETE /maintenance/{logId}`

---

## Staff Endpoints

### Get All Staff
- **Endpoint**: `GET /staff`

### Get Active Staff
- **Endpoint**: `GET /staff/active`

### Get Staff by Role
- **Endpoint**: `GET /staff/role/{role}`
- **Roles**: `Housekeeper`, `Supervisor`, `Manager`
- **Example**: `GET /staff/role/Housekeeper`

### Get Staff Details
- **Endpoint**: `GET /staff/{staffId}`

### Add New Staff
- **Endpoint**: `POST /staff`
- **Body**:
  ```json
  {
    "staffName": "Jane Smith",
    "phone": "9876543211",
    "email": "jane@hotel.com",
    "role": "Housekeeper",
    "shift": "Morning",
    "assignedFloors": "2,3",
    "hireDate": "2026-02-01"
  }
  ```
- **Shifts**: `Morning`, `Afternoon`, `Night`

### Update Staff
- **Endpoint**: `PUT /staff/{staffId}`
- **Body**: Same as create

### Update Staff Status
- **Endpoint**: `PATCH /staff/{staffId}/status`
- **Body**:
  ```json
  {
    "status": "On Leave"
  }
  ```
- **Statuses**: `Active`, `Inactive`, `On Leave`

### Delete Staff
- **Endpoint**: `DELETE /staff/{staffId}`

### Get Staff Workload
- **Endpoint**: `GET /staff/workload/stats`
- **Returns**: Task assignments and pending tasks per staff

---

## Statistics & Dashboard Endpoints

### Get Comprehensive Dashboard
- **Endpoint**: `GET /dashboard/comprehensive`
- **Returns**: Complete overview with all metrics and alerts

### Get Overview Statistics
- **Endpoint**: `GET /stats/overview`
- **Returns**: Staff, cleaning, and maintenance statistics

### Get Shift Statistics
- **Endpoint**: `GET /stats/shifts`
- **Returns**: Staff distribution across shifts and roles

### Get Room Statistics
- **Endpoint**: `GET /stats/rooms`
- **Returns**: Room availability and cleaning status breakdown

---

## Reports Endpoints

### Cleaning Efficiency Report
- **Endpoint**: `GET /reports/cleaning-efficiency?days=30`
- **Parameters**: days (default 30)
- **Returns**: Per-staff metrics: tasks, completion rate, avg time
- **Example**: `GET /reports/cleaning-efficiency?days=7`

### Maintenance Tracking Report
- **Endpoint**: `GET /reports/maintenance-tracking?days=30`
- **Parameters**: days (default 30)
- **Returns**: Per-type metrics: count, severity, costs, resolution time
- **Example**: `GET /reports/maintenance-tracking?days=30`

### Daily Summary Report
- **Endpoint**: `GET /reports/daily-summary?date=2026-02-24`
- **Parameters**: date (YYYY-MM-DD, default today)
- **Returns**: Daily task completion summary
- **Example**: `GET /reports/daily-summary?date=2026-02-24`

---

## Response Format

All endpoints return:
```json
{
  "success": true,
  "message": "Operation description",
  "data": {},
  "timestamp": "2026-02-24T15:30:00.000Z"
}
```

## Error Responses

### 400 Bad Request
```json
{
  "success": false,
  "message": "Invalid status provided",
  "data": null,
  "timestamp": "2026-02-24T15:30:00.000Z"
}
```

### 404 Not Found
```json
{
  "success": false,
  "message": "Room not found",
  "data": null,
  "timestamp": "2026-02-24T15:30:00.000Z"
}
```

### 500 Server Error
```json
{
  "success": false,
  "message": "Internal server error",
  "data": null,
  "timestamp": "2026-02-24T15:30:00.000Z"
}
```

---

## Common Workflows

### Workflow: Evening Cleaning
```
1. GET /rooms/status/Dirty          # Get all dirty rooms
2. POST /tasks                      # Create cleaning tasks
3. GET /staff/active                # Get available staff
4. PATCH /tasks/{id}/assign         # Assign to staff
5. PATCH /tasks/{id}/start          # Staff starts task
6. PATCH /rooms/{id}/status         # Update status to "Cleaning in Progress"
7. PATCH /tasks/{id}/complete       # Mark task complete
8. PATCH /rooms/{id}/status         # Update to "Ready for Guest"
```

### Workflow: Report & Fix Maintenance Issue
```
1. POST /maintenance/report-with-room-update    # Report issue (auto-updates room)
2. GET /maintenance/critical                    # Check critical issues
3. PATCH /maintenance/{id}/assign               # Assign to technician
4. PATCH /maintenance/{id}/start                # Work starts
5. PATCH /maintenance/{id}/complete-with-room-update  # Mark complete (auto-updates room)
6. Post-cleanup cleaning scheduled if needed
```

---

## Testing Commands

### Using cURL

```bash
# Get all rooms with cleaning status
curl "http://localhost:3000/api/housekeeping/rooms" \
  -H "Content-Type: application/json"

# Get dirty rooms
curl "http://localhost:3000/api/housekeeping/rooms/status/Dirty" \
  -H "Content-Type: application/json"

# Update room cleaning status
curl -X PATCH "http://localhost:3000/api/housekeeping/rooms/5/status" \
  -H "Content-Type: application/json" \
  -d '{
    "cleaningStatus": "Cleaned",
    "staffId": 2
  }'

# Report maintenance
curl -X POST "http://localhost:3000/api/housekeeping/maintenance/report-with-room-update" \
  -H "Content-Type: application/json" \
  -d '{
    "roomId": 2,
    "maintenanceType": "Plumbing",
    "issueDescription": "Sink leaking",
    "severity": "High",
    "reportedBy": "John Doe",
    "costEstimate": 500
  }'

# Get comprehensive dashboard
curl "http://localhost:3000/api/housekeeping/dashboard/comprehensive" \
  -H "Content-Type: application/json"

# Generate efficiency report
curl "http://localhost:3000/api/housekeeping/reports/cleaning-efficiency?days=30" \
  -H "Content-Type: application/json"
```
