# 🎯 Hotel Management System - API Reference

Base URL: `http://localhost:3000/api`

## 📋 Table of Contents
- [Rooms API](#rooms-api)
- [Guests API](#guests-api)
- [Bookings API](#bookings-api)
- [Response Format](#response-format)
- [Error Codes](#error-codes)

---

## 🛏️ Rooms API

### Get All Rooms
```http
GET /api/rooms
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "room_id": 1,
      "room_number": "101",
      "room_type": "Single",
      "price": 1500.00,
      "status": "Available",
      "description": "Cozy single room",
      "amenities": "WiFi, TV, AC"
    }
  ]
}
```

### Get Room by ID
```http
GET /api/rooms/:id
```

### Get Available Rooms
```http
GET /api/rooms/available/search?checkIn=2026-02-25&checkOut=2026-02-27
```

### Get Room Statistics
```http
GET /api/rooms/stats/overview
```

**Response:**
```json
{
  "success": true,
  "data": {
    "total_rooms": 7,
    "available_rooms": 5,
    "booked_rooms": 1,
    "maintenance_rooms": 1
  }
}
```

### Create New Room
```http
POST /api/rooms
Content-Type: application/json

{
  "room_number": "105",
  "room_type": "Suite",
  "price": 5000.00,
  "status": "Available",
  "description": "Luxury suite",
  "amenities": "WiFi, TV, AC, Jacuzzi"
}
```

### Update Room
```http
PUT /api/rooms/:id
Content-Type: application/json

{
  "room_number": "105",
  "room_type": "Suite",
  "price": 5500.00,
  "status": "Available",
  "description": "Updated description",
  "amenities": "WiFi, TV, AC, Jacuzzi, Mini-bar"
}
```

### Update Room Status
```http
PATCH /api/rooms/:id/status
Content-Type: application/json

{
  "status": "Maintenance"
}
```

### Delete Room
```http
DELETE /api/rooms/:id
```

---

## 👥 Guests API

### Get All Guests
```http
GET /api/guests
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "guest_id": 1,
      "name": "John Doe",
      "phone": "9876543210",
      "email": "john@example.com",
      "id_proof": "AADHAR123456",
      "address": "123 Main St",
      "created_at": "2026-02-24T10:30:00.000Z"
    }
  ]
}
```

### Get Guest by ID
```http
GET /api/guests/:id
```

### Search Guests
```http
GET /api/guests/search/contact?q=john
```

### Get Guest Booking History
```http
GET /api/guests/:id/history
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "booking_id": 1,
      "room_number": "101",
      "room_type": "Single",
      "check_in": "2026-02-25",
      "check_out": "2026-02-27",
      "total_amount": 3540.00,
      "booking_status": "Confirmed"
    }
  ]
}
```

### Create New Guest
```http
POST /api/guests
Content-Type: application/json

{
  "name": "Jane Smith",
  "phone": "9876543211",
  "email": "jane@example.com",
  "id_proof": "PAN12345",
  "address": "456 Oak Ave"
}
```

### Update Guest
```http
PUT /api/guests/:id
Content-Type: application/json

{
  "name": "Jane Smith Updated",
  "phone": "9876543211",
  "email": "jane.new@example.com",
  "id_proof": "PAN12345",
  "address": "456 Oak Ave, Apt 2"
}
```

### Delete Guest
```http
DELETE /api/guests/:id
```

---

## 📅 Bookings API

### Get All Bookings
```http
GET /api/bookings
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "booking_id": 1,
      "guest_name": "John Doe",
      "guest_phone": "9876543210",
      "guest_email": "john@example.com",
      "room_number": "101",
      "room_type": "Single",
      "check_in": "2026-02-25",
      "check_out": "2026-02-27",
      "total_amount": 3540.00,
      "payment_status": "Paid",
      "booking_status": "Confirmed"
    }
  ]
}
```

### Get Booking by ID
```http
GET /api/bookings/:id
```

### Get Active Bookings
```http
GET /api/bookings/active/list
```

### Get Today's Check-ins
```http
GET /api/bookings/today/checkins
```

### Get Today's Check-outs
```http
GET /api/bookings/today/checkouts
```

### Get Dashboard Statistics
```http
GET /api/bookings/stats/dashboard
```

**Response:**
```json
{
  "success": true,
  "data": {
    "confirmed_bookings": 5,
    "checked_in": 3,
    "today_checkins": 2,
    "today_checkouts": 1,
    "today_revenue": 5000.00,
    "available_rooms": 4
  }
}
```

### Get Revenue Statistics
```http
GET /api/bookings/stats/revenue?startDate=2026-02-01&endDate=2026-02-28
```

**Response:**
```json
{
  "success": true,
  "data": {
    "total_bookings": 15,
    "total_revenue": 45000.00,
    "collected_amount": 40000.00,
    "pending_amount": 5000.00,
    "average_booking_value": 3000.00
  }
}
```

### Create New Booking
```http
POST /api/bookings
Content-Type: application/json

{
  "guest_id": 1,
  "room_id": 1,
  "check_in": "2026-02-25",
  "check_out": "2026-02-27",
  "total_amount": 3540.00,
  "advance_payment": 1000.00,
  "payment_method": "UPI",
  "special_requests": "Early check-in if possible"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Booking created successfully",
  "bookingId": 5
}
```

### Update Booking
```http
PUT /api/bookings/:id
Content-Type: application/json

{
  "check_in": "2026-02-26",
  "check_out": "2026-02-28",
  "total_amount": 3540.00,
  "advance_payment": 2000.00,
  "payment_method": "Card",
  "special_requests": "Late check-out needed"
}
```

### Check-in
```http
PATCH /api/bookings/:id/checkin
```

**Response:**
```json
{
  "success": true,
  "message": "Check-in successful"
}
```

### Check-out
```http
PATCH /api/bookings/:id/checkout
```

**Response:**
```json
{
  "success": true,
  "message": "Check-out successful"
}
```

### Cancel Booking
```http
PATCH /api/bookings/:id/cancel
```

### Update Payment
```http
PATCH /api/bookings/:id/payment
Content-Type: application/json

{
  "advance_payment": 3540.00,
  "payment_method": "Cash"
}
```

---

## 📦 Response Format

### Success Response
```json
{
  "success": true,
  "data": { },
  "message": "Operation successful"
}
```

### Error Response
```json
{
  "success": false,
  "message": "Error description"
}
```

---

## ⚠️ Error Codes

| Status Code | Description |
|-------------|-------------|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request |
| 404 | Not Found |
| 500 | Internal Server Error |

---

## 💡 Usage Examples

### Example 1: Complete Booking Flow

```javascript
// 1. Create guest
const guestResponse = await fetch('http://localhost:3000/api/guests', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: 'John Doe',
    phone: '9876543210',
    email: 'john@example.com',
    id_proof: 'AADHAR123456',
    address: '123 Main St'
  })
});
const guest = await guestResponse.json();

// 2. Check available rooms
const roomsResponse = await fetch(
  'http://localhost:3000/api/rooms/available/search?checkIn=2026-02-25&checkOut=2026-02-27'
);
const rooms = await roomsResponse.json();

// 3. Create booking
const bookingResponse = await fetch('http://localhost:3000/api/bookings', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    guest_id: guest.guestId,
    room_id: rooms.data[0].room_id,
    check_in: '2026-02-25',
    check_out: '2026-02-27',
    total_amount: 3540.00,
    advance_payment: 1000.00,
    payment_method: 'UPI'
  })
});
```

### Example 2: Get Daily Report

```javascript
// Get today's statistics
const dashboard = await fetch('http://localhost:3000/api/bookings/stats/dashboard');
const stats = await dashboard.json();

console.log(`Today's Check-ins: ${stats.data.today_checkins}`);
console.log(`Today's Revenue: ₹${stats.data.today_revenue}`);
console.log(`Available Rooms: ${stats.data.available_rooms}`);
```

---

## 🔐 Notes

- All endpoints return JSON
- Content-Type: application/json for POST/PUT/PATCH requests
- No authentication required (add in production)
- CORS enabled for all origins
- Database transactions used for booking operations

---

**Last Updated:** February 24, 2026
