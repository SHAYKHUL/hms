# Testing Guide - Guest Portal Token Authentication

## 🧪 Pre-Testing Setup

### 1. Database Schema Update
```bash
# Navigate to project root
cd d:\ShaykhulWork\HotelManagementSystem(HMS)

# Update database schema
mysql -u root -p hotel_management < database/schema.sql

# Enter your MySQL password when prompted
```

### 2. Start Backend Server
```bash
cd backend
npm start

# Expected output:
# Server running on http://localhost:3000
# Connected to database
```

### 3. Sample Test Data
If you don't have test bookings, insert sample data:

```sql
-- Connect to MySQL
mysql -u root -p hotel_management

-- Insert test guest
INSERT INTO guests (name, email, phone, address, city, state, zip, country)
VALUES ('John Test', 'john@test.com', '123456789', '123 Main St', 'NYC', 'NY', '10001', 'USA');

-- Insert test room
INSERT INTO rooms (room_number, room_type, capacity, price_per_night, status)
VALUES ('1013', 'Standard', 2, 100, 'Available');

-- Insert test booking (MUST be Confirmed status)
INSERT INTO bookings (guest_id, room_id, check_in_date, check_out_date, total_nights, total_price, status)
VALUES (1, 1, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 3 DAY), 3, 300, 'Confirmed');

-- Verify data
SELECT * FROM guests;
SELECT * FROM bookings WHERE status = 'Confirmed';
SELECT * FROM rooms WHERE room_number = '1013';
```

---

## ✅ Test Case 1: Check-In and PIN Generation

### Staff Actions:
1. Open browser and navigate to: `file:///d:/ShaykhulWork/HotelManagementSystem(HMS)/frontend/index.html`
2. Click on **"Bookings"** in the menu
3. Wait for bookings table to load
4. Find the test booking (John Test, Room 1013, Confirmed status)
5. Look for the ✓ (check-in) button in the Actions column
6. Click the check-in button

### Expected Result:
- ✅ Check-in confirmation prompt appears
- ✅ Modal shows: "Check-in successful"
- ✅ **PIN displays as 6-digit number** (e.g., "123456")
- ✅ Instructions: "Share this PIN with the guest for portal access"
- ✅ Copy button available
- ✅ Booking status changes to "CheckedIn"

### Verification:
```bash
# Check database for new session
mysql -u root -p hotel_management
SELECT * FROM guest_sessions WHERE is_active = 1;

# Should show:
# - session_id: auto-generated
# - booking_id: 1
# - guest_id: 1
# - access_token: 64-char hex string
# - token_pin: "123456" (or similar)
# - is_active: 1
```

---

## ✅ Test Case 2: Copy PIN to Clipboard

### Staff Actions (Post Check-In):
1. Modal still open showing PIN
2. Click the **"Copy PIN"** button
3. Open any text editor (Notepad)
4. Paste (Ctrl+V)

### Expected Result:
- ✅ PIN copied to clipboard
- ✅ Alert or confirmation message appears
- ✅ Pasted text shows 6-digit PIN

---

## ✅ Test Case 3: Guest Portal Access with PIN

### Guest Actions:
1. Open browser and navigate to: `file:///d:/ShaykhulWork/HotelManagementSystem(HMS)/frontend/guest-portal.html`
2. Page loads and shows **PIN Login Screen**
3. See input field: "Enter 6-digit PIN"
4. Copy PIN from staff interaction (Test Case 1)
5. Paste PIN into input field
6. Click **"Access Portal"** button (or press Enter)

### Expected Result:
- ✅ System validates PIN via API
- ✅ PIN login screen disappears
- ✅ **Guest portal loads** with:
  - Booking details (Name, Room, Check-in/out dates)
  - Available services list
  - Service ordering interface
- ✅ Token stored in localStorage
- ✅ Logout button visible in header

### Console Verification:
1. Open Browser DevTools (F12)
2. Go to Console tab
3. Check localStorage:
```javascript
console.log(localStorage.getItem('guestPortalToken'));
// Should show 64-char hex string

console.log(localStorage.getItem('guestBookingData'));
// Should show guest JSON data
```

---

## ✅ Test Case 4: Guest Portal Functionality

### Guest Actions:
1. Portal is now unlocked (from Test Case 3)
2. Browse available services
3. Click on a service (e.g., "Room Service - Breakfast")
4. Order service (quantity and special requests)
5. Click **"Order Service"** button

### Expected Result:
- ✅ New order appears in "My Orders" section
- ✅ Order shows:
  - Service name
  - Quantity
  - Special requests
  - Order status: "Pending"
  - Order date/time
- ✅ Service can be ordered multiple times
- ✅ Orders persist on page refresh

---

## ✅ Test Case 5: Token Persistence (Page Reload)

### Guest Actions:
1. Portal is loaded with content visible
2. Press F5 or Ctrl+R to reload page
3. Page refreshes

### Expected Result:
- ✅ Page redirects to PIN login screen
- ✅ System validates stored token in background
- ✅ **Portal re-loads immediately** without asking for PIN again
- ✅ All orders still visible
- ✅ Seamless user experience

---

## ✅ Test Case 6: Invalid PIN

### Guest Actions:
1. Open guest-portal.html in new tab (clears localStorage)
2. See PIN login screen
3. Enter incorrect PIN: "999999"
4. Click "Access Portal"

### Expected Result:
- ✅ Error message: "Invalid PIN. Please try again."
- ✅ PIN field remains visible
- ✅ PIN field cleared
- ✅ Can try again

---

## ✅ Test Case 7: Guest Logout

### Guest Actions:
1. Portal is loaded
2. Find **"Logout"** button in header sidebar
3. Click Logout

### Expected Result:
- ✅ Portal content disappears
- ✅ PIN login screen re-appears
- ✅ localStorage cleared
- ✅ Must enter PIN again to access portal

---

## ✅ Test Case 8: Check-Out and Token Deactivation

### Staff Actions:
1. Navigate to Bookings page
2. Find the test booking (now status: "CheckedIn")
3. Look for → (check-out) button
4. Click check-out button
5. Confirm check-out

### Expected Result:
- ✅ Check-out confirmation appears
- ✅ Status changes to "CheckedOut"
- ✅ Room status changes to "Available"
- ✅ Session deactivated in database

### Database Verification:
```bash
mysql -u root -p hotel_management
SELECT * FROM guest_sessions WHERE booking_id = 1;

# Should show:
# - is_active: 0
# - checked_out_at: [current timestamp]
```

---

## ✅ Test Case 9: Guest Access After Checkout

### Guest Actions:
1. Guest still has portal open (from Test Case 7, reloaded)
2. Press F5 to reload portal page
3. System checks token validity

### Expected Result:
- ✅ Portal redirects to PIN login screen
- ✅ localStorage token cleared
- ✅ Error message or notice about session expired
- ✅ PIN entry screen shows
- ✅ Old PIN (e.g., "123456") no longer works

### Verification:
1. Try entering old PIN
2. Error: "Invalid PIN. Please try again."

---

## ✅ Test Case 10: API Endpoint Testing

### Using cURL or Postman:

**Test PIN Validation Endpoint:**
```bash
# From Test Case 1, use the PIN from database or modal
# Example: PIN = "123456"

curl -X POST http://localhost:3000/api/guest-sessions/validate-pin \
  -H "Content-Type: application/json" \
  -d '{"pin":"123456"}'

# Expected response:
{
  "success": true,
  "message": "PIN is valid",
  "data": {
    "token": "abc123...",
    "bookingId": 1,
    "guestId": 1,
    "guestName": "John Test",
    "roomNumber": "1013"
  }
}
```

**Test Token Validation Endpoint:**
```bash
# Use token from response above

curl -X POST http://localhost:3000/api/guest-sessions/validate-token \
  -H "Content-Type: application/json" \
  -d '{"token":"abc123..."}'

# Expected response:
{
  "success": true,
  "message": "Token is valid",
  "data": {
    "bookingId": 1,
    "guestId": 1,
    "guestName": "John Test",
    "roomNumber": "1013"
  }
}
```

**Test Get Session by Booking:**
```bash
curl http://localhost:3000/api/guest-sessions/booking/1

# Expected response (before checkout):
{
  "success": true,
  "data": {
    "session_id": 1,
    "booking_id": 1,
    "guest_id": 1,
    "token_pin": "123456",
    "is_active": 1,
    "created_at": "2026-02-24T10:30:00Z",
    "access_count": 2
  }
}
```

---

## 📊 Test Report Template

Use this to document your testing:

```
TEST EXECUTION REPORT
Date: ___________
Tester: ___________

Test Case 1: Check-In and PIN Generation
Status: [ ] PASS [ ] FAIL
Notes: _________________________________

Test Case 2: Copy PIN to Clipboard
Status: [ ] PASS [ ] FAIL
Notes: _________________________________

Test Case 3: Guest Portal Access with PIN
Status: [ ] PASS [ ] FAIL
Notes: _________________________________

Test Case 4: Guest Portal Functionality
Status: [ ] PASS [ ] FAIL
Notes: _________________________________

Test Case 5: Token Persistence
Status: [ ] PASS [ ] FAIL
Notes: _________________________________

Test Case 6: Invalid PIN
Status: [ ] PASS [ ] FAIL
Notes: _________________________________

Test Case 7: Guest Logout
Status: [ ] PASS [ ] FAIL
Notes: _________________________________

Test Case 8: Check-Out and Token Deactivation
Status: [ ] PASS [ ] FAIL
Notes: _________________________________

Test Case 9: Guest Access After Checkout
Status: [ ] PASS [ ] FAIL
Notes: _________________________________

Test Case 10: API Endpoint Testing
Status: [ ] PASS [ ] FAIL
Notes: _________________________________

Overall Status: [ ] ALL PASS [ ] SOME FAILED

Issues Found: _________________________________
_________________________________

Recommendations: _________________________________
_________________________________
```

---

## 🔍 Debugging Tips

### PIN Not Showing on Check-in
1. Check browser console for errors (F12)
2. Check server logs for errors
3. Verify database connection
4. Test API directly: `GET /api/guest-sessions`

### Portal Won't Load After PIN Entry
1. Check if API returned token
2. Verify token stored in localStorage
3. Check console for API errors
4. Test validateAndLoadPortal() function

### Session Still Active After Checkout
1. Verify is_active = 0 in database
2. Force browser cache clear (Ctrl+Shift+Delete)
3. Check if multiple sessions exist for same booking
4. Review server logs

### Port 3000 Already in Use
```bash
# Find what's using port 3000
netstat -ano | findstr :3000

# Kill process (replace PID)
taskkill /PID [PID] /F
```

---

## ✨ Success Criteria

All test cases pass:
- ✅ PIN generates and displays on check-in
- ✅ Guest can access portal with correct PIN
- ✅ Portal loads with booking and service data
- ✅ Services can be ordered
- ✅ Token persists across page reloads
- ✅ Invalid PIN is rejected
- ✅ Logout clears session
- ✅ Token deactivates on check-out
- ✅ Guest cannot access portal after check-out
- ✅ API endpoints return correct responses

---

**Version**: 2.1.0  
**Last Updated**: February 24, 2026  
**Support**: See TOKEN_AUTH_GUIDE.md for API details
