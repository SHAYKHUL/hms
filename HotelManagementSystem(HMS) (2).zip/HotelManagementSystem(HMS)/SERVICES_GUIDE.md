# Room Service & Amenities Feature - Implementation Guide

## Overview
The Hotel Management System now includes a complete Room Service and Amenities management system that allows guests to order services directly to their rooms and enables staff to manage and fulfill these orders efficiently.

## New Features

### 1. Services Catalog Management
- **Location**: `services.html`
- **Features**:
  - Add, edit, and delete services
  - Categorize services (Food, Beverage, Laundry, Spa, Transport, Housekeeping, Other)
  - Set pricing and availability
  - Filter services by category or search

### 2. Guest Portal
- **Location**: `guest-portal.html`
- **Features**:
  - Guest-friendly interface for browsing and ordering services
  - Browse services by category
  - View detailed service descriptions and pricing
  - Select quantity and add special instructions
  - Track order status in real-time
  - View order history

### 3. Service Orders Management
- **Location**: `services.html` (Orders tab)
- **Features**:
  - View all service orders
  - Filter by status (Pending, InProgress, Completed, Cancelled)
  - Update order status
  - Pending orders dashboard for quick action
  - Order statistics and analytics

### 4. Dashboard Integration
- **Location**: `index.html`
- **Features**:
  - Pending service orders counter
  - Quick access to guest portal
  - Service statistics

## Database Schema

### New Tables

#### `services` Table
```sql
- service_id (Primary Key)
- service_name
- category (ENUM: Food, Beverage, Laundry, Spa, Transport, Housekeeping, Other)
- description
- price
- availability (Available/Unavailable)
- image_url
- created_at, updated_at
```

#### `service_orders` Table
```sql
- order_id (Primary Key)
- booking_id (Foreign Key → bookings)
- service_id (Foreign Key → services)
- quantity
- unit_price
- total_price
- order_status (ENUM: Pending, InProgress, Completed, Cancelled)
- special_instructions
- ordered_at
- completed_at
```

#### `service_order_details` View
Combines data from service_orders, services, bookings, guests, and rooms for comprehensive order information.

## API Endpoints

### Services Endpoints
- `GET /api/services` - Get all services
- `GET /api/services/available` - Get available services only
- `GET /api/services/categories` - Get all categories
- `GET /api/services/category/:category` - Get services by category
- `GET /api/services/:id` - Get service by ID
- `POST /api/services` - Create new service
- `PUT /api/services/:id` - Update service
- `DELETE /api/services/:id` - Delete service

### Service Orders Endpoints
- `GET /api/service-orders` - Get all orders
- `GET /api/service-orders/pending` - Get pending orders
- `GET /api/service-orders/statistics` - Get order statistics
- `GET /api/service-orders/popular/:limit` - Get popular services
- `GET /api/service-orders/status/:status` - Get orders by status
- `GET /api/service-orders/booking/:bookingId` - Get orders by booking
- `GET /api/service-orders/room/:roomNumber` - Get orders by room
- `GET /api/service-orders/:id` - Get order by ID
- `POST /api/service-orders` - Create new order
- `PATCH /api/service-orders/:id/status` - Update order status
- `PUT /api/service-orders/:id` - Update order
- `DELETE /api/service-orders/:id` - Delete order

## Installation & Setup

### 1. Database Setup

#### For Fresh Installation
Run the updated `schema.sql` file which includes all tables:
```bash
mysql -u root -p hotel_management < database/schema.sql
```

#### For Existing Database
Run the update script to add services tables:
```bash
mysql -u root -p hotel_management < database/add_services.sql
```

### 2. Backend Setup
The backend files are already created:
- `backend/models/Service.js` - Service model
- `backend/models/ServiceOrder.js` - ServiceOrder model
- `backend/routes/services.js` - Services routes
- `backend/routes/serviceOrders.js` - Service orders routes
- `backend/server.js` - Updated with new routes

### 3. Frontend Setup
New pages and scripts:
- `frontend/services.html` - Services management page
- `frontend/guest-portal.html` - Guest-friendly ordering interface
- `frontend/js/services.js` - Services management JavaScript
- `frontend/js/guest-portal.js` - Guest portal JavaScript
- `frontend/css/style.css` - Updated with service styles

## Usage Guide

### For Hotel Staff

#### Managing Services
1. Navigate to **Services** from the sidebar
2. Click **Add Service** to create a new service
3. Fill in:
   - Service name
   - Category
   - Description
   - Price
   - Availability status
4. Save the service

#### Managing Orders
1. Go to **Services** > **Service Orders** tab
2. View all orders with guest and room information
3. Click **Pending Orders** tab to see orders requiring attention
4. Update order status:
   - **Pending** → **InProgress** → **Completed**
   - Or cancel if necessary
5. Track completion times and statistics

### For Guests

#### Ordering Services
1. Navigate to **Guest Portal**
2. Select your active booking from the dropdown
3. View your room and booking details
4. Browse services by category:
   - All Services
   - Food
   - Beverages
   - Laundry
   - Spa & Wellness
   - Transport
   - Housekeeping
   - Other
5. For each service:
   - Adjust quantity using +/- buttons
   - Click **Order** button
   - Add special instructions (optional)
6. Track your orders in the "My Orders" section

#### Tracking Orders
- Orders appear immediately in "My Orders" section
- Status updates in real-time:
  - **Pending** - Order received, waiting to be processed
  - **InProgress** - Currently being prepared/fulfilled
  - **Completed** - Delivered/Completed
  - **Cancelled** - Order was cancelled

## Sample Services Included

### Food Items
- Breakfast Buffet (₹500)
- Chicken Curry with Rice (₹350)
- Vegetable Biryani (₹300)
- Club Sandwich (₹250)
- Margherita Pizza (₹400)
- Caesar Salad (₹200)

### Beverages
- Fresh Juice (₹120)
- Coffee (₹100)
- Tea (₹80)
- Soft Drinks (₹60)
- Mineral Water (₹40)

### Laundry Services
- Laundry Service (₹150/kg)
- Express Laundry (₹250/kg)
- Dry Cleaning (₹200/item)

### Spa & Wellness
- Full Body Massage (₹2000)
- Facial Treatment (₹1500)
- Aromatherapy (₹1200)

### Transport
- Airport Pickup (₹800)
- City Tour (₹2500)
- Car Rental (₹3000/day)

### Housekeeping
- Extra Towels (₹100)
- Extra Bedding (₹150)
- Room Cleaning (₹200)

### Other
- Newspaper (₹30)
- Iron & Board (₹50)
- Baby Cot (₹200/day)

## Key Features & Benefits

### For Hotel Management
✅ Centralized service management
✅ Real-time order tracking
✅ Revenue analytics from services
✅ Popular services insights
✅ Efficient order fulfillment workflow
✅ Order history for billing

### For Guests
✅ Easy-to-use ordering interface
✅ Browse services by category
✅ Real-time order status updates
✅ Add special instructions
✅ View complete order history
✅ 24/7 service ordering availability

### Technical Benefits
✅ RESTful API design
✅ Responsive frontend design
✅ Real-time updates (30-second refresh)
✅ Database views for complex queries
✅ Proper foreign key relationships
✅ Transaction tracking with timestamps

## Future Enhancements (Suggestions)

1. **Payment Integration**
   - Add service charges to booking bill
   - Online payment for services
   - Multiple payment methods

2. **Notifications**
   - Email/SMS notifications for order status
   - Push notifications for guests
   - Staff alerts for new orders

3. **Advanced Features**
   - Service scheduling (book spa/transport in advance)
   - Rating and reviews for services
   - Service bundles/packages
   - Loyalty points for service orders

4. **Analytics**
   - Revenue reports by service category
   - Peak ordering times
   - Guest preferences analysis
   - Inventory management for services

5. **Mobile App**
   - Dedicated mobile app for guests
   - QR code scanning for quick access
   - Push notifications

## Troubleshooting

### Issue: Services not loading
- Check database connection
- Verify `services` table exists
- Check API endpoint: `http://localhost:3000/api/services`

### Issue: Cannot create orders
- Ensure booking exists and is active (Confirmed/CheckedIn status)
- Verify service is available
- Check foreign key constraints

### Issue: Orders not updating
- Check order_id exists
- Verify status value is valid (Pending, InProgress, Completed, Cancelled)
- Check network requests in browser console

## Testing the Features

### Test Service Management
```bash
# Get all services
curl http://localhost:3000/api/services

# Get available services
curl http://localhost:3000/api/services/available

# Create a service
curl -X POST http://localhost:3000/api/services \
  -H "Content-Type: application/json" \
  -d '{"service_name":"Test Service","category":"Food","price":100,"availability":"Available"}'
```

### Test Service Orders
```bash
# Get all orders
curl http://localhost:3000/api/service-orders

# Get pending orders
curl http://localhost:3000/api/service-orders/pending

# Create an order
curl -X POST http://localhost:3000/api/service-orders \
  -H "Content-Type: application/json" \
  -d '{"booking_id":1,"service_id":1,"quantity":2,"unit_price":500,"total_price":1000}'
```

## Support

For issues or questions:
1. Check the console for error messages
2. Verify database schema is up to date
3. Ensure all dependencies are installed
4. Check API endpoints are accessible

## Conclusion

The Room Service & Amenities feature transforms the HMS into a complete, guest-friendly hotel management solution. Guests can now order services seamlessly while hotel staff can manage and track all service requests efficiently, improving guest satisfaction and operational efficiency.
