# 🚀 Quick Setup Guide - Hotel Management System

## Fast Track Setup (5 minutes)

### 1️⃣ Setup Database (2 minutes)

Open MySQL Command Line or Workbench and run:

```sql
CREATE DATABASE hotel_management_db;
USE hotel_management_db;
SOURCE d:/ShaykhulWork/HotelManagementSystem(HMS)/database/schema.sql;
```

Or in Windows PowerShell:
```powershell
mysql -u root -p -e "CREATE DATABASE hotel_management_db"
mysql -u root -p hotel_management_db < database/schema.sql
```

### 2️⃣ Configure Backend (1 minute)

Edit `backend/.env` and set your MySQL password:
```env
DB_PASSWORD=your_mysql_password_here
```

### 3️⃣ Install & Start Backend (2 minutes)

```powershell
cd backend
npm install
npm start
```

✅ You should see: "✅ Database connected successfully"
✅ Server running at: http://localhost:3000

### 4️⃣ Access Frontend

**Option A: Direct File Access**
- Open `frontend/index.html` in your browser
- Update API URL if needed in `frontend/js/config.js`

**Option B: Using Local Server (Recommended)**
```powershell
cd frontend
python -m http.server 8080
```
Then visit: http://localhost:8080

## 🎯 First Steps After Setup

1. **Dashboard**: View system overview at `index.html`
2. **Add Rooms**: Go to "Rooms" → Click "Add Room"
3. **Add Guest**: Go to "Guests" → Click "Add Guest"
4. **Create Booking**: Go to "Bookings" → Click "New Booking"

## ✅ Verify Installation

### Check Backend:
Visit http://localhost:3000 in browser
Should see: 
```json
{
  "message": "Hotel Management System API",
  "version": "1.0.0"
}
```

### Check Database:
```sql
SELECT COUNT(*) FROM rooms;  -- Should return 7 (sample rooms)
```

### Check Frontend:
Open `index.html` - Dashboard should load with room statistics

## 🔧 Common Issues & Quick Fixes

### ❌ "Database connection failed"
**Fix:** Check `.env` file has correct MySQL credentials

### ❌ "Cannot GET /api/rooms"
**Fix:** Ensure backend server is running (`npm start` in backend folder)

### ❌ Frontend shows "Loading..." forever
**Fix:** Check if backend is running on port 3000

### ❌ CORS Error
**Fix:** Already configured! If you still see it, use a local server for frontend

### ❌ Module not found
**Fix:** Run `npm install` again in backend folder

## 📊 Sample Login Workflow

1. Open Dashboard → See 7 available rooms
2. Click "New Booking"
3. Add guest details:
   - Name: John Doe
   - Phone: 9876543210
   - ID Proof: AADHAR123456
4. Select dates and choose a room
5. Add payment and confirm
6. Check Dashboard for updated statistics!

## 🎨 Feature Highlights

✅ **Complete CRUD Operations** for Rooms, Guests, Bookings
✅ **Real-time Dashboard** with occupancy tracking
✅ **Smart Booking System** with availability checking
✅ **Payment Tracking** with multiple methods
✅ **Reports & Analytics** with date range filtering
✅ **Responsive Design** works on all screen sizes

## 📞 Testing the System

### Test Scenario 1: Create a Booking
1. Add a guest
2. Book Room 101 (Single) for today to tomorrow
3. Verify room status changes to "Booked"
4. Check Dashboard shows updated stats

### Test Scenario 2: Check-in/Check-out
1. Find booking in Bookings page
2. Click Check-in icon
3. Verify status changes to "CheckedIn"
4. Click Check-out icon
5. Verify room becomes "Available" again

### Test Scenario 3: Generate Report
1. Go to Reports page
2. Select last 30 days
3. Click "Generate Report"
4. See revenue statistics and booking list

## 💡 Pro Tips

- Use the search feature in Bookings to find guests quickly
- Filter rooms by status to see available rooms only
- Check Dashboard every morning for today's check-ins/outs
- Use Reports for monthly revenue analysis
- Print reports for physical records

## 🔄 Development Mode

For auto-reload during development:
```powershell
cd backend
npm install -D nodemon
npm run dev
```

## 📱 Access URLs

- **Backend API**: http://localhost:3000
- **Frontend**: http://localhost:8080 (or direct file)
- **API Docs**: http://localhost:3000 (root endpoint)

## ✨ Next Steps

1. ✅ System is ready to use!
2. 🎨 Customize colors in `frontend/css/style.css`
3. 📊 Add more rooms in Room Management
4. 👥 Start adding your guests
5. 📅 Begin taking bookings!

---

**Need Help?** Check the main README.md for detailed documentation.

**Happy Hotel Managing! 🏨**
