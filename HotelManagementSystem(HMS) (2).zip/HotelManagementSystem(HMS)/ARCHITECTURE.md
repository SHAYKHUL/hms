# System Architecture & Design

## 🏗️ High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     HOTEL MANAGEMENT SYSTEM v2.1.0               │
└─────────────────────────────────────────────────────────────────┘

┌──────────────────────────┐         ┌──────────────────────────┐
│    STAFF INTERFACE       │         │   GUEST PORTAL           │
│  (Employees/Managers)    │         │  (Room Service Access)   │
│                          │         │                          │
│ • Bookings Management    │         │ • PIN Login Screen       │
│ • Room Management        │         │ • Service Ordering       │
│ • Guest Management       │         │ • Order Tracking         │
│ • Check-in/Check-out     │         │ • Portal Logout          │
│ • PIN Display Modal      │         │                          │
│ • Reports & Analytics    │         │                          │
└──────────────┬───────────┘         └──────────────┬────────────┘
               │                                    │
               └────────────✓ HTTP/HTTPS ✓──────────┘
                            │
                    ┌───────▼──────────┐
                    │  FRONTEND LAYER  │
                    │  (JavaScript/CSS)│
                    │                  │
                    │ • HTML Pages     │
                    │ • API Calls      │
                    │ • localStorage   │
                    │ • Session Mgmt   │
                    └───────┬──────────┘
                            │
                    HTTP/REST/JSON
                            │
               ┌────────────▼───────────────┐
               │   EXPRESS.JS API SERVER    │
               │   (Backend Layer)          │
               │                            │
               │ • Router Layer             │
               │   ├── /api/rooms           │
               │   ├── /api/guests          │
               │   ├── /api/bookings        │
               │   └── /api/guest-sessions  │
               │                            │
               │ • Model Layer (Business)   │
               │   ├── Room.js              │
               │   ├── Guest.js             │
               │   ├── Booking.js           │
               │   └── GuestSession.js      │
               │                            │
               │ • Config Layer             │
               │   └── database.js          │
               └────────────┬───────────────┘
                            │
                    MySQL Protocol (Port 3306)
                            │
               ┌────────────▼───────────────┐
               │  MYSQL DATABASE            │
               │  (Persistent Data Store)   │
               │                            │
               │ Tables:                    │
               │ ├── rooms                  │
               │ ├── guests                 │
               │ ├── bookings               │
               │ ├── guest_sessions (NEW)   │
               │ ├── services               │
               │ └── service_orders         │
               └────────────────────────────┘
```

---

## 📊 Data Flow Diagram

### Guest Portal Authentication Flow (v2.1.0)

```
STAFF                          API SERVER                       DATABASE
  │                                │                              │
  ├──Click Check-in─────────────────│                              │
  │                                │                              │
  │                    ┌─ Booking.checkIn()                       │
  │                    │                                          │
  │                    └─ Generate Token                          │
  │                       (crypto 32-byte)                        │
  │                       Generate PIN (6-digit)                  │
  │                                │                              │
  │                                ├─ GuestSession.create()─────►│
  │                                │                     INSERT   │
  │                                │  Session ID, Token, PIN ────►│
  │◄─ Return Session Data──────────│◄─ Return Session Object──── │
  │   (PIN in modal)               │                              │
  │                                │                              │
  │ Copy PIN: "123456"             │                              │
  │ Share with guest...            │                              │
  │                                │                              │
  │                                │                              │
GUEST                             │                              │
  │                                │                              │
  ├─ Open Guest Portal             │                              │
  │  (guest-portal.html)           │                              │
  │                                │                              │
  ├─ See login screen              │                              │
  │  (PIN input box)               │                              │
  │                                │                              │
  ├─ Enter PIN: "123456"           │                              │
  │  Click "Access Portal"         │                              │
  │                                │                              │
  ├──POST /validate-pin────────────│                              │
  │  {"pin": "123456"}             │                              │
  │                                ├─ GuestSession.validatePin()--│
  │                                │   SELECT * WHERE token_pin=? │
  │                                │◄─ Return Session Record──────│
  │                                │                              │
  │◄──Return {token, booking}───────│                              │
  │                                │                              │
  │ Store in localStorage:         │                              │
  │ • guestPortalToken             │                              │
  │ • guestBookingData             │                              │
  │                                │                              │
  ├─ Portal loads                  │                              │
  │  Services visible              │                              │
  │  Orders tracked                │                              │
  │                                │                              │
  │ ... Guest uses portal ...      │                              │
  │                                │                              │
  │ Click Logout                   │                              │
  │                                │                              │
  ├─ localStorage cleared          │                              │
  │ ─ Pin login screen shows       │                              │
  │                                │                              │
  │                                │                              │
STAFF                            │                              │
  │                                │                              │
  ├─Click Check-out────────────────│                              │
  │                                │                              │
  │                    ┌─ Booking.checkOut()                      │
  │                    │                                          │
  │                    └─ GuestSession.removeSession()────────────│
  │                                │       UPDATE is_active=0    │
  │                                │       checked_out_at=NOW()  │
  │                                │◄──────Confirmed──────────────│
  │                                │                              │
  │                    ├─ Update Room status                      │
  │                    │   (Available)                            │
  │                    │                                          │
  │◄─Checkout Complete─────────────│                              │
  │   Room Available                │                              │
  │                                │                              │
```

---

## 🔄 Component Interactions

### 1. Booking Check-In Flow (with Auth)

**File**: `backend/models/Booking.js` → `backend/models/GuestSession.js`

```javascript
// Booking.checkIn() - ENHANCED FOR AUTH
async checkIn(bookingId) {
  // 1. Get guest_id from booking
  const booking = await db.query('SELECT guest_id FROM bookings WHERE booking_id=?', [bookingId]);
  
  // 2. Create guest session
  const session = await GuestSession.create(bookingId, guest_id);
  // Returns: {pin: "123456", token: "abc123...", bookingId, guestId}
  
  // 3. Update booking status
  await db.query('UPDATE bookings SET status="CheckedIn" WHERE booking_id=?', [bookingId]);
  
  // 4. Return session for PIN display
  return {affectedRows: 1, session};
}
```

### 2. Guest Portal Access Flow

**Files**: `frontend/js/guest-portal.js` → `backend/routes/guestSessions.js`

```javascript
// Step 1: Guest enters PIN and calls validatePin()
async function authenticateGuest() {
  const pin = document.getElementById('accessPin').value;
  
  // POST /api/guest-sessions/validate-pin
  const response = await apiCall('POST', 'guest-sessions/validate-pin', {pin});
  
  // Step 2: Backend validates and returns token
  // Step 3: Store token in localStorage
  localStorage.setItem('guestPortalToken', response.data.token);
  
  // Step 4: Load portal content
  await loadPortal();
}
```

### 3. Token Validation on Page Load

```javascript
// guest-portal.js - validateAndLoadPortal()
document.addEventListener('DOMContentLoaded', async () => {
  const token = localStorage.getItem('guestPortalToken');
  
  if(!token) {
    showAuthScreen(); // Show PIN login
    return;
  }
  
  // Validate token with API
  const response = await apiCall('POST', 'guest-sessions/validate-token', {token});
  
  if(response.success) {
    await loadPortal(); // Load portal content
  } else {
    showAuthScreen(); // Invalid token, show login
  }
});
```

---

## 📁 File Dependencies

```
server.js
  ├── config/database.js
  │   └── MySQL connection pool
  │
  ├── models/Room.js
  │   └── database.js
  │
  ├── models/Guest.js
  │   └── database.js
  │
  ├── models/Booking.js
  │   ├── database.js
  │   └── GuestSession.js (NEW)
  │
  ├── models/GuestSession.js (NEW)
  │   ├── database.js
  │   └── crypto (Node.js built-in)
  │
  ├── routes/rooms.js
  │   └── Room model
  │
  ├── routes/guests.js
  │   └── Guest model
  │
  ├── routes/bookings.js
  │   └── Booking model
  │
  └── routes/guestSessions.js (NEW)
      └── GuestSession model


Frontend (HTML Pages)
  ├── index.html
  │   └── js/dashboard.js
  │       ├── js/config.js
  │       └── Calls: /api/bookings, /api/rooms
  │
  ├── bookings.html
  │   └── js/bookings.js (UPDATED)
  │       ├── js/config.js
  │       ├── Calls: /api/bookings/*
  │       └── Shows PIN modal (NEW)
  │
  ├── rooms.html
  │   └── js/rooms.js
  │       ├── js/config.js
  │       └── Calls: /api/rooms
  │
  ├── guests.html
  │   └── js/guests.js
  │       ├── js/config.js
  │       └── Calls: /api/guests
  │
  ├── reports.html
  │   └── js/reports.js
  │       ├── js/config.js
  │       └── Calls: /api/bookings/stats/*
  │
  └── guest-portal.html (UPDATED)
      └── js/guest-portal.js (COMPLETELY REWRITTEN)
          ├── js/config.js
          ├── localStorage API
          └── Calls: /api/guest-sessions/*
```

---

## 🗄️ Database Schema Relationships

```
rooms
  │
  ├─── (1:N) ──→ bookings
  │              │
  │              ├─── (1:N) ──→ service_orders
  │              │               │
  │              │               └─── (N:1) ──→ services
  │              │
  │              └─── (1:1) ──→ guest_sessions (NEW)
  │
  └─── guests
        │
        ├─── (1:N) ──→ bookings
        │              │
        │              └─── (1:1) ──→ guest_sessions (NEW)
        │
        └─── (1:N) ──→ guest_sessions (NEW)


Key Relationships:
┌─────────────────────────────────────────┐
│ booking_id (PRIMARY)                    │
│ guest_id (FOREIGN KEY)                  │
│ room_id (FOREIGN KEY)                   │
└────────↑─────────────────────────────────┘
         │
         │ (1:1 relationship)
         │
┌────────▼────────────────────────────────┐
│ guest_sessions (NEW TABLE)              │
│ ├─ session_id (PRIMARY)                 │
│ ├─ booking_id (UNIQUE FOREIGN KEY)      │
│ ├─ guest_id (FOREIGN KEY)               │
│ ├─ access_token (UNIQUE, 256-char)      │
│ ├─ token_pin (UNIQUE, 6-digit)          │
│ ├─ is_active (1=active, 0=inactive)     │
│ ├─ created_at (timestamp)               │
│ ├─ expires_at (optional expiry)         │
│ ├─ checked_out_at (timestamp)           │
│ ├─ last_accessed (timestamp)            │
│ └─ access_count (audit trail)           │
└─────────────────────────────────────────┘
```

---

## 🔐 Security Architecture

### Token Generation & Validation

```
PIN: 6-digit (000000-999999)
├── Generated: Math.random() * 900000 + 100000
├── Storage: guest_sessions.token_pin
├── Unique Index: ON(token_pin)
└── Use: Guest-friendly human input

TOKEN: 256-bit Hexadecimal (64 characters)
├── Generated: crypto.randomBytes(32).toString('hex')
├── Storage: guest_sessions.access_token
├── Unique Index: ON(access_token)
├── Persistence: localStorage (client-side)
├── Validation: Hash comparison in database
└── Expiry: On checkout (is_active = 0)

Access Flow:
PIN (login) → Server validation → Token (session)
    ↓              ↓                   ↓
6 digits    Check DB match    localStorage storage
(manual)    Increment counter  (automatic)
            Return token       (transparent)
```

### Data Protection

```
DATABASE
├── guest_sessions.access_token: VARCHAR(256) UNIQUE
│   └── Ensures one token per session
├── guest_sessions.token_pin: VARCHAR(6) UNIQUE
│   └── Ensures one PIN per session
├── guest_sessions.is_active: TINYINT DEFAULT 1
│   └── Controls session lifecycle
└── Indices for fast validation
    ├── UNIQUE(access_token)
    ├── UNIQUE(token_pin)
    └── INDEX(booking_id, is_active)

FRONTEND (localStorage)
├── guestPortalToken: Stored in localStorage
│   └── Cleared on logout, auto-validates on load
└── guestBookingData: Guest information
    └── Referenced for portal display
```

---

## 🔄 Request/Response Cycle

### PIN Validation Request

```javascript
// CLIENT (guest-portal.js)
const request = {
  method: 'POST',
  url: 'http://localhost:3000/api/guest-sessions/validate-pin',
  body: JSON.stringify({pin: '123456'}),
  headers: {'Content-Type': 'application/json'}
};

// SERVER (guestSessions.js)
router.post('/validate-pin', async (req, res) => {
  const { pin } = req.body;
  
  // Call GuestSession.validatePin(pin)
  // Returns: {valid: boolean, session: {...}, message: string}
  
  if(!result.valid) {
    return res.status(401).json({success: false, message: result.message});
  }
  
  res.json({
    success: true,
    message: 'PIN is valid',
    data: {
      token: result.session.access_token,
      bookingId: result.session.booking_id,
      guestId: result.session.guest_id,
      guestName: guestData.name,
      roomNumber: roomData.room_number
    }
  });
});

// CLIENT receives response
{
  "success": true,
  "message": "PIN is valid",
  "data": {
    "token": "abc123...",
    "bookingId": 1,
    "guestId": 1,
    "guestName": "John Test",
    "roomNumber": "1013"
  }
}
```

---

## 📈 Performance Considerations

### Database Indexing

```sql
-- Current indices (optimized for v2.1.0)
UNIQUE INDEX idx_booking_id ON guest_sessions(booking_id);
UNIQUE INDEX idx_access_token ON guest_sessions(access_token);
UNIQUE INDEX idx_token_pin ON guest_sessions(token_pin);
INDEX idx_is_active ON guest_sessions(is_active);
INDEX idx_guest_id ON guest_sessions(guest_id);
```

### Query Optimization

```javascript
// GOOD: Uses index on access_token
SELECT * FROM guest_sessions WHERE access_token = ? AND is_active = 1;

// GOOD: Uses index on booking_id
SELECT * FROM guest_sessions WHERE booking_id = ? LIMIT 1;

// AVOID: Full table scan
SELECT * FROM guest_sessions WHERE checked_out_at IS NULL;
```

### Caching Strategy

```javascript
// Frontend caching (localStorage)
localStorage.setItem('guestPortalToken', token);  // Session cache
localStorage.setItem('guestBookingData', JSON.stringify(booking));  // Data cache

// Recommended: API caching headers
Cache-Control: private, max-age=3600  // Cache for 1 hour (optional)
ETag: "version_string"  // For conditional requests
```

---

## 🚀 Scalability Roadmap

### Near Term (v2.2.0)
- [ ] Redis caching for active sessions
- [ ] Rate limiting on PIN validation API
- [ ] Email notifications on successful check-in
- [ ] API request logging and monitoring

### Medium Term (v3.0.0)
- [ ] Multiple concurrent user management
- [ ] Session timeout features
- [ ] Dashboard for session management (staff)
- [ ] SMS integration for PIN delivery
- [ ] QR code generation for quick access

### Long Term (v4.0.0)
- [ ] Mobile app integration
- [ ] Biometric authentication
- [ ] Advanced analytics dashboard
- [ ] Machine learning for service recommendations
- [ ] Microservices architecture

---

## 🧪 Testing Architecture

### Unit Tests (GuestSession.js)

```javascript
describe('GuestSession', () => {
  it('should generate token with correct format', () => {
    const session = GuestSession.generateToken();
    expect(session.token).toMatch(/^[a-f0-9]{64}$/);  // 64-char hex
    expect(session.pin).toMatch(/^\d{6}$/);           // 6-digit
  });

  it('should validate correct PIN', async () => {
    const result = await GuestSession.validatePin('123456');
    expect(result.valid).toBe(true);
  });

  it('should reject invalid PIN', async () => {
    const result = await GuestSession.validatePin('999999');
    expect(result.valid).toBe(false);
  });
});
```

### Integration Tests (API)

```javascript
describe('Guest Sessions API', () => {
  it('should validate PIN and return token', async () => {
    const response = await request(app)
      .post('/api/guest-sessions/validate-pin')
      .send({pin: '123456'})
      .expect(200);
    
    expect(response.body.success).toBe(true);
    expect(response.body.data.token).toBeDefined();
  });

  it('should reject invalid PIN', async () => {
    const response = await request(app)
      .post('/api/guest-sessions/validate-pin')
      .send({pin: '999999'})
      .expect(401);
    
    expect(response.body.success).toBe(false);
  });
});
```

---

## 📊 System Metrics

### Key Performance Indicators (KPIs)

```
Response Times:
├── PIN Validation: < 100ms
├── Token Validation: < 50ms
├── Portal Load: < 500ms
└── Service Order: < 200ms

Database:
├── Active Sessions: Typically < 100 concurrent
├── Database Size: ~5-10MB per 1000 bookings
├── Query Time: < 10ms for indexed queries
└── Backup Time: < 5 minutes

Frontend:
├── Page Load: < 2 seconds
├── JavaScript: < 50KB
├── CSS: < 20KB
└── localStorage Size: < 5KB per session
```

---

## 🔗 Related Documentation

- [TOKEN_AUTH_GUIDE.md](TOKEN_AUTH_GUIDE.md) - Implementation specifics
- [TESTING_GUIDE.md](TESTING_GUIDE.md) - Test procedures
- [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) - Deployment options
- [API_REFERENCE.md](API_REFERENCE.md) - Complete API specs
- [QUICK_REFERENCE.md](QUICK_REFERENCE.md) - Quick Start Guide

---

**Version**: 2.1.0  
**Last Updated**: February 24, 2026  
**Architecture Review**: Algolizen
