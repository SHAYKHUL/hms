# Database Migration Guide

## Overview
This guide helps you update your database schema with the new room and booking improvements.

---

## ⚠️ IMPORTANT: Backup First!

Before making any changes, backup your database:

```sql
-- Example: Create a backup
CREATE DATABASE hms_backup_2026_02_24 AS SELECT * FROM hms;
```

Or using command line:
```bash
mysqldump -u root -p hms > hms_backup_2026_02_24.sql
```

---

## Migration Steps

### Step 1: Update Rooms Table

Add new columns to track bed count and guest capacity:

```sql
-- Add bed_count column
ALTER TABLE rooms 
ADD COLUMN bed_count INT DEFAULT 1 NOT NULL AFTER price;

-- Add max_guests column  
ALTER TABLE rooms 
ADD COLUMN max_guests INT DEFAULT 2 NOT NULL AFTER bed_count;

-- Add indexes for performance
ALTER TABLE rooms ADD INDEX idx_status (status);
ALTER TABLE rooms ADD INDEX idx_room_type (room_type);
```

### Step 2: Update Bookings Table

Add discount and guest tracking columns:

```sql
-- Add number_of_guests
ALTER TABLE bookings 
ADD COLUMN number_of_guests INT DEFAULT 1 NOT NULL AFTER check_out;

-- Add room_price (historical record)
ALTER TABLE bookings 
ADD COLUMN room_price DECIMAL(10, 2) NOT NULL AFTER number_of_guests;

-- Add discount tracking columns
ALTER TABLE bookings 
ADD COLUMN discount_type ENUM('None', 'Percentage', 'Fixed') DEFAULT 'None' AFTER total_amount;

ALTER TABLE bookings 
ADD COLUMN discount_value DECIMAL(10, 2) DEFAULT 0 AFTER discount_type;

ALTER TABLE bookings 
ADD COLUMN discount_reason VARCHAR(100) AFTER discount_value;

-- Add performance indexes
ALTER TABLE bookings ADD INDEX idx_status (booking_status);
ALTER TABLE bookings ADD INDEX idx_check_in (check_in);
ALTER TABLE bookings ADD INDEX idx_check_out (check_out);
ALTER TABLE bookings ADD INDEX idx_guest (guest_id);
```

### Step 3: Generate "Number of Nights" Column

The `number_of_nights` is a generated column in the updated schema:

```sql
-- For existing bookings, if you need to reference it separately:
-- It's calculated as: DATEDIFF(check_out, check_in)

-- Verify the calculation:
SELECT booking_id, check_in, check_out, 
       DATEDIFF(check_out, check_in) as nights 
FROM bookings 
LIMIT 5;
```

---

## Alternative: Complete Schema Replacement

If you want a fresh start with the complete updated schema:

1. **Backup your entire database:**
   ```bash
   mysqldump -u root -p hms > hms_full_backup.sql
   ```

2. **Drop and recreate with new schema:**
   - Use the updated `schema.sql` file
   - This will create a fresh database with all improvements

3. **Migrate data if needed:**
   - If you have important existing data, manually import it

---

## Verification Checklist

After migration, verify everything worked:

```sql
-- Check rooms table structure
DESCRIBE rooms;
-- Should show: bed_count, max_guests columns

-- Check bookings table structure
DESCRIBE bookings;
-- Should show: number_of_guests, room_price, discount_type, discount_value, discount_reason columns

-- Check for sample room
SELECT room_id, room_number, room_type, price, bed_count, max_guests 
FROM rooms LIMIT 1;

-- Check for sample booking
SELECT booking_id, guest_id, number_of_guests, 
       room_price, total_amount, discount_type, discount_value 
FROM bookings LIMIT 1;

-- Verify indexes exist
SHOW INDEX FROM rooms;
SHOW INDEX FROM bookings;
```

---

## Rollback Plan (if needed)

If something goes wrong, restore from backup:

```bash
# Using the backup file
mysql -u root -p hms < hms_backup_2026_02_24.sql
```

---

## Default Values

The migration sets sensible defaults:

| Field | Default | Reason |
|-------|---------|--------|
| `bed_count` | 1 | Single bed rooms |
| `max_guests` | 2 | Standard room capacity |
| `number_of_guests` | 1 | Single guest booking |
| `discount_type` | 'None' | No discount by default |
| `discount_value` | 0 | No discount amount |

---

## Update Your Application Code

After migration, update your backend configuration:

### Node.js/Backend
No code changes needed! The models already support:
- Reading/writing bed_count and max_guests
- Handling discount fields
- Validating guest capacity

### Frontend
Already updated to include:
- Bed count and max guests in room forms
- Number of guests in booking form
- Discount selection in payment step

---

## Testing New Features

### Test Room Capacity
```sql
-- Add a single-bed room
INSERT INTO rooms (room_number, room_type, price, bed_count, max_guests) 
VALUES ('201', 'Single', 1500.00, 1, 1);

-- Add a deluxe suite
INSERT INTO rooms (room_number, room_type, price, bed_count, max_guests) 
VALUES ('501', 'Deluxe', 5000.00, 2, 4);
```

### Test Booking with Discount
```sql
-- View a booking with discount
SELECT booking_id, guest_id, check_in, check_out,
       room_price, total_amount, 
       discount_type, discount_value, discount_reason
FROM bookings 
WHERE discount_type != 'None'
LIMIT 1;
```

---

## Troubleshooting

### Error: "Column already exists"
- Column might already be added from earlier attempt
- Use `ALTER TABLE ... ADD COLUMN IF NOT EXISTS ...` (MySQL 8.0+)

### Error: "Duplicate key name"
- Index might already exist
- Use `ALTER TABLE ... ADD INDEX IF NOT EXISTS ...` (MySQL 5.7.6+)

### Slow Migration
- Large tables might take time
- Consider running migration during off-hours
- No downtime - migration adds columns only

---

## Common Questions

**Q: Will existing bookings lose data?**
A: No. We're only adding new columns with default values. Existing data remains untouched.

**Q: Can I undo this?**
A: Yes! If you restore from backup. That's why backup is important.

**Q: Do I need to update all my rooms?**
A: You can gradually update individual rooms. New rooms will have defaults (1 bed, 2 guests).

**Q: What if I already have bookings?**
A: They'll automatically get default values for new fields. You can update them later if needed.

---

## Support

If you encounter issues:
1. Check the error message carefully
2. Verify your database backup
3. Run the verification checklist
4. Review the rollback plan if needed

**Safe to proceed** - All changes are additive (no data loss).

---

*Last Updated: February 24, 2026*
