# Hotel Management System (HMS)

A comprehensive web-based Hotel Management System built with Node.js, Express, MySQL, HTML, CSS, and JavaScript.

## 🏨 Features

### ✅ Core Functionality

1. **Room Management**
   - Add / Edit / Delete rooms
   - Room types (Single, Double, Suite, Deluxe)
   - Room status (Available, Booked, Maintenance)
   - Room amenities and descriptions

2. **Reservation System**
   - Book rooms with date selection
   - Check-in / Check-out management
   - Cancel bookings
   - View booking history
   - Automatic room availability checking

3. **Guest Management**
   - Store guest details (Name, Phone, Email, ID Proof, Address)
   - Search guests
   - View guest booking history
   - Edit guest information

4. **Billing & Payments**
   - Automatic invoice generation
   - Multiple payment methods (Cash, Card, UPI, Online)
   - Tax calculation (18% GST)
   - Payment status tracking (Pending, Partial, Paid)
   - Advance payment support

5. **Admin Dashboard**
   - Real-time occupancy rate
   - Daily revenue tracking
   - Today's check-ins and check-outs
   - Room status overview
   - Quick actions

6. **Reports & Analytics**
   - Revenue reports with date range
   - Booking statistics
   - Payment collection reports
   - Printable reports

7. **Room Service & Amenities** ⭐ NEW
   - Complete service catalog management
   - Guest-friendly ordering portal
   - Real-time order tracking
   - Service categories (Food, Beverage, Laundry, Spa, Transport, Housekeeping, Other)
   - Order status management (Pending, InProgress, Completed, Cancelled)
   - Service statistics and analytics
   - Popular services insights

8. **Guest Portal Authentication** ⭐ NEW v2.1.0
   - Secure PIN-based guest access (6-digit unique PIN)
   - Automatic token generation on check-in
   - Token-based session management (256-bit encryption)
   - Access logging with audit trails
   - Automatic token deactivation on check-out
   - localStorage-based session persistence
   - Copy-to-clipboard PIN sharing for staff
   - Beautiful PIN display modal during check-in

## 🛠️ Technology Stack

- **Frontend:** HTML5, CSS3, JavaScript (Vanilla)
- **Backend:** Node.js, Express.js
- **Database:** MySQL
- **Icons:** Font Awesome 6.4.0

## 📁 Project Structure

```
HotelManagementSystem(HMS)/
│
├── backend/
│   ├── config/
│   │   └── database.js          # Database configuration
│   ├── models/
│   │   ├── Room.js              # Room model
│   │   ├── Guest.js             # Guest model
│   │   ├── Booking.js           # Booking model (updated for auth)
│   │   └── GuestSession.js      # Guest session & token model ⭐ NEW
│   ├── routes/
│   │   ├── rooms.js             # Room API routes
│   │   ├── guests.js            # Guest API routes
│   │   ├── bookings.js          # Booking API routes (updated)
│   │   └── guestSessions.js     # Guest session API routes ⭐ NEW
│   ├── server.js                # Main server file (updated for auth)
│   ├── package.json             # Dependencies
│   └── .env                     # Environment variables
│
├── frontend/
│   ├── css/
│   │   └── style.css            # Main stylesheet
│   ├── js/
│   │   ├── config.js            # API configuration
│   │   ├── dashboard.js         # Dashboard logic
│   │   ├── rooms.js             # Room management
│   │   ├── bookings.js          # Booking management (updated PIN display)
│   │   ├── guests.js            # Guest management
│   │   ├── reports.js           # Reports & analytics
│   │   └── guest-portal.js      # Guest portal authentication ⭐ NEW
│   ├── index.html               # Dashboard page
│   ├── rooms.html               # Room management page
│   ├── bookings.html            # Booking management page
│   ├── guests.html              # Guest management page
│   ├── reports.html             # Reports page
│   └── guest-portal.html        # Guest portal page ⭐ NEW (with PIN auth)
│
└── database/
    └── schema.sql               # Database schema (guest_sessions table ⭐ NEW)
```

## 🚀 Installation & Setup

### Prerequisites

- Node.js (v14 or higher)
- MySQL (v5.7 or higher)
- A modern web browser

### Step 1: Clone or Download the Project

```bash
cd d:\ShaykhulWork\HotelManagementSystem(HMS)
```

### Step 2: Set Up Database

1. Open MySQL Workbench or command line
2. Create a new database:

```sql
CREATE DATABASE hotel_management_db;
```

3. Import the schema:

```bash
mysql -u root -p hotel_management_db < database/schema.sql
```

Or execute the `schema.sql` file in MySQL Workbench.

### Step 3: Configure Backend

1. Navigate to the backend folder:

```bash
cd backend
```

2. Install dependencies:

```bash
npm install
```

3. Configure the `.env` file:

```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=hotel_management_db
DB_PORT=3306

PORT=3000
TAX_RATE=18
```

**Important:** Update `DB_PASSWORD` with your MySQL password.

### Step 4: Start the Backend Server

```bash
npm start
```

Or for development with auto-reload:

```bash
npm run dev
```

The server will start at `http://localhost:3000`

### Step 5: Access the Frontend

1. Open the frontend folder
2. Open `index.html` in your web browser, or use a local server:

```bash
# Using Python
python -m http.server 8080

# Using Node.js http-server
npx http-server -p 8080
```

3. Access the application at `http://localhost:8080`

## 📊 Database Schema

### Tables

1. **rooms**
   - room_id (PK)
   - room_number (Unique)
   - room_type (Single/Double/Suite/Deluxe)
   - price
   - status (Available/Booked/Maintenance)
   - description
   - amenities

2. **guests**
   - guest_id (PK)
   - name
   - phone
   - email
   - id_proof
   - address

3. **bookings**
   - booking_id (PK)
   - guest_id (FK)
   - room_id (FK)
   - check_in
   - check_out
   - total_amount
   - advance_payment
   - payment_status (Pending/Partial/Paid)
   - payment_method (Cash/Card/UPI/Online)
   - booking_status (Confirmed/CheckedIn/CheckedOut/Cancelled)
   - special_requests

## 🔌 API Endpoints

### Rooms
- `GET /api/rooms` - Get all rooms
- `GET /api/rooms/:id` - Get room by ID
- `GET /api/rooms/available/search` - Get available rooms
- `GET /api/rooms/stats/overview` - Get room statistics
- `POST /api/rooms` - Create new room
- `PUT /api/rooms/:id` - Update room
- `PATCH /api/rooms/:id/status` - Update room status
- `DELETE /api/rooms/:id` - Delete room

### Guests
- `GET /api/guests` - Get all guests
- `GET /api/guests/:id` - Get guest by ID
- `GET /api/guests/search/contact?q=term` - Search guests
- `GET /api/guests/:id/history` - Get guest booking history
- `POST /api/guests` - Create new guest
- `PUT /api/guests/:id` - Update guest
- `DELETE /api/guests/:id` - Delete guest

### Bookings
- `GET /api/bookings` - Get all bookings
- `GET /api/bookings/:id` - Get booking by ID
- `GET /api/bookings/active/list` - Get active bookings
- `GET /api/bookings/today/checkins` - Get today's check-ins
- `GET /api/bookings/today/checkouts` - Get today's check-outs
- `GET /api/bookings/stats/dashboard` - Get dashboard statistics
- `GET /api/bookings/stats/revenue` - Get revenue statistics
- `POST /api/bookings` - Create new booking
- `PUT /api/bookings/:id` - Update booking
- `PATCH /api/bookings/:id/checkin` - Check-in (generates PIN & token)
- `PATCH /api/bookings/:id/checkout` - Check-out (deactivates token)
- `PATCH /api/bookings/:id/cancel` - Cancel booking
- `PATCH /api/bookings/:id/payment` - Update payment

### Guest Sessions ⭐ NEW
- `POST /api/guest-sessions/validate-token` - Validate access token
- `POST /api/guest-sessions/validate-pin` - Validate PIN for guest access
- `GET /api/guest-sessions/booking/:bookingId` - Get session by booking ID
- `GET /api/guest-sessions` - Get all active sessions (admin)
- `POST /api/guest-sessions/cleanup/expired` - Cleanup expired sessions

## 🎨 Features Overview

### Dashboard
- Real-time statistics
- Today's check-ins and check-outs
- Room occupancy visualization
- Quick action buttons

### Room Management
- Grid view of all rooms
- Filter by status and type
- Add/Edit/Delete rooms with modal forms
- Color-coded status indicators

### Booking System
- Multi-step booking process
- Guest search with autocomplete
- Real-time room availability checking
- Automatic price calculation with tax
- Payment tracking

### Guest Management
- Complete guest database
- Search functionality
- Booking history for each guest
- Edit and delete capabilities

### Reports
- Customizable date range reports
- Revenue analytics
- Booking statistics
- Printable format

## 🔐 Guest Portal Authentication (v2.1.0)

### How It Works

1. **Check-In**: Staff clicks check-in → System generates 6-digit PIN + token
2. **PIN Display**: Beautiful modal shows PIN with copy button
3. **Guest Access**: Guest opens guest portal, enters PIN, gains access
4. **Token Storage**: Token stored in localStorage for persistent sessions
5. **Check-Out**: Staff clicks check-out → Token auto-deactivates

### Documentation Files

- **[TOKEN_AUTH_GUIDE.md](TOKEN_AUTH_GUIDE.md)** - Complete technical documentation
  - Database schema for guest_sessions
  - GuestSession model methods
  - API endpoint details
  - Frontend implementation details

- **[TESTING_GUIDE.md](TESTING_GUIDE.md)** - Step-by-step testing guide
  - 10 comprehensive test cases
  - Pre-testing setup instructions
  - cURL API testing examples
  - Debugging tips

- **[QUICK_REFERENCE.md](QUICK_REFERENCE.md)** - Staff & guest quick reference
  - How to check-in/check-out guests
  - How guests access the portal
  - Common PIN issues
  - FAQ section

### Key Features

✅ **Security:**
- 256-bit encrypted access tokens
- 6-digit PIN for guest-friendly access
- Unique PIN per check-in
- Auto-deactivation on check-out
- Access logging and audit trails

✅ **User Experience:**
- No dropdown selection needed
- Simple PIN entry screen
- Copy-to-clipboard for staff
- Seamless token persistence
- Logout functionality

## 📚 Documentation

- [API_REFERENCE.md](API_REFERENCE.md) - Complete API documentation
- [SETUP_GUIDE.md](SETUP_GUIDE.md) - Initial setup instructions
- [TOKEN_AUTH_GUIDE.md](TOKEN_AUTH_GUIDE.md) - Guest portal authentication guide
- [TESTING_GUIDE.md](TESTING_GUIDE.md) - Testing and validation guide
- [QUICK_REFERENCE.md](QUICK_REFERENCE.md) - Quick reference for users

### Creating a New Booking

1. Click "New Booking" from Dashboard or Bookings page
2. **Step 1:** Search for existing guest or add new guest details
3. **Step 2:** Select check-in and check-out dates, choose available room
4. **Step 3:** Review summary, add payment details, confirm booking

### Managing Rooms

1. Go to "Rooms" page
2. Click "Add Room" to create new room
3. Click "Edit" on a room card to modify details
4. Use filters to view rooms by status or type

### Check-in/Check-out Process

1. Go to "Bookings" page
2. Find the booking
3. Click check-in icon for confirmed bookings
4. Click check-out icon for checked-in guests
5. System automatically updates room status

### Generating Reports

1. Go to "Reports" page
2. Select date range
3. Click "Generate Report"
4. View statistics and detailed booking list
5. Click "Print Report" for printable version

## 🔧 Configuration

### Changing Tax Rate

Edit `backend/.env`:
```env
TAX_RATE=18  # Change to your tax rate
```

### Changing Port

Edit `backend/.env`:
```env
PORT=3000  # Change to your preferred port
```

Update `frontend/js/config.js`:
```javascript
const API_BASE_URL = 'http://localhost:3000/api';  // Update port
```

## 🐛 Troubleshooting

### Database Connection Error
- Verify MySQL is running
- Check credentials in `.env` file
- Ensure database `hotel_management_db` exists

### API Not Working
- Ensure backend server is running on port 3000
- Check browser console for errors
- Verify API_BASE_URL in `config.js`

### CORS Issues
- Backend already has CORS enabled
- If issues persist, check browser security settings

## 📝 Sample Data

The database schema includes sample room data:
- 7 rooms with different types
- Various price points
- Different statuses for testing

## 🔐 Security Notes

For production deployment:
- Add authentication/authorization
- Use environment variables for sensitive data
- Implement input validation and sanitization
- Use HTTPS
- Add rate limiting
- Implement proper error handling

## 📱 Browser Compatibility

- Chrome (recommended)
- Firefox
- Edge
- Safari

## 👨‍💻 Development

To contribute or modify:

1. Backend changes: Edit files in `/backend`
2. Frontend changes: Edit files in `/frontend`
3. Database changes: Update `/database/schema.sql`
4. Restart server after backend changes
5. Refresh browser after frontend changes

## 📄 License

MIT License - Free to use for educational and commercial purposes

## 🙏 Support

For issues or questions:
1. Check troubleshooting section
2. Review API documentation
3. Check browser console for errors

---

**Version**: 2.1.0  
**Last Updated**: February 24, 2026

### Latest Changes (v2.1.0)
✅ Guest portal PIN-based authentication system  
✅ Token generation and validation  
✅ Automatic session management  
✅ Copy-to-clipboard PIN sharing  
✅ localStorage token persistence  
✅ Complete documentation and testing guides  

**Built with ❤️ for Hotel Management**
