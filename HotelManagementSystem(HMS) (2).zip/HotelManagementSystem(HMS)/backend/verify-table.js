const mysql = require('mysql2/promise');

async function verifyTable() {
    const connection = await mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'hotel_management_db'
    });

    try {
        // Check if room_cleaning_status table exists and has data
        const [rows] = await connection.query('SELECT COUNT(*) as count FROM room_cleaning_status');
        console.log(`✅ room_cleaning_status table exists`);
        console.log(`✅ Total records: ${rows[0].count}`);

        // Show table structure
        const [structure] = await connection.query('DESCRIBE room_cleaning_status');
        console.log('\n✅ Table Structure:');
        structure.forEach(col => {
            console.log(`   - ${col.Field}: ${col.Type}`);
        });

        // Show sample data
        const [data] = await connection.query('SELECT * FROM room_cleaning_status LIMIT 3');
        console.log('\n✅ Sample Data:');
        console.log(JSON.stringify(data, null, 2));

    } catch (error) {
        console.error('❌ Error:', error.message);
        process.exit(1);
    } finally {
        await connection.end();
    }
}

verifyTable();
