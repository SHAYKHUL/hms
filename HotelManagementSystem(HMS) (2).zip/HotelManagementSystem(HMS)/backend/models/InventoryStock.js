const db = require('../config/database');

class InventoryStock {
    // Get stock by item ID
    static async getByItemId(itemId) {
        const [rows] = await db.query(
            `SELECT 
                s.stock_id,
                s.item_id,
                s.current_quantity,
                s.minimum_quantity,
                s.maximum_quantity,
                s.reorder_quantity,
                s.last_restocked,
                s.last_consumed_date,
                s.total_value,
                s.created_at,
                s.updated_at,
                i.item_name,
                i.unit,
                i.unit_cost,
                c.category_name
            FROM inventory_stocks s
            JOIN inventory_items i ON s.item_id = i.item_id
            JOIN inventory_categories c ON i.category_id = c.category_id
            WHERE s.item_id = ?`,
            [itemId]
        );
        return rows[0];
    }

    // Update stock quantity (internal method with transaction)
    static async updateQuantity(itemId, newQuantity, reason = 'Adjustment', notes = '', createdBy = 'System', bookedAgainstId = null) {
        try {
            // Get current quantity and unit cost
            const [current] = await db.query(
                `SELECT s.current_quantity, i.unit_cost
                FROM inventory_stocks s
                JOIN inventory_items i ON s.item_id = i.item_id
                WHERE s.item_id = ?`,
                [itemId]
            );

            if (current.length === 0) {
                throw new Error('Stock record not found');
            }

            const previousQuantity = current[0].current_quantity;
            const unitCost = current[0].unit_cost;
            const quantityChange = newQuantity - previousQuantity;
            const totalValue = newQuantity * unitCost;

            // Update stock and calculate total_value
            await db.query(
                `UPDATE inventory_stocks 
                SET current_quantity = ?, 
                    total_value = ?,
                    last_consumed_date = CURRENT_TIMESTAMP,
                    updated_at = CURRENT_TIMESTAMP
                WHERE item_id = ?`,
                [newQuantity, totalValue, itemId]
            );

            // Log transaction
            await db.query(
                `INSERT INTO inventory_transactions 
                (item_id, transaction_type, quantity_change, previous_quantity, new_quantity, notes, created_by, booked_against)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                [itemId, reason, quantityChange, previousQuantity, newQuantity, notes || null, createdBy, bookedAgainstId || null]
            );

            return {
                success: true,
                previousQuantity,
                newQuantity,
                quantityChange,
                totalValue
            };
        } catch (error) {
            throw error;
        }
    }

    // Restock item
    static async restock(itemId, quantity, notes = '', createdBy = 'System') {
        if (quantity <= 0) {
            throw new Error('Restock quantity must be positive');
        }

        const stock = await this.getByItemId(itemId);
        if (!stock) {
            throw new Error('Item not found');
        }

        const newQuantity = stock.current_quantity + quantity;

        return await this.updateQuantity(itemId, newQuantity, 'Restock', notes, createdBy);
    }

    // Consume/Use item
    static async consume(itemId, quantity, notes = '', createdBy = 'System', bookedAgainstId = null) {
        if (quantity <= 0) {
            throw new Error('Consume quantity must be positive');
        }

        const stock = await this.getByItemId(itemId);
        if (!stock) {
            throw new Error('Item not found');
        }

        if (stock.current_quantity < quantity) {
            throw new Error(`Insufficient stock. Available: ${stock.current_quantity}, Requested: ${quantity}`);
        }

        const newQuantity = stock.current_quantity - quantity;

        return await this.updateQuantity(itemId, newQuantity, 'Consume', notes, createdBy, bookedAgainstId);
    }

    // Adjust stock (for discrepancies, damage, expiry)
    static async adjust(itemId, quantityChange, adjustmentType = 'Adjustment', notes = '', createdBy = 'System') {
        const stock = await this.getByItemId(itemId);
        if (!stock) {
            throw new Error('Item not found');
        }

        const newQuantity = stock.current_quantity + quantityChange;
        
        if (newQuantity < 0) {
            throw new Error('Adjustment would result in negative stock');
        }

        return await this.updateQuantity(itemId, newQuantity, adjustmentType, notes, createdBy);
    }

    // Update thresholds
    static async updateThresholds(itemId, minimumQuantity, maximumQuantity, reorderQuantity) {
        if (minimumQuantity < 0) {
            throw new Error('Minimum quantity must be non-negative');
        }
        if (maximumQuantity < minimumQuantity) {
            throw new Error('Maximum quantity must be >= minimum quantity');
        }
        if (reorderQuantity <= 0) {
            throw new Error('Reorder quantity must be positive');
        }

        const [result] = await db.query(
            `UPDATE inventory_stocks 
            SET minimum_quantity = ?, maximum_quantity = ?, reorder_quantity = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE item_id = ?`,
            [minimumQuantity, maximumQuantity, reorderQuantity, itemId]
        );

        return result.affectedRows > 0;
    }

    // ============ TRANSACTION HISTORY ============

    // Get transactions for an item
    static async getTransactions(itemId, limit = 50, offset = 0) {
        const [rows] = await db.query(
            `SELECT 
                t.transaction_id,
                t.item_id,
                t.transaction_type,
                t.quantity_change,
                t.previous_quantity,
                t.new_quantity,
                t.notes,
                t.created_by,
                t.created_at,
                i.item_name,
                b.booking_id,
                g.name AS guest_name
            FROM inventory_transactions t
            JOIN inventory_items i ON t.item_id = i.item_id
            LEFT JOIN bookings b ON t.booked_against = b.booking_id
            LEFT JOIN guests g ON b.guest_id = g.guest_id
            WHERE t.item_id = ?
            ORDER BY t.created_at DESC
            LIMIT ? OFFSET ?`,
            [itemId, limit, offset]
        );
        return rows;
    }

    // Get all recent transactions
    static async getAllTransactions(limit = 100, offset = 0) {
        const [rows] = await db.query(
            `SELECT 
                t.transaction_id,
                t.item_id,
                t.transaction_type,
                t.quantity_change,
                t.previous_quantity,
                t.new_quantity,
                t.notes,
                t.created_by,
                t.created_at,
                i.item_name,
                c.category_name,
                b.booking_id,
                g.name AS guest_name
            FROM inventory_transactions t
            JOIN inventory_items i ON t.item_id = i.item_id
            JOIN inventory_categories c ON i.category_id = c.category_id
            LEFT JOIN bookings b ON t.booked_against = b.booking_id
            LEFT JOIN guests g ON b.guest_id = g.guest_id
            ORDER BY t.created_at DESC
            LIMIT ? OFFSET ?`,
            [limit, offset]
        );
        return rows;
    }

    // Get transaction counts
    static async getTransactionCount(itemId = null) {
        if (itemId) {
            const [result] = await db.query(
                'SELECT COUNT(*) as count FROM inventory_transactions WHERE item_id = ?',
                [itemId]
            );
            return result[0].count;
        } else {
            const [result] = await db.query(
                'SELECT COUNT(*) as count FROM inventory_transactions'
            );
            return result[0].count;
        }
    }

    // Get transactions by type
    static async getTransactionsByType(transactionType, limit = 50) {
        const [rows] = await db.query(
            `SELECT 
                t.transaction_id,
                t.item_id,
                t.transaction_type,
                t.quantity_change,
                t.previous_quantity,
                t.new_quantity,
                t.notes,
                t.created_by,
                t.created_at,
                i.item_name,
                c.category_name
            FROM inventory_transactions t
            JOIN inventory_items i ON t.item_id = i.item_id
            JOIN inventory_categories c ON i.category_id = c.category_id
            WHERE t.transaction_type = ?
            ORDER BY t.created_at DESC
            LIMIT ?`,
            [transactionType, limit]
        );
        return rows;
    }

    // Get transactions by date range
    static async getTransactionsByDateRange(startDate, endDate, limit = 100) {
        const [rows] = await db.query(
            `SELECT 
                t.transaction_id,
                t.item_id,
                t.transaction_type,
                t.quantity_change,
                t.previous_quantity,
                t.new_quantity,
                t.notes,
                t.created_by,
                t.created_at,
                i.item_name,
                c.category_name
            FROM inventory_transactions t
            JOIN inventory_items i ON t.item_id = i.item_id
            JOIN inventory_categories c ON i.category_id = c.category_id
            WHERE DATE(t.created_at) BETWEEN ? AND ?
            ORDER BY t.created_at DESC
            LIMIT ?`,
            [startDate, endDate, limit]
        );
        return rows;
    }

    // ============ STATISTICS ============

    // Get stock movement summary
    static async getStockMovementSummary(itemId, days = 30) {
        const [rows] = await db.query(
            `SELECT 
                DATE(created_at) as date,
                transaction_type,
                SUM(CASE WHEN transaction_type IN ('Restock', 'Adjustment') AND quantity_change > 0 THEN quantity_change ELSE 0 END) as total_added,
                SUM(CASE WHEN transaction_type IN ('Consume', 'Damage', 'Expiry') THEN ABS(quantity_change) ELSE 0 END) as total_removed,
                COUNT(*) as transaction_count
            FROM inventory_transactions
            WHERE item_id = ? AND created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
            GROUP BY DATE(created_at)
            ORDER BY date DESC`,
            [itemId, days]
        );
        return rows;
    }

    // Get consumption rate (for forecasting)
    static async getConsumptionRate(itemId, days = 30) {
        const [result] = await db.query(
            `SELECT 
                COUNT(*) as transaction_count,
                SUM(CASE WHEN transaction_type = 'Consume' THEN ABS(quantity_change) ELSE 0 END) as total_consumed,
                AVG(CASE WHEN transaction_type = 'Consume' THEN ABS(quantity_change) ELSE NULL END) as avg_consumption
            FROM inventory_transactions
            WHERE item_id = ? AND transaction_type = 'Consume' 
                AND created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)`,
            [itemId, days]
        );
        return result[0];
    }

    // Get suppliers for low-stock items
    static async getLowStockWithSuppliers() {
        const [rows] = await db.query(
            `SELECT 
                i.item_id,
                i.item_name,
                i.unit,
                i.unit_cost,
                i.supplier_name,
                i.supplier_phone,
                c.category_name,
                s.current_quantity,
                s.minimum_quantity,
                s.reorder_quantity,
                s.total_value
            FROM inventory_items i
            JOIN inventory_categories c ON i.category_id = c.category_id
            JOIN inventory_stocks s ON i.item_id = s.item_id
            WHERE s.current_quantity <= s.minimum_quantity AND i.status = 'Active'
            ORDER BY s.current_quantity ASC, i.supplier_name`
        );
        return rows;
    }
}

module.exports = InventoryStock;
