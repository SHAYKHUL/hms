const db = require('../config/database');

class Invoice {
    // Generate new invoice from booking
    static async generateFromBooking(bookingId) {
        try {
            // Get booking details with guest and room info
            const [bookingRows] = await db.query(`
                SELECT b.*, g.name as guest_name, r.room_number, r.price as room_base_price
                FROM bookings b
                JOIN guests g ON b.guest_id = g.guest_id
                JOIN rooms r ON b.room_id = r.room_id
                WHERE b.booking_id = ?
            `, [bookingId]);

            if (bookingRows.length === 0) {
                throw new Error('Booking not found');
            }

            const booking = bookingRows[0];

            // Check if invoice already exists
            const [existingInvoice] = await db.query(
                'SELECT * FROM invoices WHERE booking_id = ?',
                [bookingId]
            );

            if (existingInvoice.length > 0) {
                throw new Error('Invoice already exists for this booking');
            }

            // Get services total for this booking
            const [servicesResult] = await db.query(`
                SELECT COALESCE(SUM(total_price), 0) as services_total
                FROM service_orders
                WHERE booking_id = ? AND order_status IN ('Completed', 'Invoiced')
            `, [bookingId]);

            const servicesTotal = servicesResult[0].services_total || 0;

            // Get billing settings
            const [settingsRows] = await db.query(`
                SELECT setting_key, setting_value 
                FROM billing_settings 
                WHERE setting_key IN ('invoice_prefix', 'tax_rate', 'due_days')
            `);

            const settings = {};
            settingsRows.forEach(s => {
                settings[s.setting_key] = s.setting_value;
            });

            // Calculate amounts
            const invoicePrefix = settings.invoice_prefix || 'INV-';
            const taxRate = parseFloat(settings.tax_rate) || 0;
            const duedays = parseInt(settings.due_days) || 7;

            const roomCharges = parseFloat(booking.total_amount) || 0;
            const subtotal = roomCharges + parseFloat(servicesTotal);
            const discountAmount = parseFloat(booking.discount_value) || 0;
            const subtotalAfterDiscount = subtotal - discountAmount;
            const taxAmount = (subtotalAfterDiscount * taxRate) / 100;
            const grandTotal = subtotalAfterDiscount + taxAmount;

            // Generate unique invoice number
            const invoiceNumber = await this.generateInvoiceNumber(invoicePrefix);

            // Get next due date
            const invoiceDate = new Date();
            const dueDate = new Date(invoiceDate);
            dueDate.setDate(dueDate.getDate() + duedays);

            // Create invoice
            const [result] = await db.query(`
                INSERT INTO invoices (
                    booking_id, guest_id, invoice_number, invoice_date, due_date,
                    check_in_date, check_out_date, room_number,
                    room_price, number_of_nights, subtotal, services_total,
                    discount_amount, discount_type, discount_reason,
                    tax_rate, tax_amount, grand_total, amount_due, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `, [
                bookingId, booking.guest_id, invoiceNumber, 
                this.formatDate(invoiceDate), this.formatDate(dueDate),
                this.formatDate(booking.check_in), this.formatDate(booking.check_out),
                booking.room_number,
                parseFloat(booking.room_price) || 0, booking.number_of_nights, 
                roomCharges, parseFloat(servicesTotal) || 0,
                discountAmount, booking.discount_type, booking.discount_reason,
                taxRate, taxAmount, grandTotal, grandTotal, 'Generated'
            ]);

            const invoiceId = result.insertId;

            // Add invoice items
            // Room charges
            await this.addInvoiceItem(invoiceId, `Room ${booking.room_number} - ${booking.number_of_nights} nights`, 'Room', booking.number_of_nights, parseFloat(booking.room_price), roomCharges);

            // Service charges
            if (servicesTotal > 0) {
                const [serviceOrders] = await db.query(`
                    SELECT s.service_name, so.quantity, so.unit_price, so.total_price
                    FROM service_orders so
                    JOIN services s ON so.service_id = s.service_id
                    WHERE so.booking_id = ? AND so.order_status IN ('Completed', 'Invoiced')
                `, [bookingId]);

                for (const service of serviceOrders) {
                    await this.addInvoiceItem(
                        invoiceId,
                        service.service_name,
                        'Service',
                        service.quantity,
                        service.unit_price,
                        service.total_price
                    );
                }
            }

            // Discount item
            if (discountAmount > 0) {
                await this.addInvoiceItem(
                    invoiceId,
                    `Discount (${booking.discount_type})`,
                    'Discount',
                    1,
                    -discountAmount,
                    -discountAmount
                );
            }

            // Tax item
            if (taxAmount > 0) {
                await this.addInvoiceItem(
                    invoiceId,
                    `Tax (${taxRate}%)`,
                    'Tax',
                    1,
                    taxAmount,
                    taxAmount
                );
            }

            // Update booking status
            await db.query('UPDATE bookings SET booking_status = ? WHERE booking_id = ?', ['CheckedOut', bookingId]);

            return {
                success: true,
                invoiceId: invoiceId,
                invoiceNumber: invoiceNumber,
                grandTotal: grandTotal,
                amountDue: grandTotal
            };
        } catch (error) {
            throw new Error(`Failed to generate invoice: ${error.message}`);
        }
    }

    // Get all invoices
    static async getAll(limit = 100, offset = 0) {
        const [rows] = await db.query(`
            SELECT * FROM invoice_summary
            ORDER BY invoice_date DESC
            LIMIT ? OFFSET ?
        `, [limit, offset]);
        return rows;
    }

    // Get invoice by ID
    static async getById(invoiceId) {
        const [rows] = await db.query(`
            SELECT * FROM invoices WHERE invoice_id = ?
        `, [invoiceId]);
        return rows[0];
    }

    // Get invoice by booking ID
    static async getByBookingId(bookingId) {
        const [rows] = await db.query(`
            SELECT * FROM invoices WHERE booking_id = ?
        `, [bookingId]);
        return rows[0];
    }

    // Get invoice details with items
    static async getDetails(invoiceId) {
        const invoice = await this.getById(invoiceId);
        if (!invoice) return null;

        const [items] = await db.query(`
            SELECT * FROM invoice_items WHERE invoice_id = ? ORDER BY item_id
        `, [invoiceId]);

        const [payments] = await db.query(`
            SELECT * FROM payments WHERE invoice_id = ? ORDER BY payment_date DESC
        `, [invoiceId]);

        return {
            ...invoice,
            items: items,
            payments: payments
        };
    }

    // Get invoices for guest
    static async getByGuestId(guestId, limit = 50, offset = 0) {
        const [rows] = await db.query(`
            SELECT * FROM invoice_summary 
            WHERE guest_id = ?
            ORDER BY invoice_date DESC
            LIMIT ? OFFSET ?
        `, [guestId, limit, offset]);
        return rows;
    }

    // Get invoices for date range
    static async getByDateRange(startDate, endDate, limit = 100, offset = 0) {
        const [rows] = await db.query(`
            SELECT * FROM invoices
            WHERE invoice_date BETWEEN ? AND ?
            ORDER BY invoice_date DESC
            LIMIT ? OFFSET ?
        `, [startDate, endDate, limit, offset]);
        return rows;
    }

    // Add invoice item
    static async addInvoiceItem(invoiceId, description, itemType, quantity, unitPrice, totalPrice) {
        const [result] = await db.query(`
            INSERT INTO invoice_items (invoice_id, description, item_type, quantity, unit_price, total_price)
            VALUES (?, ?, ?, ?, ?, ?)
        `, [invoiceId, description, itemType, quantity, unitPrice, totalPrice]);
        return result.insertId;
    }

    // Update invoice status
    static async updateStatus(invoiceId, status) {
        const [result] = await db.query(`
            UPDATE invoices SET status = ? WHERE invoice_id = ?
        `, [status, invoiceId]);
        return result.affectedRows;
    }

    // Update payment amounts on invoice
    static async updatePaymentAmount(invoiceId) {
        const [payments] = await db.query(`
            SELECT COALESCE(SUM(amount), 0) as total_paid
            FROM payments
            WHERE invoice_id = ? AND payment_status = 'Processed'
        `, [invoiceId]);

        const invoice = await this.getById(invoiceId);
        const totalPaid = payments[0].total_paid || 0;
        const amountDue = invoice.grand_total - totalPaid;
        
        let newStatus = 'Generated';
        if (amountDue <= 0) {
            newStatus = 'Paid';
        } else if (totalPaid > 0) {
            newStatus = 'Partially_Paid';
        }

        const [result] = await db.query(`
            UPDATE invoices 
            SET amount_paid = ?, amount_due = ?, status = ?
            WHERE invoice_id = ?
        `, [totalPaid, Math.max(0, amountDue), newStatus, invoiceId]);

        return result.affectedRows;
    }

    // Generate unique invoice number
    static async generateInvoiceNumber(prefix = 'INV-') {
        const [result] = await db.query(`
            SELECT COUNT(*) as count FROM invoices WHERE invoice_number LIKE ?
        `, [`${prefix}%`]);

        const count = result[0].count || 0;
        const invoiceNumber = `${prefix}${String(count + 1).padStart(6, '0')}`;

        // Check uniqueness
        const [existing] = await db.query('SELECT * FROM invoices WHERE invoice_number = ?', [invoiceNumber]);
        if (existing.length > 0) {
            return this.generateInvoiceNumber(prefix);
        }

        return invoiceNumber;
    }

    // Format date helper
    static formatDate(date) {
        if (!date) {
            return null;
        }
        if (typeof date === 'string') {
            date = new Date(date);
        }
        if (date instanceof Date && !isNaN(date.getTime())) {
            return date.toISOString().split('T')[0];
        }
        return null;
    }

    // Get invoice statistics
    static async getStatistics(startDate, endDate) {
        const [stats] = await db.query(`
            SELECT 
                COUNT(*) as total_invoices,
                SUM(grand_total) as total_revenue,
                SUM(amount_paid) as total_collected,
                SUM(amount_due) as total_outstanding,
                COUNT(CASE WHEN status = 'Paid' THEN 1 END) as paid_invoices,
                COUNT(CASE WHEN status = 'Partially_Paid' THEN 1 END) as partially_paid_invoices,
                COUNT(CASE WHEN status = 'Generated' THEN 1 END) as pending_invoices
            FROM invoices
            WHERE invoice_date BETWEEN ? AND ?
        `, [startDate, endDate]);

        return stats[0];
    }

    // Cancel invoice
    static async cancel(invoiceId, reason) {
        const [result] = await db.query(`
            UPDATE invoices 
            SET status = 'Cancelled'
            WHERE invoice_id = ?
        `, [invoiceId]);

        return result.affectedRows;
    }
}

module.exports = Invoice;
