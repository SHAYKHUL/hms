const db = require('../config/database');

class Service {
    // Get all services
    static async getAll() {
        const [rows] = await db.query(
            'SELECT * FROM services ORDER BY category, service_name'
        );
        return rows;
    }

    // Get services by category
    static async getByCategory(category) {
        const [rows] = await db.query(
            'SELECT * FROM services WHERE category = ? AND availability = "Available" ORDER BY service_name',
            [category]
        );
        return rows;
    }

    // Get available services
    static async getAvailable() {
        const [rows] = await db.query(
            'SELECT * FROM services WHERE availability = "Available" ORDER BY category, service_name'
        );
        return rows;
    }

    // Get service by ID
    static async getById(id) {
        const [rows] = await db.query(
            'SELECT * FROM services WHERE service_id = ?',
            [id]
        );
        return rows[0];
    }

    // Create new service
    static async create(serviceData) {
        const { service_name, category, description, price, availability, image_url } = serviceData;
        const [result] = await db.query(
            'INSERT INTO services (service_name, category, description, price, availability, image_url) VALUES (?, ?, ?, ?, ?, ?)',
            [service_name, category, description, price, availability || 'Available', image_url]
        );
        return result.insertId;
    }

    // Update service
    static async update(id, serviceData) {
        const { service_name, category, description, price, availability, image_url } = serviceData;
        const [result] = await db.query(
            'UPDATE services SET service_name = ?, category = ?, description = ?, price = ?, availability = ?, image_url = ? WHERE service_id = ?',
            [service_name, category, description, price, availability, image_url, id]
        );
        return result.affectedRows > 0;
    }

    // Delete service
    static async delete(id) {
        const [result] = await db.query(
            'DELETE FROM services WHERE service_id = ?',
            [id]
        );
        return result.affectedRows > 0;
    }

    // Get service categories
    static async getCategories() {
        const [rows] = await db.query(
            'SELECT DISTINCT category FROM services ORDER BY category'
        );
        return rows.map(row => row.category);
    }
}

module.exports = Service;
