const db = require('../config/database');

class CleaningTask {
    // Get all cleaning tasks
    static async getAllTasks(limit = 100, offset = 0) {
        const [rows] = await db.query(`
            SELECT 
                t.task_id,
                t.room_id,
                t.staff_id,
                t.task_type,
                t.status,
                t.priority,
                t.scheduled_date,
                t.scheduled_time,
                t.start_time,
                t.completion_time,
                t.notes,
                t.created_at,
                r.room_number,
                r.room_type,
                r.status as room_status,
                s.staff_name,
                s.role,
                s.phone,
                a.staff_name as assigned_by_name
            FROM cleaning_tasks t
            JOIN rooms r ON t.room_id = r.room_id
            LEFT JOIN housekeeping_staff s ON t.staff_id = s.staff_id
            LEFT JOIN housekeeping_staff a ON t.assigned_by = a.staff_id
            ORDER BY t.scheduled_date DESC, t.scheduled_time DESC
            LIMIT ? OFFSET ?
        `, [limit, offset]);
        return rows;
    }

    // Get tasks by date
    static async getTasksByDate(date) {
        const [rows] = await db.query(`
            SELECT 
                t.task_id,
                t.room_id,
                t.staff_id,
                t.task_type,
                t.status,
                t.priority,
                t.scheduled_date,
                t.scheduled_time,
                t.start_time,
                t.completion_time,
                t.notes,
                r.room_number,
                r.room_type,
                s.staff_name,
                s.role
            FROM cleaning_tasks t
            JOIN rooms r ON t.room_id = r.room_id
            LEFT JOIN housekeeping_staff s ON t.staff_id = s.staff_id
            WHERE t.scheduled_date = ?
            ORDER BY t.priority DESC, t.scheduled_time ASC
        `, [date]);
        return rows;
    }

    // Get tasks by status
    static async getTasksByStatus(status) {
        if (!['Not Started', 'In Progress', 'Completed', 'Cancelled', 'Pending Approval'].includes(status)) {
            throw new Error('Invalid status');
        }

        const [rows] = await db.query(`
            SELECT 
                t.task_id,
                t.room_id,
                t.staff_id,
                t.task_type,
                t.status,
                t.priority,
                t.scheduled_date,
                t.scheduled_time,
                t.start_time,
                t.completion_time,
                r.room_number,
                r.room_type,
                s.staff_name,
                s.role
            FROM cleaning_tasks t
            JOIN rooms r ON t.room_id = r.room_id
            LEFT JOIN housekeeping_staff s ON t.staff_id = s.staff_id
            WHERE t.status = ?
            ORDER BY t.priority DESC, t.scheduled_date ASC
        `, [status]);
        return rows;
    }

    // Get staff tasks
    static async getStaffTasks(staffId) {
        const [rows] = await db.query(`
            SELECT 
                t.task_id,
                t.room_id,
                t.task_type,
                t.status,
                t.priority,
                t.scheduled_date,
                t.scheduled_time,
                t.start_time,
                t.completion_time,
                t.notes,
                r.room_number,
                r.room_type,
                r.status as room_status
            FROM cleaning_tasks t
            JOIN rooms r ON t.room_id = r.room_id
            WHERE t.staff_id = ?
            ORDER BY t.scheduled_date DESC, t.scheduled_time DESC
        `, [staffId]);
        return rows;
    }

    // Get room cleaning history
    static async getRoomCleaningHistory(roomId, limit = 20) {
        const [rows] = await db.query(`
            SELECT 
                t.task_id,
                t.task_type,
                t.status,
                t.priority,
                t.scheduled_date,
                t.start_time,
                t.completion_time,
                t.notes,
                s.staff_name,
                s.role
            FROM cleaning_tasks t
            LEFT JOIN housekeeping_staff s ON t.staff_id = s.staff_id
            WHERE t.room_id = ?
            ORDER BY t.scheduled_date DESC
            LIMIT ?
        `, [roomId, limit]);
        return rows;
    }

    // Get task by ID
    static async getTaskById(taskId) {
        const [rows] = await db.query(`
            SELECT 
                t.*,
                r.room_number,
                r.room_type,
                s.staff_name,
                s.phone,
                a.staff_name as assigned_by_name
            FROM cleaning_tasks t
            JOIN rooms r ON t.room_id = r.room_id
            LEFT JOIN housekeeping_staff s ON t.staff_id = s.staff_id
            LEFT JOIN housekeeping_staff a ON t.assigned_by = a.staff_id
            WHERE t.task_id = ?
        `, [taskId]);
        return rows[0];
    }

    // Create cleaning task
    static async createTask(roomId, taskType, priority, scheduledDate, scheduledTime, notes, assignedBy, staffId = null) {
        if (!roomId || !taskType || !priority || !scheduledDate) {
            throw new Error('Room, task type, priority, and scheduled date are required');
        }

        if (!['Deep Clean', 'Regular Clean', 'Quick Clean', 'Turnover', 'Spot Clean'].includes(taskType)) {
            throw new Error('Invalid task type');
        }

        if (!['Low', 'Medium', 'High', 'Urgent'].includes(priority)) {
            throw new Error('Invalid priority');
        }

        // Check room exists
        const [roomExists] = await db.query(`SELECT room_id FROM rooms WHERE room_id = ?`, [roomId]);
        if (roomExists.length === 0) {
            throw new Error('Room not found');
        }

        const [result] = await db.query(
            `INSERT INTO cleaning_tasks 
             (room_id, staff_id, task_type, priority, scheduled_date, scheduled_time, notes, assigned_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [roomId, staffId || null, taskType, priority, scheduledDate, scheduledTime || null, notes || null, assignedBy || null]
        );

        return { task_id: result.insertId, roomId, taskType, priority };
    }

    // Update task
    static async updateTask(taskId, staffId, status, notes, priority) {
        const task = await this.getTaskById(taskId);
        if (!task) {
            throw new Error('Task not found');
        }

        if (status && !['Not Started', 'In Progress', 'Completed', 'Cancelled', 'Pending Approval'].includes(status)) {
            throw new Error('Invalid status');
        }

        if (priority && !['Low', 'Medium', 'High', 'Urgent'].includes(priority)) {
            throw new Error('Invalid priority');
        }

        let updateFields = [];
        let updateValues = [];

        if (staffId) {
            updateFields.push('staff_id = ?');
            updateValues.push(staffId);
        }
        if (status) {
            updateFields.push('status = ?');
            updateValues.push(status);
        }
        if (notes) {
            updateFields.push('notes = ?');
            updateValues.push(notes);
        }
        if (priority) {
            updateFields.push('priority = ?');
            updateValues.push(priority);
        }

        updateFields.push('updated_at = CURRENT_TIMESTAMP');
        updateValues.push(taskId);

        await db.query(
            `UPDATE cleaning_tasks SET ${updateFields.join(', ')} WHERE task_id = ?`,
            updateValues
        );

        return { success: true, message: 'Task updated successfully' };
    }

    // Start task
    static async startTask(taskId) {
        const [result] = await db.query(
            `UPDATE cleaning_tasks 
             SET status = 'In Progress', start_time = CURRENT_TIMESTAMP
             WHERE task_id = ?`,
            [taskId]
        );

        if (result.affectedRows === 0) {
            throw new Error('Task not found or already started');
        }

        return { success: true, message: 'Task started' };
    }

    // Complete task
    static async completeTask(taskId, notes = '') {
        const [result] = await db.query(
            `UPDATE cleaning_tasks 
             SET status = 'Completed', completion_time = CURRENT_TIMESTAMP, notes = CONCAT(COALESCE(notes, ''), ' - Completed: ', ?)
             WHERE task_id = ?`,
            [notes || 'Task completed', taskId]
        );

        if (result.affectedRows === 0) {
            throw new Error('Task not found');
        }

        return { success: true, message: 'Task completed' };
    }

    // Assign task to staff
    static async assignTask(taskId, staffId) {
        const task = await this.getTaskById(taskId);
        if (!task) {
            throw new Error('Task not found');
        }

        // Check staff exists
        const [staffExists] = await db.query(
            `SELECT staff_id FROM housekeeping_staff WHERE staff_id = ?`,
            [staffId]
        );
        if (staffExists.length === 0) {
            throw new Error('Staff not found');
        }

        await db.query(
            `UPDATE cleaning_tasks SET staff_id = ?, updated_at = CURRENT_TIMESTAMP WHERE task_id = ?`,
            [staffId, taskId]
        );

        return { success: true, message: 'Task assigned successfully' };
    }

    // Delete task
    static async deleteTask(taskId) {
        const [result] = await db.query(`DELETE FROM cleaning_tasks WHERE task_id = ?`, [taskId]);

        if (result.affectedRows === 0) {
            throw new Error('Task not found');
        }

        return { success: true, message: 'Task deleted successfully' };
    }

    // Get cleaning statistics
    static async getStatistics() {
        // Tasks by status today
        const [tasksToday] = await db.query(`
            SELECT 
                status,
                COUNT(*) as count
            FROM cleaning_tasks
            WHERE scheduled_date = CURDATE()
            GROUP BY status
        `);

        // Completed today
        const [completedToday] = await db.query(`
            SELECT COUNT(*) as count
            FROM cleaning_tasks
            WHERE scheduled_date = CURDATE() AND status = 'Completed'
        `);

        // Pending tasks
        const [pending] = await db.query(`
            SELECT COUNT(*) as count
            FROM cleaning_tasks
            WHERE status IN ('Not Started', 'Pending Approval') AND scheduled_date <= CURDATE()
        `);

        // Average completion time
        const [avgTime] = await db.query(`
            SELECT 
                AVG(TIMESTAMPDIFF(MINUTE, start_time, completion_time)) as avg_minutes
            FROM cleaning_tasks
            WHERE status = 'Completed' AND start_time IS NOT NULL
        `);

        return {
            tasksToday: tasksToday || [],
            completedToday: completedToday[0]?.count || 0,
            pendingTasks: pending[0]?.count || 0,
            avgCompletionTime: avgTime[0]?.avg_minutes || 0
        };
    }
}

module.exports = CleaningTask;
