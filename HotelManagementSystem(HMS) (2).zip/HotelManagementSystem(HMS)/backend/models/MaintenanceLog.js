const db = require('../config/database');

class MaintenanceLog {
    // Get all maintenance logs
    static async getAllLogs(limit = 100, offset = 0) {
        const [rows] = await db.query(`
            SELECT 
                m.log_id,
                m.room_id,
                m.maintenance_type,
                m.issue_description,
                m.severity,
                m.status,
                m.assigned_to,
                m.reported_by,
                m.reported_date,
                m.completed_date,
                m.cost_estimate,
                m.actual_cost,
                m.notes,
                r.room_number,
                r.room_type,
                r.status as room_status
            FROM maintenance_logs m
            JOIN rooms r ON m.room_id = r.room_id
            ORDER BY m.severity DESC, m.reported_date DESC
            LIMIT ? OFFSET ?
        `, [limit, offset]);
        return rows;
    }

    // Get logs by status
    static async getLogsByStatus(status) {
        if (!['Reported', 'Assigned', 'In Progress', 'Completed', 'On Hold'].includes(status)) {
            throw new Error('Invalid status');
        }

        const [rows] = await db.query(`
            SELECT 
                m.log_id,
                m.room_id,
                m.maintenance_type,
                m.issue_description,
                m.severity,
                m.status,
                m.assigned_to,
                m.reported_by,
                m.reported_date,
                m.completed_date,
                m.cost_estimate,
                m.actual_cost,
                r.room_number,
                r.room_type
            FROM maintenance_logs m
            JOIN rooms r ON m.room_id = r.room_id
            WHERE m.status = ?
            ORDER BY m.severity DESC, m.reported_date ASC
        `, [status]);
        return rows;
    }

    // Get logs by severity
    static async getLogsBySeverity(severity) {
        if (!['Low', 'Medium', 'High', 'Critical'].includes(severity)) {
            throw new Error('Invalid severity level');
        }

        const [rows] = await db.query(`
            SELECT 
                m.log_id,
                m.room_id,
                m.maintenance_type,
                m.issue_description,
                m.severity,
                m.status,
                m.assigned_to,
                m.reported_date,
                m.cost_estimate,
                r.room_number,
                r.room_type
            FROM maintenance_logs m
            JOIN rooms r ON m.room_id = r.room_id
            WHERE m.severity = ?
            ORDER BY m.reported_date DESC
        `, [severity]);
        return rows;
    }

    // Get logs by type
    static async getLogsByType(maintenanceType) {
        if (!['Plumbing', 'Electrical', 'HVAC', 'Furniture', 'Appliance', 'Paint', 'Flooring', 'Other'].includes(maintenanceType)) {
            throw new Error('Invalid maintenance type');
        }

        const [rows] = await db.query(`
            SELECT 
                m.log_id,
                m.room_id,
                m.maintenance_type,
                m.issue_description,
                m.severity,
                m.status,
                m.reported_date,
                m.cost_estimate,
                r.room_number,
                r.room_type
            FROM maintenance_logs m
            JOIN rooms r ON m.room_id = r.room_id
            WHERE m.maintenance_type = ?
            ORDER BY m.reported_date DESC
        `, [maintenanceType]);
        return rows;
    }

    // Get room maintenance history
    static async getRoomMaintenanceHistory(roomId, limit = 20) {
        const [rows] = await db.query(`
            SELECT 
                log_id,
                maintenance_type,
                issue_description,
                severity,
                status,
                reported_date,
                completed_date,
                assigned_to,
                cost_estimate,
                actual_cost,
                notes
            FROM maintenance_logs
            WHERE room_id = ?
            ORDER BY reported_date DESC
            LIMIT ?
        `, [roomId, limit]);
        return rows;
    }

    // Get log by ID
    static async getLogById(logId) {
        const [rows] = await db.query(`
            SELECT 
                m.*,
                r.room_number,
                r.room_type
            FROM maintenance_logs m
            JOIN rooms r ON m.room_id = r.room_id
            WHERE m.log_id = ?
        `, [logId]);
        return rows[0];
    }

    // Report new maintenance issue
    static async reportIssue(roomId, maintenanceType, issueDescription, severity, reportedBy, costEstimate = null, partsRequired = null) {
        if (!roomId || !maintenanceType || !issueDescription || !severity) {
            throw new Error('Room, maintenance type, issue description, and severity are required');
        }

        if (issueDescription.length < 5) {
            throw new Error('Issue description must be at least 5 characters');
        }

        if (!['Plumbing', 'Electrical', 'HVAC', 'Furniture', 'Appliance', 'Paint', 'Flooring', 'Other'].includes(maintenanceType)) {
            throw new Error('Invalid maintenance type');
        }

        if (!['Low', 'Medium', 'High', 'Critical'].includes(severity)) {
            throw new Error('Invalid severity level');
        }

        // Check room exists
        const [roomExists] = await db.query(`SELECT room_id FROM rooms WHERE room_id = ?`, [roomId]);
        if (roomExists.length === 0) {
            throw new Error('Room not found');
        }

        const [result] = await db.query(
            `INSERT INTO maintenance_logs 
             (room_id, maintenance_type, issue_description, severity, reported_by, cost_estimate, parts_required)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [roomId, maintenanceType, issueDescription, severity, reportedBy || null, costEstimate || null, partsRequired || null]
        );

        return { log_id: result.insertId, roomId, maintenanceType, status: 'Reported' };
    }

    // Assign maintenance
    static async assignMaintenance(logId, assignedTo) {
        const log = await this.getLogById(logId);
        if (!log) {
            throw new Error('Maintenance log not found');
        }

        const [result] = await db.query(
            `UPDATE maintenance_logs 
             SET status = 'Assigned', assigned_to = ?, updated_at = CURRENT_TIMESTAMP
             WHERE log_id = ?`,
            [assignedTo, logId]
        );

        return { success: result.affectedRows > 0, message: 'Maintenance assigned' };
    }

    // Start maintenance work
    static async startWork(logId) {
        const [result] = await db.query(
            `UPDATE maintenance_logs 
             SET status = 'In Progress', updated_at = CURRENT_TIMESTAMP
             WHERE log_id = ?`,
            [logId]
        );

        if (result.affectedRows === 0) {
            throw new Error('Maintenance log not found');
        }

        return { success: true, message: 'Work started' };
    }

    // Complete maintenance
    static async completeMaintenance(logId, actualCost = null, notes = '') {
        const [result] = await db.query(
            `UPDATE maintenance_logs 
             SET status = 'Completed', 
                 completed_date = CURRENT_TIMESTAMP,
                 actual_cost = COALESCE(?, actual_cost),
                 notes = CONCAT(COALESCE(notes, ''), ' - Completed: ', ?),
                 updated_at = CURRENT_TIMESTAMP
             WHERE log_id = ?`,
            [actualCost || null, notes || 'Completed successfully', logId]
        );

        if (result.affectedRows === 0) {
            throw new Error('Maintenance log not found');
        }

        return { success: true, message: 'Maintenance completed' };
    }

    // Hold maintenance (pause work)
    static async holdMaintenance(logId, reason = '') {
        const [result] = await db.query(
            `UPDATE maintenance_logs 
             SET status = 'On Hold',
                 notes = CONCAT(COALESCE(notes, ''), ' - On Hold: ', ?),
                 updated_at = CURRENT_TIMESTAMP
             WHERE log_id = ?`,
            [reason || 'On hold', logId]
        );

        if (result.affectedRows === 0) {
            throw new Error('Maintenance log not found');
        }

        return { success: true, message: 'Maintenance put on hold' };
    }

    // Update maintenance details
    static async updateLog(logId, costEstimate = null, actualCost = null, notes = null, partsRequired = null) {
        const log = await this.getLogById(logId);
        if (!log) {
            throw new Error('Maintenance log not found');
        }

        let updates = [];
        let values = [];

        if (costEstimate !== null) {
            updates.push('cost_estimate = ?');
            values.push(costEstimate);
        }
        if (actualCost !== null) {
            updates.push('actual_cost = ?');
            values.push(actualCost);
        }
        if (notes !== null) {
            updates.push('notes = ?');
            values.push(notes);
        }
        if (partsRequired !== null) {
            updates.push('parts_required = ?');
            values.push(partsRequired);
        }

        if (updates.length === 0) {
            return { success: false, message: 'No updates provided' };
        }

        updates.push('updated_at = CURRENT_TIMESTAMP');
        values.push(logId);

        await db.query(
            `UPDATE maintenance_logs SET ${updates.join(', ')} WHERE log_id = ?`,
            values
        );

        return { success: true, message: 'Maintenance details updated' };
    }

    // Delete maintenance log
    static async deleteLog(logId) {
        const [result] = await db.query(`DELETE FROM maintenance_logs WHERE log_id = ?`, [logId]);

        if (result.affectedRows === 0) {
            throw new Error('Maintenance log not found');
        }

        return { success: true, message: 'Maintenance log deleted' };
    }

    // Get maintenance statistics
    static async getStatistics() {
        // Total pending
        const [pending] = await db.query(`
            SELECT COUNT(*) as count 
            FROM maintenance_logs 
            WHERE status IN ('Reported', 'Assigned', 'In Progress')
        `);

        // By severity
        const [bySeverity] = await db.query(`
            SELECT 
                severity,
                COUNT(*) as count,
                SUM(CASE WHEN status IN ('Completed') THEN 1 ELSE 0 END) as completed
            FROM maintenance_logs
            GROUP BY severity
        `);

        // By type
        const [byType] = await db.query(`
            SELECT 
                maintenance_type,
                COUNT(*) as count
            FROM maintenance_logs
            WHERE status != 'Completed'
            GROUP BY maintenance_type
        `);

        // Cost summary
        const [costSummary] = await db.query(`
            SELECT 
                SUM(cost_estimate) as total_estimate,
                SUM(actual_cost) as total_actual,
                COUNT(*) as completed_count
            FROM maintenance_logs
            WHERE status = 'Completed'
        `);

        return {
            totalPending: pending[0]?.count || 0,
            bySeverity: bySeverity || [],
            byType: byType || [],
            costSummary: costSummary[0] || { total_estimate: 0, total_actual: 0, completed_count: 0 }
        };
    }

    // Get critical issues needing immediate attention
    static async getCriticalIssues() {
        const [rows] = await db.query(`
            SELECT 
                log_id,
                room_id,
                maintenance_type,
                issue_description,
                severity,
                status,
                assigned_to,
                reported_date,
                r.room_number
            FROM maintenance_logs m
            JOIN rooms r ON m.room_id = r.room_id
            WHERE m.severity = 'Critical' AND m.status IN ('Reported', 'Assigned', 'In Progress')
            ORDER BY m.reported_date ASC
        `);
        return rows;
    }
}

module.exports = MaintenanceLog;
