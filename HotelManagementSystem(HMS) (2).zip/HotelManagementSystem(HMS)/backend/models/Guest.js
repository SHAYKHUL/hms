const db = require('../config/database');

class Guest {
    // Get all guests
    static async getAll() {
        const [rows] = await db.query('SELECT * FROM guests ORDER BY created_at DESC');
        return rows;
    }

    // Get guest by ID
    static async getById(id) {
        const [rows] = await db.query('SELECT * FROM guests WHERE guest_id = ?', [id]);
        return rows[0];
    }

    // Search guest by phone or email
    static async searchByContact(searchTerm) {
        const [rows] = await db.query(
            'SELECT * FROM guests WHERE phone LIKE ? OR email LIKE ? OR name LIKE ?',
            [`%${searchTerm}%`, `%${searchTerm}%`, `%${searchTerm}%`]
        );
        return rows;
    }

    // Create new guest
    static async create(guestData) {
        const { name, phone, email, id_proof, address } = guestData;
        const [result] = await db.query(
            'INSERT INTO guests (name, phone, email, id_proof, address) VALUES (?, ?, ?, ?, ?)',
            [name, phone, email, id_proof, address]
        );
        return result.insertId;
    }

    // Update guest
    static async update(id, guestData) {
        const { name, phone, email, id_proof, address } = guestData;
        const [result] = await db.query(
            'UPDATE guests SET name = ?, phone = ?, email = ?, id_proof = ?, address = ? WHERE guest_id = ?',
            [name, phone, email, id_proof, address, id]
        );
        return result.affectedRows;
    }

    // Delete guest
    static async delete(id) {
        const [result] = await db.query('DELETE FROM guests WHERE guest_id = ?', [id]);
        return result.affectedRows;
    }

    // Get guest booking history
    static async getBookingHistory(guestId) {
        const [rows] = await db.query(`
            SELECT b.*, r.room_number, r.room_type 
            FROM bookings b
            JOIN rooms r ON b.room_id = r.room_id
            WHERE b.guest_id = ?
            ORDER BY b.created_at DESC
        `, [guestId]);
        return rows;
    }
}

module.exports = Guest;
