const db = require('../config/database');

class Refund {
    // Create new refund record
    static async create(refundData) {
        const { payment_id, invoice_id, booking_id, guest_id, refund_amount, refund_reason, refund_method } = refundData;

        try {
            // Get billing settings for refund prefix
            const [settingsRows] = await db.query(
                "SELECT setting_value FROM billing_settings WHERE setting_key = 'payment_prefix'"
            );
            const refundPrefix = 'REF-';

            // Generate unique refund number
            const refundNumber = await this.generateRefundNumber(refundPrefix);

            const refundDate = new Date();

            const [result] = await db.query(`
                INSERT INTO refunds (
                    payment_id, invoice_id, booking_id, guest_id, refund_number,
                    refund_amount, refund_reason, refund_date, refund_method, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `, [
                payment_id || null, invoice_id, booking_id, guest_id, refundNumber,
                refund_amount, refund_reason, refundDate, refund_method, 'Pending'
            ]);

            const refundId = result.insertId;

            return {
                success: true,
                refundId: refundId,
                refundNumber: refundNumber,
                amount: refund_amount
            };
        } catch (error) {
            throw new Error(`Failed to create refund: ${error.message}`);
        }
    }

    // Get all refunds
    static async getAll(limit = 100, offset = 0) {
        const [rows] = await db.query(`
            SELECT * FROM refunds
            ORDER BY refund_date DESC
            LIMIT ? OFFSET ?
        `, [limit, offset]);
        return rows;
    }

    // Get refund by ID
    static async getById(refundId) {
        const [rows] = await db.query(`
            SELECT * FROM refunds WHERE refund_id = ?
        `, [refundId]);
        return rows[0];
    }

    // Get refunds for invoice
    static async getByInvoiceId(invoiceId) {
        const [rows] = await db.query(`
            SELECT * FROM refunds
            WHERE invoice_id = ?
            ORDER BY refund_date DESC
        `, [invoiceId]);
        return rows;
    }

    // Get refunds for guest
    static async getByGuestId(guestId, limit = 50, offset = 0) {
        const [rows] = await db.query(`
            SELECT * FROM refunds
            WHERE guest_id = ?
            ORDER BY refund_date DESC
            LIMIT ? OFFSET ?
        `, [guestId, limit, offset]);
        return rows;
    }

    // Get refunds for date range
    static async getByDateRange(startDate, endDate, limit = 100, offset = 0) {
        const [rows] = await db.query(`
            SELECT * FROM refunds
            WHERE DATE(refund_date) BETWEEN ? AND ?
            ORDER BY refund_date DESC
            LIMIT ? OFFSET ?
        `, [startDate, endDate, limit, offset]);
        return rows;
    }

    // Approve refund
    static async approveRefund(refundId, approvedBy) {
        const [result] = await db.query(`
            UPDATE refunds
            SET status = 'Processed', approved_by = ?
            WHERE refund_id = ?
        `, [approvedBy, refundId]);

        return result.affectedRows;
    }

    // Reject refund
    static async rejectRefund(refundId, reason) {
        const [result] = await db.query(`
            UPDATE refunds
            SET status = 'Failed', notes = ?
            WHERE refund_id = ?
        `, [reason, refundId]);

        return result.affectedRows;
    }

    // Generate unique refund number
    static async generateRefundNumber(prefix = 'REF-') {
        const [result] = await db.query(`
            SELECT COUNT(*) as count FROM refunds WHERE refund_number LIKE ?
        `, [`${prefix}%`]);

        const count = result[0].count || 0;
        const refundNumber = `${prefix}${String(count + 1).padStart(6, '0')}`;

        // Check uniqueness
        const [existing] = await db.query('SELECT * FROM refunds WHERE refund_number = ?', [refundNumber]);
        if (existing.length > 0) {
            return this.generateRefundNumber(prefix);
        }

        return refundNumber;
    }

    // Get refund statistics
    static async getStatistics(startDate, endDate) {
        const [stats] = await db.query(`
            SELECT 
                COUNT(*) as total_refunds,
                SUM(refund_amount) as total_refunded,
                COUNT(CASE WHEN status = 'Processed' THEN 1 END) as processed_refunds,
                COUNT(CASE WHEN status = 'Pending' THEN 1 END) as pending_refunds,
                COUNT(CASE WHEN status = 'Failed' THEN 1 END) as failed_refunds
            FROM refunds
            WHERE DATE(refund_date) BETWEEN ? AND ?
        `, [startDate, endDate]);

        return stats[0];
    }

    // Get refund details with related info
    static async getDetails(refundId) {
        const refund = await this.getById(refundId);
        if (!refund) return null;

        const [payment] = await db.query(
            'SELECT * FROM payments WHERE payment_id = ?',
            [refund.payment_id]
        );

        const [invoice] = await db.query(
            'SELECT * FROM invoices WHERE invoice_id = ?',
            [refund.invoice_id]
        );

        const [guest] = await db.query(
            'SELECT * FROM guests WHERE guest_id = ?',
            [refund.guest_id]
        );

        return {
            ...refund,
            payment: payment[0] || null,
            invoice: invoice[0] || null,
            guest: guest[0] || null
        };
    }
}

module.exports = Refund;
