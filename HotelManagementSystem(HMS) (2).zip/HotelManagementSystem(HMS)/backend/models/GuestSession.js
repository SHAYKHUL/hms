const db = require('../config/database');
const crypto = require('crypto');

class GuestSession {
    // Generate unique token and PIN
    static generateToken() {
        const token = crypto.randomBytes(32).toString('hex');
        const pin = Math.floor(100000 + Math.random() * 900000).toString(); // 6-digit PIN
        return { token, pin };
    }

    // Create new guest session (on check-in)
    static async create(bookingId, guestId) {
        try {
            const { token, pin } = this.generateToken();
            
            // Check if session already exists
            const [existing] = await db.query(
                'SELECT session_id FROM guest_sessions WHERE booking_id = ? AND is_active = 1',
                [bookingId]
            );
            
            if (existing.length > 0) {
                // Remove old session
                await this.removeSession(bookingId);
            }
            
            // Create new session
            const [result] = await db.query(
                `INSERT INTO guest_sessions (booking_id, guest_id, access_token, token_pin, is_active)
                 VALUES (?, ?, ?, ?, 1)`,
                [bookingId, guestId, token, pin]
            );
            
            return {
                sessionId: result.insertId,
                token,
                pin,
                bookingId,
                guestId
            };
        } catch (error) {
            throw error;
        }
    }

    // Get session by token
    static async getByToken(token) {
        try {
            const [rows] = await db.query(
                `SELECT gs.*, b.room_id, b.guest_id, r.room_number, g.name as guest_name
                 FROM guest_sessions gs
                 JOIN bookings b ON gs.booking_id = b.booking_id
                 JOIN rooms r ON b.room_id = r.room_id
                 JOIN guests g ON b.guest_id = g.guest_id
                 WHERE gs.access_token = ? AND gs.is_active = 1`,
                [token]
            );
            
            if (rows.length > 0) {
                // Update last accessed and access count
                await db.query(
                    'UPDATE guest_sessions SET last_accessed = NOW(), access_count = access_count + 1 WHERE session_id = ?',
                    [rows[0].session_id]
                );
                return rows[0];
            }
            return null;
        } catch (error) {
            throw error;
        }
    }

    // Get session by PIN
    static async getByPin(pin) {
        try {
            const [rows] = await db.query(
                `SELECT gs.*, b.room_id, b.guest_id, r.room_number, g.name as guest_name
                 FROM guest_sessions gs
                 JOIN bookings b ON gs.booking_id = b.booking_id
                 JOIN rooms r ON b.room_id = r.room_id
                 JOIN guests g ON b.guest_id = g.guest_id
                 WHERE gs.token_pin = ? AND gs.is_active = 1`,
                [pin]
            );
            
            if (rows.length > 0) {
                // Update last accessed and access count
                await db.query(
                    'UPDATE guest_sessions SET last_accessed = NOW(), access_count = access_count + 1 WHERE session_id = ?',
                    [rows[0].session_id]
                );
                return rows[0];
            }
            return null;
        } catch (error) {
            throw error;
        }
    }

    // Get session by booking ID
    static async getByBookingId(bookingId) {
        try {
            const [rows] = await db.query(
                `SELECT * FROM guest_sessions WHERE booking_id = ? AND is_active = 1`,
                [bookingId]
            );
            return rows[0] || null;
        } catch (error) {
            throw error;
        }
    }

    // Validate token
    static async validateToken(token) {
        try {
            const session = await this.getByToken(token);
            
            if (!session) {
                return { valid: false, message: 'Invalid or expired token' };
            }
            
            // Check if session has expired
            if (session.expires_at && new Date(session.expires_at) < new Date()) {
                await this.removeSession(session.booking_id);
                return { valid: false, message: 'Token has expired' };
            }
            
            if (!session.is_active) {
                return { valid: false, message: 'Session is inactive' };
            }
            
            return { valid: true, session };
        } catch (error) {
            throw error;
        }
    }

    // Validate PIN
    static async validatePin(pin) {
        try {
            const session = await this.getByPin(pin);
            
            if (!session) {
                return { valid: false, message: 'Invalid PIN' };
            }
            
            // Check if session has expired
            if (session.expires_at && new Date(session.expires_at) < new Date()) {
                await this.removeSession(session.booking_id);
                return { valid: false, message: 'PIN has expired' };
            }
            
            if (!session.is_active) {
                return { valid: false, message: 'Session is inactive' };
            }
            
            return { valid: true, session };
        } catch (error) {
            throw error;
        }
    }

    // Remove session (on checkout)
    static async removeSession(bookingId) {
        try {
            const [result] = await db.query(
                `UPDATE guest_sessions 
                 SET is_active = 0, checked_out_at = NOW() 
                 WHERE booking_id = ? AND is_active = 1`,
                [bookingId]
            );
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }

    // Get session info for display
    static async getSessionInfo(bookingId) {
        try {
            const [rows] = await db.query(
                `SELECT session_id, booking_id, guest_id, token_pin, is_active, created_at, last_accessed, access_count
                 FROM guest_sessions 
                 WHERE booking_id = ? AND is_active = 1`,
                [bookingId]
            );
            return rows[0] || null;
        } catch (error) {
            throw error;
        }
    }

    // Get all active sessions
    static async getAllActive() {
        try {
            const [rows] = await db.query(
                `SELECT gs.*, g.name as guest_name, r.room_number
                 FROM guest_sessions gs
                 JOIN guests g ON gs.guest_id = g.guest_id
                 JOIN bookings b ON gs.booking_id = b.booking_id
                 JOIN rooms r ON b.room_id = r.room_id
                 WHERE gs.is_active = 1
                 ORDER BY gs.created_at DESC`
            );
            return rows;
        } catch (error) {
            throw error;
        }
    }

    // Clean up expired sessions (can be run periodically)
    static async cleanupExpiredSessions() {
        try {
            const [result] = await db.query(
                `UPDATE guest_sessions 
                 SET is_active = 0, checked_out_at = NOW() 
                 WHERE is_active = 1 AND expires_at IS NOT NULL AND expires_at < NOW()`
            );
            return result.affectedRows;
        } catch (error) {
            throw error;
        }
    }
}

module.exports = GuestSession;
