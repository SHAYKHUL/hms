const db = require('../config/database');

class ServiceOrder {
    // Get all service orders with details
    static async getAll() {
        const [rows] = await db.query(
            'SELECT * FROM service_order_details ORDER BY ordered_at DESC'
        );
        return rows;
    }

    // Get service orders by booking ID
    static async getByBookingId(bookingId) {
        const [rows] = await db.query(
            'SELECT * FROM service_order_details WHERE booking_id = ? ORDER BY ordered_at DESC',
            [bookingId]
        );
        return rows;
    }

    // Get service orders by room number
    static async getByRoomNumber(roomNumber) {
        const [rows] = await db.query(
            'SELECT * FROM service_order_details WHERE room_number = ? ORDER BY ordered_at DESC',
            [roomNumber]
        );
        return rows;
    }

    // Get service order by ID
    static async getById(id) {
        const [rows] = await db.query(
            'SELECT * FROM service_order_details WHERE order_id = ?',
            [id]
        );
        return rows[0];
    }

    // Get pending orders
    static async getPending() {
        const [rows] = await db.query(
            'SELECT * FROM service_order_details WHERE order_status = "Pending" ORDER BY ordered_at ASC'
        );
        return rows;
    }

    // Get orders by status
    static async getByStatus(status) {
        const [rows] = await db.query(
            'SELECT * FROM service_order_details WHERE order_status = ? ORDER BY ordered_at DESC',
            [status]
        );
        return rows;
    }

    // Create new service order
    static async create(orderData) {
        const { booking_id, service_id, quantity, unit_price, total_price, special_instructions } = orderData;
        const [result] = await db.query(
            'INSERT INTO service_orders (booking_id, service_id, quantity, unit_price, total_price, special_instructions) VALUES (?, ?, ?, ?, ?, ?)',
            [booking_id, service_id, quantity, unit_price, total_price, special_instructions]
        );
        return result.insertId;
    }

    // Update order status
    static async updateStatus(id, status) {
        const completed_at = status === 'Completed' ? new Date() : null;
        const [result] = await db.query(
            'UPDATE service_orders SET order_status = ?, completed_at = ? WHERE order_id = ?',
            [status, completed_at, id]
        );
        return result.affectedRows > 0;
    }

    // Update order
    static async update(id, orderData) {
        const { quantity, unit_price, total_price, order_status, special_instructions } = orderData;
        const [result] = await db.query(
            'UPDATE service_orders SET quantity = ?, unit_price = ?, total_price = ?, order_status = ?, special_instructions = ? WHERE order_id = ?',
            [quantity, unit_price, total_price, order_status, special_instructions, id]
        );
        return result.affectedRows > 0;
    }

    // Delete order
    static async delete(id) {
        const [result] = await db.query(
            'DELETE FROM service_orders WHERE order_id = ?',
            [id]
        );
        return result.affectedRows > 0;
    }

    // Get total revenue from service orders
    static async getTotalRevenue(startDate = null, endDate = null) {
        let query = 'SELECT SUM(total_price) as total_revenue FROM service_orders WHERE order_status = "Completed"';
        const params = [];
        
        if (startDate && endDate) {
            query += ' AND ordered_at BETWEEN ? AND ?';
            params.push(startDate, endDate);
        }
        
        const [rows] = await db.query(query, params);
        return rows[0].total_revenue || 0;
    }

    // Get order statistics
    static async getStatistics() {
        const [stats] = await db.query(`
            SELECT 
                COUNT(*) as total_orders,
                SUM(CASE WHEN order_status = 'Pending' THEN 1 ELSE 0 END) as pending_orders,
                SUM(CASE WHEN order_status = 'InProgress' THEN 1 ELSE 0 END) as in_progress_orders,
                SUM(CASE WHEN order_status = 'Completed' THEN 1 ELSE 0 END) as completed_orders,
                SUM(CASE WHEN order_status = 'Cancelled' THEN 1 ELSE 0 END) as cancelled_orders,
                SUM(CASE WHEN order_status = 'Completed' THEN total_price ELSE 0 END) as total_revenue
            FROM service_orders
        `);
        return stats[0];
    }

    // Get popular services
    static async getPopularServices(limit = 5) {
        const [rows] = await db.query(`
            SELECT 
                s.service_name,
                s.category,
                COUNT(so.order_id) as order_count,
                SUM(so.total_price) as total_revenue
            FROM service_orders so
            JOIN services s ON so.service_id = s.service_id
            WHERE so.order_status = 'Completed'
            GROUP BY s.service_id
            ORDER BY order_count DESC
            LIMIT ?
        `, [limit]);
        return rows;
    }
}

module.exports = ServiceOrder;
