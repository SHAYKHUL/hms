const db = require('../config/database');

class Room {
    // Get all rooms
    static async getAll() {
        const [rows] = await db.query('SELECT * FROM rooms ORDER BY room_number');
        return rows;
    }

    // Get room by ID
    static async getById(id) {
        const [rows] = await db.query('SELECT * FROM rooms WHERE room_id = ?', [id]);
        return rows[0];
    }

    // Get all rooms with enhanced status including booking information
    static async getAllWithBookingStatus() {
        const [rows] = await db.query(`
            SELECT 
                r.*,
                COALESCE(rc.cleaning_status, 'Clean') as cleaning_status,
                COALESCE(rc.last_cleaned_by, null) as last_cleaned_by,
                COALESCE(rc.last_cleaned_date, null) as last_cleaned_date,
                s.staff_name as last_cleaned_by_name,
                -- Current booking information
                b.booking_id as current_booking_id,
                b.guest_id as current_guest_id,
                g.name as current_guest_name,
                b.check_in as current_checkin,
                b.check_out as current_checkout,
                b.booking_status as current_booking_status,
                b.actual_checkout_time,
                b.checkout_type,
                b.is_early_checkout,
                -- Room availability status
                CASE 
                    WHEN r.status = 'Maintenance' THEN 'Under Maintenance'
                    WHEN b.booking_status = 'CheckedIn' THEN 'Occupied'
                    WHEN b.booking_status = 'Confirmed' AND DATE(b.check_in) = CURDATE() THEN 'Reserved (Arriving Today)'
                    WHEN b.booking_status = 'Confirmed' AND DATE(b.check_in) > CURDATE() THEN 'Reserved'
                    WHEN b.booking_status = 'CheckedOut' AND b.is_early_checkout = TRUE THEN 'Available (Early Checkout)'
                    ELSE 'Available'
                END as availability_status,
                -- Time until available
                CASE 
                    WHEN b.booking_status = 'CheckedIn' THEN CONCAT(DATE(b.check_out), ' 12:00:00')
                    WHEN b.booking_status = 'CheckedOut' AND b.actual_checkout_time IS NOT NULL THEN b.actual_checkout_time
                    WHEN b.booking_status = 'Confirmed' AND DATE(b.check_in) > CURDATE() THEN CONCAT(DATE(b.check_in), ' 12:00:00')
                    ELSE NULL
                END as available_from,
                (SELECT COUNT(*) FROM cleaning_tasks WHERE room_id = r.room_id AND status != 'Completed' AND scheduled_date <= CURDATE()) as pending_tasks,
                (SELECT COUNT(*) FROM maintenance_logs WHERE room_id = r.room_id AND status IN ('Reported', 'Assigned', 'In Progress')) as pending_maintenance
            FROM rooms r
            LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
            LEFT JOIN housekeeping_staff s ON rc.last_cleaned_by = s.staff_id
            LEFT JOIN bookings b ON r.room_id = b.room_id 
                AND b.booking_status IN ('Confirmed', 'CheckedIn') 
                AND (DATE(b.check_out) >= CURDATE() OR (b.booking_status = 'CheckedIn'))
            LEFT JOIN guests g ON b.guest_id = g.guest_id
            ORDER BY r.room_number
        `);
        return rows;
    }

    // Get room cleaning status
    static async getCleaningStatus(roomId) {
        const [rows] = await db.query(`
            SELECT 
                r.*,
                COALESCE(rc.cleaning_status, 'Pending') as cleaning_status,
                rc.last_cleaned_by,
                rc.last_cleaned_date,
                rc.next_cleaning_scheduled,
                s.staff_name as last_cleaned_by_name,
                (SELECT COUNT(*) FROM cleaning_tasks WHERE room_id = r.room_id AND status != 'Completed' AND scheduled_date <= CURDATE()) as pending_tasks,
                (SELECT COUNT(*) FROM maintenance_logs WHERE room_id = r.room_id AND status IN ('Reported', 'Assigned', 'In Progress')) as pending_maintenance
            FROM rooms r
            LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
            LEFT JOIN housekeeping_staff s ON rc.last_cleaned_by = s.staff_id
            WHERE r.room_id = ?
        `, [roomId]);
        return rows[0];
    }

    // Enhanced room status validation
    static validateRoomStatus(status) {
        const validStatuses = ['Available', 'Reserved', 'Occupied', 'Booked', 'Maintenance', 'Under_Maintenance', 'Out_Of_Service'];
        return validStatuses.includes(status);
    }

    // Update room cleaning status
    static async updateCleaningStatus(roomId, cleaningStatus, staffId = null) {
        const validStatuses = ['Dirty', 'Cleaning in Progress', 'Cleaned', 'Ready for Guest', 'Pending', 'Inspecting', 'Ready', 'Maintenance Required'];
        if (!validStatuses.includes(cleaningStatus)) {
            throw new Error('Invalid cleaning status');
        }

        // Check if status record exists
        const [exists] = await db.query(
            'SELECT room_id FROM room_cleaning_status WHERE room_id = ?',
            [roomId]
        );

        if (exists.length > 0) {
            // Update existing record
            if (cleaningStatus === 'Cleaned' && staffId) {
                await db.query(
                    `UPDATE room_cleaning_status 
                     SET cleaning_status = ?, last_cleaned_by = ?, last_cleaned_date = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
                     WHERE room_id = ?`,
                    [cleaningStatus, staffId, roomId]
                );
            } else {
                await db.query(
                    `UPDATE room_cleaning_status 
                     SET cleaning_status = ?, updated_at = CURRENT_TIMESTAMP
                     WHERE room_id = ?`,
                    [cleaningStatus, roomId]
                );
            }
        } else {
            // Insert new record
            await db.query(
                `INSERT INTO room_cleaning_status (room_id, cleaning_status, last_cleaned_by)
                 VALUES (?, ?, ?)`,
                [roomId, cleaningStatus, staffId || null]
            );
        }

        return { success: true, cleaning_status: cleaningStatus };
    }

    // Update room status with timestamp
    static async updateStatus(roomId, status) {
        const [result] = await db.query(
            'UPDATE rooms SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE room_id = ?',
            [status, roomId]
        );
        return result.affectedRows;
    }

    // Auto-update room status based on bookings and checkout events
    static async autoUpdateRoomStatus(roomId) {
        const [bookings] = await db.query(`
            SELECT * FROM bookings 
            WHERE room_id = ? 
            AND booking_status IN ('Confirmed', 'CheckedIn', 'CheckedOut')
            ORDER BY updated_at DESC 
            LIMIT 1
        `, [roomId]);

        let newStatus = 'Available';
        
        if (bookings.length > 0) {
            const booking = bookings[0];
            const now = new Date();
            const checkIn = new Date(booking.check_in);
            const checkOut = new Date(booking.check_out);
            
            switch (booking.booking_status) {
                case 'CheckedIn':
                    newStatus = 'Booked';
                    break;
                case 'Confirmed':
                    if (checkIn <= now && now < checkOut) {
                        newStatus = 'Booked';
                    } else if (checkIn > now) {
                        newStatus = 'Available'; // Reserved but not yet time
                    }
                    break;
                case 'CheckedOut':
                    // If early checkout, immediately available
                    if (booking.is_early_checkout) {
                        newStatus = 'Available';
                    } else {
                        newStatus = 'Available';
                    }
                    break;
            }
        }

        // Update the room status
        await this.updateStatus(roomId, newStatus);
        return newStatus;
    }

    // Get room occupancy summary with early checkout detection
    static async getOccupancySummary(date = null) {
        const targetDate = date || new Date().toISOString().split('T')[0];
        
        const [rows] = await db.query(`
            SELECT 
                COUNT(*) as total_rooms,
                SUM(CASE WHEN r.status = 'Available' THEN 1 ELSE 0 END) as available_rooms,
                SUM(CASE WHEN r.status = 'Booked' THEN 1 ELSE 0 END) as occupied_rooms,
                SUM(CASE WHEN r.status = 'Maintenance' THEN 1 ELSE 0 END) as maintenance_rooms,
                SUM(CASE 
                    WHEN b.is_early_checkout = TRUE AND DATE(b.actual_checkout_time) = ? 
                    THEN 1 ELSE 0 
                END) as early_checkouts_today,
                SUM(CASE 
                    WHEN b.checkout_type = 'Late' AND DATE(b.actual_checkout_time) = ? 
                    THEN 1 ELSE 0 
                END) as late_checkouts_today,
                ROUND((SUM(CASE WHEN r.status = 'Booked' THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2) as occupancy_percentage
            FROM rooms r
            LEFT JOIN bookings b ON r.room_id = b.room_id 
                AND b.booking_status = 'CheckedOut' 
                AND DATE(b.actual_checkout_time) = ?
        `, [targetDate, targetDate, targetDate]);
        
        return rows[0];
    }

    // Enhanced room availability check with early checkout consideration
    static async getAvailable(checkIn, checkOut, acType = null) {
        let query = `
            SELECT r.*, 
                   COALESCE(rc.cleaning_status, 'Pending') as cleaning_status,
                   (
                       SELECT JSON_EXTRACT(
                           check_room_availability_enhanced(r.room_id, ?, ?), 
                           '$.available'
                       )
                   ) as is_truly_available
            FROM rooms r
            LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
            WHERE (
                r.status = 'Available' 
                OR (
                    r.room_id IN (
                        SELECT DISTINCT b.room_id 
                        FROM bookings b 
                        WHERE b.is_early_checkout = TRUE 
                        AND b.actual_checkout_time IS NOT NULL
                        AND b.actual_checkout_time <= ?
                        AND b.check_out > ?
                    )
                )
            )
            AND r.room_id NOT IN (
                SELECT room_id FROM bookings 
                WHERE booking_status IN ('Confirmed', 'CheckedIn')
                AND check_in <= ? AND check_out >= ?
                AND (actual_checkout_time IS NULL OR actual_checkout_time >= ?)
            )
        `;
        
        let params = [checkIn, checkOut, checkIn, checkIn, checkOut, checkIn, checkIn];
        
        // Add AC/Non-AC filtering if specified
        if (acType && ['AC', 'Non-AC'].includes(acType)) {
            query += ` AND r.ac_type = ?`;
            params.push(acType);
        }
        
        query += ` ORDER BY r.room_type, r.ac_type, r.price`;
        
        const [rows] = await db.query(query, params);
        return rows;
    }

    // Get rooms available for immediate occupancy
    static async getImmediatelyAvailable() {
        const [rows] = await db.query(`
            SELECT r.*, 
                   COALESCE(rc.cleaning_status, 'Pending') as cleaning_status
            FROM rooms r
            LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
            WHERE r.status = 'Available'
            AND (
                rc.cleaning_status IS NULL 
                OR rc.cleaning_status IN ('Cleaned', 'Ready for Guest', 'Ready')
            )
            ORDER BY r.room_number
        `);
        return rows;
    }

    // Create new room
    static async create(roomData) {
        const { room_number, room_type, ac_type, price, bed_count, max_guests, status, description, amenities } = roomData;
        // Normalize room number to uppercase for consistency
        const normalizedRoomNumber = (room_number || '').toString().trim().toUpperCase();
        
        const [result] = await db.query(
            'INSERT INTO rooms (room_number, room_type, ac_type, price, bed_count, max_guests, status, description, amenities) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [normalizedRoomNumber, room_type, ac_type || 'AC', price, bed_count || 1, max_guests || 2, status || 'Available', description, amenities]
        );
        
        // Initialize cleaning status for new room
        const roomId = result.insertId;
        await db.query(
            'INSERT INTO room_cleaning_status (room_id, cleaning_status) VALUES (?, ?)',
            [roomId, 'Pending']
        );
        
        return roomId;
    }

    // Update room
    static async update(id, roomData) {
        const { room_number, room_type, ac_type, price, bed_count, max_guests, status, description, amenities } = roomData;
        // Normalize room number to uppercase for consistency
        const normalizedRoomNumber = (room_number || '').toString().trim().toUpperCase();
        
        const [result] = await db.query(
            'UPDATE rooms SET room_number = ?, room_type = ?, ac_type = ?, price = ?, bed_count = ?, max_guests = ?, status = ?, description = ?, amenities = ? WHERE room_id = ?',
            [normalizedRoomNumber, room_type, ac_type || 'AC', price, bed_count || 1, max_guests || 2, status, description, amenities, id]
        );
        return result.affectedRows;
    }

    // Enhanced room status update with history tracking
    static async updateStatus(id, status, reason = 'Manual', notes = null, changedBy = null) {
        if (!this.validateRoomStatus(status)) {
            throw new Error('Invalid room status');
        }
        
        // Get current status
        const [currentRoom] = await db.query('SELECT status FROM rooms WHERE room_id = ?', [id]);
        if (currentRoom.length === 0) {
            throw new Error('Room not found');
        }
        
        const previousStatus = currentRoom[0].status;
        
        // Update room status
        const [result] = await db.query(
            'UPDATE rooms SET status = ? WHERE room_id = ?',
            [status, id]
        );
        
        // Log the change in history
        if (result.affectedRows > 0 && previousStatus !== status) {
            await db.query(
                `INSERT INTO room_availability_history 
                 (room_id, previous_status, new_status, change_reason, changed_by, notes)
                 VALUES (?, ?, ?, ?, ?, ?)`,
                [id, previousStatus, status, reason, changedBy, notes]
            );
        }
        
        return result.affectedRows;
    }

    // Update room status with full history tracking (alternate method name)
    static async updateStatusWithHistory(id, status, reason = 'Manual', notes = null, changedBy = null) {
        return this.updateStatus(id, status, reason, notes, changedBy);
    }

    // Delete room
    static async delete(id) {
        const [result] = await db.query('DELETE FROM rooms WHERE room_id = ?', [id]);
        return result.affectedRows;
    }

    // Enhanced room statistics with new statuses
    static async getStatistics() {
        const [stats] = await db.query(`
            SELECT 
                COUNT(distinct r.room_id) as total_rooms,
                SUM(CASE WHEN r.status = 'Available' THEN 1 ELSE 0 END) as available_rooms,
                SUM(CASE WHEN r.status = 'Reserved' THEN 1 ELSE 0 END) as reserved_rooms,
                SUM(CASE WHEN r.status = 'Occupied' THEN 1 ELSE 0 END) as occupied_rooms,
                SUM(CASE WHEN r.status = 'Booked' THEN 1 ELSE 0 END) as booked_rooms,
                SUM(CASE WHEN r.status = 'Maintenance' THEN 1 ELSE 0 END) as maintenance_rooms,
                SUM(CASE WHEN r.status = 'Under_Maintenance' THEN 1 ELSE 0 END) as under_maintenance_rooms,
                SUM(CASE WHEN r.status = 'Out_Of_Service' THEN 1 ELSE 0 END) as out_of_service_rooms,
                SUM(CASE WHEN rc.cleaning_status = 'Cleaned' OR rc.cleaning_status = 'Ready' THEN 1 ELSE 0 END) as cleaned_rooms,
                SUM(CASE WHEN rc.cleaning_status = 'Dirty' THEN 1 ELSE 0 END) as dirty_rooms,
                SUM(CASE WHEN rc.cleaning_status = 'Cleaning in Progress' THEN 1 ELSE 0 END) as cleaning_in_progress,
                SUM(CASE WHEN rc.cleaning_status = 'Maintenance Required' THEN 1 ELSE 0 END) as maintenance_required,
                -- Early checkout statistics
                (SELECT COUNT(*) FROM bookings WHERE is_early_checkout = TRUE AND DATE(actual_checkout_time) = CURDATE()) as today_early_checkouts,
                (SELECT COUNT(DISTINCT room_id) FROM bookings WHERE is_early_checkout = TRUE AND DATE(actual_checkout_time) = CURDATE()) as rooms_available_from_early_checkout
            FROM rooms r
            LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
        `);
        return stats[0];
    }

    // Get room availability history
    static async getAvailabilityHistory(roomId, limit = 10) {
        const [rows] = await db.query(`
            SELECT 
                rah.*,
                b.booking_id,
                CONCAT(g.name, ' (Room ', r.room_number, ')') as booking_details
            FROM room_availability_history rah
            LEFT JOIN bookings b ON rah.booking_id = b.booking_id
            LEFT JOIN guests g ON b.guest_id = g.guest_id
            LEFT JOIN rooms r ON rah.room_id = r.room_id
            WHERE rah.room_id = ?
            ORDER BY rah.change_time DESC
            LIMIT ?
        `, [roomId, limit]);
        return rows;
    }

    // Get rooms that became available due to early checkout
    static async getRoomsFromEarlyCheckout() {
        const [rows] = await db.query(`
            SELECT 
                r.*,
                b.booking_id,
                b.actual_checkout_time,
                b.early_checkout_reason,
                g.name as guest_name,
                COALESCE(rc.cleaning_status, 'Pending') as cleaning_status
            FROM rooms r
            JOIN bookings b ON r.room_id = b.room_id
            JOIN guests g ON b.guest_id = g.guest_id
            LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
            WHERE b.is_early_checkout = TRUE
            AND DATE(b.actual_checkout_time) = CURDATE()
            AND r.status = 'Available'
            ORDER BY b.actual_checkout_time DESC
        `);
        return rows;
    }

    // Get rooms by cleaning status
    static async getRoomsByCleaningStatus(cleaningStatus) {
        const validStatuses = ['Dirty', 'Cleaning in Progress', 'Cleaned', 'Ready for Guest', 'Pending', 'Inspecting'];
        if (!validStatuses.includes(cleaningStatus)) {
            throw new Error('Invalid cleaning status');
        }

        const [rows] = await db.query(`
            SELECT 
                r.*,
                rc.cleaning_status,
                rc.last_cleaned_by,
                rc.last_cleaned_date,
                s.staff_name as last_cleaned_by_name
            FROM rooms r
            LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
            LEFT JOIN housekeeping_staff s ON rc.last_cleaned_by = s.staff_id
            WHERE rc.cleaning_status = ?
            ORDER BY r.room_number
        `, [cleaningStatus]);
        return rows;
    }

    // Schedule next cleaning for room
    static async scheduleNextCleaning(roomId, scheduledDate) {
        const [result] = await db.query(
            `UPDATE room_cleaning_status 
             SET next_cleaning_scheduled = ?, updated_at = CURRENT_TIMESTAMP
             WHERE room_id = ?`,
            [scheduledDate, roomId]
        );
        return result.affectedRows > 0;
    }

    // Get rooms needing cleaning
    static async getRoomsNeedingCleaning() {
        const [rows] = await db.query(`
            SELECT 
                r.*,
                rc.cleaning_status,
                rc.last_cleaned_date,
                s.staff_name as last_cleaned_by_name,
                COUNT(ct.task_id) as pending_tasks
            FROM rooms r
            LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
            LEFT JOIN housekeeping_staff s ON rc.last_cleaned_by = s.staff_id
            LEFT JOIN cleaning_tasks ct ON r.room_id = ct.room_id AND ct.status != 'Completed'
            WHERE rc.cleaning_status IN ('Dirty', 'Pending') OR r.status = 'Available'
            GROUP BY r.room_id
            ORDER BY rc.cleaning_status DESC, r.room_number ASC
        `);
        return rows;
    }

    // Get occupancy rate for a date range
    static async getOccupancyRate(startDate, endDate) {
        const [result] = await db.query(`
            SELECT 
                COUNT(DISTINCT r.room_id) as total_rooms,
                SUM(
                    DATEDIFF(
                        LEAST(b.check_out, ? + INTERVAL 1 DAY),
                        GREATEST(b.check_in, ?)
                    )
                ) as total_room_nights_booked,
                COUNT(DISTINCT r.room_id) * DATEDIFF(? + INTERVAL 1 DAY, ?) as total_room_nights_available,
                ROUND(
                    SUM(
                        DATEDIFF(
                            LEAST(b.check_out, ? + INTERVAL 1 DAY),
                            GREATEST(b.check_in, ?)
                        )
                    ) * 100.0 / (COUNT(DISTINCT r.room_id) * DATEDIFF(? + INTERVAL 1 DAY, ?)),
                    2
                ) as occupancy_percentage
            FROM rooms r
            LEFT JOIN bookings b ON r.room_id = b.room_id 
                AND b.booking_status IN ('Confirmed', 'CheckedIn', 'CheckedOut')
                AND b.check_in < ? + INTERVAL 1 DAY
                AND b.check_out > ?
        `, [endDate, startDate, endDate, startDate, endDate, startDate, endDate, startDate, endDate, startDate]);
        
        return result[0];
    }

    // Enhanced room availability check with early checkout consideration
    static async isAvailableForDates(roomId, checkIn, checkOut) {
        const [result] = await db.query(
            'SELECT check_room_availability_enhanced(?, ?, ?) as availability_result',
            [roomId, checkIn, checkOut]
        );
        
        if (result.length > 0 && result[0].availability_result) {
            const availabilityData = JSON.parse(result[0].availability_result);
            return availabilityData.available === 1 || availabilityData.available === true;
        }
        
        // Fallback to original logic if function fails
        const [conflicts] = await db.query(`
            SELECT COUNT(*) as conflicts FROM bookings 
            WHERE room_id = ? 
            AND booking_status IN ('Confirmed', 'CheckedIn')
            AND check_in <= ? 
            AND check_out >= ?
            AND (actual_checkout_time IS NULL OR actual_checkout_time >= ?)
        `, [roomId, checkOut, checkIn, checkIn]);
        
        return conflicts[0].conflicts === 0;
    }

    // Get detailed availability information for a room
    static async getDetailedAvailability(roomId, checkIn, checkOut) {
        try {
            const [result] = await db.query(
                'SELECT check_room_availability_enhanced(?, ?, ?) as availability_result',
                [roomId, checkIn, checkOut]
            );
            
            if (result.length > 0 && result[0].availability_result) {
                const availabilityData = JSON.parse(result[0].availability_result);
                
                // Get additional room details
                const [roomDetails] = await db.query(`
                    SELECT r.*, 
                           COALESCE(rc.cleaning_status, 'Pending') as cleaning_status,
                           rc.last_cleaned_date
                    FROM rooms r
                    LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
                    WHERE r.room_id = ?
                `, [roomId]);
                
                return {
                    ...availabilityData,
                    room_details: roomDetails[0] || null
                };
            }
            
            return { available: false, conflicts: 1, early_checkout_available: false };
        } catch (error) {
            console.error('Error checking detailed availability:', error);
            return { available: false, conflicts: 1, early_checkout_available: false, error: error.message };
        }
    }

    // Get revenue by room for date range
    static async getRevenueByRoom(startDate, endDate) {
        const [rows] = await db.query(`
            SELECT 
                r.room_id,
                r.room_number,
                r.room_type,
                COUNT(b.booking_id) as total_bookings,
                SUM(b.total_amount) as total_revenue,
                ROUND(AVG(b.total_amount), 2) as avg_booking_value
            FROM rooms r
            LEFT JOIN bookings b ON r.room_id = b.room_id 
                AND b.check_in >= ?
                AND b.check_out <= ?
                AND b.booking_status != 'Cancelled'
            GROUP BY r.room_id
            ORDER BY total_revenue DESC
        `, [startDate, endDate]);
        
        return rows;
    }
}

module.exports = Room;
