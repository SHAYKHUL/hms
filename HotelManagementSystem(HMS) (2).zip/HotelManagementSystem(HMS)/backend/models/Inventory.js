const db = require('../config/database');

class Inventory {
    // ============ CATEGORIES ============
    
    // Get all categories
    static async getAllCategories() {
        const [rows] = await db.query(
            'SELECT * FROM inventory_categories ORDER BY category_name'
        );
        return rows;
    }

    // Get category by ID
    static async getCategoryById(categoryId) {
        const [rows] = await db.query(
            'SELECT * FROM inventory_categories WHERE category_id = ?',
            [categoryId]
        );
        return rows[0];
    }

    // Create new category
    static async createCategory(categoryData) {
        const { category_name, description } = categoryData;
        
        // Validation
        if (!category_name || category_name.trim().length === 0) {
            throw new Error('Category name is required');
        }
        if (category_name.length > 100) {
            throw new Error('Category name must not exceed 100 characters');
        }

        const [result] = await db.query(
            'INSERT INTO inventory_categories (category_name, description) VALUES (?, ?)',
            [category_name, description || null]
        );
        
        return result.insertId;
    }

    // Update category
    static async updateCategory(categoryId, categoryData) {
        const { category_name, description } = categoryData;
        
        if (!category_name || category_name.trim().length === 0) {
            throw new Error('Category name is required');
        }
        if (category_name.length > 100) {
            throw new Error('Category name must not exceed 100 characters');
        }

        const [result] = await db.query(
            'UPDATE inventory_categories SET category_name = ?, description = ? WHERE category_id = ?',
            [category_name, description || null, categoryId]
        );
        
        return result.affectedRows > 0;
    }

    // Delete category
    static async deleteCategory(categoryId) {
        const [result] = await db.query(
            'DELETE FROM inventory_categories WHERE category_id = ?',
            [categoryId]
        );
        
        return result.affectedRows > 0;
    }

    // ============ INVENTORY ITEMS ============
    
    // Get all items
    static async getAllItems() {
        const [rows] = await db.query(
            `SELECT 
                i.item_id,
                i.item_name,
                i.category_id,
                i.unit,
                i.unit_cost,
                i.description,
                i.supplier_name,
                i.supplier_phone,
                i.status,
                i.created_at,
                i.updated_at,
                c.category_name,
                s.current_quantity,
                s.minimum_quantity,
                s.maximum_quantity,
                s.total_value
            FROM inventory_items i
            JOIN inventory_categories c ON i.category_id = c.category_id
            LEFT JOIN inventory_stocks s ON i.item_id = s.item_id
            ORDER BY c.category_name, i.item_name`
        );
        return rows;
    }

    // Get items by category
    static async getItemsByCategory(categoryId) {
        const [rows] = await db.query(
            `SELECT 
                i.item_id,
                i.item_name,
                i.category_id,
                i.unit,
                i.unit_cost,
                i.description,
                i.supplier_name,
                i.supplier_phone,
                i.status,
                c.category_name,
                s.current_quantity,
                s.minimum_quantity,
                s.total_value
            FROM inventory_items i
            JOIN inventory_categories c ON i.category_id = c.category_id
            LEFT JOIN inventory_stocks s ON i.item_id = s.item_id
            WHERE i.category_id = ?
            ORDER BY i.item_name`,
            [categoryId]
        );
        return rows;
    }

    // Get item by ID
    static async getItemById(itemId) {
        const [rows] = await db.query(
            `SELECT 
                i.item_id,
                i.item_name,
                i.category_id,
                i.unit,
                i.unit_cost,
                i.description,
                i.supplier_name,
                i.supplier_phone,
                i.status,
                i.created_at,
                i.updated_at,
                c.category_name,
                s.current_quantity,
                s.minimum_quantity,
                s.maximum_quantity,
                s.reorder_quantity,
                s.total_value,
                s.last_restocked,
                s.last_consumed_date
            FROM inventory_items i
            JOIN inventory_categories c ON i.category_id = c.category_id
            LEFT JOIN inventory_stocks s ON i.item_id = s.item_id
            WHERE i.item_id = ?`,
            [itemId]
        );
        return rows[0];
    }

    // Create new item
    static async createItem(itemData) {
        const {
            item_name,
            category_id,
            unit,
            unit_cost,
            description,
            supplier_name,
            supplier_phone
        } = itemData;

        // Validation
        if (!item_name || item_name.trim().length === 0) {
            throw new Error('Item name is required');
        }
        if (!category_id) {
            throw new Error('Category is required');
        }
        if (!unit) {
            throw new Error('Unit is required');
        }
        if (unit_cost === undefined || unit_cost === null || unit_cost < 0) {
            throw new Error('Unit cost must be a positive number');
        }

        // Verify category exists
        const category = await this.getCategoryById(category_id);
        if (!category) {
            throw new Error('Category not found');
        }

        const [result] = await db.query(
            `INSERT INTO inventory_items 
            (item_name, category_id, unit, unit_cost, description, supplier_name, supplier_phone) 
            VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [item_name, category_id, unit, unit_cost, description || null, supplier_name || null, supplier_phone || null]
        );

        // Initialize stock record
        await db.query(
            'INSERT INTO inventory_stocks (item_id, current_quantity) VALUES (?, ?)',
            [result.insertId, 0]
        );

        return result.insertId;
    }

    // Update item
    static async updateItem(itemId, itemData) {
        const {
            item_name,
            category_id,
            unit,
            unit_cost,
            description,
            supplier_name,
            supplier_phone,
            status
        } = itemData;

        if (!item_name || item_name.trim().length === 0) {
            throw new Error('Item name is required');
        }
        if (!category_id) {
            throw new Error('Category is required');
        }
        if (unit_cost !== undefined && unit_cost !== null && unit_cost < 0) {
            throw new Error('Unit cost must be a positive number');
        }

        const [result] = await db.query(
            `UPDATE inventory_items 
            SET item_name = ?, category_id = ?, unit = ?, unit_cost = ?, 
                description = ?, supplier_name = ?, supplier_phone = ?, status = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE item_id = ?`,
            [item_name, category_id, unit, unit_cost || 0, description || null, 
             supplier_name || null, supplier_phone || null, status || 'Active', itemId]
        );

        return result.affectedRows > 0;
    }

    // Delete item
    static async deleteItem(itemId) {
        const [result] = await db.query(
            'DELETE FROM inventory_items WHERE item_id = ?',
            [itemId]
        );

        return result.affectedRows > 0;
    }

    // ============ INVENTORY SEARCH & FILTERS ============

    // Search items by name
    static async searchItems(searchTerm) {
        const [rows] = await db.query(
            `SELECT 
                i.item_id,
                i.item_name,
                i.category_id,
                i.unit,
                i.unit_cost,
                c.category_name,
                s.current_quantity,
                s.minimum_quantity,
                s.total_value
            FROM inventory_items i
            JOIN inventory_categories c ON i.category_id = c.category_id
            LEFT JOIN inventory_stocks s ON i.item_id = s.item_id
            WHERE i.item_name LIKE ? OR i.description LIKE ?
            ORDER BY i.item_name`,
            [`%${searchTerm}%`, `%${searchTerm}%`]
        );
        return rows;
    }

    // Get low stock items
    static async getLowStockItems() {
        const [rows] = await db.query(
            `SELECT 
                i.item_id,
                i.item_name,
                i.category_id,
                i.unit,
                i.unit_cost,
                c.category_name,
                s.current_quantity,
                s.minimum_quantity,
                s.reorder_quantity,
                s.total_value
            FROM inventory_items i
            JOIN inventory_categories c ON i.category_id = c.category_id
            JOIN inventory_stocks s ON i.item_id = s.item_id
            WHERE s.current_quantity <= s.minimum_quantity AND i.status = 'Active'
            ORDER BY s.current_quantity ASC`
        );
        return rows;
    }

    // Get inventory value by category
    static async getInventoryValueByCategory() {
        const [rows] = await db.query(
            `SELECT 
                c.category_id,
                c.category_name,
                COUNT(i.item_id) AS item_count,
                COALESCE(SUM(s.total_value), 0) AS total_value,
                COALESCE(SUM(s.current_quantity), 0) AS total_quantity
            FROM inventory_categories c
            LEFT JOIN inventory_items i ON c.category_id = i.category_id
            LEFT JOIN inventory_stocks s ON i.item_id = s.item_id
            GROUP BY c.category_id, c.category_name
            ORDER BY total_value DESC`
        );
        return rows;
    }

    // Get inventory statistics
    static async getInventoryStats() {
        const [stats] = await db.query(
            `SELECT 
                COUNT(DISTINCT i.item_id) AS total_items,
                COUNT(DISTINCT i.category_id) AS total_categories,
                COALESCE(SUM(s.total_value), 0) AS total_inventory_value,
                COUNT(CASE WHEN s.current_quantity <= s.minimum_quantity THEN 1 END) AS low_stock_count,
                COALESCE(AVG(s.current_quantity), 0) AS avg_stock_level
            FROM inventory_items i
            LEFT JOIN inventory_stocks s ON i.item_id = s.item_id
            WHERE i.status = 'Active'`
        );
        return stats[0];
    }
}

module.exports = Inventory;
