const db = require('../config/database');

class Payment {
    // Create new payment record
    static async create(paymentData) {
        const { invoice_id, booking_id, guest_id, amount, payment_method, reference_number, transaction_id, received_by, notes } = paymentData;

        try {
            // Get billing settings for payment prefix
            const [settingsRows] = await db.query(
                "SELECT setting_value FROM billing_settings WHERE setting_key = 'payment_prefix'"
            );
            const paymentPrefix = settingsRows.length > 0 ? settingsRows[0].setting_value : 'PAY-';

            // Generate unique payment number
            const paymentNumber = await this.generatePaymentNumber(paymentPrefix);

            const paymentDate = new Date();

            const [result] = await db.query(`
                INSERT INTO payments (
                    invoice_id, booking_id, guest_id, payment_number,
                    amount, payment_method, reference_number, transaction_id,
                    payment_date, received_by, payment_status, notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `, [
                invoice_id, booking_id, guest_id, paymentNumber,
                amount, payment_method, reference_number || null, transaction_id || null,
                paymentDate, received_by || 'System', 'Processed', notes || null
            ]);

            const paymentId = result.insertId;

            // Update invoice payment amounts
            const Invoice = require('./Invoice');
            await Invoice.updatePaymentAmount(invoice_id);

            // Update booking payment status
            await db.query(`
                UPDATE bookings SET payment_status = 'Paid' WHERE booking_id = ?
            `, [booking_id]);

            return {
                success: true,
                paymentId: paymentId,
                paymentNumber: paymentNumber,
                amount: amount
            };
        } catch (error) {
            throw new Error(`Failed to create payment: ${error.message}`);
        }
    }

    // Get all payments
    static async getAll(limit = 100, offset = 0) {
        const [rows] = await db.query(`
            SELECT * FROM payment_summary
            ORDER BY payment_date DESC
            LIMIT ? OFFSET ?
        `, [limit, offset]);
        return rows;
    }

    // Get payment by ID
    static async getById(paymentId) {
        const [rows] = await db.query(`
            SELECT * FROM payments WHERE payment_id = ?
        `, [paymentId]);
        return rows[0];
    }

    // Get payments for invoice
    static async getByInvoiceId(invoiceId) {
        const [rows] = await db.query(`
            SELECT * FROM payments 
            WHERE invoice_id = ? 
            ORDER BY payment_date DESC
        `, [invoiceId]);
        return rows;
    }

    // Get payments for booking
    static async getByBookingId(bookingId) {
        const [rows] = await db.query(`
            SELECT * FROM payments
            WHERE booking_id = ?
            ORDER BY payment_date DESC
        `, [bookingId]);
        return rows;
    }

    // Get payments for guest
    static async getByGuestId(guestId, limit = 50, offset = 0) {
        const [rows] = await db.query(`
            SELECT * FROM payment_summary
            WHERE guest_id = ?
            ORDER BY payment_date DESC
            LIMIT ? OFFSET ?
        `, [guestId, limit, offset]);
        return rows;
    }

    // Get payments for date range
    static async getByDateRange(startDate, endDate, limit = 100, offset = 0) {
        const [rows] = await db.query(`
            SELECT * FROM payments
            WHERE DATE(payment_date) BETWEEN ? AND ?
            ORDER BY payment_date DESC
            LIMIT ? OFFSET ?
        `, [startDate, endDate, limit, offset]);
        return rows;
    }

    // Get payment methods
    static async getPaymentMethods() {
        const [rows] = await db.query(`
            SELECT * FROM payment_methods 
            WHERE is_active = 1 
            ORDER BY is_default DESC, method_name
        `);
        return rows;
    }

    // Record payment receipt
    static async recordReceipt(paymentId) {
        const payment = await this.getById(paymentId);
        if (!payment) {
            throw new Error('Payment not found');
        }

        // Update payment status to show receipt generated
        const [result] = await db.query(`
            UPDATE payments SET payment_status = 'Processed' WHERE payment_id = ?
        `, [paymentId]);

        return result.affectedRows;
    }

    // get payment details with invoice
    static async getDetails(paymentId) {
        const payment = await this.getById(paymentId);
        if (!payment) return null;

        const Invoice = require('./Invoice');
        const invoice = await Invoice.getById(payment.invoice_id);

        return {
            ...payment,
            invoice: invoice
        };
    }

    // Generate unique payment number
    static async generatePaymentNumber(prefix = 'PAY-') {
        const [result] = await db.query(`
            SELECT COUNT(*) as count FROM payments WHERE payment_number LIKE ?
        `, [`${prefix}%`]);

        const count = result[0].count || 0;
        const paymentNumber = `${prefix}${String(count + 1).padStart(6, '0')}`;

        // Check uniqueness
        const [existing] = await db.query('SELECT * FROM payments WHERE payment_number = ?', [paymentNumber]);
        if (existing.length > 0) {
            return this.generatePaymentNumber(prefix);
        }

        return paymentNumber;
    }

    // Get payment statistics
    static async getStatistics(startDate, endDate) {
        const [stats] = await db.query(`
            SELECT 
                COUNT(*) as total_payments,
                SUM(amount) as total_amount,
                COUNT(DISTINCT guest_id) as unique_guests,
                COUNT(DISTINCT booking_id) as bookings_settled,
                payment_method,
                COUNT(*) as count,
                SUM(amount) as method_total
            FROM payments
            WHERE DATE(payment_date) BETWEEN ? AND ? AND payment_status = 'Processed'
            GROUP BY payment_method
        `, [startDate, endDate]);

        const summary = {
            total_payments: 0,
            total_amount: 0,
            unique_guests: 0,
            bookings_settled: 0,
            by_method: {}
        };

        if (stats && stats.length > 0) {
            const firstRow = stats[0];
            summary.total_payments = firstRow.total_payments || 0;
            summary.total_amount = firstRow.total_amount || 0;
            summary.unique_guests = firstRow.unique_guests || 0;
            summary.bookings_settled = firstRow.bookings_settled || 0;

            stats.forEach(row => {
                summary.by_method[row.payment_method] = {
                    count: row.count,
                    total: row.method_total
                };
            });
        }

        return summary;
    }

    // Process refund
    static async processRefund(paymentId, refundAmount, reason) {
        try {
            const payment = await this.getById(paymentId);
            if (!payment) {
                throw new Error('Payment not found');
            }

            if (refundAmount > payment.amount) {
                throw new Error('Refund amount cannot exceed payment amount');
            }

            // Create refund record
            const Refund = require('./Refund');
            const refundResult = await Refund.create({
                payment_id: paymentId,
                invoice_id: payment.invoice_id,
                booking_id: payment.booking_id,
                guest_id: payment.guest_id,
                refund_amount: refundAmount,
                refund_reason: reason,
                refund_method: payment.payment_method
            });

            // Update payment amounts
            const Invoice = require('./Invoice');
            await Invoice.updatePaymentAmount(payment.invoice_id);

            return refundResult;
        } catch (error) {
            throw new Error(`Failed to process refund: ${error.message}`);
        }
    }

    // Get payment receipt data
    static async getReceiptData(paymentId) {
        const [paymentData] = await db.query(`
            SELECT 
                p.*,
                g.name as guest_name,
                g.email as guest_email,
                g.phone as guest_phone,
                i.invoice_number,
                i.grand_total as invoice_total,
                b.room_id,
                r.room_number
            FROM payments p
            LEFT JOIN guests g ON p.guest_id = g.guest_id
            LEFT JOIN invoices i ON p.invoice_id = i.invoice_id
            LEFT JOIN bookings b ON p.booking_id = b.booking_id
            LEFT JOIN rooms r ON b.room_id = r.room_id
            WHERE p.payment_id = ?
        `, [paymentId]);

        return paymentData[0] || null;
    }

    // Update payment method
    static async updatePaymentMethod(paymentId, paymentMethod) {
        const [result] = await db.query(`
            UPDATE payments SET payment_method = ? WHERE payment_id = ?
        `, [paymentMethod, paymentId]);
        return result.affectedRows;
    }

    // Verify payment status
    static async verifyPaymentStatus(paymentId) {
        const payment = await this.getById(paymentId);
        if (!payment) {
            throw new Error('Payment not found');
        }

        return {
            paymentId: paymentId,
            status: payment.payment_status,
            amount: payment.amount,
            method: payment.payment_method,
            date: payment.payment_date
        };
    }
}

module.exports = Payment;
