const express = require('express');
const router = express.Router();
const Service = require('../models/Service');

// Get all services
router.get('/', async (req, res) => {
    try {
        const services = await Service.getAll();
        res.json({
            success: true,
            data: services
        });
    } catch (error) {
        console.error('Error fetching services:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching services',
            error: error.message
        });
    }
});

// Get available services
router.get('/available', async (req, res) => {
    try {
        const services = await Service.getAvailable();
        res.json({
            success: true,
            data: services
        });
    } catch (error) {
        console.error('Error fetching available services:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching available services',
            error: error.message
        });
    }
});

// Get service categories
router.get('/categories', async (req, res) => {
    try {
        const categories = await Service.getCategories();
        res.json({
            success: true,
            data: categories
        });
    } catch (error) {
        console.error('Error fetching categories:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching categories',
            error: error.message
        });
    }
});

// Get services by category
router.get('/category/:category', async (req, res) => {
    try {
        const services = await Service.getByCategory(req.params.category);
        res.json({
            success: true,
            data: services
        });
    } catch (error) {
        console.error('Error fetching services by category:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching services by category',
            error: error.message
        });
    }
});

// Get service by ID
router.get('/:id', async (req, res) => {
    try {
        const service = await Service.getById(req.params.id);
        if (!service) {
            return res.status(404).json({
                success: false,
                message: 'Service not found'
            });
        }
        res.json({
            success: true,
            data: service
        });
    } catch (error) {
        console.error('Error fetching service:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching service',
            error: error.message
        });
    }
});

// Create new service
router.post('/', async (req, res) => {
    try {
        const serviceId = await Service.create(req.body);
        const service = await Service.getById(serviceId);
        res.status(201).json({
            success: true,
            message: 'Service created successfully',
            data: service
        });
    } catch (error) {
        console.error('Error creating service:', error);
        res.status(500).json({
            success: false,
            message: 'Error creating service',
            error: error.message
        });
    }
});

// Update service
router.put('/:id', async (req, res) => {
    try {
        const updated = await Service.update(req.params.id, req.body);
        if (!updated) {
            return res.status(404).json({
                success: false,
                message: 'Service not found'
            });
        }
        const service = await Service.getById(req.params.id);
        res.json({
            success: true,
            message: 'Service updated successfully',
            data: service
        });
    } catch (error) {
        console.error('Error updating service:', error);
        res.status(500).json({
            success: false,
            message: 'Error updating service',
            error: error.message
        });
    }
});

// Delete service
router.delete('/:id', async (req, res) => {
    try {
        const deleted = await Service.delete(req.params.id);
        if (!deleted) {
            return res.status(404).json({
                success: false,
                message: 'Service not found'
            });
        }
        res.json({
            success: true,
            message: 'Service deleted successfully'
        });
    } catch (error) {
        console.error('Error deleting service:', error);
        res.status(500).json({
            success: false,
            message: 'Error deleting service',
            error: error.message
        });
    }
});

module.exports = router;
