const express = require('express');
const router = express.Router();
const Inventory = require('../models/Inventory');
const InventoryStock = require('../models/InventoryStock');

// ============ INVENTORY CATEGORIES ============

// Get all categories
router.get('/categories', async (req, res) => {
    try {
        const categories = await Inventory.getAllCategories();
        res.json({
            success: true,
            data: categories
        });
    } catch (error) {
        console.error('Error fetching categories:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching categories'
        });
    }
});

// Get category by ID
router.get('/categories/:id', async (req, res) => {
    try {
        const category = await Inventory.getCategoryById(req.params.id);
        if (!category) {
            return res.status(404).json({
                success: false,
                message: 'Category not found'
            });
        }
        res.json({
            success: true,
            data: category
        });
    } catch (error) {
        console.error('Error fetching category:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching category'
        });
    }
});

// Create category
router.post('/categories', async (req, res) => {
    try {
        const categoryId = await Inventory.createCategory(req.body);
        res.status(201).json({
            success: true,
            message: 'Category created successfully',
            categoryId
        });
    } catch (error) {
        console.error('Error creating category:', error);
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
});

// Update category
router.put('/categories/:id', async (req, res) => {
    try {
        const updated = await Inventory.updateCategory(req.params.id, req.body);
        if (!updated) {
            return res.status(404).json({
                success: false,
                message: 'Category not found'
            });
        }
        res.json({
            success: true,
            message: 'Category updated successfully'
        });
    } catch (error) {
        console.error('Error updating category:', error);
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
});

// Delete category
router.delete('/categories/:id', async (req, res) => {
    try {
        const deleted = await Inventory.deleteCategory(req.params.id);
        if (!deleted) {
            return res.status(404).json({
                success: false,
                message: 'Category not found'
            });
        }
        res.json({
            success: true,
            message: 'Category deleted successfully'
        });
    } catch (error) {
        console.error('Error deleting category:', error);
        res.status(500).json({
            success: false,
            message: 'Error deleting category'
        });
    }
});

// ============ INVENTORY ITEMS ============

// Get all items
router.get('/', async (req, res) => {
    try {
        const items = await Inventory.getAllItems();
        res.json({
            success: true,
            data: items
        });
    } catch (error) {
        console.error('Error fetching items:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching inventory items'
        });
    }
});

// Get items by category
router.get('/category/:categoryId', async (req, res) => {
    try {
        const items = await Inventory.getItemsByCategory(req.params.categoryId);
        res.json({
            success: true,
            data: items
        });
    } catch (error) {
        console.error('Error fetching items by category:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching items'
        });
    }
});

// Get item by ID
router.get('/:id', async (req, res) => {
    try {
        const item = await Inventory.getItemById(req.params.id);
        if (!item) {
            return res.status(404).json({
                success: false,
                message: 'Item not found'
            });
        }
        res.json({
            success: true,
            data: item
        });
    } catch (error) {
        console.error('Error fetching item:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching item'
        });
    }
});

// Create item
router.post('/', async (req, res) => {
    try {
        const itemId = await Inventory.createItem(req.body);
        res.status(201).json({
            success: true,
            message: 'Item created successfully',
            itemId
        });
    } catch (error) {
        console.error('Error creating item:', error);
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
});

// Update item
router.put('/:id', async (req, res) => {
    try {
        const updated = await Inventory.updateItem(req.params.id, req.body);
        if (!updated) {
            return res.status(404).json({
                success: false,
                message: 'Item not found'
            });
        }
        res.json({
            success: true,
            message: 'Item updated successfully'
        });
    } catch (error) {
        console.error('Error updating item:', error);
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
});

// Delete item
router.delete('/:id', async (req, res) => {
    try {
        const deleted = await Inventory.deleteItem(req.params.id);
        if (!deleted) {
            return res.status(404).json({
                success: false,
                message: 'Item not found'
            });
        }
        res.json({
            success: true,
            message: 'Item deleted successfully'
        });
    } catch (error) {
        console.error('Error deleting item:', error);
        res.status(500).json({
            success: false,
            message: 'Error deleting item'
        });
    }
});

// Search items
router.get('/search/:term', async (req, res) => {
    try {
        const items = await Inventory.searchItems(req.params.term);
        res.json({
            success: true,
            data: items
        });
    } catch (error) {
        console.error('Error searching items:', error);
        res.status(500).json({
            success: false,
            message: 'Error searching items'
        });
    }
});

// ============ STOCK MANAGEMENT ============

// Get low stock items
router.get('/status/low-stock', async (req, res) => {
    try {
        const items = await Inventory.getLowStockItems();
        res.json({
            success: true,
            data: items
        });
    } catch (error) {
        console.error('Error fetching low stock items:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching low stock items'
        });
    }
});

// Restock item
router.post('/:itemId/restock', async (req, res) => {
    try {
        const { quantity, notes, createdBy } = req.body;
        
        if (!quantity || quantity <= 0) {
            return res.status(400).json({
                success: false,
                message: 'Quantity must be positive'
            });
        }

        const result = await InventoryStock.restock(
            req.params.itemId,
            quantity,
            notes,
            createdBy || 'System'
        );

        res.json({
            success: true,
            message: 'Item restocked successfully',
            data: result
        });
    } catch (error) {
        console.error('Error restocking item:', error);
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
});

// Consume item
router.post('/:itemId/consume', async (req, res) => {
    try {
        const { quantity, notes, createdBy, bookingId } = req.body;
        
        if (!quantity || quantity <= 0) {
            return res.status(400).json({
                success: false,
                message: 'Quantity must be positive'
            });
        }

        const result = await InventoryStock.consume(
            req.params.itemId,
            quantity,
            notes,
            createdBy || 'System',
            bookingId || null
        );

        res.json({
            success: true,
            message: 'Item consumed successfully',
            data: result
        });
    } catch (error) {
        console.error('Error consuming item:', error);
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
});

// Adjust stock
router.post('/:itemId/adjust', async (req, res) => {
    try {
        const { quantityChange, adjustmentType, notes, createdBy } = req.body;
        
        if (quantityChange === undefined || quantityChange === null) {
            return res.status(400).json({
                success: false,
                message: 'Quantity change is required'
            });
        }

        const result = await InventoryStock.adjust(
            req.params.itemId,
            quantityChange,
            adjustmentType || 'Adjustment',
            notes,
            createdBy || 'System'
        );

        res.json({
            success: true,
            message: 'Stock adjusted successfully',
            data: result
        });
    } catch (error) {
        console.error('Error adjusting stock:', error);
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
});

// Update stock thresholds
router.put('/:itemId/thresholds', async (req, res) => {
    try {
        const { minimumQuantity, maximumQuantity, reorderQuantity } = req.body;
        
        const updated = await InventoryStock.updateThresholds(
            req.params.itemId,
            minimumQuantity,
            maximumQuantity,
            reorderQuantity
        );

        if (!updated) {
            return res.status(404).json({
                success: false,
                message: 'Item not found'
            });
        }

        res.json({
            success: true,
            message: 'Thresholds updated successfully'
        });
    } catch (error) {
        console.error('Error updating thresholds:', error);
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
});

// ============ TRANSACTIONS ============

// Get transactions for an item
router.get('/:itemId/transactions', async (req, res) => {
    try {
        const limit = Math.min(parseInt(req.query.limit) || 50, 500);
        const offset = parseInt(req.query.offset) || 0;
        
        const transactions = await InventoryStock.getTransactions(req.params.itemId, limit, offset);
        const count = await InventoryStock.getTransactionCount(req.params.itemId);

        res.json({
            success: true,
            data: transactions,
            pagination: {
                limit,
                offset,
                total: count
            }
        });
    } catch (error) {
        console.error('Error fetching transactions:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching transactions'
        });
    }
});

// Get all transactions
router.get('/history/all', async (req, res) => {
    try {
        const limit = Math.min(parseInt(req.query.limit) || 100, 500);
        const offset = parseInt(req.query.offset) || 0;
        
        const transactions = await InventoryStock.getAllTransactions(limit, offset);
        const count = await InventoryStock.getTransactionCount();

        res.json({
            success: true,
            data: transactions,
            pagination: {
                limit,
                offset,
                total: count
            }
        });
    } catch (error) {
        console.error('Error fetching all transactions:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching transactions'
        });
    }
});

// ============ STATISTICS & REPORTS ============

// Get inventory value by category
router.get('/reports/value-by-category', async (req, res) => {
    try {
        const data = await Inventory.getInventoryValueByCategory();
        res.json({
            success: true,
            data
        });
    } catch (error) {
        console.error('Error fetching inventory value:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching inventory data'
        });
    }
});

// Get inventory statistics
router.get('/reports/statistics', async (req, res) => {
    try {
        const stats = await Inventory.getInventoryStats();
        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        console.error('Error fetching statistics:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching statistics'
        });
    }
});

// Get low stock with supplier info
router.get('/reports/low-stock-suppliers', async (req, res) => {
    try {
        const data = await InventoryStock.getLowStockWithSuppliers();
        res.json({
            success: true,
            data
        });
    } catch (error) {
        console.error('Error fetching supplier data:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching supplier data'
        });
    }
});

module.exports = router;
