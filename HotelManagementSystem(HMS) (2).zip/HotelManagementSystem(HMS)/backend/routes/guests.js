const express = require('express');
const router = express.Router();
const Guest = require('../models/Guest');

// GET all guests
router.get('/', async (req, res) => {
    try {
        const guests = await Guest.getAll();
        res.json({ success: true, data: guests });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// GET guest by ID
router.get('/:id', async (req, res) => {
    try {
        const guest = await Guest.getById(req.params.id);
        if (!guest) {
            return res.status(404).json({ success: false, message: 'Guest not found' });
        }
        res.json({ success: true, data: guest });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// GET search guests
router.get('/search/contact', async (req, res) => {
    try {
        const { q } = req.query;
        if (!q) {
            return res.status(400).json({ success: false, message: 'Search term required' });
        }
        const guests = await Guest.searchByContact(q);
        res.json({ success: true, data: guests });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// GET guest booking history
router.get('/:id/history', async (req, res) => {
    try {
        const history = await Guest.getBookingHistory(req.params.id);
        res.json({ success: true, data: history });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// POST create new guest
router.post('/', async (req, res) => {
    try {
        const guestId = await Guest.create(req.body);
        res.status(201).json({ success: true, message: 'Guest created successfully', guestId });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// PUT update guest
router.put('/:id', async (req, res) => {
    try {
        const affected = await Guest.update(req.params.id, req.body);
        if (affected === 0) {
            return res.status(404).json({ success: false, message: 'Guest not found' });
        }
        res.json({ success: true, message: 'Guest updated successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// DELETE guest
router.delete('/:id', async (req, res) => {
    try {
        const affected = await Guest.delete(req.params.id);
        if (affected === 0) {
            return res.status(404).json({ success: false, message: 'Guest not found' });
        }
        res.json({ success: true, message: 'Guest deleted successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

module.exports = router;
