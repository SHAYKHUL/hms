const express = require('express');
const router = express.Router();
const ServiceOrder = require('../models/ServiceOrder');

// Get all service orders
router.get('/', async (req, res) => {
    try {
        const orders = await ServiceOrder.getAll();
        res.json({
            success: true,
            data: orders
        });
    } catch (error) {
        console.error('Error fetching service orders:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching service orders',
            error: error.message
        });
    }
});

// Get pending orders
router.get('/pending', async (req, res) => {
    try {
        const orders = await ServiceOrder.getPending();
        res.json({
            success: true,
            data: orders
        });
    } catch (error) {
        console.error('Error fetching pending orders:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching pending orders',
            error: error.message
        });
    }
});

// Get order statistics
router.get('/statistics', async (req, res) => {
    try {
        const stats = await ServiceOrder.getStatistics();
        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        console.error('Error fetching statistics:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching statistics',
            error: error.message
        });
    }
});

// Get popular services
router.get('/popular/:limit?', async (req, res) => {
    try {
        const limit = parseInt(req.params.limit) || 5;
        const services = await ServiceOrder.getPopularServices(limit);
        res.json({
            success: true,
            data: services
        });
    } catch (error) {
        console.error('Error fetching popular services:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching popular services',
            error: error.message
        });
    }
});

// Get orders by status
router.get('/status/:status', async (req, res) => {
    try {
        const orders = await ServiceOrder.getByStatus(req.params.status);
        res.json({
            success: true,
            data: orders
        });
    } catch (error) {
        console.error('Error fetching orders by status:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching orders by status',
            error: error.message
        });
    }
});

// Get orders by booking ID
router.get('/booking/:bookingId', async (req, res) => {
    try {
        const orders = await ServiceOrder.getByBookingId(req.params.bookingId);
        res.json({
            success: true,
            data: orders
        });
    } catch (error) {
        console.error('Error fetching orders by booking:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching orders by booking',
            error: error.message
        });
    }
});

// Get orders by room number
router.get('/room/:roomNumber', async (req, res) => {
    try {
        const orders = await ServiceOrder.getByRoomNumber(req.params.roomNumber);
        res.json({
            success: true,
            data: orders
        });
    } catch (error) {
        console.error('Error fetching orders by room:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching orders by room',
            error: error.message
        });
    }
});

// Get order by ID
router.get('/:id', async (req, res) => {
    try {
        const order = await ServiceOrder.getById(req.params.id);
        if (!order) {
            return res.status(404).json({
                success: false,
                message: 'Order not found'
            });
        }
        res.json({
            success: true,
            data: order
        });
    } catch (error) {
        console.error('Error fetching order:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching order',
            error: error.message
        });
    }
});

// Create new service order
router.post('/', async (req, res) => {
    try {
        const orderId = await ServiceOrder.create(req.body);
        const order = await ServiceOrder.getById(orderId);
        res.status(201).json({
            success: true,
            message: 'Service order created successfully',
            data: order
        });
    } catch (error) {
        console.error('Error creating service order:', error);
        res.status(500).json({
            success: false,
            message: 'Error creating service order',
            error: error.message
        });
    }
});

// Update order status
router.patch('/:id/status', async (req, res) => {
    try {
        const { status } = req.body;
        const updated = await ServiceOrder.updateStatus(req.params.id, status);
        if (!updated) {
            return res.status(404).json({
                success: false,
                message: 'Order not found'
            });
        }
        const order = await ServiceOrder.getById(req.params.id);
        res.json({
            success: true,
            message: 'Order status updated successfully',
            data: order
        });
    } catch (error) {
        console.error('Error updating order status:', error);
        res.status(500).json({
            success: false,
            message: 'Error updating order status',
            error: error.message
        });
    }
});

// Update order
router.put('/:id', async (req, res) => {
    try {
        const updated = await ServiceOrder.update(req.params.id, req.body);
        if (!updated) {
            return res.status(404).json({
                success: false,
                message: 'Order not found'
            });
        }
        const order = await ServiceOrder.getById(req.params.id);
        res.json({
            success: true,
            message: 'Order updated successfully',
            data: order
        });
    } catch (error) {
        console.error('Error updating order:', error);
        res.status(500).json({
            success: false,
            message: 'Error updating order',
            error: error.message
        });
    }
});

// Delete order
router.delete('/:id', async (req, res) => {
    try {
        const deleted = await ServiceOrder.delete(req.params.id);
        if (!deleted) {
            return res.status(404).json({
                success: false,
                message: 'Order not found'
            });
        }
        res.json({
            success: true,
            message: 'Order deleted successfully'
        });
    } catch (error) {
        console.error('Error deleting order:', error);
        res.status(500).json({
            success: false,
            message: 'Error deleting order',
            error: error.message
        });
    }
});

module.exports = router;
