const express = require('express');
const router = express.Router();
const Booking = require('../models/Booking');
const Room = require('../models/Room');
const Guest = require('../models/Guest');
const mysql = require('mysql2/promise');
const dbConfig = require('../config/database');

// Helper: Generate invoice HTML
function generateInvoiceHTML(booking, guest, room, services = []) {
    const invoiceDate = new Date().toLocaleDateString();
    const checkInDate = new Date(booking.check_in).toLocaleDateString();
    const checkOutDate = new Date(booking.check_out).toLocaleDateString();
    
    const nights = Math.ceil((new Date(booking.check_out) - new Date(booking.check_in)) / (1000 * 60 * 60 * 24));
    const subtotal = booking.room_price * nights;
    const discount = booking.discount_value || 0;
    const total = booking.total_amount;

    let servicesHTML = '';
    let servicesTotal = 0;
    if (services && services.length > 0) {
        services.forEach(service => {
            servicesHTML += `
                <tr>
                    <td>${service.service_name}</td>
                    <td>₹${service.unit_price.toFixed(2)}</td>
                    <td>${service.quantity}</td>
                    <td>₹${service.total_price.toFixed(2)}</td>
                </tr>
            `;
            servicesTotal += service.total_price;
        });
    }

    return `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; color: #333; }
                .invoice-container { max-width: 900px; margin: 0 auto; border: 1px solid #ddd; padding: 30px; }
                .header { border-bottom: 3px solid #2c3e50; padding-bottom: 20px; margin-bottom: 30px; }
                .hotel-name { font-size: 28px; font-weight: bold; color: #2c3e50; }
                .hotel-info { font-size: 12px; color: #666; margin-top: 5px; }
                .flex-row { display: flex; justify-content: space-between; margin-bottom: 20px; }
                .section { margin-bottom: 30px; }
                .section-title { font-size: 14px; font-weight: bold; background: #ecf0f1; padding: 10px; margin-bottom: 15px; }
                .info-row { display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 13px; }
                .label { font-weight: bold; min-width: 150px; }
                table { width: 100%; border-collapse: collapse; margin: 15px 0; }
                th { background: #34495e; color: white; padding: 10px; text-align: left; font-size: 12px; }
                td { padding: 10px; border-bottom: 1px solid #ddd; font-size: 12px; }
                .summary { background: #ecf0f1; padding: 15px; }
                .summary-row { display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 13px; }
                .summary-row.total { font-size: 16px; font-weight: bold; color: #2c3e50; border-top: 2px solid #34495e; padding-top: 10px; }
                .footer { margin-top: 30px; text-align: center; font-size: 11px; color: #999; }
                .amount-right { text-align: right; }
                .highlight { color: #27ae60; font-weight: bold; }
                @media print { 
                    body { margin: 0; }
                    .invoice-container { border: none; box-shadow: none; }
                }
            </style>
        </head>
        <body>
            <div class="invoice-container">
                <div class="header">
                    <div class="hotel-name">🏨 Hotel Management System</div>
                    <div class="hotel-info">
                        Invoice Date: ${invoiceDate} | Booking ID: ${booking.booking_id}
                    </div>
                </div>

                <div class="flex-row">
                    <div class="section" style="flex: 1;">
                        <div class="section-title">GUEST INFORMATION</div>
                        <div class="info-row">
                            <span class="label">Name:</span>
                            <strong>${guest.name}</strong>
                        </div>
                        <div class="info-row">
                            <span class="label">Phone:</span>
                            <span>${guest.phone}</span>
                        </div>
                        <div class="info-row">
                            <span class="label">Email:</span>
                            <span>${guest.email || 'N/A'}</span>
                        </div>
                        <div class="info-row">
                            <span class="label">ID Proof:</span>
                            <span>${guest.id_proof}</span>
                        </div>
                    </div>

                    <div class="section" style="flex: 1; margin-left: 30px;">
                        <div class="section-title">BOOKING DETAILS</div>
                        <div class="info-row">
                            <span class="label">Room Number:</span>
                            <strong>${room.room_number}</strong>
                        </div>
                        <div class="info-row">
                            <span class="label">Room Type:</span>
                            <span>${room.room_type}</span>
                        </div>
                        <div class="info-row">
                            <span class="label">Check-in:</span>
                            <span>${checkInDate}</span>
                        </div>
                        <div class="info-row">
                            <span class="label">Check-out:</span>
                            <span>${checkOutDate}</span>
                        </div>
                        <div class="info-row">
                            <span class="label">Nights:</span>
                            <span class="highlight">${nights}</span>
                        </div>
                    </div>
                </div>

                <div class="section">
                    <div class="section-title">ROOM AMENITIES</div>
                    <div class="info-row">
                        <span>${room.amenities || 'Standard amenities'}</span>
                    </div>
                </div>

                <div class="section">
                    <table>
                        <thead>
                            <tr>
                                <th>Description</th>
                                <th style="text-align: right;">Unit Price</th>
                                <th style="text-align: right;">Qty</th>
                                <th style="text-align: right;">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><strong>Room Accommodation</strong></td>
                                <td class="amount-right">₹${booking.room_price.toFixed(2)}</td>
                                <td style="text-align: right;">${nights}</td>
                                <td class="amount-right"><strong>₹${subtotal.toFixed(2)}</strong></td>
                            </tr>
                            ${servicesHTML}
                        </tbody>
                    </table>
                </div>

                <div class="section summary">
                    ${discount > 0 ? `
                        <div class="summary-row">
                            <span>Subtotal:</span>
                            <span class="amount-right">₹${subtotal.toFixed(2)}</span>
                        </div>
                        <div class="summary-row">
                            <span>Discount (${booking.discount_reason || booking.discount_type}):</span>
                            <span class="amount-right" style="color: #27ae60;">-₹${discount.toFixed(2)}</span>
                        </div>
                    ` : ''}
                    ${servicesTotal > 0 ? `
                        <div class="summary-row">
                            <span>Services Total:</span>
                            <span class="amount-right">₹${servicesTotal.toFixed(2)}</span>
                        </div>
                    ` : ''}
                    <div class="summary-row total">
                        <span>TOTAL AMOUNT DUE:</span>
                        <span class="amount-right">₹${total.toFixed(2)}</span>
                    </div>
                    <div class="summary-row" style="margin-top: 10px;">
                        <span>Advance Payment:</span>
                        <span class="amount-right">₹${(booking.advance_payment || 0).toFixed(2)}</span>
                    </div>
                    <div class="summary-row" style="color: #27ae60; font-weight: bold;">
                        <span>Balance Due:</span>
                        <span class="amount-right">₹${(total - (booking.advance_payment || 0)).toFixed(2)}</span>
                    </div>
                </div>

                <div class="section">
                    <div class="section-title">PAYMENT INFORMATION</div>
                    <div class="info-row">
                        <span class="label">Payment Method:</span>
                        <span>${booking.payment_method}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Payment Status:</span>
                        <span class="highlight">${booking.payment_status}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Booking Status:</span>
                        <span>${booking.booking_status}</span>
                    </div>
                </div>

                ${booking.special_requests ? `
                    <div class="section">
                        <div class="section-title">SPECIAL REQUESTS</div>
                        <p>${booking.special_requests}</p>
                    </div>
                ` : ''}

                <div class="footer">
                    <p>Thank you for choosing Hotel Management System. Have a pleasant stay!</p>
                    <p>This is a computer-generated invoice. No signature required.</p>
                </div>
            </div>
        </body>
        </html>
    `;
}

// GET: Smart room search with filters
router.post('/smart-search', async (req, res) => {
    try {
        const {
            checkIn,
            checkOut,
            numberOfGuests,
            roomType,
            maxPrice,
            hasAC,
            amenities
        } = req.body;

        if (!checkIn || !checkOut) {
            return res.status(400).json({ 
                success: false, 
                message: 'Check-in and check-out dates are required' 
            });
        }

        const connection = await mysql.createConnection(dbConfig);
        
        let query = `
            SELECT DISTINCT r.* 
            FROM rooms r
            WHERE r.status = 'Available'
            AND r.room_id NOT IN (
                SELECT DISTINCT room_id FROM bookings 
                WHERE booking_status IN ('Confirmed', 'CheckedIn')
                AND (
                    (check_in <= ? AND check_out > ?)
                    OR (check_in < ? AND check_out >= ?)
                    OR (check_in >= ? AND check_out <= ?)
                )
            )
        `;
        
        const params = [checkOut, checkIn, checkOut, checkIn, checkIn, checkOut];

        // Apply filters
        if (numberOfGuests) {
            query += ` AND r.max_guests >= ?`;
            params.push(numberOfGuests);
        }

        if (roomType) {
            query += ` AND r.room_type = ?`;
            params.push(roomType);
        }

        if (maxPrice) {
            query += ` AND r.price <= ?`;
            params.push(maxPrice);
        }

        if (hasAC === true) {
            query += ` AND r.amenities LIKE '%AC%'`;
        }

        query += ` ORDER BY r.price ASC`;

        const [rooms] = await connection.execute(query, params);
        await connection.end();

        res.json({
            success: true,
            data: rooms,
            count: rooms.length,
            filters: {
                checkIn,
                checkOut,
                numberOfGuests,
                roomType,
                maxPrice,
                hasAC
            }
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: 'Room search failed',
            error: error.message 
        });
    }
});

// POST: Create booking with invoice
router.post('/create-with-invoice', async (req, res) => {
    try {
        const {
            guest_id,
            room_id,
            check_in,
            check_out,
            number_of_guests,
            payment_method,
            advance_payment,
            discount_type,
            discount_value,
            discount_reason,
            special_requests,
            selected_services
        } = req.body;

        // Validate required fields
        if (!guest_id || !room_id || !check_in || !check_out || !number_of_guests) {
            return res.status(400).json({
                success: false,
                message: 'Missing required booking information'
            });
        }

        const connection = await mysql.createConnection(dbConfig);

        try {
            await connection.beginTransaction();

            // Get room details
            const [roomData] = await connection.execute(
                'SELECT * FROM rooms WHERE room_id = ?',
                [room_id]
            );
            if (roomData.length === 0) {
                await connection.rollback();
                return res.status(404).json({ success: false, message: 'Room not found' });
            }
            const room = roomData[0];

            // Get guest details
            const [guestData] = await connection.execute(
                'SELECT * FROM guests WHERE guest_id = ?',
                [guest_id]
            );
            if (guestData.length === 0) {
                await connection.rollback();
                return res.status(404).json({ success: false, message: 'Guest not found' });
            }
            const guest = guestData[0];

            // Calculate nights and amount
            const nights = Math.ceil((new Date(check_out) - new Date(check_in)) / (1000 * 60 * 60 * 24));
            const room_price = parseFloat(room.price);
            let total_amount = room_price * nights;
            let discount_amt = 0;

            if (discount_type && discount_value > 0) {
                if (discount_type === 'Percentage') {
                    discount_amt = (total_amount * discount_value) / 100;
                } else {
                    discount_amt = discount_value;
                }
                total_amount -= discount_amt;
            }

            // Create booking
            const bookingData = {
                guest_id,
                room_id,
                check_in,
                check_out,
                number_of_guests,
                room_price,
                total_amount,
                discount_type: discount_type || 'None',
                discount_value: discount_amt,
                discount_reason,
                advance_payment: advance_payment || 0,
                payment_status: advance_payment > 0 ? 'Partial' : 'Pending',
                payment_method: payment_method || 'Cash',
                booking_status: 'Confirmed',
                special_requests
            };

            const [insertResult] = await connection.execute(
                `INSERT INTO bookings (
                    guest_id, room_id, check_in, check_out, number_of_guests,
                    room_price, total_amount, discount_type, discount_value,
                    discount_reason, advance_payment, payment_status,
                    payment_method, booking_status, special_requests
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [
                    guest_id, room_id, check_in, check_out, number_of_guests,
                    room_price, total_amount, bookingData.discount_type,
                    discount_amt, discount_reason, advance_payment || 0,
                    bookingData.payment_status, payment_method || 'Cash',
                    'Confirmed', special_requests
                ]
            );

            const booking_id = insertResult.insertId;

            // Add selected services if any
            let services = [];
            if (selected_services && selected_services.length > 0) {
                for (const service of selected_services) {
                    const unit_price = parseFloat(service.price);
                    const quantity = parseInt(service.quantity) || 1;
                    const total_price = unit_price * quantity;

                    await connection.execute(
                        `INSERT INTO service_orders (
                            booking_id, service_id, quantity, unit_price, total_price, order_status
                        ) VALUES (?, ?, ?, ?, ?, 'Pending')`,
                        [booking_id, service.service_id, quantity, unit_price, total_price]
                    );

                    services.push({
                        service_name: service.service_name,
                        unit_price,
                        quantity,
                        total_price
                    });

                    // Update total amount
                    total_amount += total_price;
                }

                // Update booking total
                await connection.execute(
                    'UPDATE bookings SET total_amount = ? WHERE booking_id = ?',
                    [total_amount, booking_id]
                );
            }

            await connection.commit();

            // Get updated booking for invoice
            const [finalBooking] = await connection.execute(
                'SELECT * FROM bookings WHERE booking_id = ?',
                [booking_id]
            );

            const invoiceHTML = generateInvoiceHTML(
                finalBooking[0],
                guest,
                room,
                services
            );

            res.json({
                success: true,
                message: 'Booking created successfully',
                booking_id,
                booking: finalBooking[0],
                invoice: invoiceHTML
            });

        } finally {
            await connection.end();
        }

    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Booking creation failed',
            error: error.message
        });
    }
});

// GET: Generate invoice for existing booking
router.get('/:booking_id/invoice', async (req, res) => {
    try {
        const { booking_id } = req.params;

        const connection = await mysql.createConnection(dbConfig);

        const [bookingData] = await connection.execute(
            'SELECT * FROM bookings WHERE booking_id = ?',
            [booking_id]
        );

        if (bookingData.length === 0) {
            await connection.end();
            return res.status(404).json({ success: false, message: 'Booking not found' });
        }

        const booking = bookingData[0];

        const [guestData] = await connection.execute(
            'SELECT * FROM guests WHERE guest_id = ?',
            [booking.guest_id]
        );
        const guest = guestData[0];

        const [roomData] = await connection.execute(
            'SELECT * FROM rooms WHERE room_id = ?',
            [booking.room_id]
        );
        const room = roomData[0];

        const [servicesData] = await connection.execute(
            `SELECT so.*, s.service_name FROM service_orders so
             JOIN services s ON so.service_id = s.service_id
             WHERE so.booking_id = ?`,
            [booking_id]
        );

        await connection.end();

        const invoiceHTML = generateInvoiceHTML(booking, guest, room, servicesData);

        res.setHeader('Content-Type', 'text/html');
        res.send(invoiceHTML);

    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Invoice generation failed',
            error: error.message
        });
    }
});

module.exports = router;
