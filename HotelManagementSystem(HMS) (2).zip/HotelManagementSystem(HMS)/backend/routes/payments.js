const express = require('express');
const router = express.Router();
const Payment = require('../models/Payment');
const Refund = require('../models/Refund');

// Validation helper
function validatePaymentRequest(data) {
    const errors = [];
    
    if (!data.invoice_id || isNaN(data.invoice_id)) {
        errors.push('Valid invoice ID is required');
    }
    if (!data.booking_id || isNaN(data.booking_id)) {
        errors.push('Valid booking ID is required');
    }
    if (!data.guest_id || isNaN(data.guest_id)) {
        errors.push('Valid guest ID is required');
    }
    if (!data.amount || isNaN(data.amount) || parseFloat(data.amount) <= 0) {
        errors.push('Valid amount is required');
    }
    if (!data.payment_method) {
        errors.push('Payment method is required');
    }
    
    return errors;
}

// ===== SPECIFIC ROUTES FIRST (before generic routes!) =====

// POST create payment record - MUST COME BEFORE generic routes!
router.post('/', async (req, res) => {
    try {
        const errors = validatePaymentRequest(req.body);
        
        if (errors.length > 0) {
            return res.status(400).json({
                success: false,
                message: 'Validation errors',
                errors: errors
            });
        }
        
        const result = await Payment.create({
            invoice_id: req.body.invoice_id,
            booking_id: req.body.booking_id,
            guest_id: req.body.guest_id,
            amount: parseFloat(req.body.amount),
            payment_method: req.body.payment_method,
            reference_number: req.body.reference_number,
            transaction_id: req.body.transaction_id,
            received_by: req.body.received_by || 'System',
            notes: req.body.notes
        });
        
        res.status(201).json({
            success: true,
            message: 'Payment recorded successfully',
            data: result
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
});

// POST create refund
router.post('/refunds', async (req, res) => {
    try {
        const { invoice_id, booking_id, guest_id, refund_amount, reason, refund_method } = req.body;
        
        if (!invoice_id || !booking_id || !guest_id || !refund_amount || !reason) {
            return res.status(400).json({
                success: false,
                message: 'Missing required fields'
            });
        }
        
        const result = await Refund.create({
            invoice_id,
            booking_id,
            guest_id,
            refund_amount: parseFloat(refund_amount),
            refund_reason: reason,
            refund_method: refund_method || 'Cash'
        });
        
        res.status(201).json({
            success: true,
            message: 'Refund created successfully',
            data: result
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
});

// ===== GET SPECIFIC ROUTES =====

// GET available payment methods
router.get('/methods/list', async (req, res) => {
    try {
        const methods = await Payment.getPaymentMethods();
        res.json({
            success: true,
            data: methods
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch payment methods',
            error: error.message
        });
    }
});
router.get('/stats/range', async (req, res) => {
    try {
        let { start, end } = req.query;
        
        if (!start || !end) {
            const today = new Date();
            const dateStr = today.toISOString().split('T')[0];
            start = dateStr;
            end = dateStr;
        }
        
        const stats = await Payment.getStatistics(start, end);
        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch statistics',
            error: error.message
        });
    }
});

// GET payments by date range
router.get('/date-range/list', async (req, res) => {
    try {
        const { start, end } = req.query;
        
        if (!start || !end) {
            return res.status(400).json({
                success: false,
                message: 'Start and end dates are required'
            });
        }
        
        const limit = Math.min(parseInt(req.query.limit) || 100, 1000);
        const offset = parseInt(req.query.offset) || 0;
        
        const payments = await Payment.getByDateRange(start, end, limit, offset);
        res.json({
            success: true,
            data: payments,
            count: payments.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch payments',
            error: error.message
        });
    }
});

// GET all refunds
router.get('/refunds/list', async (req, res) => {
    try {
        const limit = Math.min(parseInt(req.query.limit) || 100, 1000);
        const offset = parseInt(req.query.offset) || 0;
        
        const refunds = await Refund.getAll(limit, offset);
        res.json({
            success: true,
            data: refunds,
            count: refunds.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch refunds',
            error: error.message
        });
    }
});

// GET payments for invoice
router.get('/invoice/:invoiceId', async (req, res) => {
    try {
        if (!req.params.invoiceId || isNaN(req.params.invoiceId)) {
            return res.status(400).json({ success: false, message: 'Invalid invoice ID' });
        }
        
        const payments = await Payment.getByInvoiceId(parseInt(req.params.invoiceId));
        res.json({
            success: true,
            data: payments,
            count: payments.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch payments',
            error: error.message
        });
    }
});

// GET payments for booking
router.get('/booking/:bookingId', async (req, res) => {
    try {
        if (!req.params.bookingId || isNaN(req.params.bookingId)) {
            return res.status(400).json({ success: false, message: 'Invalid booking ID' });
        }
        
        const payments = await Payment.getByBookingId(parseInt(req.params.bookingId));
        res.json({
            success: true,
            data: payments,
            count: payments.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch payments',
            error: error.message
        });
    }
});

// GET payments for guest
router.get('/guest/:guestId', async (req, res) => {
    try {
        if (!req.params.guestId || isNaN(req.params.guestId)) {
            return res.status(400).json({ success: false, message: 'Invalid guest ID' });
        }
        
        const limit = Math.min(parseInt(req.query.limit) || 50, 1000);
        const offset = parseInt(req.query.offset) || 0;
        
        const payments = await Payment.getByGuestId(parseInt(req.params.guestId), limit, offset);
        res.json({
            success: true,
            data: payments,
            count: payments.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch payments',
            error: error.message
        });
    }
});

// GET payment receipt data
router.get('/:id/receipt', async (req, res) => {
    try {
        if (!req.params.id || isNaN(req.params.id)) {
            return res.status(400).json({ success: false, message: 'Invalid payment ID' });
        }
        
        const receipt = await Payment.getReceiptData(parseInt(req.params.id));
        if (!receipt) {
            return res.status(404).json({ success: false, message: 'Payment not found' });
        }
        
        res.json({
            success: true,
            data: receipt
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch receipt data',
            error: error.message
        });
    }
});

// GET refund by ID
router.get('/refunds/:id', async (req, res) => {
    try {
        const refund = await Refund.getDetails(parseInt(req.params.id));
        if (!refund) {
            return res.status(404).json({ success: false, message: 'Refund not found' });
        }
        
        res.json({ success: true, data: refund });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch refund',
            error: error.message
        });
    }
});

// ===== GENERIC CATCH-ALL ROUTES (LAST!) =====

// GET all payments
router.get('/', async (req, res) => {
    try {
        const limit = Math.min(parseInt(req.query.limit) || 100, 1000);
        const offset = parseInt(req.query.offset) || 0;
        
        const payments = await Payment.getAll(limit, offset);
        res.json({
            success: true,
            data: payments,
            count: payments.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch payments',
            error: error.message
        });
    }
});

// GET payment by ID
router.get('/:id', async (req, res) => {
    try {
        if (!req.params.id || isNaN(req.params.id)) {
            return res.status(400).json({ success: false, message: 'Invalid payment ID' });
        }
        
        const payment = await Payment.getDetails(parseInt(req.params.id));
        if (!payment) {
            return res.status(404).json({ success: false, message: 'Payment not found' });
        }
        
        res.json({ success: true, data: payment });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch payment',
            error: error.message
        });
    }
});

module.exports = router;

