const express = require('express');
const router = express.Router();
const GuestSession = require('../models/GuestSession');

// Validate token
router.post('/validate-token', async (req, res) => {
    try {
        const { token } = req.body;
        
        if (!token) {
            return res.status(400).json({
                success: false,
                message: 'Token is required'
            });
        }
        
        const result = await GuestSession.validateToken(token);
        
        if (!result.valid) {
            return res.status(401).json({
                success: false,
                message: result.message
            });
        }
        
        res.json({
            success: true,
            message: 'Token is valid',
            data: {
                bookingId: result.session.booking_id,
                guestId: result.session.guest_id,
                guestName: result.session.guest_name,
                roomNumber: result.session.room_number
            }
        });
    } catch (error) {
        console.error('Error validating token:', error);
        res.status(500).json({
            success: false,
            message: 'Error validating token',
            error: error.message
        });
    }
});

// Validate PIN
router.post('/validate-pin', async (req, res) => {
    try {
        const { pin } = req.body;
        
        if (!pin) {
            return res.status(400).json({
                success: false,
                message: 'PIN is required'
            });
        }
        
        const result = await GuestSession.validatePin(pin);
        
        if (!result.valid) {
            return res.status(401).json({
                success: false,
                message: result.message
            });
        }
        
        res.json({
            success: true,
            message: 'PIN is valid',
            data: {
                token: result.session.access_token,
                bookingId: result.session.booking_id,
                guestId: result.session.guest_id,
                guestName: result.session.guest_name,
                roomNumber: result.session.room_number
            }
        });
    } catch (error) {
        console.error('Error validating PIN:', error);
        res.status(500).json({
            success: false,
            message: 'Error validating PIN',
            error: error.message
        });
    }
});

// Get session info by booking ID
router.get('/booking/:bookingId', async (req, res) => {
    try {
        const session = await GuestSession.getSessionInfo(req.params.bookingId);
        
        if (!session) {
            return res.status(404).json({
                success: false,
                message: 'No active session found for this booking'
            });
        }
        
        res.json({
            success: true,
            data: session
        });
    } catch (error) {
        console.error('Error fetching session:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching session',
            error: error.message
        });
    }
});

// Get all active sessions
router.get('/', async (req, res) => {
    try {
        const sessions = await GuestSession.getAllActive();
        res.json({
            success: true,
            data: sessions
        });
    } catch (error) {
        console.error('Error fetching sessions:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching sessions',
            error: error.message
        });
    }
});

// Cleanup expired sessions
router.post('/cleanup/expired', async (req, res) => {
    try {
        const cleaned = await GuestSession.cleanupExpiredSessions();
        res.json({
            success: true,
            message: `Cleaned up ${cleaned} expired sessions`
        });
    } catch (error) {
        console.error('Error cleaning up sessions:', error);
        res.status(500).json({
            success: false,
            message: 'Error cleaning up sessions',
            error: error.message
        });
    }
});

module.exports = router;
