const express = require('express');
const router = express.Router();
const Invoice = require('../models/Invoice');
const Payment = require('../models/Payment');

// Validation helper
function validateInvoiceRequest(data) {
    const errors = [];
    
    if (!data.booking_id || isNaN(data.booking_id)) {
        errors.push('Valid booking ID is required');
    }
    
    return errors;
}

// ===== SPECIFIC ROUTES FIRST =====

// GET invoices by date range
router.get('/date-range/list', async (req, res) => {
    try {
        const { start, end } = req.query;
        
        if (!start || !end) {
            return res.status(400).json({
                success: false,
                message: 'Start and end dates are required'
            });
        }
        
        const limit = Math.min(parseInt(req.query.limit) || 100, 1000);
        const offset = parseInt(req.query.offset) || 0;
        
        const invoices = await Invoice.getByDateRange(start, end, limit, offset);
        res.json({
            success: true,
            data: invoices,
            count: invoices.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch invoices',
            error: error.message
        });
    }
});

// GET invoice statistics
router.get('/stats/range', async (req, res) => {
    try {
        const { start, end } = req.query;
        
        if (!start || !end) {
            const today = new Date();
            start = today.toISOString().split('T')[0];
            end = today.toISOString().split('T')[0];
        }
        
        const stats = await Invoice.getStatistics(start, end);
        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch statistics',
            error: error.message
        });
    }
});

// GET invoice for booking
router.get('/booking/:bookingId', async (req, res) => {
    try {
        if (!req.params.bookingId || isNaN(req.params.bookingId)) {
            return res.status(400).json({ success: false, message: 'Invalid booking ID' });
        }
        
        const invoice = await Invoice.getByBookingId(parseInt(req.params.bookingId));
        if (!invoice) {
            return res.status(404).json({ success: false, message: 'Invoice not found for this booking' });
        }
        
        const details = await Invoice.getDetails(invoice.invoice_id);
        res.json({ success: true, data: details });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch invoice',
            error: error.message
        });
    }
});

// GET invoices for guest
router.get('/guest/:guestId', async (req, res) => {
    try {
        if (!req.params.guestId || isNaN(req.params.guestId)) {
            return res.status(400).json({ success: false, message: 'Invalid guest ID' });
        }
        
        const limit = Math.min(parseInt(req.query.limit) || 50, 1000);
        const offset = parseInt(req.query.offset) || 0;
        
        const invoices = await Invoice.getByGuestId(parseInt(req.params.guestId), limit, offset);
        res.json({
            success: true,
            data: invoices,
            count: invoices.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch guest invoices',
            error: error.message
        });
    }
});

// ===== POST ROUTES (MUST COME BEFORE GET /:id) =====

// POST generate invoice from booking
router.post('/generate', async (req, res) => {
    try {
        const errors = validateInvoiceRequest(req.body);
        
        if (errors.length > 0) {
            return res.status(400).json({
                success: false,
                message: 'Validation errors',
                errors: errors
            });
        }
        
        const result = await Invoice.generateFromBooking(req.body.booking_id);
        res.status(201).json({
            success: true,
            message: 'Invoice generated successfully',
            data: result
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
});

// ===== GENERIC ROUTES =====

// GET all invoices
router.get('/', async (req, res) => {
    try {
        const limit = Math.min(parseInt(req.query.limit) || 100, 1000);
        const offset = parseInt(req.query.offset) || 0;
        
        const invoices = await Invoice.getAll(limit, offset);
        res.json({
            success: true,
            data: invoices,
            count: invoices.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch invoices',
            error: error.message
        });
    }
});

// GET invoice by ID
router.get('/:id', async (req, res) => {
    try {
        if (!req.params.id || isNaN(req.params.id)) {
            return res.status(400).json({ success: false, message: 'Invalid invoice ID' });
        }
        
        const invoice = await Invoice.getDetails(parseInt(req.params.id));
        if (!invoice) {
            return res.status(404).json({ success: false, message: 'Invoice not found' });
        }
        
        res.json({ success: true, data: invoice });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch invoice',
            error: error.message
        });
    }
});

// ===== PUT ROUTES =====

// PUT update invoice status
router.put('/:id/status', async (req, res) => {
    try {
        const { status } = req.body;
        
        if (!status) {
            return res.status(400).json({
                success: false,
                message: 'Status is required'
            });
        }
        
        const validStatuses = ['Draft', 'Generated', 'Sent', 'Partially_Paid', 'Paid', 'Cancelled'];
        if (!validStatuses.includes(status)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid status'
            });
        }
        
        await Invoice.updateStatus(req.params.id, status);
        res.json({
            success: true,
            message: 'Invoice status updated'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to update invoice status',
            error: error.message
        });
    }
});

// PUT cancel invoice
router.put('/:id/cancel', async (req, res) => {
    try {
        const { reason } = req.body;
        
        await Invoice.cancel(req.params.id, reason || 'No reason provided');
        res.json({
            success: true,
            message: 'Invoice cancelled successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to cancel invoice',
            error: error.message
        });
    }
});

module.exports = router;
