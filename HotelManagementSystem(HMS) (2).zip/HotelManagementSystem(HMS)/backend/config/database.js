const mysql = require('mysql2');
require('dotenv').config();

// Create optimized connection pool
const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'hotel_management_db',
    port: process.env.DB_PORT || 3306,
    // Connection pooling settings
    waitForConnections: true,
    connectionLimit: 20,  // Increased from 10 for better concurrency
    maxIdle: 10,           // max idle connections
    idleTimeout: 60000,    // close idle after 60s
    queueLimit: 0,
    enableKeepAlive: true, // Keep connections alive
    // Query settings for better performance
    multipleStatements: false,
    supportBigNumbers: true,
    bigNumberStrings: true,
    decimalNumbers: true,
    timezone: '+00:00'
});

// Promisify for async/await
const promisePool = pool.promise();

// Test connection
pool.getConnection((err, connection) => {
    if (err) {
        console.error('❌ Database connection failed:', err.message);
        return;
    }
    console.log('✅ Database connected successfully');
    connection.release();
});

module.exports = promisePool;
