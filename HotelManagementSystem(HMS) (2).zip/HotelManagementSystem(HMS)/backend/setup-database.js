// Database Setup Script - Creates all tables and loads sample data
const fs = require('fs');
const mysql = require('mysql2');
require('dotenv').config();

console.log('🔧 Starting database setup...\n');

// Create connection for database initialization
const connection = mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    port: process.env.DB_PORT || 3306
});

connection.connect((err) => {
    if (err) {
        console.error('❌ Failed to connect to MySQL:', err.message);
        process.exit(1);
    }
    console.log('✅ Connected to MySQL server\n');

    // Create database if it doesn't exist
    const dbName = process.env.DB_NAME || 'hotel_management_db';
    console.log(`📦 Creating database '${dbName}' if it doesn't exist...`);
    
    connection.query(`CREATE DATABASE IF NOT EXISTS ${dbName}`, (err) => {
        if (err) {
            console.error('❌ Failed to create database:', err.message);
            connection.end();
            process.exit(1);
        }
        console.log(`✅ Database '${dbName}' ready\n`);
        
        // Close and reconnect to the specific database
        connection.end();
        
        // Now connect to the specific database and run schema
        const dbConnection = mysql.createConnection({
            host: process.env.DB_HOST || 'localhost',
            user: process.env.DB_USER || 'root',
            password: process.env.DB_PASSWORD || '',
            database: dbName,
            port: process.env.DB_PORT || 3306,
            multipleStatements: true
        });

        dbConnection.connect((err) => {
            if (err) {
                console.error('❌ Failed to connect to database:', err.message);
                process.exit(1);
            }
            console.log(`✅ Connected to database '${dbName}'\n`);

            // Read and execute schema.sql
            const schemaPath = '../database/schema.sql';
            if (!fs.existsSync(schemaPath)) {
                console.error(`❌ Schema file not found at ${schemaPath}`);
                dbConnection.end();
                process.exit(1);
            }

            console.log('📄 Reading schema.sql...');
            const sql = fs.readFileSync(schemaPath, 'utf8');
            
            console.log('⏳ Executing schema (creating tables and loading sample data)...\n');
            
            dbConnection.query(sql, (err, results) => {
                if (err) {
                    console.error('❌ Error executing schema:', err.message);
                    console.error('SQL Error Code:', err.code);
                    dbConnection.end();
                    process.exit(1);
                }
                
                console.log('✅ Database setup completed successfully!\n');
                console.log('📊 Tables created:');
                console.log('  ✓ rooms');
                console.log('  ✓ guests');
                console.log('  ✓ bookings');
                console.log('  ✓ services');
                console.log('  ✓ service_orders');
                console.log('  ✓ guest_sessions');
                console.log('  ✓ inventory_categories');
                console.log('  ✓ inventory_items');
                console.log('  ✓ inventory_stocks');
                console.log('  ✓ inventory_transactions');
                console.log('  ✓ housekeeping_staff');
                console.log('  ✓ cleaning_tasks');
                console.log('  ✓ maintenance_logs\n');
                
                console.log('📦 Sample Data Loaded:');
                console.log('  ✓ 8 inventory categories');
                console.log('  ✓ 25 inventory items');
                console.log('  ✓ 7 rooms');
                console.log('  ✓ 30+ services');
                console.log('  ✓ 8 housekeeping staff');
                console.log('  ✓ 7 cleaning tasks');
                console.log('  ✓ 7 maintenance logs');
                console.log('  ✓ 3 database views\n');
                
                // Run room cleaning status migration
                console.log('⏳ Running room cleaning status migration...');
                const migrationPath = '../database/add_room_cleaning_status.sql';
                if (!fs.existsSync(migrationPath)) {
                    console.log('⚠️  Room cleaning status migration file not found (optional)');
                    console.log('🎉 Your HMS database is ready to use!\n');
                    dbConnection.end();
                    process.exit(0);
                }

                const migrationSql = fs.readFileSync(migrationPath, 'utf8');
                dbConnection.query(migrationSql, (err, results) => {
                    if (err) {
                        console.warn('⚠️  Warning: Room cleaning status migration encountered an issue:', err.message);
                        console.log('The database is still functional, but room cleaning status features may be limited.\n');
                    } else {
                        console.log('✅ Room cleaning status migration completed successfully');
                        console.log('  ✓ room_cleaning_status table');
                        console.log('  ✓ room_cleaning_history table');
                        console.log('  ✓ room_status_overview view');
                        console.log('  ✓ housekeeping_dashboard view\n');
                    }
                
                console.log('🎉 Your HMS database is ready to use!\n');
                
                dbConnection.end();
                process.exit(0);
                });
            });
