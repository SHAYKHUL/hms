const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');

async function migrateDatabase() {
    const connection = await mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '',
        multipleStatements: true
    });

    try {
        // First, create database if not exists
        await connection.query('CREATE DATABASE IF NOT EXISTS hotel_management_db');
        
        // Use the database
        await connection.query('USE hotel_management_db');
        
        // Read schema file
        const schemaPath = path.join(__dirname, '..', 'database', 'schema.sql');
        const schemaSQL = fs.readFileSync(schemaPath, 'utf8');
        
        // Execute schema
        await connection.query(schemaSQL);
        
        console.log('✅ Database migration completed successfully!');
        console.log('✅ All tables created');
        console.log('✅ Views created (booking_details, service_order_details)');
        console.log('✅ Sample data inserted');
        
    } catch (error) {
        console.error('❌ Migration failed:', error.message);
        process.exit(1);
    } finally {
        await connection.end();
    }
}

migrateDatabase();
