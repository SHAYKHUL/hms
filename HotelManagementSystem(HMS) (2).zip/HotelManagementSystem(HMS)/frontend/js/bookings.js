// Bookings Management JavaScript - OPTIMIZED

let allBookings = [];
let currentPage = 1;
let pageSize = 20;
let totalPages = 1;
let totalBookings = 0;
let currentStep = 1;
let selectedGuest = null;
let selectedRoom = null;

// Debounce utility - PERFORMANCE OPTIMIZATION
const debounce = (func, delay) => {
    let timeoutId;
    return function(...args) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => func(...args), delay);
    };
};

// Debounced reload for date filters
const debouncedReloadBookings = debounce(() => loadBookings(1), 300);

function onDateFilterChange() {
    debouncedReloadBookings();
}

// Load bookings with pagination - PERFORMANCE OPTIMIZED
async function loadBookings(page = 1) {
    try {
        currentPage = page;
        let url = `${API_ENDPOINTS.bookings}?page=${page}&limit=${pageSize}`;
        const startDateEl = document.getElementById('startDateFilter');
        const endDateEl = document.getElementById('endDateFilter');
        if (startDateEl && startDateEl.value) url += `&startDate=${encodeURIComponent(startDateEl.value)}`;
        if (endDateEl && endDateEl.value) url += `&endDate=${encodeURIComponent(endDateEl.value)}`;

        const response = await apiCall(url);
        if (response.success) {
            allBookings = response.data || [];
            totalBookings = response.pagination?.total || 0;
            totalPages = response.pagination?.pages || 1;
            displayBookings(allBookings);
            updatePagination();
        }
    } catch (error) {
        document.getElementById('bookingsTable').innerHTML = '<tr><td colspan="9" class="text-danger">Error loading bookings</td></tr>';
    }
}

// Update pagination controls
function updatePagination() {
    const paginationContainer = document.getElementById('bookingsPagination');
    if (!paginationContainer) return;
    
    let html = '<div style="display: flex; align-items: center; justify-content: center; gap: 10px; margin-top: 20px;">';
    
    // Previous button
    if (currentPage > 1) {
        html += `<button class="btn btn-sm btn-secondary" onclick="loadBookings(${currentPage - 1})">← Previous</button>`;
    } else {
        html += `<button class="btn btn-sm btn-secondary" disabled>← Previous</button>`;
    }
    
    // Page info
    html += `<span style="padding: 0 15px;">Page ${currentPage} of ${totalPages} (${totalBookings} total)</span>`;
    
    // Next button
    if (currentPage < totalPages) {
        html += `<button class="btn btn-sm btn-secondary" onclick="loadBookings(${currentPage + 1})">Next →</button>`;
    } else {
        html += `<button class="btn btn-sm btn-secondary" disabled>Next →</button>`;
    }
    
    html += '</div>';
    paginationContainer.innerHTML = html;
}

// Display bookings
function displayBookings(bookings) {
    const tbody = document.getElementById('bookingsTable');
    
    if (bookings.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No bookings found</td></tr>';
        return;
    }
    
    tbody.innerHTML = bookings.map(booking => {
        let menuItems = `
            <button class="action-item" onclick="viewBooking(${booking.booking_id})">
                <i class="fas fa-eye"></i> View
            </button>
        `;
        
        if (booking.booking_status === 'Confirmed') {
            menuItems += `
                <button class="action-item" onclick="checkIn(${booking.booking_id})">
                    <i class="fas fa-sign-in-alt"></i> Check-in
                </button>
                <button class="action-item" onclick="openExtensionModal(${booking.booking_id})">
                    <i class="fas fa-arrow-right"></i> Extend Stay
                </button>
            `;
        } else if (booking.booking_status === 'CheckedIn') {
            menuItems += `
                <button class="action-item" onclick="openExtensionModal(${booking.booking_id})">
                    <i class="fas fa-arrow-right"></i> Extend Stay
                </button>
                <button class="action-item" onclick="checkOut(${booking.booking_id})">
                    <i class="fas fa-sign-out-alt"></i> Check-out
                </button>
            `;
        }

        // Add billing actions for CheckedOut bookings
        if (booking.booking_status === 'CheckedOut') {
            menuItems += `
                <div style="border-top: 1px solid #e0e0e0; margin: 5px 0;"></div>
                <button class="action-item" onclick="handleGenerateInvoice(${booking.booking_id})">
                    <i class="fas fa-file-invoice"></i> Generate Invoice
                </button>
                <button class="action-item" onclick="handleViewInvoice(${booking.booking_id})">
                    <i class="fas fa-receipt"></i> View Invoice
                </button>
                <button class="action-item" onclick="handleRecordPayment(${booking.booking_id}, ${booking.guest_id})">
                    <i class="fas fa-money-bill"></i> Record Payment
                </button>
            `;
        }
        
        if (booking.booking_status === 'Confirmed' || booking.booking_status === 'CheckedIn') {
            menuItems += `
                <button class="action-item danger" onclick="cancelBooking(${booking.booking_id})">
                    <i class="fas fa-times"></i> Cancel
                </button>
            `;
        }
        
        // Format checkout details with type information
        let checkoutDisplay = formatDate(booking.check_out);
        if (booking.checkout_type && booking.booking_status === 'CheckedOut') {
            switch (booking.checkout_type) {
                case 'Early':
                    checkoutDisplay += ` <span class="badge badge-info" title="Checked out early">⚡ Early</span>`;
                    break;
                case 'Late':
                    checkoutDisplay += ` <span class="badge badge-warning" title="Late checkout fee applied">⏰ Late</span>`;
                    break;
                case 'Standard':
                    checkoutDisplay += ` <span class="badge badge-success" title="Standard checkout">✓</span>`;
                    break;
            }
        }
        
        return `
            <tr>
                <td>#${booking.booking_id}</td>
                <td>${booking.guest_name}</td>
                <td>Room ${booking.room_number}</td>
                <td>${formatDate(booking.check_in)}</td>
                <td>${checkoutDisplay}</td>
                <td>${formatCurrency(booking.total_amount)}</td>
                <td><span class="badge badge-${getPaymentBadge(booking.payment_status)}">${booking.payment_status}</span></td>
                <td><span class="badge badge-${getStatusBadge(booking.booking_status)}">${booking.booking_status}</span></td>
                <td>
                    <div class="action-menu">
                        <button class="action-btn" onclick="toggleActionMenu(this)">
                            <i class="fas fa-ellipsis-v"></i>
                        </button>
                        <div class="action-dropdown">
                            ${menuItems}
                        </div>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
    
    // Close dropdowns when clicking outside (attach once)
    if (!window._bookingActionListenerAdded) {
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.action-menu')) {
                document.querySelectorAll('.action-dropdown').forEach(d => d.classList.remove('show'));
            }
        });
        window._bookingActionListenerAdded = true;
    }
}

function getPaymentBadge(status) {
    const badges = {
        'Paid': 'success',
        'Partial': 'warning',
        'Pending': 'danger'
    };
    return badges[status] || 'secondary';
}

function getStatusBadge(status) {
    const badges = {
        'Confirmed': 'info',
        'CheckedIn': 'success',
        'CheckedOut': 'secondary',
        'Cancelled': 'danger',
        'Checked-out Early': 'warning',
        'CheckedOut Early': 'warning'
    };
    return badges[status] || 'secondary';
}

// Toggle action menu dropdown
function toggleActionMenu(btn) {
    const dropdown = btn.nextElementSibling;
    const allDropdowns = document.querySelectorAll('.action-dropdown');
    
    allDropdowns.forEach(d => {
        if (d !== dropdown) d.classList.remove('show');
    });
    
    dropdown.classList.toggle('show');
}

// Filter bookings with debouncing - PERFORMANCE OPTIMIZED
const debouncedFilterBookings = debounce(function() {
    const statusFilter = document.getElementById('statusFilter').value;
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    
    let filtered = allBookings;
    
    if (statusFilter) {
        filtered = filtered.filter(b => b.booking_status === statusFilter);
    }
    
    if (searchTerm) {
        filtered = filtered.filter(b => 
            b.guest_name.toLowerCase().includes(searchTerm) ||
            b.room_number.toLowerCase().includes(searchTerm)
        );
    }
    
    displayBookings(filtered);
}, 300); // Debounce for 300ms

function filterBookings() {
    debouncedFilterBookings();
}

// Open New Booking Modal
function openNewBookingModal() {
    currentStep = 1;
    selectedGuest = null;
    selectedRoom = null;
    document.getElementById('bookingForm').reset();
    showStep(1);
    document.getElementById('bookingModal').classList.add('show');
    // focus first input in modal for accessibility
    setTimeout(() => {
        const guestSearch = document.getElementById('guestSearch');
        const guestName = document.getElementById('guestName');
        if (guestSearch) guestSearch.focus(); else if (guestName) guestName.focus();
    }, 50);
    // prevent body scroll while modal open
    document.body.classList.add('modal-open');
}

// Close Booking Modal
function closeBookingModal() {
    document.getElementById('bookingModal').classList.remove('show');
    // remove body lock if no other modal open
    setTimeout(() => {
        if (document.querySelectorAll('.modal.show').length === 0) document.body.classList.remove('modal-open');
    }, 10);
}

// Navigation between steps
function showStep(step) {
    document.querySelectorAll('.booking-step').forEach(el => el.classList.remove('active'));
    document.getElementById(`step${step}`).classList.add('active');
    currentStep = step;
}

function nextStep(step) {
    if (step === 2) {
        // Validate guest details
        const guestId = document.getElementById('selectedGuestId').value;
        const guestName = document.getElementById('guestName').value;
        
        if (!guestId && !guestName) {
            showNotification('Please select or add guest details', 'error');
            return;
        }
    } else if (step === 3) {
        // Validate room selection
        const roomId = document.getElementById('selectedRoomId').value;
        const checkIn = document.getElementById('checkIn').value;
        const checkOut = document.getElementById('checkOut').value;
        
        if (!checkIn || !checkOut) {
            showNotification('Please select check-in and check-out dates', 'error');
            return;
        }
        
        if (!roomId) {
            showNotification('Please select a room', 'error');
            return;
        }
        
        // Show booking summary
        showBookingSummary();
    }
    
    showStep(step);
}

function prevStep(step) {
    showStep(step);
}

// Handle discount type change
function updateDiscountDisplay() {
    const discountType = document.getElementById('discountType').value;
    const discountValueGroup = document.getElementById('discountValueGroup');
    
    if (discountType === 'None') {
        discountValueGroup.style.display = 'none';
        document.getElementById('discountValue').value = 0;
    } else {
        discountValueGroup.style.display = 'block';
    }
    
    updateBookingSummary();
}

// Update booking summary with discount
function updateBookingSummary() {
    showBookingSummary();
}

// Search guests with debouncing - PERFORMANCE OPTIMIZED
const debouncedSearchGuests = debounce(async function(searchTerm) {
    if (searchTerm.length < 2) {
        document.getElementById('guestResults').innerHTML = '';
        return;
    }
    
    try {
        const response = await apiCall(`${API_ENDPOINTS.guests}/search/contact?q=${searchTerm}`);
        if (response.success) {
            displayGuestResults(response.data);
        }
    } catch (error) {
        console.error('Error searching guests:', error);
    }
}, 500); // Debounce for 500ms to reduce API calls

async function searchGuests() {
    const searchTerm = document.getElementById('guestSearch').value;
    debouncedSearchGuests(searchTerm);
}

function displayGuestResults(guests) {
    const container = document.getElementById('guestResults');

    container.innerHTML = '';
    if (!guests || guests.length === 0) {
        container.innerHTML = '<div class="search-result-item">No guests found</div>';
        return;
    }

    guests.forEach(guest => {
        const div = document.createElement('div');
        div.className = 'search-result-item';
        const name = document.createElement('strong');
        name.textContent = guest.name;
        const br = document.createElement('br');
        const small = document.createElement('small');
        small.textContent = guest.phone + (guest.email ? ' | ' + guest.email : '');

        div.appendChild(name);
        div.appendChild(br);
        div.appendChild(small);

        div.addEventListener('click', () => {
            selectGuest(guest.guest_id, guest.name.replace(/'/g, "\'"), guest.phone.replace(/'/g, "\'"), (guest.email||'').replace(/'/g, "\'"), (guest.id_proof||'').replace(/'/g, "\\'"), (guest.address||'').replace(/'/g, "\\'"));
        });

        container.appendChild(div);
    });
}

function selectGuest(id, name, phone, email, idProof, address) {
    document.getElementById('selectedGuestId').value = id;
    document.getElementById('guestName').value = name;
    document.getElementById('guestPhone').value = phone;
    document.getElementById('guestEmail').value = email;
    document.getElementById('guestIdProof').value = idProof;
    document.getElementById('guestAddress').value = address;
    document.getElementById('guestResults').innerHTML = '';
    document.getElementById('guestSearch').value = name;
}

// Search available rooms
async function searchAvailableRooms() {
    const checkIn = document.getElementById('checkIn').value;
    const checkOut = document.getElementById('checkOut').value;
    const acType = document.getElementById('acTypeFilter').value;
    
    if (!checkIn || !checkOut) {
        return;
    }
    
    if (new Date(checkOut) <= new Date(checkIn)) {
        showNotification('Check-out date must be after check-in date', 'error');
        return;
    }
    
    try {
        let url = `${API_ENDPOINTS.rooms}/available/search?checkIn=${checkIn}&checkOut=${checkOut}`;
        if (acType) {
            url += `&acType=${encodeURIComponent(acType)}`;
        }
        const response = await apiCall(url);
        if (response.success) {
            displayAvailableRooms(response.data);
        }
    } catch (error) {
        console.error('Error loading available rooms:', error);
    }
}

function displayAvailableRooms(rooms) {
    const container = document.getElementById('availableRooms');
    
    if (rooms.length === 0) {
        container.innerHTML = '<p class="text-muted">No rooms available for selected dates</p>';
        return;
    }
    
    container.innerHTML = rooms.map(room => `
        <div class="available-room-item" onclick="selectRoom(${room.room_id}, '${room.room_number}', '${room.room_type}', '${room.ac_type}', ${room.price}, this)">
            <strong>Room ${room.room_number}</strong><br>
            <small>${room.room_type} • ${room.ac_type}</small><br>
            <strong>${formatCurrency(room.price)}/night</strong>
        </div>
    `).join('');
}

function selectRoom(id, number, type, acType, price, el) {
    document.getElementById('selectedRoomId').value = id;
    document.getElementById('roomPrice').value = price;
    selectedRoom = { id, number, type, acType, price };
    
    // Highlight selected room
    document.querySelectorAll('.available-room-item').forEach(el => el.classList.remove('selected'));
    if (el && el.classList) el.classList.add('selected');
}

// Show booking summary
function showBookingSummary() {
    const checkIn = document.getElementById('checkIn').value;
    const checkOut = document.getElementById('checkOut').value;
    const roomPrice = parseFloat(document.getElementById('roomPrice').value);
    const guestName = document.getElementById('guestName').value;
    const numberOfGuests = parseInt(document.getElementById('numberOfGuests').value) || 1;
    
    const days = calculateDays(checkIn, checkOut);
    const subtotal = roomPrice * days;
    
    // Calculate discount
    const discountType = document.getElementById('discountType').value;
    const discountValue = parseFloat(document.getElementById('discountValue').value) || 0;
    let discount = 0;
    if (discountType === 'Percentage') {
        discount = subtotal * (discountValue / 100);
    } else if (discountType === 'Fixed') {
        discount = discountValue;
    }
    
    const afterDiscount = Math.max(0, subtotal - discount);
    const tax = afterDiscount * TAX_RATE;
    const total = afterDiscount + tax;
    
    const summaryHTML = `
        <h4>Booking Summary</h4>
        <div class="summary-item">
            <span>Guest:</span>
            <strong>${guestName}</strong>
        </div>
        <div class="summary-item">
            <span>Room:</span>
            <strong>${selectedRoom ? `${selectedRoom.number} (${selectedRoom.type} • ${selectedRoom.acType})` : 'Not selected'}</strong>
        </div>
        <div class="summary-item">
            <span>Number of Guests:</span>
            <strong>${numberOfGuests}</strong>
        </div>
        <div class="summary-item">
            <span>Check-in:</span>
            <strong>${formatDate(checkIn)}</strong>
        </div>
        <div class="summary-item">
            <span>Check-out:</span>
            <strong>${formatDate(checkOut)}</strong>
        </div>
        <div class="summary-item">
            <span>Number of Nights:</span>
            <strong>${days}</strong>
        </div>
        <div class="summary-item">
            <span>Room Rate:</span>
            <strong>${formatCurrency(roomPrice)}/night</strong>
        </div>
        <div class="summary-item">
            <span>Subtotal:</span>
            <strong>${formatCurrency(subtotal)}</strong>
        </div>
        ${discount > 0 ? `
        <div class="summary-item" style="color: green;">
            <span>Discount (${discountType === 'Percentage' ? discountValue + '%' : formatCurrency(discountValue)}):</span>
            <strong>-${formatCurrency(discount)}</strong>
        </div>
        ` : ''}
        <div class="summary-item">
            <span>Subtotal after Discount:</span>
            <strong>${formatCurrency(afterDiscount)}</strong>
        </div>
        <div class="summary-item">
            <span>Tax (18% GST):</span>
            <strong>${formatCurrency(tax)}</strong>
        </div>
        <div class="summary-item summary-total">
            <span>Total Amount:</span>
            <strong>${formatCurrency(total)}</strong>
        </div>
    `;
    
    document.getElementById('bookingSummary').innerHTML = summaryHTML;
}

// Handle booking form submission
document.getElementById('bookingForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    try {
        // Validate step 1: Guest details
        const guestName = document.getElementById('guestName').value.trim();
        const guestPhone = document.getElementById('guestPhone').value.trim();
        const guestIdProof = document.getElementById('guestIdProof').value.trim();
        
        const guestErrors = [];
        if (!guestName) guestErrors.push('Guest name is required');
        if (!guestPhone) guestErrors.push('Phone number is required');
        if (!guestIdProof) guestErrors.push('ID proof is required');
        
        if (guestErrors.length > 0) {
            showNotification('Please fix guest details:\n• ' + guestErrors.join('\n• '), 'error');
            return;
        }
        
        // Validate step 2: Room and date selection
        const checkIn = document.getElementById('checkIn').value;
        const checkOut = document.getElementById('checkOut').value;
        const roomId = document.getElementById('selectedRoomId').value;
        const numberOfGuests = document.getElementById('numberOfGuests').value;
        
        const roomErrors = [];
        if (!checkIn) roomErrors.push('Check-in date is required');
        if (!checkOut) roomErrors.push('Check-out date is required');
        if (!roomId) roomErrors.push('Please select a room');
        if (!numberOfGuests || numberOfGuests < 1) roomErrors.push('Invalid number of guests');
        
        if (roomErrors.length > 0) {
            showNotification('Please fix booking details:\n• ' + roomErrors.join('\n• '), 'error');
            return;
        }
        
        if (new Date(checkOut) <= new Date(checkIn)) {
            showNotification('Check-out date must be after check-in date', 'error');
            return;
        }
        
        // Create guest if new
        let guestId = document.getElementById('selectedGuestId').value;
        
        if (!guestId) {
            const guestData = {
                name: guestName,
                phone: guestPhone,
                email: document.getElementById('guestEmail').value.trim(),
                id_proof: guestIdProof,
                address: document.getElementById('guestAddress').value.trim()
            };
            
            const guestResponse = await apiCall(`${API_ENDPOINTS.guests}`, {
                method: 'POST',
                body: JSON.stringify(guestData)
            });
            
            if (!guestResponse.success) {
                showNotification('Error: ' + (guestResponse.message || 'Failed to create guest'), 'error');
                return;
            }
            
            guestId = guestResponse.guestId;
        }
        
        // Calculate total amount
        const roomPrice = parseFloat(document.getElementById('roomPrice').value);
        const days = calculateDays(checkIn, checkOut);
        const subtotal = roomPrice * days;
        
        // Calculate discount
        const discountType = document.getElementById('discountType').value;
        const discountValue = parseFloat(document.getElementById('discountValue').value) || 0;
        let discount = 0;
        if (discountType === 'Percentage') {
            if (discountValue < 0 || discountValue > 100) {
                showNotification('Discount percentage must be between 0 and 100', 'error');
                return;
            }
            discount = subtotal * (discountValue / 100);
        } else if (discountType === 'Fixed') {
            discount = discountValue;
        }
        
        const afterDiscount = Math.max(0, subtotal - discount);
        const tax = afterDiscount * TAX_RATE;
        const total = afterDiscount + tax;
        
        // Create booking
        const bookingData = {
            guest_id: guestId,
            room_id: roomId,
            check_in: checkIn,
            check_out: checkOut,
            number_of_guests: parseInt(numberOfGuests),
            room_price: roomPrice,
            total_amount: total,
            discount_type: discountType,
            discount_value: discountValue,
            discount_reason: document.getElementById('discountReason').value.trim(),
            advance_payment: parseFloat(document.getElementById('advancePayment').value) || 0,
            payment_method: document.getElementById('paymentMethod').value,
            special_requests: document.getElementById('specialRequests').value.trim()
        };
        
        const bookingResponse = await apiCall(`${API_ENDPOINTS.bookings}`, {
            method: 'POST',
            body: JSON.stringify(bookingData)
        });
        
        if (!bookingResponse.success) {
            if (bookingResponse.errors && Array.isArray(bookingResponse.errors)) {
                showNotification('Booking Error:\n• ' + bookingResponse.errors.join('\n• '), 'error');
            } else {
                showNotification('Error: ' + (bookingResponse.message || 'Failed to create booking'), 'error');
            }
            return;
        }
        
        showNotification('✓ Booking created successfully!', 'success');
        closeBookingModal();
        loadBookings();
    } catch (error) {
        console.error('Error creating booking:', error);
        showNotification('Error: ' + (error.message || 'Failed to create booking'), 'error');
    }
});

// View booking details
async function viewBooking(bookingId) {
    try {
        const response = await apiCall(`${API_ENDPOINTS.bookings}/${bookingId}`);
        if (response.success) {
            const booking = response.data;
            
            const detailsHTML = `
                <div style="padding: 20px;">
                    <h3>Booking #${booking.booking_id}</h3>
                    <div style="margin-top: 20px;">
                        <h4>Guest Details</h4>
                        <p><strong>Name:</strong> ${booking.guest_name}</p>
                        <p><strong>Phone:</strong> ${booking.guest_phone}</p>
                        ${booking.guest_email ? `<p><strong>Email:</strong> ${booking.guest_email}</p>` : ''}
                    </div>
                    <div style="margin-top: 20px;">
                        <h4>Booking Details</h4>
                        <p><strong>Room:</strong> ${booking.room_number} (${booking.room_type})</p>
                        <p><strong>Check-in:</strong> ${formatDate(booking.check_in)}</p>
                        <p><strong>Check-out:</strong> ${formatDate(booking.check_out)}</p>
                        <p><strong>Status:</strong> <span class="badge badge-${getStatusBadge(booking.booking_status)}">${booking.booking_status}</span></p>
                    </div>
                    <div style="margin-top: 20px;">
                        <h4>Payment Details</h4>
                        <p><strong>Total Amount:</strong> ${formatCurrency(booking.total_amount)}</p>
                        <p><strong>Payment Status:</strong> <span class="badge badge-${getPaymentBadge(booking.payment_status)}">${booking.payment_status}</span></p>
                    </div>
                </div>
            `;
            
            document.getElementById('bookingDetailsContent').innerHTML = detailsHTML;
                    document.getElementById('bookingDetailsModal').classList.add('show');
                    // lock body scroll while details modal open
                    document.body.classList.add('modal-open');
        }
    } catch (error) {
        console.error('Error loading booking details:', error);
    }
}

function closeDetailsModal() {
    document.getElementById('bookingDetailsModal').classList.remove('show');
    setTimeout(() => {
        if (document.querySelectorAll('.modal.show').length === 0) document.body.classList.remove('modal-open');
    }, 10);
}

// Check-in
async function checkIn(bookingId) {
    if (!confirm('Confirm check-in for this booking?')) return;
    
    try {
        const response = await apiCall(`${API_ENDPOINTS.bookings}/${bookingId}/checkin`, {
            method: 'PATCH'
        });
        
        if (response.success) {
            if (response.data && response.data.pin) {
                // Show guest access token
                showGuestAccessToken(response.data);
            } else {
                showNotification('✓ Check-in successful!', 'success');
            }
            loadBookings();
        } else {
            showNotification('Error: ' + (response.message || 'Failed to check-in'), 'error');
        }
    } catch (error) {
        console.error('Error checking in:', error);
        showNotification('Error: ' + (error.message || 'Failed to check-in'), 'error');
    }
}

// Show Guest Access Token Modal
function showGuestAccessToken(sessionData) {
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.7);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
    `;
    
    modal.innerHTML = `
        <div style="background: white; padding: 2rem; border-radius: 10px; max-width: 500px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
            <div style="text-align: center; margin-bottom: 1.5rem;">
                <i class="fas fa-key" style="font-size: 3rem; color: #667eea; margin-bottom: 1rem;"></i>
                <h2 style="color: #333; margin: 0;">Guest Access PIN</h2>
                <p style="color: #666; margin-top: 0.5rem;">Share this PIN with the guest for portal access</p>
            </div>
            
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 1.5rem; border-radius: 10px; text-align: center; margin-bottom: 1.5rem;">
                <p style="margin: 0; font-size: 0.875rem; opacity: 0.9;">PIN Code</p>
                <h1 style="margin: 0.5rem 0 0 0; font-size: 2.5rem; letter-spacing: 5px; font-weight: bold;">${sessionData.pin}</h1>
            </div>
            
            <div style="background: #f8f9fa; padding: 1rem; border-radius: 5px; margin-bottom: 1.5rem;">
                <p style="margin: 0 0 0.5rem 0; color: #333; font-weight: bold;">Instructions:</p>
                <ol style="margin: 0; padding-left: 1.5rem; color: #666; font-size: 0.875rem;">
                    <li>Give this PIN to the guest</li>
                    <li>Guest enters PIN on Guest Portal page</li>
                    <li>PIN automatically expires at check-out</li>
                </ol>
            </div>
            
            <button onclick="copyToClipboard('${sessionData.pin}')" style="width: 100%; padding: 0.75rem; background: #667eea; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: bold; margin-bottom: 0.5rem;">
                <i class="fas fa-copy"></i> Copy PIN to Clipboard
            </button>
            <button onclick="this.closest('[style*=position]').remove();" style="width: 100%; padding: 0.75rem; background: #e0e0e0; color: #333; border: none; border-radius: 5px; cursor: pointer; font-weight: bold;">
                OK, Done
            </button>
        </div>
    `;
    
    document.body.appendChild(modal);
}

// Copy to Clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showNotification('PIN copied to clipboard!', 'success');
    }).catch(() => {
        alert('PIN: ' + text);
    });
}

// Check-out
async function checkOut(bookingId) {
    if (!confirm('Confirm check-out for this booking?')) return;
    
    try {
        const response = await apiCall(`${API_ENDPOINTS.bookings}/${bookingId}/checkout`, {
            method: 'PATCH'
        });
        
        if (response.success) {
            let message = response.message;
            let notificationType = 'success';
            
            // Display additional information based on checkout type
            if (response.data) {
                const { checkout_type, is_early, late_fee, checkout_time } = response.data;
                
                if (is_early) {
                    message += ` 🕐 Checked out at ${new Date(checkout_time).toLocaleTimeString()}`;
                    notificationType = 'info';
                    
                    // Show early checkout notification
                    setTimeout(() => {
                        showNotification('📌 Room is now available for immediate booking!', 'success');
                    }, 1500);
                }
                
                if (checkout_type === 'Late' && late_fee > 0) {
                    message += ` ⚠️ Late checkout fee applied: $${late_fee}`;
                    notificationType = 'warning';
                    
                    // Show late fee notification
                    setTimeout(() => {
                        showNotification('💰 Late checkout fee has been added to the bill', 'warning');
                    }, 1500);
                }
            }
            
            showNotification(message, notificationType);
            loadBookings();
            
            // Refresh room status if on rooms page
            if (typeof loadRooms === 'function') {
                loadRooms();
            }
            
        } else {
            showNotification('Error: ' + (response.message || 'Failed to check-out'), 'error');
        }
    } catch (error) {
        console.error('Error checking out:', error);
        showNotification('Error: ' + (error.message || 'Failed to check-out'), 'error');
    }
}

// ====== EARLY CHECKOUT FUNCTIONS ======

// Open early checkout modal
async function openEarlyCheckoutModal(bookingId) {
    const booking = allBookings.find(b => b.booking_id == bookingId);
    if (!booking) return;
    
    // Check eligibility first
    try {
        const eligibilityResponse = await apiCall(`${API_ENDPOINTS.bookings}/${bookingId}/early-checkout/eligibility`);
        
        if (!eligibilityResponse.success || !eligibilityResponse.data.eligible) {
            showNotification('Cannot process early checkout: ' + (eligibilityResponse.data?.reason || 'Unknown error'), 'error');
            return;
        }
        
        // Get refund calculation
        const refundResponse = await apiCall(`${API_ENDPOINTS.bookings}/${bookingId}/early-checkout/refund-calculation`);
        
        let modalContent = `
            <div class="modal-header">
                <h3>Early Check-out</h3>
                <button type="button" class="close" onclick="closeEarlyCheckoutModal()">&times;</button>
            </div>
            <div class="modal-body">
                <div class="early-checkout-booking-info">
                    <h4>Booking Details</h4>
                    <p><strong>Guest:</strong> ${booking.guest_name}</p>
                    <p><strong>Room:</strong> ${booking.room_number} (${booking.room_type})</p>
                    <p><strong>Original Check-in:</strong> ${formatDate(booking.check_in)}</p>
                    <p><strong>Original Check-out:</strong> ${formatDate(booking.check_out)}</p>
                    <p><strong>Days Remaining:</strong> ${eligibilityResponse.data.days_remaining} day(s)</p>
                </div>
        `;
        
        if (refundResponse.success) {
            const refund = refundResponse.data;
            modalContent += `
                <div class="early-checkout-refund-info">
                    <h4>Refund Calculation</h4>
                    <table class="refund-table">
                        <tr>
                            <td>Total Nights:</td>
                            <td>${refund.nights_calculation.total_nights}</td>
                        </tr>
                        <tr>
                            <td>Nights Stayed:</td>
                            <td>${refund.nights_calculation.stayed_nights}</td>
                        </tr>
                        <tr>
                            <td>Unused Nights:</td>
                            <td>${refund.nights_calculation.unused_nights}</td>
                        </tr>
                        <tr>
                            <td>Nightly Rate:</td>
                            <td>${formatCurrency(refund.financial_breakdown.nightly_rate)}</td>
                        </tr>
                        <tr>
                            <td>Amount Used:</td>
                            <td>${formatCurrency(refund.financial_breakdown.used_amount)}</td>
                        </tr>
                        <tr style="color: orange;">
                            <td>Gross Refund:</td>
                            <td>${formatCurrency(refund.financial_breakdown.gross_refund)}</td>
                        </tr>
                        <tr style="color: red;">
                            <td>Early Checkout Penalty (${refund.financial_breakdown.penalty_percentage}):</td>
                            <td>-${formatCurrency(refund.financial_breakdown.penalty_amount)}</td>
                        </tr>
                        <tr style="color: green; font-weight: bold; border-top: 2px solid #ddd;">
                            <td>Net Refund:</td>
                            <td>${formatCurrency(refund.financial_breakdown.net_refund)}</td>
                        </tr>
                    </table>
                </div>
            `;
        }
        
        modalContent += `
                <div class="early-checkout-reason">
                    <h4>Reason for Early Check-out</h4>
                    <textarea id="earlyCheckoutReason" placeholder="Please provide a reason for early checkout (optional)" rows="3"></textarea>
                </div>
                
                <div class="early-checkout-confirmation">
                    <label>
                        <input type="checkbox" id="processRefundCheckbox" checked>
                        Process refund automatically
                    </label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeEarlyCheckoutModal()">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="processEarlyCheckout(${bookingId})">Confirm Early Check-out</button>
            </div>
        `;
        
        document.getElementById('earlyCheckoutModalContent').innerHTML = modalContent;
        document.getElementById('earlyCheckoutModal').classList.add('show');
        document.body.classList.add('modal-open');
        
    } catch (error) {
        console.error('Error opening early checkout modal:', error);
        showNotification('Error: ' + (error.message || 'Failed to load early checkout details'), 'error');
    }
}

// Close early checkout modal
function closeEarlyCheckoutModal() {
    document.getElementById('earlyCheckoutModal').classList.remove('show');
    setTimeout(() => {
        if (document.querySelectorAll('.modal.show').length === 0) document.body.classList.remove('modal-open');
    }, 10);
}

// Process early checkout
async function processEarlyCheckout(bookingId) {
    try {
        const reason = document.getElementById('earlyCheckoutReason').value.trim();
        const processRefund = document.getElementById('processRefundCheckbox').checked;
        
        if (!confirm(
            `Are you sure you want to process early check-out?\\n\\n` +
            `This will:\\n` +
            `• Check out the guest immediately\\n` +
            `• Make the room available for new bookings\\n` +
            (processRefund ? `• Process the calculated refund\\n` : '') +
            `• This action cannot be undone`
        )) {
            return;
        }
        
        const requestData = {
            reason: reason || 'Early checkout requested',
            processRefund: processRefund
        };
        
        const response = await apiCall(
            `${API_ENDPOINTS.bookings}/${bookingId}/early-checkout/process`,
            {
                method: 'POST',
                body: JSON.stringify(requestData)
            }
        );
        
        if (response.success) {
            let message = '✓ Early check-out processed successfully!';
            
            if (response.data.refund_details && response.data.refund_details.financial_breakdown.net_refund > 0) {
                message += `\\n💰 Refund of ${formatCurrency(response.data.refund_details.financial_breakdown.net_refund)} will be processed.`;
            }
            
            showNotification(message, 'success');
            closeEarlyCheckoutModal();
            loadBookings();
        } else {
            showNotification('Error: ' + (response.message || 'Failed to process early checkout'), 'error');
        }
        
    } catch (error) {
        console.error('Error processing early checkout:', error);
        showNotification('Error: ' + (error.message || 'Failed to process early checkout'), 'error');
    }
}

// Cancel booking
async function cancelBooking(bookingId) {
    if (!confirm('Are you sure you want to cancel this booking? This action cannot be undone.')) return;
    
    try {
        const response = await apiCall(`${API_ENDPOINTS.bookings}/${bookingId}/cancel`, {
            method: 'PATCH'
        });
        
        if (response.success) {
            showNotification('✓ Booking cancelled successfully!', 'success');
            loadBookings();
        } else {
            showNotification('Error: ' + (response.message || 'Failed to cancel booking'), 'error');
        }
    } catch (error) {
        console.error('Error cancelling booking:', error);
        showNotification('Error: ' + (error.message || 'Failed to cancel booking'), 'error');
    }
}

// ====== BOOKING EXTENSION FUNCTIONS ======

// Open extension request modal
async function openExtensionModal(bookingId) {
    const booking = allBookings.find(b => b.booking_id == bookingId);
    if (!booking) return;
    
    document.getElementById('extensionBookingId').value = bookingId;
    document.getElementById('extensionCurrentCheckout').innerText = formatDate(booking.check_out);
    document.getElementById('currentRoomInfo').innerText = `Room ${booking.room_number} (${booking.room_type})`;
    // Set extension date input min/default to one day after current check-out (local date)
    const currentCheckout = new Date(booking.check_out);
    const nextDay = new Date(currentCheckout);
    nextDay.setDate(currentCheckout.getDate() + 1);
    const toYMD = (d) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
    const minDateStr = toYMD(nextDay);
    const extensionInput = document.getElementById('extensionNewCheckout');
    if (extensionInput) {
        extensionInput.min = minDateStr;
        // Pre-fill with next available date to avoid accidental past selections
        extensionInput.value = minDateStr;
    }
    document.getElementById('extensionResults').innerHTML = '';
    document.getElementById('extensionModal').classList.add('show');
    document.body.classList.add('modal-open');
}

function closeExtensionModal() {
    document.getElementById('extensionModal').classList.remove('show');
    setTimeout(() => {
        if (document.querySelectorAll('.modal.show').length === 0) document.body.classList.remove('modal-open');
    }, 10);
}

// Check extension options
async function checkExtensionOptions() {
    try {
        const bookingId = document.getElementById('extensionBookingId').value;
        const newCheckout = document.getElementById('extensionNewCheckout').value;
        
        if (!newCheckout) {
            showNotification('Please select a new check-out date', 'warning');
            return;
        }
        
        const response = await apiCall(`${API_ENDPOINTS.bookings}/${bookingId}/extension-options?new_check_out=${newCheckout}`);
        
        if (response.success) {
            displayExtensionOptions(response.data);
        } else {
            showNotification('Error: ' + (response.message || 'Failed to check options'), 'error');
        }
    } catch (error) {
        console.error('Error checking extension:', error);
        showNotification('Error: ' + (error.message || 'Failed to check extension options'), 'error');
    }
}

// Display extension options
function displayExtensionOptions(options) {
    const resultsDiv = document.getElementById('extensionResults');
    resultsDiv.innerHTML = '';
    
    // Show current status
    const statusHtml = `
        <div class="alert ${options.canExtend ? 'alert-success' : 'alert-danger'}" style="margin-bottom: 15px;">
            <strong>${options.canExtend ? '✓ Extension Available' : '✗ Conflict Detected'}</strong>
            <p style="margin: 5px 0 0 0;">${options.message || options.conflict?.message}</p>
        </div>
    `;
    resultsDiv.innerHTML += statusHtml;
    
    if (options.canExtend) {
        // Simple extension case
        const simpleHtml = `
            <div class="extension-option card" style="margin-bottom: 15px; padding: 15px;">
                <h5 style="margin: 0 0 10px 0;">✓ Same Room Extension</h5>
                <p style="font-size: 14px; margin: 5px 0;">
                    <strong>Period:</strong> ${formatDate(options.currentBooking.check_out)} to ${options.extensionRequest.new_check_out}
                    (${options.extensionRequest.nights_requested} nights)
                </p>
                <p style="font-size: 14px; margin: 5px 0;">
                    <strong>Cost:</strong> ${formatCurrency(options.currentBooking.room_price * options.extensionRequest.nights_requested)}
                </p>
                <button class="btn btn-success btn-sm" onclick="proceedWithExtension('${options.currentBooking.booking_id}', 'same_room')">
                    Approve Extension
                </button>
            </div>
        `;
        resultsDiv.innerHTML += simpleHtml;
    } else {
        // Show alternatives
        if (options.alternatives.alternative_rooms && options.alternatives.alternative_rooms.length > 0) {
            resultsDiv.innerHTML += '<h5 style="margin-top: 20px; margin-bottom: 10px;">Alternative Rooms Available:</h5>';
            
            options.alternatives.alternative_rooms.forEach(room => {
                const altHtml = `
                    <div class="extension-option card" style="margin-bottom: 10px; padding: 12px;">
                        <h6 style="margin: 0 0 5px 0;">Room ${room.room_number} - ${room.room_type}</h6>
                        <p style="font-size: 13px; margin: 3px 0;">
                            Amenities: ${room.amenities || 'N/A'}
                        </p>
                        <p style="font-size: 13px; margin: 3px 0;">
                            <strong>Extension Cost:</strong> ${formatCurrency(room.extension_cost)}
                        </p>
                        <button class="btn btn-info btn-sm" onclick="proceedWithExtension('${options.currentBooking.booking_id}', 'alternative_room', ${room.room_id})">
                            Book This Room
                        </button>
                    </div>
                `;
                resultsDiv.innerHTML += altHtml;
            });
        }
        
        if (options.alternatives.alternative_dates) {
            const altDatesHtml = `
                <div class="extension-option card" style="margin: 15px 0; padding: 12px; border-left: 4px solid #ffc107;">
                    <h5 style="margin: 0 0 10px 0; color: #ff6b6b;">⏳ Alternative Dates</h5>
                    <p style="font-size: 13px; margin: 3px 0;">
                        Current room will be available from: <strong>${formatDate(options.alternatives.alternative_dates.available_from)}</strong>
                    </p>
                    <p style="font-size: 13px; margin: 3px 0;">
                        Wait: <strong>${options.alternatives.alternative_dates.wait_period_days} days</strong>
                    </p>
                    <button class="btn btn-warning btn-sm" onclick="proceedWithExtension('${options.currentBooking.booking_id}', 'alternative_dates')">
                        Book Alternative Dates
                    </button>
                </div>
            `;
            resultsDiv.innerHTML += altDatesHtml;
        }
        
        if (options.alternatives.alternative_rooms.length === 0 && !options.alternatives.alternative_dates) {
            resultsDiv.innerHTML += `
                <div class="alert alert-warning" style="margin-top: 15px;">
                    <strong>No alternatives available</strong> - Please contact support for special requests.
                </div>
            `;
        }
    }
}

// Proceed with extension
async function proceedWithExtension(bookingId, resolutionType, alternativeRoomId = null) {
    try {
        const newCheckout = document.getElementById('extensionNewCheckout').value;
        
        const payload = {
            new_check_out: newCheckout,
            resolution_type: resolutionType
        };
        
        if (alternativeRoomId) {
            payload.resolution_details = {
                alternative_room_id: alternativeRoomId
            };
        }
        
        const response = await apiCall(`${API_ENDPOINTS.bookings}/${bookingId}/extend`, {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        
        if (response.success) {
            showNotification('✓ Booking extended successfully!', 'success');
            closeExtensionModal();
            loadBookings();
        } else {
            showNotification('Error: ' + (response.message || 'Failed to extend booking'), 'error');
        }
    } catch (error) {
        console.error('Error extending booking:', error);
        showNotification('Error: ' + (error.message || 'Failed to extend booking'), 'error');
    }
}

// Load bookings and attach global modal handlers on page load
window.addEventListener('DOMContentLoaded', function() {
    if (typeof loadBookings === 'function') loadBookings();

    // Close modals with Escape
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            // close any open modal by removing .show
            document.querySelectorAll('.modal.show').forEach(m => m.classList.remove('show'));
            // close any open action dropdowns
            document.querySelectorAll('.action-dropdown.show').forEach(d => d.classList.remove('show'));
        }
    });

    // Click outside to close modals (keeps existing behavior)
    window.addEventListener('click', function(event) {
        if (event.target.id === 'bookingModal') closeBookingModal();
        if (event.target.id === 'bookingDetailsModal') closeDetailsModal();
        if (event.target.id === 'extensionModal') closeExtensionModal();
    });

    // Sync guestSearch to guestName so single input works for search and entry
    const guestSearchEl = document.getElementById('guestSearch');
    const guestNameEl = document.getElementById('guestName');
    const selectedGuestIdEl = document.getElementById('selectedGuestId');
    if (guestSearchEl && guestNameEl) {
        guestSearchEl.addEventListener('input', function() {
            // if user types, clear any previously selected guest
            if (selectedGuestIdEl && selectedGuestIdEl.value) selectedGuestIdEl.value = '';
            guestNameEl.value = this.value;
        });
    }
});

// ============================================
// BILLING FUNCTIONS
// ============================================

// Generate invoice for a booking
async function handleGenerateInvoice(bookingId) {
    if (confirm('Generate invoice for this booking?')) {
        await generateInvoice(bookingId);
        setTimeout(() => loadBookings(), 1000);
    }
}

// View invoice for a booking
async function handleViewInvoice(bookingId) {
    try {
        if (!bookingId) {
            showNotification('Error: Invalid booking ID', 'error');
            return;
        }
        
        showNotification('Loading invoice...', 'info');
        const invoice = await getInvoiceByBooking(bookingId);
        
        if (invoice) {
            displayInvoiceModal(invoice);
        } else {
            showNotification('No invoice found for this booking', 'warning');
        }
    } catch (error) {
        console.error('Error loading invoice:', error);
        showNotification('Error loading invoice: ' + error.message, 'error');
    }
}

// Display invoice in modal
async function displayInvoiceModal(invoice) {
    const modal = document.getElementById('invoiceModal');
    const content = document.getElementById('invoiceContent');
    
    if (!modal || !content) {
        console.error('Invoice modal elements not found in DOM');
        showNotification('Error: Invoice modal not available', 'error');
        return;
    }
    
    if (!invoice) {
        console.error('No invoice data provided');
        showNotification('Error: No invoice data to display', 'error');
        return;
    }

    const subtotalAfterDiscount = parseFloat(invoice.subtotal || 0) - parseFloat(invoice.discount_amount || 0);
    
    let itemsHTML = (invoice.items && invoice.items.length > 0) ? invoice.items.map(item => `
        <tr>
            <td>${item.description}</td>
            <td style="text-align: right;">${parseFloat(item.quantity).toFixed(2)}</td>
            <td style="text-align: right;">₹${parseFloat(item.unit_price).toFixed(2)}</td>
            <td style="text-align: right;">₹${parseFloat(item.total_price).toFixed(2)}</td>
        </tr>
    `).join('') : '<tr><td colspan="4" class="text-center text-muted">No items found</td></tr>';

    let paymentsHTML = invoice.payments && invoice.payments.length > 0 
        ? invoice.payments.map(p => `
            <tr>
                <td>${p.payment_number}</td>
                <td>${new Date(p.payment_date).toLocaleDateString()}</td>
                <td>${p.payment_method}</td>
                <td style="text-align: right;">₹${parseFloat(p.amount).toFixed(2)}</td>
                <td><span class="badge badge-success">${p.payment_status}</span></td>
            </tr>
        `).join('')
        : '<tr><td colspan="5" class="text-center text-muted">No payments recorded</td></tr>';

    content.innerHTML = `
        <div style="padding-bottom: 20px;">
            <h3>Invoice #${invoice.invoice_number}</h3>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                <div>
                    <p style="margin-bottom: 5px; color: #666; font-size: 12px;">Invoice Date</p>
                    <p style="font-weight: bold;">${new Date(invoice.invoice_date).toLocaleDateString()}</p>
                </div>
                <div>
                    <p style="margin-bottom: 5px; color: #666; font-size: 12px;">Due Date</p>
                    <p style="font-weight: bold;">${new Date(invoice.due_date).toLocaleDateString()}</p>
                </div>
                <div>
                    <p style="margin-bottom: 5px; color: #666; font-size: 12px;">Status</p>
                    <p style="font-weight: bold;"><span class="badge badge-${invoice.status === 'Paid' ? 'success' : invoice.status === 'Partially_Paid' ? 'warning' : 'danger'}">${invoice.status.replace(/_/g, ' ')}</span></p>
                </div>
            </div>

            <h4 style="margin-top: 20px; border-top: 1px solid #ddd; padding-top: 15px;">Guest & Room Information</h4>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                <div>
                    <p style="margin: 5px 0;"><strong>${invoice.guest_name}</strong></p>
                    <p style="margin: 5px 0; color: #666;">Phone: ${invoice.guest_phone}</p>
                </div>
                <div>
                    <p style="margin: 5px 0;"><strong>Room ${invoice.room_number}</strong></p>
                    <p style="margin: 5px 0; color: #666;">Check-in: ${new Date(invoice.check_in_date).toLocaleDateString()}</p>
                    <p style="margin: 5px 0; color: #666;">Check-out: ${new Date(invoice.check_out_date).toLocaleDateString()}</p>
                </div>
            </div>

            <h4 style="margin-top: 20px; border-top: 1px solid #ddd; padding-top: 15px;">Invoice Items</h4>
            <table style="width: 100%; margin-bottom: 20px; border-collapse: collapse;">
                <thead style="background-color: #f5f5f5; border-bottom: 2px solid #333;">
                    <tr>
                        <th style="padding: 10px; text-align: left;">Description</th>
                        <th style="padding: 10px; text-align: right;">Qty</th>
                        <th style="padding: 10px; text-align: right;">Unit Price</th>
                        <th style="padding: 10px; text-align: right;">Total</th>
                    </tr>
                </thead>
                <tbody>
                    ${itemsHTML}
                </tbody>
            </table>

            <h4 style="margin-top: 20px; border-top: 1px solid #ddd; padding-top: 15px;">Summary</h4>
            <div style="width: 50%; margin-left: auto; margin-bottom: 20px;">
                <div style="display: flex; justify-content: space-between; padding: 8px 0;">
                    <span>Subtotal:</span>
                    <span>₹${parseFloat(invoice.subtotal).toFixed(2)}</span>
                </div>
                ${invoice.discount_amount > 0 ? `
                    <div style="display: flex; justify-content: space-between; padding: 8px 0;">
                        <span>Discount (${invoice.discount_type}):</span>
                        <span>-₹${parseFloat(invoice.discount_amount).toFixed(2)}</span>
                    </div>
                ` : ''}
                ${invoice.tax_amount > 0 ? `
                    <div style="display: flex; justify-content: space-between; padding: 8px 0;">
                        <span>Tax (${invoice.tax_rate}%):</span>
                        <span>₹${parseFloat(invoice.tax_amount).toFixed(2)}</span>
                    </div>
                ` : ''}
                <div style="display: flex; justify-content: space-between; padding: 10px 0; border-top: 2px solid #333; font-weight: bold; font-size: 16px;">
                    <span>Grand Total:</span>
                    <span>₹${parseFloat(invoice.grand_total).toFixed(2)}</span>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 8px 0; color: green;">
                    <span>Amount Paid:</span>
                    <span>₹${parseFloat(invoice.amount_paid).toFixed(2)}</span>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 8px 0; color: red; font-weight: bold;">
                    <span>Amount Due:</span>
                    <span>₹${parseFloat(invoice.amount_due).toFixed(2)}</span>
                </div>
            </div>

            ${invoice.payments && invoice.payments.length > 0 ? `
                <h4 style="margin-top: 20px; border-top: 1px solid #ddd; padding-top: 15px;">Payment History</h4>
                <table style="width: 100%; margin-bottom: 20px; border-collapse: collapse;">
                    <thead style="background-color: #f5f5f5; border-bottom: 2px solid #333;">
                        <tr>
                            <th style="padding: 10px; text-align: left;">Payment #</th>
                            <th style="padding: 10px; text-align: left;">Date</th>
                            <th style="padding: 10px; text-align: left;">Method</th>
                            <th style="padding: 10px; text-align: right;">Amount</th>
                            <th style="padding: 10px; text-align: left;">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${paymentsHTML}
                    </tbody>
                </table>
            ` : ''}

            <div style="display: flex; gap: 10px; margin-top: 20px; padding-top: 15px; border-top: 1px solid #ddd;">
                <button onclick="printInvoice(${invoice.invoice_id})" class="btn btn-primary" style="flex: 1;">
                    <i class="fas fa-print"></i> Print Invoice
                </button>
                <button onclick="handleRecordPaymentForInvoice(${invoice.invoice_id})" class="btn btn-success" ${invoice.amount_due <= 0 ? 'disabled' : ''} style="flex: 1;">
                    <i class="fas fa-money-bill"></i> Record Payment
                </button>
                <button onclick="closeInvoiceModal()" class="btn btn-secondary" style="flex: 1;">Close</button>
            </div>
        </div>
    `;

    if (modal) {
        modal.style.display = 'flex';
        document.body.classList.add('modal-open');
    }
}

// Close invoice modal
function closeInvoiceModal() {
    const modal = document.getElementById('invoiceModal');
    if (modal) {
        modal.style.display = 'none';
        document.body.classList.remove('modal-open');
    }
}

// Print invoice function
function printInvoice(invoiceId) {
    if (!invoiceId) {
        showNotification('Error: Invalid invoice ID', 'error');
        return;
    }
    
    try {
        // Create a new window for printing
        const printWindow = window.open('', 'printInvoice', 'width=800,height=600');
        const content = document.getElementById('invoiceContent');
        
        if (!content) {
            showNotification('Error: Invoice content not available for printing', 'error');
            return;
        }
        
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Invoice #${invoiceId}</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; }
                    table { width: 100%; border-collapse: collapse; margin: 10px 0; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                    th { background-color: #f2f2f2; }
                    .header { text-align: center; margin-bottom: 30px; }
                    .total-section { margin-top: 20px; }
                    @media print { button { display: none; } }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>Hotel Management System</h1>
                    <h2>Invoice</h2>
                </div>
                ${content.innerHTML.replace(/<button[^>]*>.*?<\/button>/gi, '')}
            </body>
            </html>
        `);
        
        printWindow.document.close();
        printWindow.focus();
        
        // Print after a short delay to ensure content is loaded
        setTimeout(() => {
            printWindow.print();
            printWindow.close();
        }, 250);
        
    } catch (error) {
        console.error('Print error:', error);
        showNotification('Error printing invoice: ' + error.message, 'error');
    }
}

// Record payment for booking
async function handleRecordPayment(bookingId, guestId) {
    try {
        // Ensure modal elements exist before proceeding
        if (!document.getElementById('paymentModal')) {
            createPaymentModalIfMissing();
            // Wait a moment for DOM elements to be available
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        
        const invoice = await getInvoiceByBooking(bookingId);
        if (!invoice) {
            showNotification('No invoice found for this booking. Please generate an invoice first.', 'warning');
            return;
        }
        
        if (invoice.amount_due <= 0) {
            showNotification('This invoice has been fully paid.', 'info');
            return;
        }
        
        // Verify elements exist before setting values
        const requiredElements = ['paymentBookingId', 'paymentInvoiceId', 'paymentGuestId', 'paymentAmount', 'paymentTotalDisplay', 'paymentMethod'];
        const missingElements = requiredElements.filter(id => !document.getElementById(id));
        
        if (missingElements.length > 0) {
            console.error('Missing payment form elements:', missingElements);
            // Try creating the modal again
            createPaymentModalIfMissing();
            await new Promise(resolve => setTimeout(resolve, 100));
            
            // Check again
            const stillMissing = requiredElements.filter(id => !document.getElementById(id));
            if (stillMissing.length > 0) {
                console.error('Still missing elements after recreation:', stillMissing);
                showNotification('Payment form is not available. Please refresh the page.', 'error');
                return;
            }
        }
        
        // Safely set values with null checks
        const paymentBookingId = document.getElementById('paymentBookingId');
        const paymentInvoiceId = document.getElementById('paymentInvoiceId');
        const paymentGuestId = document.getElementById('paymentGuestId');
        const paymentAmount = document.getElementById('paymentAmount');
        const paymentTotalDisplay = document.getElementById('paymentTotalDisplay');
        
        if (paymentBookingId) paymentBookingId.value = bookingId;
        if (paymentInvoiceId) paymentInvoiceId.value = invoice.invoice_id;
        if (paymentGuestId) paymentGuestId.value = guestId;
        if (paymentAmount) paymentAmount.value = invoice.amount_due;
        if (paymentTotalDisplay) paymentTotalDisplay.textContent = parseFloat(invoice.amount_due).toFixed(2);
        
        openPaymentModal(bookingId, invoice.invoice_id);
    } catch (error) {
        console.error('Error opening payment modal:', error);
        showNotification('Error loading payment information: ' + error.message, 'error');
    }
}

// Record payment for invoice
async function handleRecordPaymentForInvoice(invoiceId) {
    try {
        const invoice = await getInvoiceDetails(invoiceId);
        if (!invoice) {
            showNotification('Invoice not found', 'error');
            return;
        }
        
        if (invoice.amount_due <= 0) {
            showNotification('This invoice has been fully paid.', 'info');
            return;
        }

        document.getElementById('paymentBookingId').value = invoice.booking_id;
        document.getElementById('paymentInvoiceId').value = invoiceId;
        document.getElementById('paymentGuestId').value = invoice.guest_id;
        document.getElementById('paymentAmount').value = invoice.amount_due;
        document.getElementById('paymentTotalDisplay').textContent = parseFloat(invoice.amount_due).toFixed(2);
        
        closeInvoiceModal();
        openPaymentModal(invoice.booking_id, invoiceId);
    } catch (error) {
        console.error('Error opening payment modal:', error);
        showNotification('Error loading payment information: ' + error.message, 'error');
    }
}

// ====== REAL-TIME ROOM STATUS FUNCTIONS ======

// Load early checkouts for today
async function loadTodayEarlyCheckouts() {
    try {
        const response = await apiCall(`${API_ENDPOINTS.bookings}/today/early-checkouts`);
        if (response.success && response.data.length > 0) {
            displayEarlyCheckoutNotification(response.data);
        }
    } catch (error) {
        console.error('Error loading early checkouts:', error);
    }
}

// Display early checkout notification
function displayEarlyCheckoutNotification(earlyCheckouts) {
    const count = earlyCheckouts.length;
    const rooms = earlyCheckouts.map(checkout => checkout.room_number).join(', ');
    
    showNotification(
        `🏃‍♀️ ${count} room(s) became available early today: ${rooms}`,
        'success',
        8000 // Show for 8 seconds
    );
}

// Check room availability in real-time
async function checkRoomAvailability(roomId, startDate, endDate) {
    try {
        const response = await apiCall(`${API_ENDPOINTS.bookings}/availability/${roomId}?start_date=${startDate}&end_date=${endDate}`);
        return response.data;
    } catch (error) {
        console.error('Error checking room availability:', error);
        return { available: false, conflicts: [], error: error.message };
    }
}

// Handle immediate room availability after early checkout
async function handleEarlyCheckoutAvailability(roomId, guestId) {
    try {
        const response = await apiCall(`${API_ENDPOINTS.bookings}/early-checkout`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ room_id: roomId, guest_id: guestId })
        });
        
        if (response.success) {
            showNotification('Room is now available for immediate booking!', 'success');
            // Refresh displays
            loadBookings();
            if (typeof loadRooms === 'function') {
                loadRooms();
            }
        }
        
        return response;
    } catch (error) {
        console.error('Error handling early checkout:', error);
        return { success: false, error: error.message };
    }
}

// Initialize real-time updates
document.addEventListener('DOMContentLoaded', function() {
    // Load early checkouts when page loads
    if (typeof loadTodayEarlyCheckouts === 'function') {
        loadTodayEarlyCheckouts();
    }
    
    // Verify modal elements exist
    verifyModalElements();
    
    // Set up periodic checks for early checkouts (every 5 minutes)
    setInterval(() => {
        if (typeof loadTodayEarlyCheckouts === 'function') {
            loadTodayEarlyCheckouts();
        }
    }, 300000); // 5 minutes
});

// Verify that required modal elements exist in the DOM
function verifyModalElements() {
    const requiredElements = [
        'invoiceModal',
        'invoiceContent',
        'paymentModal',
        'paymentBookingId',
        'paymentInvoiceId',
        'paymentGuestId',
        'paymentAmount',
        'paymentTotalDisplay',
        'paymentMethod',
        'paymentReference',
        'paymentNotes',
        'earlyCheckoutModal', 
        'earlyCheckoutModalContent'
    ];
    
    const missingElements = requiredElements.filter(id => !document.getElementById(id));
    
    if (missingElements.length > 0) {
        console.warn('Missing modal elements:', missingElements);
        
        // Create missing elements if needed
        const needsInvoiceModal = missingElements.some(id => id.includes('invoice'));
        const needsPaymentModal = missingElements.some(id => id.includes('payment'));
        
        if (needsInvoiceModal) {
            createInvoiceModalIfMissing();
            console.log('✅ Invoice modal created');
        }
        
        if (needsPaymentModal) {
            createPaymentModalIfMissing();
            console.log('✅ Payment modal created');
            
            // Double-check that payment elements exist after creation
            setTimeout(() => {
                const paymentElements = requiredElements.filter(id => id.includes('payment'));
                const stillMissing = paymentElements.filter(id => !document.getElementById(id));
                if (stillMissing.length === 0) {
                    console.log('✅ All payment modal elements verified');
                } else {
                    console.error('❌ Payment modal elements still missing:', stillMissing);
                }
            }, 50);
        }
    } else {
        console.log('✅ All modal elements found');
    }
}

// Create invoice modal if it's missing from the DOM
function createInvoiceModalIfMissing() {
    if (!document.getElementById('invoiceModal')) {
        const modalHTML = `
            <div id="invoiceModal" class="modal">
                <div class="modal-content" style="max-width: 800px; max-height: 90vh; overflow-y: auto;">
                    <div class="modal-header">
                        <h2>Invoice Details</h2>
                        <span class="close" onclick="closeInvoiceModal()">&times;</span>
                    </div>
                    <div class="modal-body" id="invoiceContent">
                        <p>Loading invoice details...</p>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        console.log('✅ Created missing invoice modal');
    }
}

// Create payment modal if it's missing from the DOM
function createPaymentModalIfMissing() {
    // Remove any existing payment modal first
    const existingModal = document.getElementById('paymentModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    const paymentModalHTML = `
        <div id="paymentModal" class="modal">
            <div class="modal-content" style="max-width: 600px;">
                <div class="modal-header">
                    <h2>Record Payment</h2>
                    <span class="close" onclick="closePaymentModal()">&times;</span>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="paymentBookingId">
                    <input type="hidden" id="paymentInvoiceId">
                    <input type="hidden" id="paymentGuestId">

                    <div class="form-group">
                        <label for="paymentAmount">Amount (₹) *</label>
                        <input type="number" id="paymentAmount" step="0.01" placeholder="Enter payment amount" required>
                    </div>

                    <div class="form-group">
                        <label for="paymentMethod">Payment Method *</label>
                        <select id="paymentMethod" required>
                            <option value="">Select payment method</option>
                            <option value="Cash">Cash</option>
                            <option value="Credit Card">Credit Card</option>
                            <option value="Debit Card">Debit Card</option>
                            <option value="UPI">UPI</option>
                            <option value="Net Banking">Net Banking</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="paymentReference">Reference Number</label>
                        <input type="text" id="paymentReference" placeholder="e.g., Transaction ID, Cheque No.">
                    </div>

                    <div class="form-group">
                        <label for="paymentNotes">Notes</label>
                        <textarea id="paymentNotes" rows="3" placeholder="Any additional notes..."></textarea>
                    </div>

                    <div style="background: #f0f0f0; padding: 15px; border-radius: 5px; margin-bottom: 15px;">
                        <p style="margin: 0;"><strong>Total Amount:</strong> ₹<span id="paymentTotalDisplay">0.00</span></p>
                    </div>

                    <div style="display: flex; gap: 10px;">
                        <button type="button" onclick="submitPaymentForm()" class="btn btn-success" style="flex: 1;">Record Payment</button>
                        <button type="button" onclick="closePaymentModal()" class="btn btn-secondary" style="flex: 1;">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', paymentModalHTML);
    console.log('✅ Payment modal created with all elements');
    
    // Verify elements were actually created
    const createdElements = ['paymentModal', 'paymentBookingId', 'paymentInvoiceId', 'paymentGuestId', 'paymentAmount', 'paymentTotalDisplay', 'paymentMethod', 'paymentReference', 'paymentNotes'];
    const missing = createdElements.filter(id => !document.getElementById(id));
    if (missing.length > 0) {
        console.error('❌ Failed to create payment elements:', missing);
    } else {
        console.log('✅ All payment modal elements successfully created');
    }
}

// Open payment modal
function openPaymentModal(bookingId, invoiceId) {
    const modal = document.getElementById('paymentModal');
    if (modal) {
        modal.style.display = 'block';
    } else {
        console.error('Payment modal not found');
    }
}

// Close payment modal
function closePaymentModal() {
    const modal = document.getElementById('paymentModal');
    if (modal) {
        modal.style.display = 'none';
        // Clear form fields
        ['paymentAmount', 'paymentMethod', 'paymentReference', 'paymentNotes'].forEach(id => {
            const element = document.getElementById(id);
            if (element) element.value = '';
        });
    }
}

// Submit payment form
async function submitPaymentForm() {
    try {
        const bookingId = document.getElementById('paymentBookingId')?.value;
        const invoiceId = document.getElementById('paymentInvoiceId')?.value;
        const guestId = document.getElementById('paymentGuestId')?.value;
        const amount = document.getElementById('paymentAmount')?.value;
        const paymentMethod = document.getElementById('paymentMethod')?.value;
        const reference = document.getElementById('paymentReference')?.value;
        const notes = document.getElementById('paymentNotes')?.value;

        if (!bookingId || !invoiceId || !guestId || !amount || !paymentMethod) {
            showNotification('Please fill in all required fields', 'error');
            return;
        }

        const paymentData = {
            booking_id: parseInt(bookingId),
            invoice_id: parseInt(invoiceId),
            guest_id: parseInt(guestId),
            amount: parseFloat(amount),
            payment_method: paymentMethod,
            reference_number: reference || null,
            notes: notes || null
        };

        const response = await fetch(`${API_BASE_URL}/payments`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(paymentData)
        });

        if (response.ok) {
            const result = await response.json();
            showNotification('Payment recorded successfully!', 'success');
            closePaymentModal();
            await loadBookings(); // Refresh the bookings list
        } else {
            let errorMessage = 'Unknown error occurred';
            
            // Try to get error message from response
            try {
                const contentType = response.headers.get('content-type');
                if (contentType && contentType.includes('application/json')) {
                    const error = await response.json();
                    errorMessage = error.message || error.errors?.join(', ') || `Error ${response.status}`;
                } else {
                    // Handle non-JSON responses (like HTML error pages)
                    const text = await response.text();
                    errorMessage = `Server error (${response.status}): ${response.statusText}`;
                    console.error('Non-JSON error response:', text);
                }
            } catch (parseError) {
                errorMessage = `Error ${response.status}: ${response.statusText}`;
                console.error('Error parsing response:', parseError);
            }
            
            showNotification(`Error recording payment: ${errorMessage}`, 'error');
        }
    } catch (error) {
        console.error('Error submitting payment:', error);
        showNotification('Error submitting payment: ' + error.message, 'error');
    }
}
