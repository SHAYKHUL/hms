// Inventory Management - Frontend Logic
// Handles API interactions, display updates, and user interactions

let currentEditingItemId = null;
let allItems = [];
let allCategories = [];
let allTransactions = [];

// Initialize on page load
document.addEventListener('DOMContentLoaded', async function() {
    console.log('Inventory page loaded');
    await loadInventory();
    await loadCategories();
    await loadStatistics();
});

// Load all inventory items
async function loadInventory() {
    try {
        console.log('Loading inventory items...');
        const response = await fetch(`${API_BASE_URL}/inventories`);
        const result = await response.json();

        if (result.success) {
            allItems = result.data || [];
            console.log(`Loaded ${allItems.length} items`);
            displayItems(allItems);
        } else {
            console.error('Failed to load items:', result.message);
            showError('Failed to load inventory items');
        }
    } catch (error) {
        console.error('Error loading inventory:', error);
        showError('Error loading inventory items');
    }
}

// Load all categories
async function loadCategories() {
    try {
        console.log('Loading categories...');
        const response = await fetch(`${API_BASE_URL}/inventories/categories`);
        const result = await response.json();

        if (result.success) {
            allCategories = result.data || [];
            console.log(`Loaded ${allCategories.length} categories`);
            displayCategories(allCategories);
            populateCategoryDropdown();
        } else {
            console.error('Failed to load categories:', result.message);
        }
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

// Load inventory statistics
async function loadStatistics() {
    try {
        console.log('Loading statistics...');
        
        // Total items
        document.getElementById('statTotalItems').textContent = allItems.length;

        // Total value and low stock count
        let totalValue = 0;
        let lowStockCount = 0;

        for (const item of allItems) {
            if (item.inventory_stock) {
                totalValue += parseFloat(item.inventory_stock.total_value) || 0;
                const currentQty = parseInt(item.inventory_stock.current_quantity) || 0;
                const minThreshold = parseInt(item.inventory_stock.minimum_quantity) || 0;
                if (currentQty <= minThreshold) {
                    lowStockCount++;
                }
            }
        }

        document.getElementById('statTotalValue').textContent = `₹${totalValue.toFixed(2)}`;
        document.getElementById('statLowStock').textContent = lowStockCount;
        document.getElementById('statCategories').textContent = allCategories.length;

        console.log(`Statistics: ${allItems.length} items, ₹${totalValue}, ${lowStockCount} low stock`);
    } catch (error) {
        console.error('Error loading statistics:', error);
    }
}

// Display items in the items list
function displayItems(items) {
    const itemsList = document.getElementById('itemsList');
    
    if (!items || items.length === 0) {
        itemsList.innerHTML = '<div class="empty-state"><i class="fas fa-inbox"></i><p>No items found</p></div>';
        return;
    }

    let html = '<div class="item-row header">';
    html += '<div>Item Name</div>';
    html += '<div>Category</div>';
    html += '<div>Stock</div>';
    html += '<div>Unit Cost</div>';
    html += '<div>Total Value</div>';
    html += '<div>Actions</div>';
    html += '</div>';

    items.forEach(item => {
        const stock = item.inventory_stock || {};
        const currentQty = parseInt(stock.current_quantity) || 0;
        const minThreshold = parseInt(stock.minimum_quantity) || 0;
        const unitCost = parseFloat(item.unit_cost) || 0;
        const totalValue = parseFloat(stock.total_value) || 0;

        let stockClass = 'stock-good';
        if (currentQty <= minThreshold) {
            stockClass = 'stock-danger';
        } else if (currentQty <= parseInt(stock.reorder_quantity)) {
            stockClass = 'stock-warning';
        }

        const categoryName = item.category_name || 'N/A';
        const unit = item.unit || '';

        html += '<div class="item-row">';
        html += `<div class="item-name">${escapeHtml(item.item_name)}</div>`;
        html += `<div>${escapeHtml(categoryName)}</div>`;
        html += `<div class="stock-level"><span class="${stockClass}">${currentQty} ${unit}</span></div>`;
        html += `<div>₹${unitCost.toFixed(2)}</div>`;
        html += `<div>₹${totalValue.toFixed(2)}</div>`;
        html += '<div class="action-buttons">';
        html += `<button class="btn-small btn-restock" onclick="openRestockModal(${item.item_id}, '${escapeHtml(item.item_name)}', ${currentQty})"><i class="fas fa-plus"></i></button>`;
        html += `<button class="btn-small btn-edit" onclick="openEditItemModal(${item.item_id})"><i class="fas fa-edit"></i></button>`;
        html += '</div>';
        html += '</div>';
    });

    itemsList.innerHTML = html;
}

// Display categories
function displayCategories(categories) {
    const categoriesList = document.getElementById('categoriesList');
    
    if (!categories || categories.length === 0) {
        categoriesList.innerHTML = '<div class="empty-state"><i class="fas fa-folder-open"></i><p>No categories found</p></div>';
        return;
    }

    let html = '';
    categories.forEach(category => {
        const itemCount = allItems.filter(i => i.category_id === category.category_id).length;
        
        html += `<div class="category-item">`;
        html += `<h3>${escapeHtml(category.category_name)}</h3>`;
        html += `<p>${itemCount} items</p>`;
        if (category.description) {
            html += `<p style="margin-top: 0.5rem; font-size: 0.85rem;">${escapeHtml(category.description)}</p>`;
        }
        html += `<div style="margin-top: 1rem; display: flex; gap: 0.5rem;">`;
        html += `<button class="btn-small btn-edit" onclick="openEditCategoryModal(${category.category_id})"><i class="fas fa-edit"></i></button>`;
        html += `<button class="btn-small btn-delete" onclick="deleteCategory(${category.category_id})"><i class="fas fa-trash"></i></button>`;
        html += `</div>`;
        html += `</div>`;
    });

    categoriesList.innerHTML = html;
}

// Load and display low stock items
async function loadLowStockItems() {
    try {
        console.log('Loading low stock items...');
        const response = await fetch(`${API_BASE_URL}/inventories/status/low-stock`);
        const result = await response.json();

        if (result.success) {
            const lowStockItems = result.data || [];
            console.log(`Found ${lowStockItems.length} low stock items`);
            displayLowStockItems(lowStockItems);
        } else {
            console.error('Failed to load low stock items:', result.message);
        }
    } catch (error) {
        console.error('Error loading low stock items:', error);
    }
}

// Display low stock items
function displayLowStockItems(items) {
    const lowStockList = document.getElementById('lowStockList');
    
    if (!items || items.length === 0) {
        lowStockList.innerHTML = '<div class="empty-state"><i class="fas fa-check-circle"></i><p>All items are adequately stocked</p></div>';
        return;
    }

    let html = '<div class="item-row header">';
    html += '<div>Item Name</div>';
    html += '<div>Current Stock</div>';
    html += '<div>Min Threshold</div>';
    html += '<div>Status</div>';
    html += '<div>Actions</div>';
    html += '</div>';

    items.forEach(item => {
        const stock = item.inventory_stock || {};
        const currentQty = parseInt(stock.current_quantity) || 0;
        const minThreshold = parseInt(stock.minimum_quantity) || 0;
        const unit = item.unit || '';

        html += '<div class="item-row">';
        html += `<div class="item-name">${escapeHtml(item.item_name)}</div>`;
        html += `<div class="stock-danger">${currentQty} ${unit}</div>`;
        html += `<div>${minThreshold} ${unit}</div>`;
        html += `<div><span class="status-badge status-inactive"><i class="fas fa-exclamation-circle"></i> Low Stock</span></div>`;
        html += '<div class="action-buttons">';
        html += `<button class="btn-small btn-restock" onclick="openRestockModal(${item.item_id}, '${escapeHtml(item.item_name)}', ${currentQty})"><i class="fas fa-plus"></i> Restock</button>`;
        html += '</div>';
        html += '</div>';
    });

    lowStockList.innerHTML = html;
}

// Load and display all transactions
async function loadAllTransactions() {
    try {
        console.log('Loading transactions...');
        const response = await fetch(`${API_BASE_URL}/inventories/history/all`);
        const result = await response.json();

        if (result.success) {
            allTransactions = result.data || [];
            console.log(`Loaded ${allTransactions.length} transactions`);
            displayTransactions(allTransactions);
        } else {
            console.error('Failed to load transactions:', result.message);
        }
    } catch (error) {
        console.error('Error loading transactions:', error);
    }
}

// Display transactions
function displayTransactions(transactions) {
    const transactionsList = document.getElementById('transactionsList');
    
    if (!transactions || transactions.length === 0) {
        transactionsList.innerHTML = '<div class="empty-state"><i class="fas fa-history"></i><p>No transactions recorded</p></div>';
        return;
    }

    let html = '';
    transactions.forEach(transaction => {
        const date = new Date(transaction.created_at);
        const formattedDate = date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
        
        let typeClass = '';
        if (transaction.transaction_type === 'Restock') typeClass = 'type-restock';
        else if (transaction.transaction_type === 'Consume') typeClass = 'type-consume';
        else typeClass = 'type-adjustment';

        const itemName = allItems.find(i => i.item_id === transaction.item_id)?.item_name || `Item #${transaction.item_id}`;
        const qtyChange = parseInt(transaction.quantity_change) || 0;
        const qtySign = qtyChange >= 0 ? '+' : '';

        html += '<div class="transaction-item">';
        html += '<div class="transaction-info">';
        html += `<div class="transaction-type"><span class="${typeClass}">${transaction.transaction_type}</span> - ${escapeHtml(itemName)}</div>`;
        html += `<div class="transaction-date">${formattedDate}</div>`;
        if (transaction.notes) {
            html += `<div class="transaction-date">${escapeHtml(transaction.notes)}</div>`;
        }
        html += '</div>';
        html += `<div class="transaction-qty">${qtySign}${qtyChange}</div>`;
        html += '</div>';
    });

    transactionsList.innerHTML = html;
}

// Switch between tabs
function switchTab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));

    // Show selected tab
    document.getElementById(tabName).classList.add('active');
    event.target.classList.add('active');

    // Load data for specific tabs
    if (tabName === 'low-stock') {
        loadLowStockItems();
    } else if (tabName === 'transactions') {
        loadAllTransactions();
    }
}

// Search inventory items
async function searchInventory() {
    const searchTerm = document.getElementById('searchInput').value.trim();
    
    if (!searchTerm) {
        displayItems(allItems);
        return;
    }

    try {
        console.log(`Searching for: ${searchTerm}`);
        const response = await fetch(`${API_BASE_URL}/inventories/search/${encodeURIComponent(searchTerm)}`);
        const result = await response.json();

        if (result.success) {
            displayItems(result.data || []);
        } else {
            showError('Search failed');
        }
    } catch (error) {
        console.error('Error searching:', error);
        showError('Error searching inventory');
    }
}

// Modal Functions

function openNewItemModal() {
    currentEditingItemId = null;
    document.getElementById('itemModalTitle').textContent = 'Add Inventory Item';
    document.getElementById('itemForm').reset();
    document.getElementById('itemModal').classList.add('active');
}

function openEditItemModal(itemId) {
    currentEditingItemId = itemId;
    const item = allItems.find(i => i.item_id === itemId);
    
    if (!item) {
        showError('Item not found');
        return;
    }

    document.getElementById('itemModalTitle').textContent = 'Edit Item';
    document.getElementById('itemName').value = item.item_name;
    document.getElementById('itemCategory').value = item.category_id;
    document.getElementById('itemUnit').value = item.unit;
    document.getElementById('itemCost').value = parseFloat(item.unit_cost) || 0;
    document.getElementById('itemDescription').value = item.description || '';
    document.getElementById('itemSupplier').value = item.supplier_name || '';
    document.getElementById('itemSupplierPhone').value = item.supplier_phone || '';

    document.getElementById('itemModal').classList.add('active');
}

function closeItemModal() {
    document.getElementById('itemModal').classList.remove('active');
    document.getElementById('itemForm').reset();
    currentEditingItemId = null;
}

function openNewCategoryModal() {
    document.getElementById('categoryModalTitle').textContent = 'Add Category';
    document.getElementById('categoryForm').reset();
    document.getElementById('categoryModal').classList.add('active');
}

function openEditCategoryModal(categoryId) {
    const category = allCategories.find(c => c.category_id === categoryId);
    
    if (!category) {
        showError('Category not found');
        return;
    }

    document.getElementById('categoryModalTitle').textContent = 'Edit Category';
    document.getElementById('categoryName').value = category.category_name;
    document.getElementById('categoryDescription').value = category.description || '';
    document.getElementById('categoryModal').dataset.editingId = categoryId;
    document.getElementById('categoryModal').classList.add('active');
}

function closeCategoryModal() {
    document.getElementById('categoryModal').classList.remove('active');
    document.getElementById('categoryForm').reset();
    delete document.getElementById('categoryModal').dataset.editingId;
}

function openRestockModal(itemId, itemName, currentQty) {
    document.getElementById('restockItemName').textContent = itemName;
    document.getElementById('restockCurrentQty').textContent = `${parseInt(currentQty) || 0}`;
    document.getElementById('restockQuantity').value = '';
    document.getElementById('restockNotes').value = '';
    document.getElementById('restockModal').dataset.itemId = itemId;
    document.getElementById('restockModal').classList.add('active');
}

function closeRestockModal() {
    document.getElementById('restockModal').classList.remove('active');
    document.getElementById('restockForm').reset();
    delete document.getElementById('restockModal').dataset.itemId;
}

// Save or Update Item
async function saveItem(event) {
    event.preventDefault();

    const itemName = document.getElementById('itemName').value.trim();
    const categoryId = document.getElementById('itemCategory').value;
    const unit = document.getElementById('itemUnit').value;
    const unitCost = parseFloat(document.getElementById('itemCost').value) || 0;
    const description = document.getElementById('itemDescription').value.trim();
    const supplierName = document.getElementById('itemSupplier').value.trim();
    const supplierPhone = document.getElementById('itemSupplierPhone').value.trim();

    if (!itemName || !categoryId || !unit || unitCost <= 0) {
        showError('Please fill in all required fields and enter a valid unit cost');
        return;
    }

    try {
        const data = {
            item_name: itemName,
            category_id: parseInt(categoryId),
            unit: unit,
            unit_cost: unitCost,
            description: description || null,
            supplier_name: supplierName || null,
            supplier_phone: supplierPhone || null
        };

        const url = currentEditingItemId 
            ? `${API_BASE_URL}/inventories/${currentEditingItemId}`
            : `${API_BASE_URL}/inventories`;
        
        const method = currentEditingItemId ? 'PUT' : 'POST';

        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (result.success) {
            showSuccess(currentEditingItemId ? 'Item updated successfully' : 'Item added successfully');
            closeItemModal();
            await loadInventory();
            await loadStatistics();
        } else {
            showError(result.message || 'Failed to save item');
        }
    } catch (error) {
        console.error('Error saving item:', error);
        showError('Error saving item');
    }
}

// Save or Update Category
async function saveCategory(event) {
    event.preventDefault();

    const categoryName = document.getElementById('categoryName').value.trim();
    const description = document.getElementById('categoryDescription').value.trim();
    const editingId = document.getElementById('categoryModal').dataset.editingId;

    if (!categoryName) {
        showError('Category name is required');
        return;
    }

    try {
        const data = {
            category_name: categoryName,
            description: description || null
        };

        const url = editingId 
            ? `${API_BASE_URL}/inventories/categories/${editingId}`
            : `${API_BASE_URL}/inventories/categories`;
        
        const method = editingId ? 'PUT' : 'POST';

        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (result.success) {
            showSuccess(editingId ? 'Category updated successfully' : 'Category added successfully');
            closeCategoryModal();
            await loadCategories();
        } else {
            showError(result.message || 'Failed to save category');
        }
    } catch (error) {
        console.error('Error saving category:', error);
        showError('Error saving category');
    }
}

// Confirm Restock
async function confirmRestock(event) {
    event.preventDefault();

    const itemId = parseInt(document.getElementById('restockModal').dataset.itemId);
    const quantity = parseInt(document.getElementById('restockQuantity').value) || 0;
    const notes = document.getElementById('restockNotes').value.trim();

    if (!quantity || quantity <= 0) {
        showError('Please enter a valid quantity');
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/inventories/${itemId}/restock`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                quantity: quantity,
                notes: notes || null,
                created_by: 'Staff'
            })
        });

        const result = await response.json();

        if (result.success) {
            showSuccess('Item restocked successfully');
            closeRestockModal();
            await loadInventory();
            await loadStatistics();
        } else {
            showError(result.message || 'Failed to restock item');
        }
    } catch (error) {
        console.error('Error restocking:', error);
        showError('Error restocking item');
    }
}

// Delete Category
async function deleteCategory(categoryId) {
    if (!confirm('Are you sure you want to delete this category? Items in this category will not be deleted.')) {
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/inventories/categories/${categoryId}`, {
            method: 'DELETE'
        });

        const result = await response.json();

        if (result.success) {
            showSuccess('Category deleted successfully');
            await loadCategories();
        } else {
            showError(result.message || 'Failed to delete category');
        }
    } catch (error) {
        console.error('Error deleting category:', error);
        showError('Error deleting category');
    }
}

// Populate category dropdown
function populateCategoryDropdown() {
    const select = document.getElementById('itemCategory');
    select.innerHTML = '<option value="">-- Select Category --</option>';
    
    allCategories.forEach(category => {
        const option = document.createElement('option');
        option.value = category.category_id;
        option.textContent = category.category_name;
        select.appendChild(option);
    });
}

// Utility Functions

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showError(message) {
    console.error(message);
    alert(message);
}

function showSuccess(message) {
    console.log(message);
    alert(message);
}

// Close modals when clicking outside
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.classList.remove('active');
    }
}
