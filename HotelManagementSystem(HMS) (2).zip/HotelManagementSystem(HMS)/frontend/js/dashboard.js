// Dashboard JavaScript

// Display current date
document.getElementById('currentDate').textContent = new Date().toLocaleDateString('en-IN', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
});

// Load dashboard data
async function loadDashboard() {
    try {
        // Load dashboard statistics
        const statsResponse = await apiCall(`${API_ENDPOINTS.bookings}/stats/dashboard`);
        if (statsResponse.success) {
            const stats = statsResponse.data;
            
            // Update stats cards
            document.getElementById('availableRooms').textContent = stats.available_rooms || 0;
            document.getElementById('confirmedBookings').textContent = stats.confirmed_bookings || 0;
            document.getElementById('todayCheckIns').textContent = stats.today_checkins || 0;
            document.getElementById('todayRevenue').textContent = formatCurrency(stats.today_revenue || 0);
        }
        
        // Load room statistics
        const roomStatsResponse = await apiCall(`${API_ENDPOINTS.rooms}/stats/overview`);
        if (roomStatsResponse.success) {
            const roomStats = roomStatsResponse.data;
            
            document.getElementById('availableRoomsCount').textContent = roomStats.available_rooms || 0;
            document.getElementById('bookedRooms').textContent = roomStats.booked_rooms || 0;
            document.getElementById('maintenanceRooms').textContent = roomStats.maintenance_rooms || 0;
            
            // Calculate occupancy rate
            const occupancyRate = roomStats.total_rooms > 0 
                ? ((roomStats.booked_rooms / roomStats.total_rooms) * 100).toFixed(1)
                : 0;
            
            document.getElementById('occupancyRate').textContent = `${occupancyRate}%`;
            
            // Update room status bars
            updateRoomStatusBars(roomStats);
        }
        
        // Load today's check-ins
        const checkInsResponse = await apiCall(`${API_ENDPOINTS.bookings}/today/checkins`);
        if (checkInsResponse.success) {
            displayCheckIns(checkInsResponse.data);
            document.getElementById('checkInCount').textContent = checkInsResponse.data.length;
        }
        
        // Load today's check-outs
        const checkOutsResponse = await apiCall(`${API_ENDPOINTS.bookings}/today/checkouts`);
        if (checkOutsResponse.success) {
            displayCheckOuts(checkOutsResponse.data);
            document.getElementById('checkOutCount').textContent = checkOutsResponse.data.length;
        }
        
        // Load recent activity
        loadRecentActivity();
        
        // Load pending service orders
        const pendingOrdersResponse = await fetch(`${API_BASE_URL}/service-orders/pending`);
        if (pendingOrdersResponse.ok) {
            const result = await pendingOrdersResponse.json();
            if (result.success) {
                document.getElementById('pendingOrders').textContent = result.data.length;
            }
        }
        
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

// Update room status bars with visual indicators
function updateRoomStatusBars(roomStats) {
    const total = roomStats.total_rooms || 1;
    const availableWidth = ((roomStats.available_rooms / total) * 100).toFixed(1);
    const bookedWidth = ((roomStats.booked_rooms / total) * 100).toFixed(1);
    const maintenanceWidth = ((roomStats.maintenance_rooms / total) * 100).toFixed(1);
    
    const availableBar = document.getElementById('availableBar');
    const bookedBar = document.getElementById('bookedBar');
    const maintenanceBar = document.getElementById('maintenanceBar');
    
    if (availableBar) {
        availableBar.style.background = `linear-gradient(to right, #27ae60 ${availableWidth}%, transparent ${availableWidth}%)`;
    }
    
    if (bookedBar) {
        bookedBar.style.background = `linear-gradient(to right, #f39c12 ${bookedWidth}%, transparent ${bookedWidth}%)`;
    }
    
    if (maintenanceBar) {
        maintenanceBar.style.background = `linear-gradient(to right, #e74c3c ${maintenanceWidth}%, transparent ${maintenanceWidth}%)`;
    }
}

// Load recent activity
async function loadRecentActivity() {
    try {
        const recentResponse = await apiCall(`${API_ENDPOINTS.bookings}?page=1&limit=5`);
        if (recentResponse.success) {
            displayRecentActivity(recentResponse.data);
        }
    } catch (error) {
        console.error('Error loading recent activity:', error);
        document.getElementById('recentActivity').innerHTML = '<p class="text-muted">Unable to load recent activity</p>';
    }
}

// Display recent activity
function displayRecentActivity(bookings) {
    const container = document.getElementById('recentActivity');
    
    if (!bookings || bookings.length === 0) {
        container.innerHTML = '<p class="text-muted">No recent activity</p>';
        return;
    }
    
    container.innerHTML = bookings.slice(0, 5).map(booking => {
        const statusColor = getStatusColor(booking.booking_status);
        return `
            <div style="display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid #f1f1f1;">
                <div>
                    <strong style="font-size: 0.85rem;">${booking.guest_name}</strong><br>
                    <small style="color: #666;">Room ${booking.room_number}</small>
                </div>
                <span style="background: ${statusColor}; color: white; padding: 2px 6px; border-radius: 10px; font-size: 0.7rem;">
                    ${booking.booking_status}
                </span>
            </div>
        `;
    }).join('');
}

// Get status color for booking status
function getStatusColor(status) {
    const colors = {
        'Confirmed': '#3498db',
        'CheckedIn': '#27ae60',
        'CheckedOut': '#7f8c8d',
        'Cancelled': '#e74c3c'
    };
    return colors[status] || '#7f8c8d';
}

// Display today's check-ins
function displayCheckIns(checkIns) {
    const container = document.getElementById('todayCheckInsList');
    
    if (checkIns.length === 0) {
        container.innerHTML = '<p class="text-muted">No check-ins scheduled for today</p>';
        return;
    }
    
    container.innerHTML = checkIns.map(booking => `
        <div class="list-item">
            <h4>${booking.guest_name}</h4>
            <p><i class="fas fa-bed"></i> Room ${booking.room_number} (${booking.room_type})</p>
            <p><i class="fas fa-phone"></i> ${booking.guest_phone}</p>
        </div>
    `).join('');
}

// Display today's check-outs
function displayCheckOuts(checkOuts) {
    const container = document.getElementById('todayCheckOutsList');
    
    if (checkOuts.length === 0) {
        container.innerHTML = '<p class="text-muted">No check-outs scheduled for today</p>';
        return;
    }
    
    container.innerHTML = checkOuts.map(booking => `
        <div class="list-item">
            <h4>${booking.guest_name}</h4>
            <p><i class="fas fa-bed"></i> Room ${booking.room_number} (${booking.room_type})</p>
            <p><i class="fas fa-rupee-sign"></i> ${formatCurrency(booking.total_amount)}</p>
        </div>
    `).join('');
}

// Load dashboard on page load
window.addEventListener('DOMContentLoaded', loadDashboard);

// Refresh dashboard every 30 seconds
setInterval(loadDashboard, 30000);
