// Reports JavaScript

// API Endpoints
const ANALYTICS_ENDPOINTS = {
    dailyCount: '/api/bookings/analytics/daily-count',
    dailyMetrics: '/api/bookings/analytics/daily-metrics',
    periodAnalysis: '/api/bookings/analytics/period-analysis',
    occupancyTrend: '/api/bookings/analytics/occupancy-trend',
    roomStatus: '/api/bookings/analytics/room-status',
    byRoomType: '/api/bookings/analytics/by-room-type'
};

// Set default date range (last 30 days)
const today = new Date();
const thirtyDaysAgo = new Date(today);
thirtyDaysAgo.setDate(today.getDate() - 30);

document.getElementById('startDate').valueAsDate = thirtyDaysAgo;
document.getElementById('endDate').valueAsDate = today;

// Generate report
async function generateReport() {
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    
    if (!startDate || !endDate) {
        showNotification('Please select start and end dates', 'error');
        return;
    }
    
    if (new Date(endDate) < new Date(startDate)) {
        showNotification('End date must be after start date', 'error');
        return;
    }
    
    try {
        // Load revenue statistics
        const statsResponse = await apiCall(`${API_ENDPOINTS.bookings}/stats/revenue?startDate=${startDate}&endDate=${endDate}`);
        
        if (statsResponse.success) {
            const stats = statsResponse.data;
            
            // Update statistics cards
            document.getElementById('totalBookings').textContent = stats.total_bookings || 0;
            document.getElementById('totalRevenue').textContent = formatCurrency(stats.total_revenue || 0);
            document.getElementById('collectedAmount').textContent = formatCurrency(stats.collected_amount || 0);
            document.getElementById('pendingAmount').textContent = formatCurrency(stats.pending_amount || 0);
        }

        // Load occupancy analysis
        const occupancyResponse = await apiCall(`${API_ENDPOINTS.bookings}/analytics/period-analysis?startDate=${startDate}&endDate=${endDate}`);
        if (occupancyResponse.success) {
            const occupancy = occupancyResponse.data;
            
            // Update occupancy metrics
            document.getElementById('occupancyPercentage').textContent = occupancy.metrics.occupancy_percentage + '%' || '-';
            document.getElementById('totalRoomNights').textContent = occupancy.rooms.total_available_nights || 0;
            document.getElementById('bookedRoomNights').textContent = occupancy.bookings.total_room_nights || 0;
            document.getElementById('revpar').textContent = formatCurrency(occupancy.metrics.revpar) || '-';
            
            // Store for later use in charts
            window.occupancyData = occupancy;
        }

        // Load occupancy trend
        const trendResponse = await apiCall(`${API_ENDPOINTS.bookings}/analytics/occupancy-trend?startDate=${startDate}&endDate=${endDate}`);
        if (trendResponse.success) {
            displayOccupancyTrend(trendResponse.data);
            window.trendData = trendResponse.data;
        }

        // Load occupancy by room type
        const typeResponse = await apiCall(`${API_ENDPOINTS.bookings}/analytics/by-room-type?startDate=${startDate}&endDate=${endDate}`);
        if (typeResponse.success) {
            displayRoomTypeOccupancy(typeResponse.data);
        }
        
        // Load all bookings for the period
        const bookingsResponse = await apiCall(`${API_ENDPOINTS.bookings}`);
        
        if (bookingsResponse.success) {
            // Filter bookings by date range
            const filteredBookings = bookingsResponse.data.filter(booking => {
                const checkInDate = new Date(booking.check_in);
                return checkInDate >= new Date(startDate) && checkInDate <= new Date(endDate);
            });
            
            displayReportBookings(filteredBookings);
        }
        
        showNotification('Report generated successfully!', 'success');
        
    } catch (error) {
        console.error('Error generating report:', error);
        showNotification('Error generating report', 'error');
    }
}

// Get today's daily metrics
async function getTodayMetrics() {
    try {
        const today = new Date().toISOString().split('T')[0];
        const response = await apiCall(`${API_ENDPOINTS.bookings}/analytics/daily-metrics?date=${today}`);
        
        if (response.success) {
            return response.data;
        }
    } catch (error) {
        console.error('Error fetching today metrics:', error);
    }
    return null;
}

// Get room status for a specific date
async function getRoomStatus(date) {
    try {
        const response = await apiCall(`${API_ENDPOINTS.bookings}/analytics/room-status?date=${date}`);
        
        if (response.success) {
            return response.data;
        }
    } catch (error) {
        console.error('Error fetching room status:', error);
    }
    return null;
}

// Display occupancy trend
function displayOccupancyTrend(trendData) {
    const container = document.getElementById('occupancyTrendContainer');
    
    if (!container) return;
    
    if (trendData.length === 0) {
        container.innerHTML = '<p class="text-center text-muted">No data available</p>';
        return;
    }
    
    // Create chart data
    const dates = trendData.map(d => d.date);
    const occupancyPercentages = trendData.map(d => parseFloat(d.occupancy_percentage));
    const revenues = trendData.map(d => parseFloat(d.daily_revenue));
    const adrs = trendData.map(d => parseFloat(d.adr));
    
    // Display as a simple table if chart library not available
    if (!window.Chart) {
        container.innerHTML = `
            <table class="table table-sm table-striped">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Occupied</th>
                        <th>Occupancy %</th>
                        <th>ADR</th>
                        <th>Daily Revenue</th>
                    </tr>
                </thead>
                <tbody>
                    ${trendData.map(d => `
                        <tr>
                            <td>${d.date}</td>
                            <td>${d.occupied_rooms}/${d.available_rooms}</td>
                            <td>${d.occupancy_percentage}%</td>
                            <td>${formatCurrency(d.adr)}</td>
                            <td>${formatCurrency(d.daily_revenue)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    }
}

// Display room type occupancy
function displayRoomTypeOccupancy(typeData) {
    const container = document.getElementById('roomTypeOccupancyContainer');
    
    if (!container) return;
    
    if (typeData.length === 0) {
        container.innerHTML = '<p class="text-center text-muted">No data available</p>';
        return;
    }
    
    container.innerHTML = `
        <table class="table table-sm table-striped">
            <thead>
                <tr>
                    <th>Room Type</th>
                    <th>Total Rooms</th>
                    <th>Booked</th>
                    <th>Occupancy %</th>
                    <th>Total Revenue</th>
                </tr>
            </thead>
            <tbody>
                ${typeData.map(type => `
                    <tr>
                        <td>${type.room_type}</td>
                        <td>${type.total_rooms}</td>
                        <td>${type.rooms_booked}</td>
                        <td>${type.occupancy_rate}%</td>
                        <td>${formatCurrency(type.total_revenue)}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

// Display bookings in report
function displayReportBookings(bookings) {
    const tbody = document.getElementById('reportBookings');
    
    if (bookings.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No bookings found for selected period</td></tr>';
        return;
    }
    
    tbody.innerHTML = bookings.map(booking => `
        <tr>
            <td>#${booking.booking_id}</td>
            <td>${booking.guest_name}</td>
            <td>Room ${booking.room_number}</td>
            <td>${formatDate(booking.check_in)}</td>
            <td>${formatDate(booking.check_out)}</td>
            <td>${formatCurrency(booking.total_amount)}</td>
            <td><span class="badge badge-${getStatusBadge(booking.booking_status)}">${booking.booking_status}</span></td>
        </tr>
    `).join('');
}

function getStatusBadge(status) {
    const badges = {
        'Confirmed': 'info',
        'CheckedIn': 'success',
        'CheckedOut': 'secondary',
        'Cancelled': 'danger'
    };
    return badges[status] || 'secondary';
}

// Generate report on page load with default dates
window.addEventListener('DOMContentLoaded', generateReport);
