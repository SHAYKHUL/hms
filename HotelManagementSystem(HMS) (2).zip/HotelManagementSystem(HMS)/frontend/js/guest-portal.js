// Guest Portal JavaScript with Token Authentication

let allServices = [];
let currentBooking = null;
let currentCategory = 'all';
let myOrders = [];
let guestToken = null;

// Service icons mapping
const categoryIcons = {
    'Food': 'fa-utensils',
    'Beverage': 'fa-coffee',
    'Laundry': 'fa-tshirt',
    'Spa': 'fa-spa',
    'Transport': 'fa-car',
    'Housekeeping': 'fa-broom',
    'Other': 'fa-ellipsis-h'
};

// Safe element getter with retry logic
async function getSafeElement(elementId, timeoutMs = 3000, intervalMs = 100) {
    // Quick hit if element already exists
    let el = document.getElementById(elementId);
    if (el) {
        console.log(`✓ Element "${elementId}" found (immediate)`);
        return el;
    }

    // If document is still loading, wait for DOMContentLoaded first
    if (document.readyState === 'loading') {
        await new Promise(resolve => document.addEventListener('DOMContentLoaded', resolve, { once: true }));
    }

    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
        el = document.getElementById(elementId);
        if (el) {
            console.log(`✓ Element "${elementId}" found after ${Date.now() - start}ms`);
            return el;
        }
        await new Promise(resolve => setTimeout(resolve, intervalMs));
    }

    console.error(`✗ Element "${elementId}" not found after ${timeoutMs}ms`);
    return null;
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    console.log('=== guest-portal.js loaded ===');
    console.log('API_BASE_URL:', API_BASE_URL);
    
    // Check if already authenticated
    const savedToken = localStorage.getItem('guestPortalToken');
    console.log('Saved token found:', !!savedToken);
    
    if (savedToken) {
        guestToken = savedToken;
        console.log('Using saved token, validating...');
        validateAndLoadPortal();
    } else {
        console.log('No saved token, redirecting to login');
        // Redirect to login page instead of showing auth overlay
        window.location.href = 'guest-login.html';
    }
});

// Show Authentication Screen
function showAuthScreen() {
    const portal = document.getElementById('guestPortal');
    if (!portal) return;

    // If overlay already exists, focus input
    let overlay = document.getElementById('guestPortalAuthOverlay');
    if (overlay) {
        const pinInput = overlay.querySelector('#accessPin');
        if (pinInput) pinInput.focus();
        return;
    }

    // Create a full-screen fixed auth overlay so underlying content is hidden
    overlay = document.createElement('div');
    overlay.id = 'guestPortalAuthOverlay';
    // Fixed overlay that doesn't scroll itself
    overlay.style.cssText = 'position: fixed; inset: 0; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,0.78); z-index: 10000; overflow: hidden; padding: 2rem 1rem;';

    // Preserve previous document state to restore later
    overlay.dataset.prevOverflow = document.body.style.overflow || '';
    overlay.dataset.prevHtmlOverflow = document.documentElement.style.overflow || '';
    const mainEl = document.querySelector('main');
    overlay.dataset.prevPointer = mainEl ? (mainEl.style.pointerEvents || '') : '';

    // Block background scrolling and pointer events
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';
    if (mainEl) mainEl.style.pointerEvents = 'none';

    overlay.innerHTML = `
        <div class="guest-auth-modal" style="max-width: 600px; width: 100%; margin: 0 auto; padding: 1.25rem 1.5rem; background: white; border-radius: 10px; box-shadow: 0 5px 30px rgba(0,0,0,0.2); max-height: 90vh; overflow-y: auto; overflow-x: hidden;">
            <div style="text-align: center; margin-bottom: 2rem;">
                <i class="fas fa-key" style="font-size: 4rem; color: #667eea; margin-bottom: 1rem;"></i>
                <h1 style="color: #333; margin: 0;">Guest Portal Access</h1>
                <p style="color: #666; margin-top: 0.5rem;">Enter your access PIN to continue</p>
            </div>

            <div style="margin-bottom: 1.5rem;">
                <label for="accessPin" style="display: block; margin-bottom: 0.5rem; color: #333; font-weight: bold;">Access PIN</label>
                <input 
                    type="text" 
                    id="accessPin" 
                    placeholder="Enter 6-digit PIN" 
                    maxlength="6"
                    style="width: 100%; padding: 0.75rem; border: 2px solid #e0e0e0; border-radius: 5px; font-size: 1.25rem; text-align: center; letter-spacing: 5px;"
                    onkeypress="if(event.key === 'Enter') authenticateGuest()"
                >
            </div>

            <button 
                onclick="authenticateGuest()" 
                style="width: 100%; padding: 0.75rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 5px; font-size: 1rem; font-weight: bold; cursor: pointer; margin-bottom: 1rem;"
            >
                <i class="fas fa-sign-in-alt"></i> Access Portal
            </button>

            <div id="authError" style="display: none; padding: 1rem; background: #f8d7da; color: #721c24; border-radius: 5px; text-align: center;"></div>
        </div>
    `;

    // Append overlay to body so it covers the whole viewport
    document.body.appendChild(overlay);

    // Focus the PIN input
    const pinInput = overlay.querySelector('#accessPin');
    if (pinInput) pinInput.focus();

    // Modal is now scrollable; body/html are locked, so scrolling inside the modal will work
}


// Authenticate Guest
async function authenticateGuest() {
    const pin = document.getElementById('accessPin').value.trim();
    const errorDiv = document.getElementById('authError');
    
    if (!pin) {
        errorDiv.textContent = 'Please enter your PIN';
        errorDiv.style.display = 'block';
        return;
    }
    
    if (pin.length !== 6) {
        errorDiv.textContent = 'PIN must be 6 digits';
        errorDiv.style.display = 'block';
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/guest-sessions/validate-pin`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ pin })
        });
        
        const result = await response.json();
        
        if (!result.success) {
            errorDiv.textContent = result.message || 'Invalid PIN. Please try again.';
            errorDiv.style.display = 'block';
            return;
        }
        
        // Store token
        guestToken = result.data.token;
        currentBooking = {
            booking_id: result.data.bookingId,
            guest_id: result.data.guestId,
            guest_name: result.data.guestName,
            room_number: result.data.roomNumber
        };
        
        localStorage.setItem('guestPortalToken', guestToken);
        localStorage.setItem('guestBookingData', JSON.stringify(currentBooking));
        
        // Load portal
        // Remove auth overlay and load portal UI
        const authOverlay = document.getElementById('guestPortalAuthOverlay');
        if (authOverlay) {
            // restore previous page state
            const mainEl = document.querySelector('main');
            if (mainEl && typeof authOverlay.dataset.prevPointer !== 'undefined') mainEl.style.pointerEvents = authOverlay.dataset.prevPointer;
            if (typeof authOverlay.dataset.prevOverflow !== 'undefined') document.body.style.overflow = authOverlay.dataset.prevOverflow;
            if (typeof authOverlay.dataset.prevHtmlOverflow !== 'undefined') document.documentElement.style.overflow = authOverlay.dataset.prevHtmlOverflow;
            authOverlay.remove();
        }
        loadPortal();
    } catch (error) {
        console.error('Authentication error:', error);
        errorDiv.textContent = 'Error authenticating. Please try again.';
        errorDiv.style.display = 'block';
    }
}

// Validate Token and Load Portal
async function validateAndLoadPortal() {
    console.log('=== validateAndLoadPortal() started ===');
    try {
        const validateUrl = `${API_BASE_URL}/guest-sessions/validate-token`;
        console.log('Validating token at:', validateUrl);
        
        const response = await fetch(validateUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ token: guestToken })
        });
        
        const result = await response.json();
        console.log('Token validation response:', result);
        
        if (!result.success) {
            console.log('Token validation failed, clearing storage and redirecting to login');
            localStorage.removeItem('guestPortalToken');
            localStorage.removeItem('guestBookingData');
            window.location.href = 'guest-login.html?expired=true';
            return;
        }
        
        // Load booking data
        currentBooking = {
            booking_id: result.data.bookingId,
            guest_id: result.data.guestId,
            guest_name: result.data.guestName,
            room_number: result.data.roomNumber
        };
        
        console.log('Booking data loaded:', currentBooking);
        console.log('Calling loadPortal()');
        loadPortal();
    } catch (error) {
        console.error('Validation error:', error);
        localStorage.removeItem('guestPortalToken');
        localStorage.removeItem('guestBookingData');
        window.location.href = 'guest-login.html?error=true';
    }
}

// Load Portal
function loadPortal() {
    console.log('=== loadPortal() started ===');
    console.log('currentBooking:', currentBooking);
    
    // Show booking info
    const bookingContainer = document.getElementById('bookingDetailsContainer');
    if (bookingContainer) {
        console.log('Showing bookingDetailsContainer');
        bookingContainer.style.display = 'grid';
        displayBookingInfo(currentBooking);
    } else {
        console.error('bookingDetailsContainer not found');
    }
    
    // Fetch booking details and services
    console.log('Fetching services and orders...');
    loadBookingDetails();
    loadServices();
    loadMyOrders();
    
    // Auto refresh orders every 30 seconds
    setInterval(() => {
        if (currentBooking) {
            loadMyOrders();
        }
    }, 30000);
    
    console.log('=== loadPortal() completed ===');
}

// Logout
function logoutGuest() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('guestPortalToken');
        localStorage.removeItem('guestBookingData');
        guestToken = null;
        currentBooking = null;
        // Redirect to login page
        window.location.href = 'guest-login.html?logged-out=true';
    }
}

// Display Booking Info
function displayBookingInfo(booking) {
    console.log('displayBookingInfo called with:', booking);
    
    if (!booking) {
        console.error('No booking data provided');
        return;
    }
    
    const nameEl = document.getElementById('guestName');
    const roomEl = document.getElementById('roomNumber');
    const typeEl = document.getElementById('roomType');
    const checkInEl = document.getElementById('checkIn');
    const checkOutEl = document.getElementById('checkOut');
    
    if (nameEl) nameEl.textContent = currentBooking.guest_name || booking.guest_name || '-';
    if (roomEl) roomEl.textContent = currentBooking.room_number || booking.room_number || '-';
    if (typeEl) typeEl.textContent = booking.room_type || '-';
    if (checkInEl) checkInEl.textContent = booking.check_in ? new Date(booking.check_in).toLocaleDateString() : '-';
    if (checkOutEl) checkOutEl.textContent = booking.check_out ? new Date(booking.check_out).toLocaleDateString() : '-';
    
    // Show/hide extension button based on booking status
    const extensionBtn = document.getElementById('extensionRequestBtn');
    const extensionMsg = document.getElementById('extensionNotAvailableMsg');
    
    if (extensionBtn && extensionMsg) {
        const isConfirmed = booking.booking_status === 'Confirmed' || booking.booking_status === 'confirmed';
        if (isConfirmed) {
            extensionBtn.style.display = 'inline-block';
            extensionMsg.classList.add('hidden');
            console.log('Booking is confirmed, extension button shown');
        } else {
            extensionBtn.style.display = 'none';
            extensionMsg.classList.remove('hidden');
            console.log('Booking not confirmed (status:', booking.booking_status + '), extension unavailable');
        }
    }
    
    console.log('Booking info displayed');
    
    // Load billing information
    loadGuestBillingInfo(booking.booking_id);
}

// ====== EXTENSION REQUEST FUNCTIONS ======

// Helper function to safely get element
function getElement(id) {
    const element = document.getElementById(id);
    if (!element) {
        console.error(`Element with ID '${id}' not found in DOM`);
        return null;
    }
    return element;
}

// Open Extension Request Modal
async function openExtensionRequestModal() {
    try {
        // Verify modal and required elements exist
        const modal = document.getElementById('extensionModal');
        const currentCheckoutDisplay = document.getElementById('currentCheckoutDisplay');
        const newCheckoutDate = document.getElementById('newCheckoutDate');
        const extensionReason = document.getElementById('extensionReason');
        const extensionError = document.getElementById('extensionError');
        const extensionOptionsContainer = document.getElementById('extensionOptionsContainer');
        
        if (!modal || !currentCheckoutDisplay || !newCheckoutDate) {
            console.error('Extension modal elements not found in DOM. Modal may not be loaded.');
            showErrorMessage('Extension feature not available. Please refresh the page.');
            return;
        }
        
        // Use currentBooking which has all details loaded from displayBookingInfo
        let booking = currentBooking;
        
        // If booking details not fully loaded, fetch them
        if (!booking || !booking.check_out) {
            console.log('Booking details not fully loaded, fetching...');
            await loadBookingDetails();
            booking = currentBooking;
        }
        
        if (!booking || !booking.check_out) {
            showErrorMessage('Unable to load booking details. Please refresh and try again.');
            return;
        }
        
        // Set current checkout date
        currentCheckoutDisplay.textContent = new Date(booking.check_out).toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        
        // Reset form
        newCheckoutDate.value = '';
        if (extensionReason) extensionReason.value = '';
        if (extensionError) extensionError.classList.add('hidden');
        if (extensionOptionsContainer) extensionOptionsContainer.classList.add('hidden');
        
        // Set minimum date to tomorrow of current checkout
        const checkOutDate = new Date(booking.check_out);
        const minDate = new Date(checkOutDate);
        minDate.setDate(minDate.getDate() + 1);
        newCheckoutDate.min = minDate.toISOString().split('T')[0];
        
        // Show modal using Tailwind class
        modal.classList.remove('hidden');
        console.log('Extension modal opened successfully');
        
    } catch (error) {
        console.error('Error opening extension modal:', error);
        showErrorMessage('Error opening extension form. Please try again.');
    }
}

// Close Extension Modal
function closeExtensionModal() {
    const modal = document.getElementById('extensionModal');
    if (modal) {
        modal.classList.add('hidden');
    }
}

// Close modal when clicking outside
document.addEventListener('click', function(event) {
    const modal = document.getElementById('extensionModal');
    if (modal && event.target === modal) {
        closeExtensionModal();
    }
});

// Check Extension Availability
async function checkExtensionAvailability() {
    try {
        const newCheckoutEl = document.getElementById('newCheckoutDate');
        const reasonEl = document.getElementById('extensionReason');
        const errorDiv = document.getElementById('extensionError');
        
        if (!newCheckoutEl || !errorDiv) {
            showErrorMessage('Extension form elements not found. Please refresh the page.');
            return;
        }
        
        const newCheckout = newCheckoutEl.value;
        const reason = reasonEl ? reasonEl.value : '';
        
        if (errorDiv) errorDiv.classList.add('hidden');
        
        if (!newCheckout) {
            if (errorDiv) {
                errorDiv.textContent = 'Please select a new checkout date';
                errorDiv.classList.remove('hidden');
            }
            return;
        }
        
        if (!currentBooking || !currentBooking.booking_id) {
            if (errorDiv) {
                errorDiv.textContent = 'Booking information not available';
                errorDiv.classList.remove('hidden');
            }
            return;
        }
        
        // Fetch extension options from API
        const response = await fetch(`${API_BASE_URL}/bookings/${currentBooking.booking_id}/extension-options?new_check_out=${newCheckout}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${guestToken}`
            }
        });
        
        const result = await response.json();
        
        if (!result.success) {
            if (errorDiv) {
                errorDiv.textContent = result.message || 'Unable to check availability';
                errorDiv.classList.remove('hidden');
            }
            return;
        }
        
        displayExtensionOptions(result.data, newCheckout, reason);
        
    } catch (error) {
        console.error('Error checking extension availability:', error);
        const errorDiv = document.getElementById('extensionError');
        if (errorDiv) {
            errorDiv.textContent = 'Error checking availability. Please try again.';
            errorDiv.classList.remove('hidden');
        }
    }
}

// Display Extension Options
function displayExtensionOptions(options, newCheckout, reason) {
    const optionsContainer = document.getElementById('extensionOptionsContainer');
    const optionsDiv = document.getElementById('extensionOptions');
    
    if (!optionsContainer || !optionsDiv) {
        console.error('Extension options container elements not found');
        showErrorMessage('Unable to display options. Please try again.');
        return;
    }
    
    optionsDiv.innerHTML = '';
    
    if (options.canExtend) {
        // Room is available for direct extension
        const additionalNights = Math.ceil((new Date(newCheckout) - new Date(options.currentBooking.check_out)) / (1000 * 60 * 60 * 24));
        const additionalCost = additionalNights * parseFloat(options.currentBooking.room_price);
        
        optionsDiv.innerHTML = `
            <div class="bg-white p-3 rounded-lg border border-green-200 mb-3">
                <h5 class="text-green-700 font-semibold mb-2"><i class="fas fa-check-circle mr-2"></i> Your Room is Available!</h5>
                <p class="text-sm text-gray-600 mb-2">You can extend your stay in the same room.</p>
                <p class="text-sm text-gray-600 mb-2"><strong>Additional Nights:</strong> ${additionalNights}</p>
                <p class="text-sm text-gray-600 mb-3"><strong>Additional Cost:</strong> ₹${additionalCost.toFixed(2)}</p>
                <button onclick="submitExtensionRequest('same_room', '${newCheckout}', '${reason}')" class="w-full bg-green-500 text-white px-3 py-2 rounded-lg text-sm hover:bg-green-600 font-medium">
                    Request This Extension
                </button>
            </div>
        `;
    } else {
        // Check for alternative options
        let hasAlternatives = false;
        
        if (options.alternatives && options.alternatives.alternative_rooms && options.alternatives.alternative_rooms.length > 0) {
            hasAlternatives = true;
            optionsDiv.innerHTML += '<h5 class="text-blue-700 font-semibold mb-2"><i class="fas fa-bed mr-2"></i> Alternative Rooms Available</h5>';
            
            options.alternatives.alternative_rooms.forEach(room => {
                const additionalNights = Math.ceil((new Date(newCheckout) - new Date(options.currentBooking.check_out)) / (1000 * 60 * 60 * 24));
                const cost = additionalNights * room.price;
                
                optionsDiv.innerHTML += `
                    <div class="bg-white p-3 rounded-lg border border-blue-200 mb-2">
                        <h6 class="font-semibold text-sm mb-1">Room ${room.room_number} - ${room.room_type}</h6>
                        <p class="text-xs text-gray-600 mb-2">₹${cost.toFixed(2)} for ${additionalNights} nights</p>
                        <button onclick="submitExtensionRequest('alternative_room', '${newCheckout}', '${reason}', ${room.room_id})" class="w-full bg-blue-500 text-white px-3 py-2 rounded-lg text-xs hover:bg-blue-600 font-medium">
                            Request This Room
                        </button>
                    </div>
                `;
            });
        }
        
        if (options.alternatives && options.alternatives.alternative_dates) {
            hasAlternatives = true;
            const availFromDate = new Date(options.alternatives.alternative_dates.available_from).toLocaleDateString();
            optionsDiv.innerHTML += `
                <div class="bg-yellow-50 p-3 rounded-lg border border-yellow-200">
                    <h5 class="text-yellow-700 font-semibold mb-2"><i class="fas fa-calendar-times mr-2"></i> Room Available from: ${availFromDate}</h5>
                    <p class="text-sm text-gray-600 mb-3">Your preferred dates are unavailable, but the room will be available from <strong>${availFromDate}</strong></p>
                    <button onclick="submitExtensionRequest('alternative_dates', '${newCheckout}', '${reason}')" class="w-full bg-yellow-500 text-gray-900 px-3 py-2 rounded-lg text-sm hover:bg-yellow-600 font-medium">
                        Request Alternative Dates
                    </button>
                </div>
            `;
        }
        
        if (!hasAlternatives) {
            optionsDiv.innerHTML = '<div class="bg-red-50 p-3 rounded-lg border border-red-200 text-red-700 text-sm"><i class="fas fa-exclamation-circle mr-2"></i><strong>No availability</strong><p class="mt-1">Your preferred dates are not available and no alternatives found. Please contact us for special requests.</p></div>';
        }
    }
    
    optionsContainer.classList.remove('hidden');
}

// Submit Extension Request
async function submitExtensionRequest(resolutionType, newCheckout, reason, alternativeRoomId = null) {
    try {
        if (!currentBooking || !currentBooking.booking_id) {
            showErrorMessage('Booking information not available');
            return;
        }
        
        const payload = {
            new_check_out: newCheckout,
            resolution_type: resolutionType,
            request_reason: reason
        };
        
        if (alternativeRoomId) {
            payload.resolution_details = {
                alternative_room_id: alternativeRoomId
            };
        }
        
        const response = await fetch(`${API_BASE_URL}/bookings/${currentBooking.booking_id}/extend`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${guestToken}`
            },
            body: JSON.stringify(payload)
        });
        
        const result = await response.json();
        
        if (!response.ok || !result.success) {
            const errorMsg = result.message || result.error || 'Failed to submit extension request';
            console.error('Extension error response:', result);
            showErrorMessage(errorMsg);
            return;
        }
        
        if (result.success) {
            showSuccessMessage('✓ Extension request submitted! You can now check your updated booking details.');
            closeExtensionModal();
            
            // Reload booking information
            setTimeout(() => {
                validateAndLoadPortal();
            }, 2000);
        }
    } catch (error) {
        console.error('Error submitting extension:', error);
        showErrorMessage('Error submitting request. Please try again.');
    }
}

// Show Error Message
function showErrorMessage(message) {
    const toast = document.createElement('div');
    toast.innerHTML = `
        <i class="fas fa-times-circle"></i>
        <span>${message}</span>
    `;
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #dc3545;
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 10px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.3);
        z-index: 10000;
        display: flex;
        align-items: center;
        gap: 0.75rem;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Load Full Booking Details
async function loadBookingDetails() {
    try {
        if (!currentBooking || !currentBooking.booking_id) {
            console.error('No booking ID available');
            return;
        }
        
        console.log('Loading booking details for ID:', currentBooking.booking_id);
        const response = await fetch(`${API_BASE_URL}/bookings/${currentBooking.booking_id}`, {
            headers: {
                'Authorization': `Bearer ${guestToken}`
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        const result = await response.json();
        
        if (result.success && result.data) {
            const booking = result.data;
            console.log('Booking details loaded:', booking);
            
            // Update currentBooking with full details
            currentBooking = {
                ...currentBooking,
                check_in: booking.check_in,
                check_out: booking.check_out,
                room_type: booking.room_type,
                room_price: booking.room_price,
                total_amount: booking.total_amount,
                booking_status: booking.booking_status
            };
            
            // Save to storage
            localStorage.setItem('guestBookingData', JSON.stringify(currentBooking));
            
            // Display booking info
            displayBookingInfo(currentBooking);
        }
    } catch (error) {
        console.error('Error loading booking details:', error);
    }
}

// Load Services
async function loadServices() {
    try {
        console.log('Loading services from:', `${API_BASE_URL}/services/available`);
        const response = await fetch(`${API_BASE_URL}/services/available`);
        const result = await response.json();
        
        console.log('Services response:', result);
        
        if (result.success) {
            allServices = result.data;
            console.log('Services loaded:', allServices.length);
            displayServices(allServices);
        } else {
            console.error('Services API error:', result.message);
        }
    } catch (error) {
        console.error('Error loading services:', error);
    }
}

// Filter by Category
function filterByCategory(category) {
    currentCategory = category;
    
    // Update active tab
    document.querySelectorAll('.category-tab').forEach(tab => {
        tab.classList.remove('active', 'bg-primary', 'text-white');
        tab.classList.add('bg-gray-100', 'text-primary');
    });
    event.target.classList.add('active', 'bg-primary', 'text-white');
    event.target.classList.remove('bg-gray-100', 'text-primary');
    
    // Filter and display services
    if (category === 'all') {
        displayServices(allServices);
    } else {
        const filtered = allServices.filter(s => s.category === category);
        displayServices(filtered);
    }
}

// Display Services
function displayServices(services) {
    const menu = document.getElementById('servicesMenu');
    
    console.log('displayServices called with', services.length, 'services');
    console.log('servicesMenu element:', menu);
    
    if (!menu) {
        console.error('servicesMenu element not found!');
        return;
    }
    
    if (!services || services.length === 0) {
        console.log('No services to display');
        menu.innerHTML = '<div class="text-center text-gray-500 py-8"><i class="fas fa-inbox text-2xl mb-2"></i><p>No services available</p></div>';
        return;
    }
    
    menu.innerHTML = services.map(service => `
        <div class="bg-white rounded-xl shadow hover:shadow-lg transition overflow-hidden border border-gray-100 flex flex-col">
            <div class="bg-gradient-to-r from-primary to-secondary text-white p-6 text-center text-3xl">
                <i class="fas ${categoryIcons[service.category] || 'fa-star'}"></i>
            </div>
            <div class="p-4 flex-1 flex flex-col">
                <h3 class="font-semibold text-gray-800 mb-1">${service.service_name}</h3>
                <p class="text-sm text-gray-600 mb-3 flex-1">${service.description || 'Available for order'}</p>
                <div class="flex justify-between items-center">
                    <span class="text-primary font-bold text-lg">₹${parseFloat(service.price).toFixed(2)}</span>
                    <div class="flex items-center gap-2 border border-gray-200 rounded-lg">
                        <button class="px-2 py-1 hover:bg-gray-100" onclick="decrementQty(${service.service_id})">−</button>
                        <input type="number" id="qty-${service.service_id}" value="1" min="1" max="10" readonly class="w-8 text-center border-0">
                        <button class="px-2 py-1 hover:bg-gray-100" onclick="incrementQty(${service.service_id})">+</button>
                    </div>
                </div>
                <button class="w-full mt-3 bg-gradient-to-r from-primary to-secondary text-white px-4 py-2 rounded-lg text-sm hover:opacity-90 font-medium" onclick="orderService(${service.service_id})">
                    <i class="fas fa-shopping-cart mr-2"></i> Order
                </button>
            </div>
        </div>
    `).join('');
    
    console.log('Services rendered, count:', services.length);
}

// Increment Quantity
function incrementQty(serviceId) {
    const input = document.getElementById(`qty-${serviceId}`);
    if (input.value < 10) {
        input.value = parseInt(input.value) + 1;
    }
}

// Decrement Quantity
function decrementQty(serviceId) {
    const input = document.getElementById(`qty-${serviceId}`);
    if (input.value > 1) {
        input.value = parseInt(input.value) - 1;
    }
}

// Order Service
async function orderService(serviceId) {
    if (!currentBooking) {
        alert('Please select a booking first');
        return;
    }
    
    const service = allServices.find(s => s.service_id === serviceId);
    if (!service) return;
    
    const quantity = parseInt(document.getElementById(`qty-${serviceId}`).value);
    const unitPrice = parseFloat(service.price);
    const totalPrice = quantity * unitPrice;
    
    // Get special instructions
    const specialInstructions = prompt('Any special instructions? (Optional)');
    
    const orderData = {
        booking_id: currentBooking.booking_id,
        service_id: serviceId,
        quantity: quantity,
        unit_price: unitPrice,
        total_price: totalPrice,
        special_instructions: specialInstructions || ''
    };
    
    try {
        const response = await fetch(`${API_BASE_URL}/service-orders`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(orderData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Reset quantity
            document.getElementById(`qty-${serviceId}`).value = 1;
            
            // Show success message
            showSuccessMessage('Order placed successfully!');
            
            // Reload orders
            loadMyOrders();
        } else {
            alert('Error placing order: ' + result.message);
        }
    } catch (error) {
        console.error('Error placing order:', error);
        alert('Error placing order. Please try again.');
    }
}

// Load My Orders
async function loadMyOrders() {
    if (!currentBooking) {
        console.log('No current booking, skipping order load');
        return;
    }
    
    try {
        console.log('Loading orders for booking:', currentBooking.booking_id);
        const response = await fetch(`${API_BASE_URL}/service-orders/booking/${currentBooking.booking_id}`);
        const result = await response.json();
        
        console.log('Orders response:', result);
        
        if (result.success) {
            myOrders = result.data;
            console.log('Orders loaded:', myOrders.length);
            displayMyOrders(result.data);
        } else {
            console.error('Orders API error:', result.message);
        }
    } catch (error) {
        console.error('Error loading orders:', error);
    }
}

// Display My Orders
function displayMyOrders(orders) {
    const container = document.getElementById('myOrdersList');
    
    console.log('displayMyOrders called with', orders ? orders.length : 0, 'orders');
    
    if (!container) {
        console.error('myOrdersList element not found!');
        return;
    }
    
    if (!orders || orders.length === 0) {
        console.log('No orders to display');
        container.innerHTML = `
            <div class="text-center text-gray-500 py-6">
                <i class="fas fa-shopping-cart text-3xl mb-3"></i>
                <p>No orders yet. Order something delicious!</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = orders.map(order => `
        <div class="border-l-4 border-primary p-4 mb-4 bg-gray-50 rounded">
            <div class="flex justify-between items-start mb-2">
                <h4 class="font-semibold text-gray-800">${order.service_name}</h4>
                <span class="px-2 py-1 rounded text-xs font-semibold ${
                    order.order_status === 'Completed' ? 'bg-green-100 text-green-700' :
                    order.order_status === 'InProgress' ? 'bg-blue-100 text-blue-700' :
                    order.order_status === 'Pending' ? 'bg-yellow-100 text-yellow-700' :
                    'bg-red-100 text-red-700'
                }">${order.order_status}</span>
            </div>
            <p class="text-sm text-gray-600 mb-2">Quantity: ${order.quantity} × ₹${parseFloat(order.unit_price).toFixed(2)} = ₹${parseFloat(order.total_price).toFixed(2)}</p>
            ${order.special_instructions ? `<p class="text-sm text-gray-600 mb-2"><strong>Note:</strong> ${order.special_instructions}</p>` : ''}
            <p class="text-xs text-gray-500">Ordered: ${new Date(order.ordered_at).toLocaleString()}</p>
        </div>
    `).join('');
    
    console.log('Orders rendered, count:', orders.length);
}

// Show Success Message
function showSuccessMessage(message) {
    // Create a toast notification
    const toast = document.createElement('div');
    toast.className = 'toast-notification';
    toast.innerHTML = `
        <i class="fas fa-check-circle"></i>
        <span>${message}</span>
    `;
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 10px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.3);
        z-index: 10000;
        display: flex;
        align-items: center;
        gap: 0.75rem;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Add CSS for animations
// ...existing code...

// ============================================
// GUEST BILLING & INVOICE FUNCTIONS
// ============================================

// Load billing information for guest
async function loadGuestBillingInfo(bookingId) {
    try {
        const invoice = await getInvoiceByBooking(bookingId);
        
        if (invoice) {
            // Update billing display
            document.getElementById('roomChargesDisplay').textContent = ?\;
            document.getElementById('servicesChargesDisplay').textContent = ?\;
            document.getElementById('grandTotalDisplay').textContent = ?\;
            document.getElementById('amountDueDisplay').textContent = ?\;
            
            // Enable download and print buttons
            document.getElementById('downloadInvoiceBtn').disabled = false;
            document.getElementById('printInvoiceBtn').disabled = false;
            
            // Hide status message
            document.getElementById('invoiceStatusMessage').classList.add('hidden');
            
            // Store invoice data for later use
            localStorage.setItem('guestInvoiceData', JSON.stringify(invoice));
        } else {
            // Show waiting message
            document.getElementById('invoiceStatusMessage').classList.remove('hidden');
            document.getElementById('invoiceStatusText').textContent = 'No invoice generated yet. It will be available after check-out.';
            document.getElementById('downloadInvoiceBtn').disabled = true;
            document.getElementById('printInvoiceBtn').disabled = true;
        }
    } catch (error) {
        console.error('Error loading billing info:', error);
        document.getElementById('invoiceStatusMessage').classList.remove('hidden');
        document.getElementById('invoiceStatusText').textContent = 'Unable to load billing information.';
    }
}

// Download invoice as PDF (or print to PDF)
function guestDownloadInvoice() {
    const invoiceData = localStorage.getItem('guestInvoiceData');
    if (!invoiceData) {
        alert('Invoice not found');
        return;
    }
    
    const invoice = JSON.parse(invoiceData);
    printInvoice(invoice.invoice_id);
}

// Print invoice
function guestPrintInvoice() {
    const invoiceData = localStorage.getItem('guestInvoiceData');
    if (!invoiceData) {
        alert('Invoice not found');
        return;
    }
    
    const invoice = JSON.parse(invoiceData);
    printInvoice(invoice.invoice_id);
}
