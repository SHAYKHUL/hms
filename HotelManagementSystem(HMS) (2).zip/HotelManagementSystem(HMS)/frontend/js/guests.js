// Guests Management JavaScript

let allGuests = [];

// Load all guests
async function loadGuests() {
    try {
        const response = await apiCall(`${API_ENDPOINTS.guests}`);
        if (response.success) {
            allGuests = response.data;
            displayGuests(allGuests);
        }
    } catch (error) {
        document.getElementById('guestsTable').innerHTML = '<tr><td colspan="7" class="text-danger">Error loading guests</td></tr>';
    }
}

// Display guests
function displayGuests(guests) {
    const tbody = document.getElementById('guestsTable');
    
    if (guests.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No guests found</td></tr>';
        return;
    }
    
    tbody.innerHTML = guests.map(guest => `
        <tr>
            <td>#${guest.guest_id}</td>
            <td>${guest.name}</td>
            <td>${guest.phone}</td>
            <td>${guest.email || '-'}</td>
            <td>${guest.id_proof}</td>
            <td>${formatDate(guest.created_at)}</td>
            <td>
                <button onclick="viewGuestDetails(${guest.guest_id})" class="btn btn-info btn-sm" title="View Details">
                    <i class="fas fa-eye"></i>
                </button>
                <button onclick="editGuest(${guest.guest_id})" class="btn btn-primary btn-sm" title="Edit">
                    <i class="fas fa-edit"></i>
                </button>
                <button onclick="deleteGuest(${guest.guest_id})" class="btn btn-danger btn-sm" title="Delete">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

// Search guests
function searchGuests() {
    const searchTerm = document.getElementById('searchGuest').value.toLowerCase();
    
    const filtered = allGuests.filter(guest => 
        guest.name.toLowerCase().includes(searchTerm) ||
        guest.phone.includes(searchTerm) ||
        (guest.email && guest.email.toLowerCase().includes(searchTerm))
    );
    
    displayGuests(filtered);
}

// Open Add Guest Modal
function openAddGuestModal() {
    document.getElementById('guestModalTitle').textContent = 'Add New Guest';
    document.getElementById('guestForm').reset();
    document.getElementById('guestId').value = '';
    document.getElementById('guestModal').classList.add('show');
}

// Edit guest
async function editGuest(guestId) {
    try {
        const response = await apiCall(`${API_ENDPOINTS.guests}/${guestId}`);
        if (response.success) {
            const guest = response.data;
            
            document.getElementById('guestModalTitle').textContent = 'Edit Guest';
            document.getElementById('guestId').value = guest.guest_id;
            document.getElementById('name').value = guest.name;
            document.getElementById('phone').value = guest.phone;
            document.getElementById('email').value = guest.email || '';
            document.getElementById('idProof').value = guest.id_proof;
            document.getElementById('address').value = guest.address || '';
            
            document.getElementById('guestModal').classList.add('show');
        }
    } catch (error) {
        console.error('Error loading guest:', error);
    }
}

// Close Guest Modal
function closeGuestModal() {
    document.getElementById('guestModal').classList.remove('show');
}

// Handle guest form submission
document.getElementById('guestForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const guestData = {
        name: document.getElementById('name').value,
        phone: document.getElementById('phone').value,
        email: document.getElementById('email').value,
        id_proof: document.getElementById('idProof').value,
        address: document.getElementById('address').value
    };
    
    try {
        const guestId = document.getElementById('guestId').value;
        
        if (guestId) {
            // Update existing guest
            await apiCall(`${API_ENDPOINTS.guests}/${guestId}`, {
                method: 'PUT',
                body: JSON.stringify(guestData)
            });
            showNotification('Guest updated successfully!', 'success');
        } else {
            // Create new guest
            await apiCall(`${API_ENDPOINTS.guests}`, {
                method: 'POST',
                body: JSON.stringify(guestData)
            });
            showNotification('Guest added successfully!', 'success');
        }
        
        closeGuestModal();
        loadGuests();
    } catch (error) {
        console.error('Error saving guest:', error);
    }
});

// Delete guest
async function deleteGuest(guestId) {
    if (!confirm('Are you sure you want to delete this guest? This will also delete all their bookings.')) {
        return;
    }
    
    try {
        await apiCall(`${API_ENDPOINTS.guests}/${guestId}`, {
            method: 'DELETE'
        });
        
        showNotification('Guest deleted successfully!', 'success');
        loadGuests();
    } catch (error) {
        console.error('Error deleting guest:', error);
    }
}

// View guest details and history
async function viewGuestDetails(guestId) {
    try {
        const [guestResponse, historyResponse] = await Promise.all([
            apiCall(`${API_ENDPOINTS.guests}/${guestId}`),
            apiCall(`${API_ENDPOINTS.guests}/${guestId}/history`)
        ]);
        
        const guest = guestResponse.data;
        const history = historyResponse.data;
        
        let detailsHTML = `
            <div style="padding: 20px;">
                <h3>Guest Details</h3>
                <div style="margin-top: 20px;">
                    <p><strong>Name:</strong> ${guest.name}</p>
                    <p><strong>Phone:</strong> ${guest.phone}</p>
                    ${guest.email ? `<p><strong>Email:</strong> ${guest.email}</p>` : ''}
                    <p><strong>ID Proof:</strong> ${guest.id_proof}</p>
                    ${guest.address ? `<p><strong>Address:</strong> ${guest.address}</p>` : ''}
                    <p><strong>Registered:</strong> ${formatDate(guest.created_at)}</p>
                </div>
                
                <h4 style="margin-top: 30px;">Booking History</h4>
        `;
        
        if (history.length === 0) {
            detailsHTML += '<p class="text-muted">No booking history</p>';
        } else {
            detailsHTML += `
                <table class="table" style="margin-top: 15px;">
                    <thead>
                        <tr>
                            <th>Booking ID</th>
                            <th>Room</th>
                            <th>Check-in</th>
                            <th>Check-out</th>
                            <th>Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${history.map(booking => `
                            <tr>
                                <td>#${booking.booking_id}</td>
                                <td>${booking.room_number}</td>
                                <td>${formatDate(booking.check_in)}</td>
                                <td>${formatDate(booking.check_out)}</td>
                                <td>${formatCurrency(booking.total_amount)}</td>
                                <td><span class="badge badge-secondary">${booking.booking_status}</span></td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;
        }
        
        detailsHTML += '</div>';
        
        document.getElementById('guestDetailsContent').innerHTML = detailsHTML;
        document.getElementById('guestDetailsModal').classList.add('show');
    } catch (error) {
        console.error('Error loading guest details:', error);
    }
}

// Close Guest Details Modal
function closeGuestDetailsModal() {
    document.getElementById('guestDetailsModal').classList.remove('show');
}

// Load guests on page load
window.addEventListener('DOMContentLoaded', loadGuests);

// Close modals when clicking outside
window.onclick = function(event) {
    if (event.target.id === 'guestModal') {
        closeGuestModal();
    }
    if (event.target.id === 'guestDetailsModal') {
        closeGuestDetailsModal();
    }
};
