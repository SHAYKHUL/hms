// Services Management JavaScript

let allServices = [];
let allOrders = [];
let currentTab = 'services';

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadServices();
    loadOrders();
    loadPendingOrders();
    
    // Set up form handlers
    document.getElementById('serviceForm').addEventListener('submit', handleServiceSubmit);
    document.getElementById('orderStatusForm').addEventListener('submit', handleOrderStatusSubmit);
    
    // Auto refresh pending orders every 30 seconds
    setInterval(loadPendingOrders, 30000);
});

// Tab Switching
function switchTab(tab) {
    currentTab = tab;
    
    // Update tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    
    if (tab === 'services') {
        document.getElementById('servicesTab').classList.add('active');
    } else if (tab === 'orders') {
        document.getElementById('ordersTab').classList.add('active');
    } else if (tab === 'pending') {
        document.getElementById('pendingTab').classList.add('active');
        loadPendingOrders();
    }
}

// Load Services
async function loadServices() {
    try {
        const response = await fetch(`${API_BASE_URL}/services`);
        const result = await response.json();
        
        if (result.success) {
            allServices = result.data;
            displayServices(allServices);
        }
    } catch (error) {
        console.error('Error loading services:', error);
        showNotification('Error loading services', 'error');
    }
}

// Display Services
function displayServices(services) {
    const grid = document.getElementById('servicesGrid');
    
    if (services.length === 0) {
        grid.innerHTML = '<p class="empty-message">No services found</p>';
        return;
    }
    
    grid.innerHTML = services.map(service => `
        <div class="service-card">
            <div class="service-card-header ${service.availability === 'Available' ? 'available' : 'unavailable'}">
                <span class="service-category">${service.category}</span>
                <span class="service-status">${service.availability}</span>
            </div>
            <div class="service-card-body">
                <h3>${service.service_name}</h3>
                <p class="service-description">${service.description || 'No description'}</p>
                <div class="service-price">₹${parseFloat(service.price).toFixed(2)}</div>
            </div>
            <div class="service-card-actions">
                <button class="btn btn-sm btn-primary" onclick="editService(${service.service_id})">
                    <i class="fas fa-edit"></i> Edit
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteService(${service.service_id})">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </div>
        </div>
    `).join('');
}

// Filter Services
function filterServices() {
    const category = document.getElementById('categoryFilter').value;
    const search = document.getElementById('serviceSearch').value.toLowerCase();
    
    let filtered = allServices;
    
    if (category) {
        filtered = filtered.filter(s => s.category === category);
    }
    
    if (search) {
        filtered = filtered.filter(s => 
            s.service_name.toLowerCase().includes(search) ||
            (s.description && s.description.toLowerCase().includes(search))
        );
    }
    
    displayServices(filtered);
}

// Show Add Service Modal
function showAddServiceModal() {
    document.getElementById('serviceModalTitle').textContent = 'Add Service';
    document.getElementById('serviceForm').reset();
    document.getElementById('serviceId').value = '';
    document.getElementById('serviceModal').style.display = 'block';
}

// Close Service Modal
function closeServiceModal() {
    document.getElementById('serviceModal').style.display = 'none';
}

// Edit Service
async function editService(id) {
    try {
        const service = allServices.find(s => s.service_id === id);
        if (!service) return;
        
        document.getElementById('serviceModalTitle').textContent = 'Edit Service';
        document.getElementById('serviceId').value = service.service_id;
        document.getElementById('serviceName').value = service.service_name;
        document.getElementById('serviceCategory').value = service.category;
        document.getElementById('serviceDescription').value = service.description || '';
        document.getElementById('servicePrice').value = service.price;
        document.getElementById('serviceAvailability').value = service.availability;
        
        document.getElementById('serviceModal').style.display = 'block';
    } catch (error) {
        console.error('Error editing service:', error);
    }
}

// Handle Service Form Submit
async function handleServiceSubmit(e) {
    e.preventDefault();
    
    const serviceId = document.getElementById('serviceId').value;
    const serviceData = {
        service_name: document.getElementById('serviceName').value,
        category: document.getElementById('serviceCategory').value,
        description: document.getElementById('serviceDescription').value,
        price: parseFloat(document.getElementById('servicePrice').value),
        availability: document.getElementById('serviceAvailability').value,
        image_url: ''
    };
    
    try {
        const url = serviceId ? 
            `${API_BASE_URL}/services/${serviceId}` : 
            `${API_BASE_URL}/services`;
        
        const method = serviceId ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(serviceData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            showNotification(result.message, 'success');
            closeServiceModal();
            loadServices();
        } else {
            showNotification(result.message, 'error');
        }
    } catch (error) {
        console.error('Error saving service:', error);
        showNotification('Error saving service', 'error');
    }
}

// Delete Service
async function deleteService(id) {
    if (!confirm('Are you sure you want to delete this service?')) return;
    
    try {
        const response = await fetch(`${API_BASE_URL}/services/${id}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        
        if (result.success) {
            showNotification(result.message, 'success');
            loadServices();
        } else {
            showNotification(result.message, 'error');
        }
    } catch (error) {
        console.error('Error deleting service:', error);
        showNotification('Error deleting service', 'error');
    }
}

// Load Orders
async function loadOrders() {
    try {
        const response = await fetch(`${API_BASE_URL}/service-orders`);
        const result = await response.json();
        
        if (result.success) {
            allOrders = result.data;
            displayOrders(allOrders);
        }
    } catch (error) {
        console.error('Error loading orders:', error);
    }
}

// Display Orders
function displayOrders(orders) {
    const tbody = document.getElementById('ordersTableBody');
    
    if (orders.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center">No orders found</td></tr>';
        return;
    }
    
    tbody.innerHTML = orders.map(order => `
        <tr>
            <td>#${order.order_id}</td>
            <td>${order.room_number}</td>
            <td>${order.guest_name}</td>
            <td>${order.service_name}</td>
            <td>${order.quantity}</td>
            <td>₹${parseFloat(order.total_price).toFixed(2)}</td>
            <td><span class="status-badge status-${order.order_status}">${order.order_status}</span></td>
            <td>${new Date(order.ordered_at).toLocaleString()}</td>
            <td>
                <button class="btn btn-sm btn-primary" onclick="updateOrderStatus(${order.order_id}, '${order.order_status}')">
                    <i class="fas fa-edit"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

// Filter Orders
function filterOrders() {
    const status = document.getElementById('orderStatusFilter').value;
    const search = document.getElementById('orderSearch').value.toLowerCase();
    
    let filtered = allOrders;
    
    if (status) {
        filtered = filtered.filter(o => o.order_status === status);
    }
    
    if (search) {
        filtered = filtered.filter(o => 
            o.guest_name.toLowerCase().includes(search) ||
            o.room_number.toLowerCase().includes(search) ||
            o.service_name.toLowerCase().includes(search)
        );
    }
    
    displayOrders(filtered);
}

// Load Pending Orders
async function loadPendingOrders() {
    try {
        const response = await fetch(`${API_BASE_URL}/service-orders/pending`);
        const result = await response.json();
        
        if (result.success) {
            document.getElementById('pendingCount').textContent = result.data.length;
            displayPendingOrders(result.data);
        }
    } catch (error) {
        console.error('Error loading pending orders:', error);
    }
}

// Display Pending Orders
function displayPendingOrders(orders) {
    const grid = document.getElementById('pendingOrdersGrid');
    
    if (orders.length === 0) {
        grid.innerHTML = '<p class="empty-message">No pending orders</p>';
        return;
    }
    
    grid.innerHTML = orders.map(order => `
        <div class="pending-order-card">
            <div class="order-header">
                <div>
                    <h3>Room ${order.room_number}</h3>
                    <p>${order.guest_name}</p>
                </div>
                <div class="order-time">
                    ${new Date(order.ordered_at).toLocaleTimeString()}
                </div>
            </div>
            <div class="order-details">
                <h4>${order.service_name}</h4>
                <p>Quantity: ${order.quantity} | Total: ₹${parseFloat(order.total_price).toFixed(2)}</p>
                ${order.special_instructions ? `<p class="special-inst"><i class="fas fa-info-circle"></i> ${order.special_instructions}</p>` : ''}
            </div>
            <div class="order-actions">
                <button class="btn btn-sm btn-success" onclick="quickUpdateStatus(${order.order_id}, 'InProgress')">
                    <i class="fas fa-play"></i> Start
                </button>
                <button class="btn btn-sm btn-primary" onclick="quickUpdateStatus(${order.order_id}, 'Completed')">
                    <i class="fas fa-check"></i> Complete
                </button>
                <button class="btn btn-sm btn-danger" onclick="quickUpdateStatus(${order.order_id}, 'Cancelled')">
                    <i class="fas fa-times"></i> Cancel
                </button>
            </div>
        </div>
    `).join('');
}

// Update Order Status
function updateOrderStatus(orderId, currentStatus) {
    document.getElementById('orderUpdateId').value = orderId;
    document.getElementById('orderStatus').value = currentStatus;
    document.getElementById('orderStatusModal').style.display = 'block';
}

// Close Order Status Modal
function closeOrderStatusModal() {
    document.getElementById('orderStatusModal').style.display = 'none';
}

// Handle Order Status Submit
async function handleOrderStatusSubmit(e) {
    e.preventDefault();
    
    const orderId = document.getElementById('orderUpdateId').value;
    const status = document.getElementById('orderStatus').value;
    
    await quickUpdateStatus(orderId, status);
    closeOrderStatusModal();
}

// Quick Update Status
async function quickUpdateStatus(orderId, status) {
    try {
        const response = await fetch(`${API_BASE_URL}/service-orders/${orderId}/status`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showNotification('Order status updated', 'success');
            loadOrders();
            loadPendingOrders();
        } else {
            showNotification(result.message, 'error');
        }
    } catch (error) {
        console.error('Error updating order status:', error);
        showNotification('Error updating order status', 'error');
    }
}

// Show Notification
function showNotification(message, type = 'info') {
    // Simple alert for now - can be enhanced with a toast notification
    alert(message);
}

// Close modal on outside click
window.onclick = function(event) {
    const serviceModal = document.getElementById('serviceModal');
    const statusModal = document.getElementById('orderStatusModal');
    
    if (event.target === serviceModal) {
        closeServiceModal();
    }
    if (event.target === statusModal) {
        closeOrderStatusModal();
    }
}
