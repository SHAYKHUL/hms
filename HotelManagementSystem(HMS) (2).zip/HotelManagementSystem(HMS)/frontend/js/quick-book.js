// Quick Booking System JavaScript
const API_BASE = 'http://localhost:3000/api';
let selectedRoom = null;
let selectedGuest = null;
let availableServices = [];

// Initialize dates to tomorrow and day after
function initializeDates() {
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const dayAfter = new Date(tomorrow);
    dayAfter.setDate(dayAfter.getDate() + 1);

    document.getElementById('checkInDate').value = tomorrow.toISOString().split('T')[0];
    document.getElementById('checkOutDate').value = dayAfter.toISOString().split('T')[0];
}

// Search available rooms
async function searchRooms() {
    const checkIn = document.getElementById('checkInDate').value;
    const checkOut = document.getElementById('checkOutDate').value;
    const numberOfGuests = parseInt(document.getElementById('numberOfGuests').value);
    const roomType = document.getElementById('roomType').value || null;
    const maxPrice = document.getElementById('maxPrice').value ? parseInt(document.getElementById('maxPrice').value) : null;
    const hasAC = document.getElementById('hasAC').checked;

    if (!checkIn || !checkOut) {
        alert('Please select check-in and check-out dates');
        return;
    }

    if (new Date(checkOut) <= new Date(checkIn)) {
        alert('Check-out date must be after check-in date');
        return;
    }

    const roomsContainer = document.getElementById('roomsContainer');
    roomsContainer.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> Searching available rooms...</div>';

    try {
        const response = await fetch(`${API_BASE}/booking-flow/smart-search`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                checkIn,
                checkOut,
                numberOfGuests,
                roomType: roomType || undefined,
                maxPrice: maxPrice || undefined,
                hasAC: hasAC || undefined
            })
        });

        const data = await response.json();

        if (data.success && data.data.length > 0) {
            displayRooms(data.data, checkIn, checkOut);
            updateStepIndicator(2);
        } else {
            roomsContainer.innerHTML = `
                <div class="no-rooms">
                    <i class="fas fa-search"></i>
                    <p>No rooms available matching your criteria</p>
                    <p style="font-size: 12px; margin-top: 10px;">Try adjusting your dates or preferences</p>
                </div>
            `;
        }
    } catch (error) {
        console.error('Search error:', error);
        roomsContainer.innerHTML = `
            <div class="no-rooms">
                <i class="fas fa-exclamation-circle"></i>
                <p>Error searching rooms: ${error.message}</p>
            </div>
        `;
    }
}

// Display available rooms
function displayRooms(rooms, checkIn, checkOut) {
    const roomsContainer = document.getElementById('roomsContainer');
    const nights = Math.ceil((new Date(checkOut) - new Date(checkIn)) / (1000 * 60 * 60 * 24));

    roomsContainer.innerHTML = rooms.map(room => `
        <div class="room-card" onclick="selectRoom(${room.room_id}, '${room.room_number}', ${room.price}, '${room.room_type}', '${room.amenities}', '${checkIn}', '${checkOut}', ${nights})">
            <div class="room-number">Room ${room.room_number}</div>
            <div class="room-type">${room.room_type}</div>
            <div class="room-price">₹${parseFloat(room.price).toLocaleString()}/night</div>
            
            <div style="font-size: 13px; color: #555; margin: 10px 0;">
                <div><strong>Total for ${nights} night${nights > 1 ? 's' : ''}:</strong> ₹${(parseFloat(room.price) * nights).toLocaleString()}</div>
            </div>

            <div class="room-details-grid">
                <div class="detail-item">
                    <span class="detail-label"><i class="fas fa-users"></i></span>
                    <span class="detail-value">${room.max_guests} guests</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label"><i class="fas fa-bed"></i></span>
                    <span class="detail-value">${room.bed_count} bed${room.bed_count > 1 ? 's' : ''}</span>
                </div>
            </div>

            ${room.amenities ? `
                <div style="margin-top: 10px;">
                    ${room.amenities.split(',').map(amenity => `
                        <span class="amenity-badge">
                            <i class="fas fa-check"></i> ${amenity.trim()}
                        </span>
                    `).join('')}
                </div>
            ` : ''}

            <div style="margin-top: 10px; text-align: center; font-size: 12px; color: #3498db;">
                <i class="fas fa-arrow-right"></i> Click to select
            </div>
        </div>
    `).join('');
}

// Select a room
function selectRoom(roomId, roomNumber, price, roomType, amenities, checkIn, checkOut, nights) {
    // Remove selection from other cards
    document.querySelectorAll('.room-card').forEach(card => card.classList.remove('selected'));

    // Mark this room as selected
    event.currentTarget.classList.add('selected');

    selectedRoom = {
        room_id: roomId,
        room_number: roomNumber,
        price: parseFloat(price),
        room_type: roomType,
        amenities,
        checkIn,
        checkOut,
        nights
    };

    // Show booking details section
    document.getElementById('bookingDetailsSection').style.display = 'block';
    updateStepIndicator(3);

    // Load services
    loadServices();

    // Load existing guests for quick selection
    loadGuests();

    // Update summary
    updateSummary();

    // Scroll to booking details
    setTimeout(() => {
        document.getElementById('bookingDetailsSection').scrollIntoView({ behavior: 'smooth' });
    }, 100);
}

// Load available services
async function loadServices() {
    const container = document.getElementById('servicesContainer');
    try {
        const response = await fetch(`${API_BASE}/services`);
        const data = await response.json();

        if (data.success && data.data.length > 0) {
            availableServices = data.data;
            container.innerHTML = data.data.map(service => `
                <div class="service-item">
                    <input type="checkbox" class="service-checkbox" data-service-id="${service.service_id}" data-service-name="${service.service_name}" data-price="${service.price}" onchange="updateSummary()">
                    <div class="service-name">
                        <strong>${service.service_name}</strong>
                        <div style="font-size: 11px; color: #7f8c8d;">${service.category}</div>
                    </div>
                    <div class="service-price">₹${parseFloat(service.price).toFixed(2)}</div>
                    <input type="number" class="service-qty" min="1" value="1" onchange="updateSummary()" style="display: none;">
                </div>
            `).join('');
        } else {
            container.innerHTML = '<div style="padding: 10px; color: #7f8c8d;">No services available</div>';
        }
    } catch (error) {
        console.error('Error loading services:', error);
        container.innerHTML = `<div style="padding: 10px; color: #e74c3c;">Error loading services</div>`;
    }
}

// Load guests for selection
async function loadGuests() {
    try {
        const response = await fetch(`${API_BASE}/guests`);
        const data = await response.json();

        if (data.success && data.data.length > 0) {
            // Create a quick select dropdown
            const guestName = document.getElementById('guestName');
            guestName.setAttribute('list', 'guestsList');
            
            // Create datalist if not exists
            let datalist = document.getElementById('guestsList');
            if (!datalist) {
                datalist = document.createElement('datalist');
                datalist.id = 'guestsList';
                document.body.appendChild(datalist);
            }
            
            datalist.innerHTML = data.data.map(guest => `
                <option value="${guest.name}">${guest.phone}</option>
            `).join('');
        }
    } catch (error) {
        console.error('Error loading guests:', error);
    }
}

// Update booking summary
function updateSummary() {
    if (!selectedRoom) return;

    const nights = selectedRoom.nights;
    const roomTotal = selectedRoom.price * nights;
    let servicesTotal = 0;

    // Calculate services total
    document.querySelectorAll('.service-checkbox:checked').forEach(checkbox => {
        const qty = parseInt(checkbox.parentElement.querySelector('.service-qty').value) || 1;
        const price = parseFloat(checkbox.getAttribute('data-price'));
        servicesTotal += price * qty;
    });

    // Get discount
    const discountType = document.getElementById('discountType').value;
    const discountValue = parseFloat(document.getElementById('discountValue').value) || 0;
    let discountAmount = 0;

    if (discountType === 'Percentage' && discountValue > 0) {
        discountAmount = (roomTotal * discountValue) / 100;
    } else if (discountType === 'Fixed' && discountValue > 0) {
        discountAmount = discountValue;
    }

    const totalAmount = roomTotal + servicesTotal - discountAmount;
    const advancePayment = parseFloat(document.getElementById('advancePayment').value) || 0;
    const balanceDue = totalAmount - advancePayment;

    // Update summary fields
    document.getElementById('summaryRoom').textContent = `Room ${selectedRoom.room_number} (${selectedRoom.room_type})`;
    document.getElementById('summaryDates').textContent = `${new Date(selectedRoom.checkIn).toLocaleDateString()} - ${new Date(selectedRoom.checkOut).toLocaleDateString()}`;
    document.getElementById('summaryNights').textContent = nights;
    document.getElementById('summaryRoomPrice').textContent = `₹${selectedRoom.price.toLocaleString()}`;
    document.getElementById('summaryTotal').textContent = `₹${totalAmount.toFixed(2)}`;
    document.getElementById('summaryAdvance').textContent = `₹${advancePayment.toFixed(2)}`;
    document.getElementById('summaryBalance').textContent = `₹${balanceDue.toFixed(2)}`;

    // Show/hide discount
    if (discountAmount > 0) {
        document.getElementById('discountSummary').style.display = 'flex';
        document.getElementById('summaryDiscount').textContent = `-₹${discountAmount.toFixed(2)}`;
    } else {
        document.getElementById('discountSummary').style.display = 'none';
    }

    // Show/hide services
    if (servicesTotal > 0) {
        document.getElementById('servicesSummary').style.display = 'block';
        document.getElementById('summaryServices').textContent = `₹${servicesTotal.toFixed(2)}`;
    } else {
        document.getElementById('servicesSummary').style.display = 'none';
    }
}

// Create or select guest
async function upsertGuest() {
    const name = document.getElementById('guestName').value.trim();
    const phone = document.getElementById('guestPhone').value.trim();
    const email = document.getElementById('guestEmail').value.trim();
    const idProof = document.getElementById('guestIdProof').value.trim();
    const address = document.getElementById('guestAddress').value.trim();

    if (!name || !phone || !idProof) {
        alert('Please fill in guest name, phone, and ID proof');
        return null;
    }

    try {
        // Try to find existing guest
        const response = await fetch(`${API_BASE}/guests`);
        const data = await response.json();
        
        const existingGuest = data.data.find(g => g.phone === phone);
        if (existingGuest) {
            selectedGuest = existingGuest;
            return existingGuest.guest_id;
        }

        // Create new guest
        const createResponse = await fetch(`${API_BASE}/guests`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, phone, email, id_proof: idProof, address })
        });

        const newGuestData = await createResponse.json();
        if (newGuestData.success) {
            selectedGuest = newGuestData.data;
            return newGuestData.data.guest_id;
        } else {
            alert('Error creating guest: ' + (newGuestData.message || 'Unknown error'));
            return null;
        }
    } catch (error) {
        console.error('Guest upsert error:', error);
        alert('Error processing guest information');
        return null;
    }
}

// Confirm and create booking
async function confirmBooking() {
    // Validate guest information
    const guestId = await upsertGuest();
    if (!guestId) return;

    if (!selectedRoom) {
        alert('No room selected');
        return;
    }

    const confirmBookingBtn = document.getElementById('confirmBookingBtn');
    confirmBookingBtn.disabled = true;
    confirmBookingBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';

    try {
        // Collect selected services
        const selectedServices = [];
        document.querySelectorAll('.service-checkbox:checked').forEach(checkbox => {
            selectedServices.push({
                service_id: parseInt(checkbox.getAttribute('data-service-id')),
                service_name: checkbox.getAttribute('data-service-name'),
                price: parseFloat(checkbox.getAttribute('data-price')),
                quantity: parseInt(checkbox.parentElement.querySelector('.service-qty').value) || 1
            });
        });

        // Prepare booking data
        const bookingData = {
            guest_id: guestId,
            room_id: selectedRoom.room_id,
            check_in: selectedRoom.checkIn,
            check_out: selectedRoom.checkOut,
            number_of_guests: parseInt(document.getElementById('numberOfGuests').value),
            payment_method: document.getElementById('paymentMethod').value,
            advance_payment: parseFloat(document.getElementById('advancePayment').value) || 0,
            discount_type: document.getElementById('discountType').value,
            discount_value: parseFloat(document.getElementById('discountValue').value) || 0,
            discount_reason: document.getElementById('discountReason').value,
            special_requests: document.getElementById('specialRequests').value,
            selected_services: selectedServices
        };

        // Create booking with invoice
        const response = await fetch(`${API_BASE}/booking-flow/create-with-invoice`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bookingData)
        });

        const result = await response.json();

        if (result.success) {
            // Show success message
            alert(`✅ Booking confirmed!\nBooking ID: ${result.booking_id}\n\nInvoice will open in a new window...`);

            // Open invoice in new window
            const invoiceWindow = window.open('', 'invoice', 'width=900,height=600');
            invoiceWindow.document.write(result.invoice);
            invoiceWindow.document.close();

            // Reset form after 2 seconds
            setTimeout(() => {
                resetBooking();
            }, 2000);
        } else {
            alert('Booking failed: ' + (result.message || 'Unknown error'));
        }
    } catch (error) {
        console.error('Booking error:', error);
        alert('Error creating booking: ' + error.message);
    } finally {
        confirmBookingBtn.disabled = false;
        confirmBookingBtn.innerHTML = '<i class="fas fa-check-circle"></i> Confirm & Generate Invoice';
    }
}

// Reset booking form
function resetBooking() {
    selectedRoom = null;
    selectedGuest = null;

    document.getElementById('bookingDetailsSection').style.display = 'none';
    document.getElementById('guestName').value = '';
    document.getElementById('guestPhone').value = '';
    document.getElementById('guestEmail').value = '';
    document.getElementById('guestIdProof').value = '';
    document.getElementById('guestAddress').value = '';
    document.getElementById('paymentMethod').value = 'Cash';
    document.getElementById('advancePayment').value = '0';
    document.getElementById('discountType').value = 'None';
    document.getElementById('discountValue').value = '0';
    document.getElementById('discountReason').value = '';
    document.getElementById('specialRequests').value = '';
    document.getElementById('numberOfGuests').value = '1';
    document.getElementById('roomType').value = '';
    document.getElementById('maxPrice').value = '';
    document.getElementById('hasAC').checked = false;

    document.querySelectorAll('.room-card').forEach(card => card.classList.remove('selected'));
    document.getElementById('roomsContainer').innerHTML = '<div class="loading"><i class="fas fa-info-circle"></i> Select dates and click search to see available rooms</div>';

    updateStepIndicator(1);
}

// Update step indicator
function updateStepIndicator(step) {
    document.querySelectorAll('.step').forEach((el, index) => {
        if (index + 1 <= step) {
            el.classList.add('active');
        } else {
            el.classList.remove('active');
        }
    });
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    initializeDates();
});

// Add event listeners for summary updates
document.addEventListener('change', (e) => {
    if (e.target.id === 'advancePayment' || 
        e.target.id === 'discountType' || 
        e.target.id === 'discountValue') {
        updateSummary();
    }
});

document.addEventListener('input', (e) => {
    if (e.target.id === 'advancePayment' || 
        e.target.id === 'discountValue') {
        updateSummary();
    }
});
