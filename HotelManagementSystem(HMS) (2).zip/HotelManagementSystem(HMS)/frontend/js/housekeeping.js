// Housekeeping Management - Frontend Logic (Enhanced)
// Complete room cleaning status tracking, cleaning tasks, maintenance management

let allStaff = [];
let allRooms = [];
let allTasks = [];
let allMaintenance = [];
let roomCleaningStatus = {};

// Initialize on page load
document.addEventListener('DOMContentLoaded', async function() {
    console.log('Housekeeping Management loaded');
    await loadDashboard();
    await loadStaff();
    await loadRoomsWithCleaningStatus();
    await loadCleaningTasks();
    await loadMaintenance();
    populateDropdowns();
});

// ============ COMPREHENSIVE DASHBOARD ============

async function loadDashboard() {
    try {
        console.log('Loading comprehensive housekeeping dashboard...');
        const response = await fetch(`${API_BASE_URL}/housekeeping/dashboard/comprehensive`);
        if (!response.ok) throw new Error('Failed to load dashboard');
        
        const result = await response.json();
        if (result.success) {
            displayDashboardMetrics(result.data);
        }
    } catch (error) {
        console.error('Error loading dashboard:', error);
        await loadStatistics(); // Fallback to simple stats
    }
}

function displayDashboardMetrics(data) {
    const statsContainer = document.getElementById('statsContainer');
    if (!statsContainer) return;

    const { staffStats, cleaningStats, maintStats, roomStats, criticalMaintenance } = data;

    let html = `
        <div class="stat-card">
            <h4>Active Staff</h4>
            <div class="value">${staffStats.totalStaff || 0}</div>
        </div>
        <div class="stat-card">
            <h4>Available Rooms</h4>
            <div class="value">${roomStats.available_rooms || 0}/${roomStats.total_rooms || 0}</div>
        </div>
        <div class="stat-card">
            <h4>Completed Today</h4>
            <div class="value">${cleaningStats.completedToday || 0}</div>
        </div>
        <div class="stat-card">
            <h4>Pending Tasks</h4>
            <div class="value" style="color: #ff6b6b;">${cleaningStats.pendingTasks || 0}</div>
        </div>
        <div class="stat-card">
            <h4>Cleaned Rooms</h4>
            <div class="value">${roomStats.cleaned_rooms || 0}</div>
        </div>
        <div class="stat-card">
            <h4>Critical Issues</h4>
            <div class="value" style="color: #ff6b6b;">${criticalMaintenance.length || 0}</div>
        </div>
    `;

    statsContainer.innerHTML = html;
}

// ============ DATA LOADING ============

async function loadRoomsWithCleaningStatus() {
    try {
        console.log('Loading rooms with cleaning status...');
        const response = await fetch(`${API_BASE_URL}/housekeeping/rooms`);
        if (!response.ok) throw new Error('Failed to load rooms');
        
        const result = await response.json();
        if (result.success) {
            allRooms = result.data || [];
            console.log(`Loaded ${allRooms.length} rooms with status`);
        }
    } catch (error) {
        console.error('Error loading rooms:', error);
        // Fallback to basic rooms loading
        const response = await fetch(`${API_BASE_URL}/rooms`);
        const result = await response.json();
        if (result.success) allRooms = result.data || [];
    }
}

async function loadStaff() {
    try {
        console.log('Loading housekeeping staff...');
        const response = await fetch(`${API_BASE_URL}/housekeeping/staff`);
        const result = await response.json();

        if (result.success) {
            allStaff = result.data || [];
            console.log(`Loaded ${allStaff.length} staff members`);
            displayStaff(allStaff);
        }
    } catch (error) {
        console.error('Error loading staff:', error);
    }
}

async function loadCleaningTasks() {
    try {
        console.log('Loading cleaning tasks...');
        const response = await fetch(`${API_BASE_URL}/housekeeping/tasks`);
        const result = await response.json();

        if (result.success) {
            allTasks = result.data || [];
            console.log(`Loaded ${allTasks.length} cleaning tasks`);
            displayCleaningTasks(allTasks);
        }
    } catch (error) {
        console.error('Error loading tasks:', error);
    }
}

async function loadMaintenance() {
    try {
        console.log('Loading maintenance logs...');
        const response = await fetch(`${API_BASE_URL}/housekeeping/maintenance`);
        const result = await response.json();

        if (result.success) {
            allMaintenance = result.data || [];
            console.log(`Loaded ${allMaintenance.length} maintenance logs`);
            displayMaintenance(allMaintenance);
            displayCriticalAlerts();
        }
    } catch (error) {
        console.error('Error loading maintenance:', error);
    }
}

async function loadStatistics() {
    try {
        console.log('Loading statistics...');
        const response = await fetch(`${API_BASE_URL}/housekeeping/stats/overview`);
        const result = await response.json();

        if (result.success) {
            displayDashboardMetrics(result.data);
        }
    } catch (error) {
        console.error('Error loading statistics:', error);
    }
}

// ============ DISPLAY FUNCTIONS ============

function displayStaff(staff) {
    const tbody = document.getElementById('staffTableBody');
    
    if (!staff || staff.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: #999;">No staff members found</td></tr>';
        return;
    }

    let html = '';
    staff.forEach(s => {
        const statusBadge = `<span class="badge badge-${s.status.toLowerCase()}">${s.status}</span>`;
        
        html += '<tr>';
        html += `<td>${escapeHtml(s.staff_name)}</td>`;
        html += `<td>${s.role}</td>`;
        html += `<td>${s.shift || 'Morning'}</td>`;
        html += `<td>${statusBadge}</td>`;
        html += `<td>${s.phone}</td>`;
        html += '<td class="action-buttons">';
        html += `<button class="btn-small btn-primary" onclick="editStaff(${s.staff_id})"><i class="fas fa-edit"></i></button>`;
        html += `<button class="btn-small btn-danger" onclick="deleteStaff(${s.staff_id})"><i class="fas fa-trash"></i></button>`;
        html += '</td>';
        html += '</tr>';
    });

    tbody.innerHTML = html;
}

function displayCleaningTasks(tasks) {
    const tbody = document.getElementById('tasksTableBody');
    
    if (!tasks || tasks.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; color: #999;">No tasks found</td></tr>';
        return;
    }

    let html = '';
    tasks.forEach(t => {
        const statusBadge = `<span class="badge badge-${t.status.toLowerCase().replace(' ', '-')}">${t.status}</span>`;
        const priorityBadge = `<span class="badge badge-${t.priority.toLowerCase()}">${t.priority}</span>`;
        const roomNum = allRooms.find(r => r.room_id === t.room_id)?.room_number || `Room ${t.room_id}`;
        
        html += '<tr>';
        html += `<td>${roomNum}</td>`;
        html += `<td>${t.task_type}</td>`;
        html += `<td>${statusBadge}</td>`;
        html += `<td>${priorityBadge}</td>`;
        html += `<td>${t.staff_name || '(Unassigned)'}</td>`;
        html += `<td>${t.scheduled_date}</td>`;
        html += '<td class="action-buttons">';
        html += `<button class="btn-small btn-primary" onclick="viewTask(${t.task_id})"><i class="fas fa-eye"></i></button>`;
        if (t.status === 'Not Started') {
            html += `<button class="btn-small btn-success" onclick="startTask(${t.task_id})"><i class="fas fa-play"></i></button>`;
        }
        if (t.status === 'In Progress') {
            html += `<button class="btn-small btn-success" onclick="completeTask(${t.task_id})"><i class="fas fa-check"></i></button>`;
        }
        html += `<button class="btn-small btn-danger" onclick="deleteTask(${t.task_id})"><i class="fas fa-trash"></i></button>`;
        html += '</td>';
        html += '</tr>';
    });

    tbody.innerHTML = html;
}

function displayMaintenance(logs) {
    const tbody = document.getElementById('maintTableBody');
    
    if (!logs || logs.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; color: #999;">No maintenance issues found</td></tr>';
        return;
    }

    let html = '';
    logs.forEach(m => {
        const statusBadge = `<span class="badge badge-${m.status.toLowerCase().replace(' ', '-')}">${m.status}</span>`;
        const severityBadge = `<span class="badge badge-${m.severity.toLowerCase()}">${m.severity}</span>`;
        const roomNum = allRooms.find(r => r.room_id === m.room_id)?.room_number || `Room ${m.room_id}`;
        
        html += '<tr>';
        html += `<td>${roomNum}</td>`;
        html += `<td>${m.maintenance_type}</td>`;
        html += `<td>${m.issue_description.substring(0, 30)}...</td>`;
        html += `<td>${severityBadge}</td>`;
        html += `<td>${statusBadge}</td>`;
        html += `<td>${m.assigned_to || '(Unassigned)'}</td>`;
        html += '<td class="action-buttons">';
        html += `<button class="btn-small btn-primary" onclick="viewMaintenance(${m.log_id})"><i class="fas fa-eye"></i></button>`;
        if (m.status === 'Reported' || m.status === 'Assigned') {
            html += `<button class="btn-small btn-success" onclick="startMaintenance(${m.log_id})"><i class="fas fa-play"></i></button>`;
        }
        if (m.status === 'In Progress') {
            html += `<button class="btn-small btn-success" onclick="completeMaintenance(${m.log_id})"><i class="fas fa-check"></i></button>`;
        }
        html += `<button class="btn-small btn-danger" onclick="deleteMaintenance(${m.log_id})"><i class="fas fa-trash"></i></button>`;
        html += '</td>';
        html += '</tr>';
    });

    tbody.innerHTML = html;
}

function displayCriticalAlerts() {
    const criticalLogs = allMaintenance.filter(m => 
        m.severity === 'Critical' && 
        m.status !== 'Completed'
    );

    const alertsDiv = document.getElementById('criticalAlerts');
    
    if (criticalLogs.length === 0) {
        alertsDiv.innerHTML = '';
        return;
    }

    let html = '';
    criticalLogs.forEach(log => {
        const room = allRooms.find(r => r.room_id === log.room_id);
        html += `
            <div class="critical-alert">
                <i class="fas fa-exclamation-triangle"></i>
                <strong>Critical Issue:</strong> ${log.maintenance_type} in ${room?.room_number || 'Room ' + log.room_id}
                <p>${log.issue_description}</p>
                <button class="btn-small btn-danger" onclick="viewMaintenance(${log.log_id})">View Details</button>
            </div>
        `;
    });

    alertsDiv.innerHTML = html;
}

// ============ ROOM CLEANING STATUS MANAGEMENT ============

function getCleaningStatusBadge(status) {
    const badges = {
        'Dirty': '<span class="badge badge-danger">Dirty</span>',
        'Cleaning in Progress': '<span class="badge badge-warning">In Progress</span>',
        'Cleaned': '<span class="badge badge-success">Cleaned</span>',
        'Ready for Guest': '<span class="badge badge-success">Ready</span>',
        'Pending': '<span class="badge badge-pending">Pending</span>',
        'Inspecting': '<span class="badge badge-info">Inspecting</span>'
    };
    return badges[status] || badges['Pending'];
}

function updateRoomCleaningStatus(roomId) {
    const room = allRooms.find(r => r.room_id === roomId);
    if (!room) return;

    const newStatus = prompt(`Update cleaning status for Room ${room.room_number}:\n\nOptions:\n- Dirty\n- Cleaning in Progress\n- Cleaned\n- Ready for Guest\n- Pending\n- Inspecting`, 'Cleaned');
    
    if (!newStatus) return;

    const validStatuses = ['Dirty', 'Cleaning in Progress', 'Cleaned', 'Ready for Guest', 'Pending', 'Inspecting'];
    if (!validStatuses.includes(newStatus)) {
        showError('Invalid status selected');
        return;
    }

    updateCleaningStatus(roomId, newStatus);
}

async function updateCleaningStatus(roomId, cleaningStatus, staffId = null) {
    try {
        const response = await fetch(`${API_BASE_URL}/housekeeping/rooms/${roomId}/status`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cleaningStatus, staffId })
        });

        const result = await response.json();
        if (result.success) {
            showSuccess('Room status updated successfully');
            await loadRoomsWithCleaningStatus();
        } else {
            showError('Error: ' + result.message);
        }
    } catch (error) {
        console.error('Error updating room status:', error);
        showError('Failed to update room status');
    }
}

// ============ MODAL FUNCTIONS ============

function populateDropdowns() {
    // Rooms dropdown for tasks
    const taskRoomSelect = document.getElementById('taskRoom');
    const maintRoomSelect = document.getElementById('maintRoom');
    const taskStaffSelect = document.getElementById('taskStaff');

    taskRoomSelect.innerHTML = '<option value="">-- Select Room --</option>';
    maintRoomSelect.innerHTML = '<option value="">-- Select Room --</option>';
    taskStaffSelect.innerHTML = '<option value="">-- Unassigned --</option>';

    allRooms.forEach(room => {
        const option = document.createElement('option');
        option.value = room.room_id;
        option.textContent = `Room ${room.room_number} (${room.room_type})`;
        taskRoomSelect.appendChild(option);
        maintRoomSelect.appendChild(option.cloneNode(true));
    });

    allStaff.filter(s => s.role === 'Housekeeper').forEach(staff => {
        const option = document.createElement('option');
        option.value = staff.staff_id;
        option.textContent = staff.staff_name;
        taskStaffSelect.appendChild(option);
    });
}

function openStaffModal() {
    document.getElementById('staffForm').reset();
    document.getElementById('staffModal').classList.add('active');
}

function closeStaffModal() {
    document.getElementById('staffModal').classList.remove('active');
}

function openTaskModal() {
    document.getElementById('taskForm').reset();
    document.getElementById('taskModal').classList.add('active');
}

function closeTaskModal() {
    document.getElementById('taskModal').classList.remove('active');
}

function openMaintenanceModal() {
    document.getElementById('maintForm').reset();
    document.getElementById('maintModal').classList.add('active');
}

function closeMaintenanceModal() {
    document.getElementById('maintModal').classList.remove('active');
}

// ============ SAVE FUNCTIONS ============

async function saveStaff(event) {
    event.preventDefault();

    const staffName = document.getElementById('staffName').value.trim();
    const phone = document.getElementById('staffPhone').value.trim();
    const email = document.getElementById('staffEmail').value.trim();
    const role = document.getElementById('staffRole').value;
    const shift = document.getElementById('staffShift').value;
    const assignedFloors = document.getElementById('staffFloors').value.trim();

    if (!staffName || !phone) {
        showError('Name and phone are required');
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/housekeeping/staff`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                staffName,
                phone,
                email: email || null,
                role,
                shift,
                assignedFloors: assignedFloors || null
            })
        });

        const result = await response.json();

        if (result.success) {
            showSuccess('Staff added successfully');
            closeStaffModal();
            await loadStaff();
            populateDropdowns();
        } else {
            showError(result.message);
        }
    } catch (error) {
        console.error('Error saving staff:', error);
        showError('Error saving staff');
    }
}

async function saveTask(event) {
    event.preventDefault();

    const roomId = parseInt(document.getElementById('taskRoom').value);
    const taskType = document.getElementById('taskType').value;
    const priority = document.getElementById('taskPriority').value;
    const scheduledDate = document.getElementById('taskDate').value;
    const staffId = document.getElementById('taskStaff').value;
    const notes = document.getElementById('taskNotes').value.trim();

    if (!roomId || !taskType || !priority || !scheduledDate) {
        showError('Room, task type, priority, and date are required');
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/housekeeping/tasks`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                roomId,
                taskType,
                priority,
                scheduledDate,
                staffId: staffId ? parseInt(staffId) : null,
                notes: notes || null,
                assignedBy: 1
            })
        });

        const result = await response.json();

        if (result.success) {
            showSuccess('Task created successfully');
            closeTaskModal();
            await loadCleaningTasks();
            await loadStatistics();
        } else {
            showError(result.message);
        }
    } catch (error) {
        console.error('Error saving task:', error);
        showError('Error creating task');
    }
}

async function saveMaintenance(event) {
    event.preventDefault();

    const roomId = parseInt(document.getElementById('maintRoom').value);
    const maintenanceType = document.getElementById('maintType').value;
    const issueDescription = document.getElementById('maintDesc').value.trim();
    const severity = document.getElementById('maintSeverity').value;
    const costEstimate = parseFloat(document.getElementById('maintCost').value) || null;

    if (!roomId || !maintenanceType || !issueDescription || !severity) {
        showError('All required fields are necessary');
        return;
    }

    try {
        // Use new endpoint that auto-updates room status
        const response = await fetch(`${API_BASE_URL}/housekeeping/maintenance/report-with-room-update`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                roomId,
                maintenanceType,
                issueDescription,
                severity,
                costEstimate,
                reportedBy: 'Staff'
            })
        });

        const result = await response.json();

        if (result.success) {
            showSuccess('Issue reported successfully');
            closeMaintenanceModal();
            await loadMaintenance();
            await loadRoomsWithCleaningStatus();
            await loadDashboard();
        } else {
            showError(result.message);
        }
    } catch (error) {
        console.error('Error reporting issue:', error);
        showError('Error reporting maintenance issue');
    }
}

// ============ ACTION FUNCTIONS ============

async function startTask(taskId) {
    try {
        const response = await fetch(`${API_BASE_URL}/housekeeping/tasks/${taskId}/start`, {
            method: 'PATCH'
        });

        const result = await response.json();

        if (result.success) {
            showSuccess('Task started');
            await loadCleaningTasks();
        } else {
            showError(result.message);
        }
    } catch (error) {
        console.error('Error starting task:', error);
        showError('Error starting task');
    }
}

async function completeTask(taskId) {
    const notes = prompt('Add completion notes (optional):');
    
    try {
        const response = await fetch(`${API_BASE_URL}/housekeeping/tasks/${taskId}/complete`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ notes: notes || '' })
        });

        const result = await response.json();

        if (result.success) {
            showSuccess('Task completed');
            await loadCleaningTasks();
            await loadStatistics();
        } else {
            showError(result.message);
        }
    } catch (error) {
        console.error('Error completing task:', error);
        showError('Error completing task');
    }
}

async function deleteTask(taskId) {
    if (!confirm('Are you sure you want to delete this task?')) return;

    try {
        const response = await fetch(`${API_BASE_URL}/housekeeping/tasks/${taskId}`, {
            method: 'DELETE'
        });

        const result = await response.json();

        if (result.success) {
            showSuccess('Task deleted');
            await loadCleaningTasks();
        } else {
            showError(result.message);
        }
    } catch (error) {
        console.error('Error deleting task:', error);
        showError('Error deleting task');
    }
}

async function startMaintenance(logId) {
    try {
        const response = await fetch(`${API_BASE_URL}/housekeeping/maintenance/${logId}/start`, {
            method: 'PATCH'
        });

        const result = await response.json();

        if (result.success) {
            showSuccess('Maintenance work started');
            await loadMaintenance();
        } else {
            showError(result.message);
        }
    } catch (error) {
        console.error('Error starting maintenance:', error);
        showError('Error starting maintenance');
    }
}

async function completeMaintenance(logId) {
    const actualCost = prompt('Enter actual cost (optional):');
    const notes = prompt('Add completion notes (optional):');
    
    try {
        // Use new endpoint that auto-updates room status
        const response = await fetch(`${API_BASE_URL}/housekeeping/maintenance/${logId}/complete-with-room-update`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                actualCost: actualCost ? parseFloat(actualCost) : null,
                notes: notes || ''
            })
        });

        const result = await response.json();

        if (result.success) {
            showSuccess('Maintenance completed and room status updated');
            await loadMaintenance();
            await loadRoomsWithCleaningStatus();
            await loadDashboard();
        } else {
            showError(result.message);
        }
    } catch (error) {
        console.error('Error completing maintenance:', error);
        showError('Error completing maintenance');
    }
}

async function deleteMaintenance(logId) {
    if (!confirm('Are you sure you want to delete this maintenance record?')) return;

    try {
        const response = await fetch(`${API_BASE_URL}/housekeeping/maintenance/${logId}`, {
            method: 'DELETE'
        });

        const result = await response.json();

        if (result.success) {
            showSuccess('Maintenance record deleted');
            await loadMaintenance();
        } else {
            showError(result.message);
        }
    } catch (error) {
        console.error('Error deleting maintenance:', error);
        showError('Error deleting maintenance');
    }
}

async function deleteStaff(staffId) {
    if (!confirm('Are you sure you want to delete this staff member?')) return;

    try {
        const response = await fetch(`${API_BASE_URL}/housekeeping/staff/${staffId}`, {
            method: 'DELETE'
        });

        const result = await response.json();

        if (result.success) {
            showSuccess('Staff deleted');
            await loadStaff();
            populateDropdowns();
        } else {
            showError(result.message);
        }
    } catch (error) {
        console.error('Error deleting staff:', error);
        showError('Error deleting staff');
    }
}

// ============ FILTER FUNCTIONS ============

function filterCleaningTasks() {
    const status = document.getElementById('taskStatusFilter').value;
    const date = document.getElementById('taskDateFilter').value;

    let filtered = allTasks;

    if (status) {
        filtered = filtered.filter(t => t.status === status);
    }

    if (date) {
        filtered = filtered.filter(t => t.scheduled_date === date);
    }

    displayCleaningTasks(filtered);
}

function filterMaintenance() {
    const status = document.getElementById('maintStatusFilter').value;
    const severity = document.getElementById('maintSeverityFilter').value;

    let filtered = allMaintenance;

    if (status) {
        filtered = filtered.filter(m => m.status === status);
    }

    if (severity) {
        filtered = filtered.filter(m => m.severity === severity);
    }

    displayMaintenance(filtered);
}

// ============ TAB SWITCHING ============

function switchTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));

    document.getElementById(tabName).classList.add('active');
    event.target.classList.add('active');
}

// ============ PLACEHOLDER FUNCTIONS ============

function viewTask(taskId) {
    const task = allTasks.find(t => t.task_id === taskId);
    if (task) {
        alert(`Task: ${task.task_type}\nRoom: ${task.room_number}\nStatus: ${task.status}`);
    }
}

function editStaff(staffId) {
    const staff = allStaff.find(s => s.staff_id === staffId);
    if (staff) {
        alert(`Edit: ${staff.staff_name}`);
    }
}

function viewMaintenance(logId) {
    const log = allMaintenance.find(m => m.log_id === logId);
    if (log) {
        alert(`Issue: ${log.maintenance_type}\nRoom: ${log.room_number}\nStatus: ${log.status}\nDescription: ${log.issue_description}`);
    }
}

// ============ UTILITY FUNCTIONS ============

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showError(message) {
    console.error(message);
    alert(message);
}

function showSuccess(message) {
    console.log(message);
    alert(message);
}

// Close modals when clicking outside
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.classList.remove('active');
    }
}

// ============ REPORTING FUNCTIONS ============

async function generateCleaningReport() {
    try {
        const response = await fetch(`${API_BASE_URL}/housekeeping/reports/cleaning-efficiency?days=30`);
        const result = await response.json();
        
        if (result.success) {
            displayReportModal('Cleaning Efficiency Report (30 days)', result.data);
        } else {
            showError('Failed to generate report');
        }
    } catch (error) {
        console.error('Error generating report:', error);
        showError('Failed to generate report');
    }
}

async function generateMaintenanceReport() {
    try {
        const response = await fetch(`${API_BASE_URL}/housekeeping/reports/maintenance-tracking?days=30`);
        const result = await response.json();
        
        if (result.success) {
            displayReportModal('Maintenance Tracking Report (30 days)', result.data);
        } else {
            showError('Failed to generate report');
        }
    } catch (error) {
        console.error('Error generating report:', error);
        showError('Failed to generate report');
    }
}

async function generateDailySummary() {
    try {
        const today = new Date().toISOString().split('T')[0];
        const response = await fetch(`${API_BASE_URL}/housekeeping/reports/daily-summary?date=${today}`);
        const result = await response.json();
        
        if (result.success) {
            displayReportModal('Daily Cleaning Summary', result.data);
        } else {
            showError('Failed to generate report');
        }
    } catch (error) {
        console.error('Error generating report:', error);
        showError('Failed to generate report');
    }
}

function displayReportModal(title, data) {
    let html = `<h3>${title}</h3>`;
    
    if (Array.isArray(data) && data.length > 0) {
        html += '<table style="width: 100%; border-collapse: collapse; margin-top: 10px;">';
        const headers = Object.keys(data[0]);
        
        html += '<thead><tr>';
        headers.forEach(h => html += `<th style="border: 1px solid #ddd; padding: 8px; text-align: left; background: #f0f0f0;">${h}</th>`);
        html += '</tr></thead><tbody>';
        
        data.forEach(row => {
            html += '<tr>';
            headers.forEach(h => {
                let val = row[h];
                if (typeof val === 'number') val = val.toFixed(2);
                html += `<td style="border: 1px solid #ddd; padding: 8px;">${val || '-'}</td>`;
            });
            html += '</tr>';
        });
        html += '</tbody></table>';
    } else {
        html += '<p style="color: #999;">No data available for this period</p>';
    }
    
    const modal = document.createElement('div');
    modal.className = 'modal active';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>${title}</h2>
                <button class="close-btn" onclick="this.closest('.modal').remove()">×</button>
            </div>
            <div style="max-height: 60vh; overflow-y: auto;">${html}</div>
            <div style="margin-top: 1rem; text-align: right;">
                <button class="btn-cancel" onclick="this.closest('.modal').remove()">Close</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}
