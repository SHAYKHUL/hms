# Deployment & Operations Guide

## 🚀 Deployment Instructions

### 1. Local Development Setup

#### Prerequisites
- Node.js v14+ installed
- MySQL 5.7+ running
- Windows/Mac/Linux OS
- Git (optional)

#### Quick Start (5 minutes)

**Step 1: Download Project**
```bash
# Extract project folder to your preferred location
cd d:\ShaykhulWork\HotelManagementSystem(HMS)
```

**Step 2: Setup Database**
```bash
# Option A: Using MySQL Workbench
# 1. Open MySQL Workbench
# 2. Click "File" → "Open SQL Script"
# 3. Select database/schema.sql
# 4. Click "Execute" (lightning bolt icon)

# Option B: Using Command Line
mysql -u root -p < database/schema.sql
# When prompted, enter your MySQL password
```

**Step 3: Install Backend**
```bash
cd backend
npm install
```

**Step 4: Configure Environment**
```bash
# Edit backend/.env file
# Change DB_PASSWORD to your MySQL password

DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_actual_password
DB_NAME=hotel_management_db
PORT=3000
```

**Step 5: Start Backend**
```bash
npm start

# Expected output:
# Server running on http://localhost:3000
# Connected to database
```

**Step 6: Open Frontend**
```bash
# Option A: Direct file open
# Navigate to frontend/index.html and open in browser
# (May have CORS issues - use Option B)

# Option B: Local HTTP Server
cd ../frontend
python -m http.server 8080

# Then open: http://localhost:8080
```

---

### 2. Windows Server Deployment

#### Using IIS and MySQL on Windows Server

**Step 1: Install Prerequisites**
```bash
# Run PowerShell as Administrator

# Install Node.js LTS
choco install nodejs-lts

# Install MySQL (if not already installed)
choco install mysql

# Verify installations
node --version
mysql --version
```

**Step 2: Setup Database**
```bash
# Connect to MySQL
mysql -u root -p

# Create database
CREATE DATABASE hotel_management_db;
EXIT;

# Import schema
mysql -u root -p hotel_management_db < schema.sql
```

**Step 3: Configure as Windows Service**
```bash
# Install PM2 globally
npm install -g pm2

# Start application with PM2
cd backend
npm install
pm2 start server.js --name "HMS-Backend"

# Save PM2 settings
pm2 save
pm2 startup
```

**Step 4: Setup IIS for Frontend**
```
1. Open IIS Manager
2. Add New Website:
   - Site Name: HMS-Frontend
   - Physical Path: d:\ShaykhulWork\HotelManagementSystem(HMS)\frontend
   - Binding: http, port 80
3. Create Application Pool (if needed)
4. Grant permissions to IIS_IUSRS group
```

**Step 5: Firewall Rules**
```bash
# Allow ports 80 (frontend) and 3000 (backend)
netsh advfirewall firewall add rule name="HMS API" dir=in action=allow protocol=tcp localport=3000
netsh advfirewall firewall add rule name="HMS Frontend" dir=in action=allow protocol=tcp localport=80
```

---

### 3. Linux Server Deployment (Ubuntu/Debian)

#### Production Setup with Nginx and PM2

**Step 1: Install Prerequisites**
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_16.x | sudo -E bash -
sudo apt install -y nodejs

# Install MySQL
sudo apt install -y mysql-server

# Install Nginx
sudo apt install -y nginx

# Install PM2
sudo npm install -g pm2
```

**Step 2: Setup Database**
```bash
# Secure MySQL installation
sudo mysql_secure_installation

# Create database
sudo mysql -u root -p < database/schema.sql

# Create database user
sudo mysql -u root -p -e "CREATE USER 'hms_user'@'localhost' IDENTIFIED BY 'hms_password';"
sudo mysql -u root -p -e "GRANT ALL PRIVILEGES ON hotel_management_db.* TO 'hms_user'@'localhost';"
sudo mysql -u root -p -e "FLUSH PRIVILEGES;"
```

**Step 3: Setup Node.js Application**
```bash
# Deploy project
cd /var/www
sudo git clone <your-repo-url> hms

# Or copy manually
# sudo cp -r HotelManagementSystem(HMS) /var/www/hms

cd hms/backend

# Install dependencies
sudo npm install

# Configure .env
sudo nano .env

# Update with:
DB_HOST=localhost
DB_USER=hms_user
DB_PASSWORD=hms_password
DB_NAME=hotel_management_db
PORT=3000
NODE_ENV=production

# Start with PM2
sudo pm2 start server.js --name "HMS-API"
sudo pm2 save
sudo pm2 startup systemd -u www-data --hp /var/www/hms
```

**Step 4: Configure Nginx**
```bash
# Create config file
sudo nano /etc/nginx/sites-available/hms.conf

# Add configuration:
server {
    listen 80;
    server_name your-domain.com;

    # Frontend (Static files)
    location / {
        alias /var/www/hms/frontend/;
        try_files $uri $uri/ /index.html;
        index index.html;
    }

    # Backend API
    location /api/ {
        proxy_pass http://localhost:3000/api/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}

# Enable site
sudo ln -s /etc/nginx/sites-available/hms.conf /etc/nginx/sites-enabled/

# Test config
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

**Step 5: SSL with Let's Encrypt (Recommended)**
```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-nginx

# Get certificate
sudo certbot --nginx -d your-domain.com

# Auto-renewal check
sudo certbot renew --dry-run
```

---

### 4. Docker Deployment

#### Using Docker for quick deployment

**Step 1: Create Dockerfile**
```dockerfile
# backend/Dockerfile
FROM node:16-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install

COPY . .

EXPOSE 3000

CMD ["npm", "start"]
```

**Step 2: Create docker-compose.yml**
```yaml
version: '3.8'

services:
  db:
    image: mysql:5.7
    environment:
      MYSQL_ROOT_PASSWORD: root_password
      MYSQL_DATABASE: hotel_management_db
    volumes:
      - ./database/schema.sql:/docker-entrypoint-initdb.d/schema.sql
    ports:
      - "3306:3306"

  api:
    build: ./backend
    environment:
      DB_HOST: db
      DB_USER: root
      DB_PASSWORD: root_password
      DB_NAME: hotel_management_db
      PORT: 3000
    ports:
      - "3000:3000"
    depends_on:
      - db

  frontend:
    image: nginx:alpine
    volumes:
      - ./frontend:/usr/share/nginx/html
    ports:
      - "80:80"
    depends_on:
      - api
```

**Step 3: Deploy**
```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

---

## 📊 Daily Operations

### Monitoring

#### Check Service Status
```bash
# Check backend is running
curl http://localhost:3000/api/rooms

# Check database connection
mysql -u root -p hotel_management_db -e "SELECT * FROM bookings LIMIT 1;"

# Check disk space
df -h

# Check memory usage
free -h
```

#### Database Backup

**Automatic Backup Script (Linux)**
```bash
#!/bin/bash
# backup_db.sh

BACKUP_DIR="/backups/hms"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

mysqldump -u root -p hotel_management_db > $BACKUP_DIR/backup_$DATE.sql

# Keep only last 30 days
find $BACKUP_DIR -name "backup_*.sql" -mtime +30 -delete

echo "Backup completed: $BACKUP_DIR/backup_$DATE.sql"
```

**Manual Backup**
```bash
# Create backup
mysqldump -u root -p hotel_management_db > backup_$(date +%Y%m%d_%H%M%S).sql

# Restore from backup
mysql -u root -p hotel_management_db < backup_20260224_100000.sql
```

### Database Maintenance

#### Weekly Tasks
```sql
-- Check for orphaned sessions (no active bookings)
SELECT * FROM guest_sessions 
WHERE is_active = 0 
AND checked_out_at < DATE_SUB(NOW(), INTERVAL 30 DAY);

-- Delete old checked-out sessions (older than 90 days)
DELETE FROM guest_sessions 
WHERE is_active = 0 
AND checked_out_at < DATE_SUB(NOW(), INTERVAL 90 DAY);

-- View active sessions
SELECT gs.*, b.booking_id, g.name, r.room_number
FROM guest_sessions gs
JOIN bookings b ON gs.booking_id = b.booking_id
JOIN guests g ON gs.guest_id = g.guest_id
JOIN rooms r ON b.room_id = r.room_id
WHERE gs.is_active = 1;
```

#### Monthly Tasks
```sql
-- Optimize tables
OPTIMIZE TABLE rooms;
OPTIMIZE TABLE guests;
OPTIMIZE TABLE bookings;
OPTIMIZE TABLE guest_sessions;
OPTIMIZE TABLE service_orders;

-- Check table sizes
SELECT 
    table_name,
    ROUND(((data_length + index_length) / 1024 / 1024), 2) AS size_mb
FROM information_schema.TABLES
WHERE table_schema = 'hotel_management_db'
ORDER BY (data_length + index_length) DESC;
```

### Log Management

#### Check Application Logs
```bash
# Node.js logs (PM2)
pm2 logs HMS-Backend

# Last 100 lines
pm2 logs HMS-Backend --lines 100

# Clear old logs
pm2 flush
```

#### Nginx Logs
```bash
# Access logs
tail -f /var/log/nginx/access.log

# Error logs
tail -f /var/log/nginx/error.log
```

---

## 🔧 Troubleshooting

### Problem: Port 3000 Already in Use

**Windows:**
```bash
# Find process using port 3000
netstat -ano | findstr :3000

# Kill process (replace PID)
taskkill /PID 1234 /F
```

**Linux:**
```bash
# Find process
lsof -i :3000

# Kill process
kill -9 1234
```

### Problem: Database Connection Failed

```bash
# Test MySQL connection
mysql -u root -p -h localhost -e "SELECT 1;"

# Check if MySQL service is running
# Windows: services.msc → MySQL80
# Linux: sudo systemctl status mysql

# Check credentials in .env file
cat backend/.env | grep DB_

# Verify database exists
mysql -u root -p -e "SHOW DATABASES;"
```

### Problem: Guest Portal Not Accessible

```bash
# Test API endpoint
curl http://localhost:3000/api/guest-sessions/

# Check CORS headers
curl -i http://localhost:3000/api/guest-sessions/

# Check browser console (F12) for errors
# Clear browser cache: Ctrl+Shift+Delete
```

### Problem: High Memory Usage

```bash
# Check Node.js memory
node --max-old-space-size=2048 backend/server.js

# Update PM2 settings
pm2 start server.js --max-memory-restart 500M

# Monitor continuously
watch -n 2 'ps aux | grep node'
```

---

## 📈 Performance Optimization

### Database Optimization

```sql
-- Add indexes for common queries
CREATE INDEX idx_booking_status ON bookings(status);
CREATE INDEX idx_booking_guest ON bookings(guest_id);
CREATE INDEX idx_session_booking ON guest_sessions(booking_id);
CREATE INDEX idx_session_token ON guest_sessions(access_token);
CREATE INDEX idx_session_active ON guest_sessions(is_active);

-- Check slow queries
SET GLOBAL slow_query_log = 'ON';
SET GLOBAL long_query_time = 2;
```

### Frontend Optimization

```javascript
// Enable compression in server.js
const compression = require('compression');
app.use(compression());

// Cache static assets (add to Nginx)
location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
}
```

---

## 🔐 Security Hardening

### Basic Security Checklist

- [ ] Change default MySQL root password
- [ ] Create separate database user with limited permissions
- [ ] Update all dependencies: `npm audit fix`
- [ ] Setup HTTPS with SSL certificate
- [ ] Configure firewall rules
- [ ] Enable CORS properly (not allow all)
- [ ] Setup regular backups
- [ ] Monitor logs for suspicious activity
- [ ] Keep servers updated
- [ ] Setup intrusion detection

### Recommended Security Headers (Nginx)
```nginx
add_header X-Frame-Options "SAMEORIGIN";
add_header X-Content-Type-Options "nosniff";
add_header X-XSS-Protection "1; mode=block";
add_header Referrer-Policy "strict-origin-when-cross-origin";
add_header Content-Security-Policy "default-src 'self'";
```

---

## 📞 Maintenance Alerts

### Recommended Monitoring

```bash
# Email alerts on service failure
# Using cron (Linux)
*/5 * * * * /path/to/check_hms_status.sh

# Using Task Scheduler (Windows)
# Advanced Properties → Run with highest privileges
```

**check_hms_status.sh:**
```bash
#!/bin/bash
if ! curl -s http://localhost:3000/api/rooms > /dev/null; then
    echo "HMS API is DOWN!" | mail -s "HMS ALERT" admin@hotel.com
fi
```

---

## 📝 Version History

| Version | Date | Changes |
|---------|------|---------|
| 2.1.0 | Feb 24, 2026 | Guest portal PIN authentication |
| 2.0.0 | Feb 23, 2026 | Room service system |
| 1.0.0 | Initial | Core HMS features |

---

## 🆘 Support & Resources

- **Documentation**: Check TOKEN_AUTH_GUIDE.md, TESTING_GUIDE.md, API_REFERENCE.md
- **Issues**: Review troubleshooting section or browser console (F12)
- **Database**: Use MySQL Workbench for visual queries
- **Logs**: Check PM2 logs or Nginx logs for error details

---

**Last Updated**: February 24, 2026  
**Version**: 2.1.0  
**Maintained by**: Algolizen
