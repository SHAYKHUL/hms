-- Booking Extension Support Schema Migration
-- Created: February 24, 2026

-- Add columns to bookings table for extension support
ALTER TABLE bookings ADD COLUMN is_extension BOOLEAN DEFAULT FALSE;
ALTER TABLE bookings ADD COLUMN parent_booking_id INT, ADD FOREIGN KEY (parent_booking_id) REFERENCES bookings(booking_id) ON DELETE SET NULL;

-- Create booking_extension_history table for tracking
CREATE TABLE IF NOT EXISTS booking_extension_history (
    extension_id INT AUTO_INCREMENT PRIMARY KEY,
    original_booking_id INT NOT NULL,
    new_booking_id INT,
    requested_check_out DATE NOT NULL,
    approved_check_out DATE NOT NULL,
    resolution_type ENUM('same_room', 'alternative_room', 'alternative_dates') NOT NULL,
    additional_cost DECIMAL(10, 2) NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected', 'Completed') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (original_booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
    FOREIGN KEY (new_booking_id) REFERENCES bookings(booking_id) ON DELETE SET NULL,
    INDEX idx_original_booking (original_booking_id),
    INDEX idx_status (status)
);

-- Add index for faster conflict checking
CREATE INDEX IF NOT EXISTS idx_room_dates ON bookings(room_id, check_in, check_out);
