-- Room Cleaning Status Table Migration
-- Created: February 24, 2026
-- Description: Tracks room cleaning status, history, and scheduling

-- Create room_cleaning_status table if it doesn't exist
CREATE TABLE IF NOT EXISTS room_cleaning_status (
    status_id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL UNIQUE,
    cleaning_status ENUM('Dirty', 'Cleaning in Progress', 'Cleaned', 'Ready for Guest', 'Pending', 'Inspecting') DEFAULT 'Pending',
    last_cleaned_by INT,
    last_cleaned_date DATETIME,
    next_cleaning_scheduled DATE,
    cleaning_notes TEXT,
    status_updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON DELETE CASCADE,
    FOREIGN KEY (last_cleaned_by) REFERENCES housekeeping_staff(staff_id) ON DELETE SET NULL,
    INDEX idx_cleaning_status (cleaning_status),
    INDEX idx_next_scheduled (next_cleaning_scheduled),
    INDEX idx_last_cleaned_date (last_cleaned_date)
);

-- Create room_cleaning_history table for audit trail
CREATE TABLE IF NOT EXISTS room_cleaning_history (
    history_id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    task_id INT,
    cleaning_status_before ENUM('Dirty', 'Cleaning in Progress', 'Cleaned', 'Ready for Guest', 'Pending', 'Inspecting'),
    cleaning_status_after ENUM('Dirty', 'Cleaning in Progress', 'Cleaned', 'Ready for Guest', 'Pending', 'Inspecting'),
    cleaned_by INT,
    time_taken_minutes INT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON DELETE CASCADE,
    FOREIGN KEY (task_id) REFERENCES cleaning_tasks(task_id) ON DELETE SET NULL,
    FOREIGN KEY (cleaned_by) REFERENCES housekeeping_staff(staff_id) ON DELETE SET NULL,
    INDEX idx_room (room_id),
    INDEX idx_created (created_at),
    INDEX idx_cleaned_by (cleaned_by)
);

-- Initialize cleaning status for all existing rooms that don't have it
INSERT INTO room_cleaning_status (room_id, cleaning_status)
SELECT r.room_id, 'Pending'
FROM rooms r
WHERE NOT EXISTS (
    SELECT 1 FROM room_cleaning_status rc WHERE rc.room_id = r.room_id
);

-- Create view for room dashboard data
CREATE OR REPLACE VIEW room_status_overview AS
SELECT 
    r.room_id,
    r.room_number,
    r.room_type,
    r.status as room_availability_status,
    r.price,
    COALESCE(rc.cleaning_status, 'Pending') as cleaning_status,
    rc.last_cleaned_date,
    s.staff_name as last_cleaned_by_name,
    rc.next_cleaning_scheduled,
    (SELECT COUNT(*) FROM cleaning_tasks 
     WHERE room_id = r.room_id AND status IN ('Not Started', 'In Progress', 'Pending Approval') AND scheduled_date <= CURDATE()) as pending_tasks,
    (SELECT COUNT(*) FROM maintenance_logs 
     WHERE room_id = r.room_id AND status IN ('Reported', 'Assigned', 'In Progress')) as pending_maintenance,
    CASE 
        WHEN r.status = 'Booked' THEN 'Occupied'
        WHEN r.status = 'Maintenance' THEN 'Maintenance'
        WHEN rc.cleaning_status IN ('Dirty', 'Pending') THEN 'Needs Cleaning'
        WHEN rc.cleaning_status = 'Cleaned' THEN 'Cleaned'
        WHEN rc.cleaning_status = 'Ready for Guest' THEN 'Ready'
        ELSE 'Available'
    END as overall_status
FROM rooms r
LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id
LEFT JOIN housekeeping_staff s ON rc.last_cleaned_by = s.staff_id
ORDER BY r.room_number;

-- Create view for housekeeping dashboard
CREATE OR REPLACE VIEW housekeeping_dashboard AS
SELECT 
    'Rooms Overview' as metric,
    'Total Rooms' as category,
    COUNT(DISTINCT r.room_id) as value
FROM rooms r
UNION ALL
SELECT 'Rooms Overview', 'Available', COUNT(*)
FROM rooms WHERE status = 'Available'
UNION ALL
SELECT 'Rooms Overview', 'Booked', COUNT(*)
FROM rooms WHERE status = 'Booked'
UNION ALL
SELECT 'Rooms Overview', 'Maintenance', COUNT(*)
FROM rooms WHERE status = 'Maintenance'
UNION ALL
SELECT 'Cleaning Status', 'Cleaned', COUNT(*)
FROM room_cleaning_status WHERE cleaning_status = 'Cleaned'
UNION ALL
SELECT 'Cleaning Status', 'Dirty', COUNT(*)
FROM room_cleaning_status WHERE cleaning_status = 'Dirty'
UNION ALL
SELECT 'Cleaning Status', 'In Progress', COUNT(*)
FROM room_cleaning_status WHERE cleaning_status = 'Cleaning in Progress'
UNION ALL
SELECT 'Tasks Today', 'Completed', COUNT(*)
FROM cleaning_tasks WHERE scheduled_date = CURDATE() AND status = 'Completed'
UNION ALL
SELECT 'Tasks Today', 'In Progress', COUNT(*)
FROM cleaning_tasks WHERE scheduled_date = CURDATE() AND status = 'In Progress'
UNION ALL
SELECT 'Tasks Today', 'Pending', COUNT(*)
FROM cleaning_tasks WHERE scheduled_date = CURDATE() AND status IN ('Not Started', 'Pending Approval')
UNION ALL
SELECT 'Maintenance', 'Critical', COUNT(*)
FROM maintenance_logs WHERE severity = 'Critical' AND status IN ('Reported', 'Assigned', 'In Progress')
UNION ALL
SELECT 'Maintenance', 'High', COUNT(*)
FROM maintenance_logs WHERE severity = 'High' AND status IN ('Reported', 'Assigned', 'In Progress')
UNION ALL
SELECT 'Staff', 'Active', COUNT(*)
FROM housekeeping_staff WHERE status = 'Active';
