-- Add AC/Non-AC room type column to rooms table
ALTER TABLE rooms 
ADD COLUMN ac_type ENUM('AC', 'Non-AC') DEFAULT 'AC' AFTER room_type;

-- Update existing rooms - set AC for Suite/Deluxe, Non-AC for others
UPDATE rooms 
SET ac_type = 'AC' 
WHERE room_type IN ('Suite', 'Deluxe');

UPDATE rooms 
SET ac_type = 'Non-AC' 
WHERE room_type IN ('Single', 'Double');

-- Add index for faster filtering
ALTER TABLE rooms 
ADD INDEX idx_ac_type (ac_type);
