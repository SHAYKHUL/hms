-- Migration to fix booking_details view to include created_at column
-- Run this script if you already have an existing database

-- Drop the existing view
DROP VIEW IF EXISTS booking_details;

-- Recreate the view with created_at column
CREATE VIEW booking_details AS
SELECT 
    b.booking_id,
    b.check_in,
    b.check_out,
    b.total_amount,
    b.payment_status,
    b.booking_status,
    b.created_at,
    g.name AS guest_name,
    g.phone AS guest_phone,
    g.email AS guest_email,
    r.room_number,
    r.room_type,
    r.price AS room_price
FROM bookings b
JOIN guests g ON b.guest_id = g.guest_id
JOIN rooms r ON b.room_id = r.room_id;
