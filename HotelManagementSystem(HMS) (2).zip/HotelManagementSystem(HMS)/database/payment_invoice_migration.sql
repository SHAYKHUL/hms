-- Payment and Invoice Management Tables
-- Created: February 26, 2026
-- Purpose: Implement final billing, invoicing, and payment tracking

-- Invoices Table
CREATE TABLE IF NOT EXISTS invoices (
    invoice_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL UNIQUE,
    guest_id INT NOT NULL,
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    invoice_date DATE NOT NULL,
    due_date DATE,
    check_in_date DATE NOT NULL,
    check_out_date DATE NOT NULL,
    room_number VARCHAR(10),
    room_price DECIMAL(10, 2) NOT NULL,
    number_of_nights INT NOT NULL,
    subtotal DECIMAL(12, 2) NOT NULL,
    services_total DECIMAL(12, 2) DEFAULT 0,
    discount_amount DECIMAL(10, 2) DEFAULT 0,
    discount_type ENUM('None', 'Percentage', 'Fixed') DEFAULT 'None',
    discount_reason VARCHAR(100),
    tax_rate DECIMAL(5, 2) DEFAULT 0,
    tax_amount DECIMAL(10, 2) DEFAULT 0,
    grand_total DECIMAL(12, 2) NOT NULL,
    amount_paid DECIMAL(12, 2) DEFAULT 0,
    amount_due DECIMAL(12, 2) NOT NULL,
    notes TEXT,
    status ENUM('Draft', 'Generated', 'Sent', 'Partially_Paid', 'Paid', 'Cancelled') DEFAULT 'Generated',
    created_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
    FOREIGN KEY (guest_id) REFERENCES guests(guest_id) ON DELETE CASCADE,
    INDEX idx_booking (booking_id),
    INDEX idx_guest (guest_id),
    INDEX idx_invoice_number (invoice_number),
    INDEX idx_status (status),
    INDEX idx_date (invoice_date)
);

-- Invoice Items Table (breakdown of charges)
CREATE TABLE IF NOT EXISTS invoice_items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    description VARCHAR(255) NOT NULL,
    item_type ENUM('Room', 'Service', 'Addon', 'Discount', 'Tax', 'Other') NOT NULL,
    quantity DECIMAL(10, 2) DEFAULT 1,
    unit_price DECIMAL(10, 2) NOT NULL,
    total_price DECIMAL(12, 2) NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id) ON DELETE CASCADE,
    INDEX idx_invoice (invoice_id),
    INDEX idx_type (item_type)
);

-- Payments Table
CREATE TABLE IF NOT EXISTS payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    booking_id INT NOT NULL,
    guest_id INT NOT NULL,
    payment_number VARCHAR(50) UNIQUE NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    payment_method ENUM('Cash', 'Credit Card', 'Debit Card', 'UPI', 'Net Banking', 'Cheque', 'Other') NOT NULL,
    reference_number VARCHAR(100),
    transaction_id VARCHAR(100),
    payment_date DATETIME NOT NULL,
    received_by VARCHAR(100),
    payment_status ENUM('Pending', 'Authorized', 'Processed', 'Failed', 'Refunded') DEFAULT 'Processed',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id) ON DELETE CASCADE,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
    FOREIGN KEY (guest_id) REFERENCES guests(guest_id) ON DELETE CASCADE,
    INDEX idx_invoice (invoice_id),
    INDEX idx_booking (booking_id),
    INDEX idx_guest (guest_id),
    INDEX idx_payment_number (payment_number),
    INDEX idx_date (payment_date),
    INDEX idx_status (payment_status)
);

-- Payment Methods Table (configuration)
CREATE TABLE IF NOT EXISTS payment_methods (
    method_id INT AUTO_INCREMENT PRIMARY KEY,
    method_name VARCHAR(50) UNIQUE NOT NULL,
    display_name VARCHAR(100) NOT NULL,
    description TEXT,
    is_active TINYINT DEFAULT 1,
    is_default TINYINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default payment methods
INSERT INTO payment_methods (method_name, display_name, description, is_active, is_default) VALUES
('cash', 'Cash', 'Direct cash payment', 1, 1),
('credit_card', 'Credit Card', 'Credit card payment', 1, 0),
('debit_card', 'Debit Card', 'Debit card payment', 1, 0),
('upi', 'UPI', 'Unified Payments Interface', 1, 0),
('net_banking', 'Net Banking', 'Online banking transfer', 1, 0),
('cheque', 'Cheque', 'Cheque payment', 1, 0)
ON DUPLICATE KEY UPDATE display_name = VALUES(display_name);

-- Billing Settings Table (configuration)
CREATE TABLE IF NOT EXISTS billing_settings (
    setting_id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(50) UNIQUE NOT NULL,
    setting_value VARCHAR(255) NOT NULL,
    setting_type ENUM('text', 'number', 'boolean', 'percentage') DEFAULT 'text',
    description VARCHAR(255),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default billing settings
INSERT INTO billing_settings (setting_key, setting_value, setting_type, description) VALUES
('tax_rate', '0', 'percentage', 'Default tax rate percentage for invoices'),
('invoice_prefix', 'INV-', 'text', 'Invoice number prefix'),
('payment_prefix', 'PAY-', 'text', 'Payment reference prefix'),
('currency', 'INR', 'text', 'Default currency for billing'),
('due_days', '7', 'number', 'Days before payment is due'),
('company_name', 'Hotel Management System', 'text', 'Company name for invoice header'),
('company_address', '', 'text', 'Company address for invoice'),
('company_phone', '', 'text', 'Company phone number'),
('company_email', '', 'text', 'Company email address'),
('company_gst', '', 'text', 'GST/Tax ID number'),
('payment_terms', '', 'text', 'Payment terms and conditions'),
('invoice_footer', 'Thank you for your stay!', 'text', 'Footer text on invoices'),
('enable_partial_refunds', '1', 'boolean', 'Allow partial refunds'),
('round_amounts', '1', 'boolean', 'Round amounts to nearest unit')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- Refunds Table
CREATE TABLE IF NOT EXISTS refunds (
    refund_id INT AUTO_INCREMENT PRIMARY KEY,
    payment_id INT,
    invoice_id INT NOT NULL,
    booking_id INT NOT NULL,
    guest_id INT NOT NULL,
    refund_number VARCHAR(50) UNIQUE NOT NULL,
    refund_amount DECIMAL(12, 2) NOT NULL,
    refund_reason VARCHAR(255) NOT NULL,
    refund_date DATETIME NOT NULL,
    refund_method ENUM('Cash', 'Credit Card', 'Bank Transfer', 'UPI', 'Other') NOT NULL,
    reference_number VARCHAR(100),
    status ENUM('Pending', 'Processed', 'Failed', 'Completed') DEFAULT 'Pending',
    approved_by VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (payment_id) REFERENCES payments(payment_id) ON DELETE SET NULL,
    FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id) ON DELETE CASCADE,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
    FOREIGN KEY (guest_id) REFERENCES guests(guest_id) ON DELETE CASCADE,
    INDEX idx_invoice (invoice_id),
    INDEX idx_booking (booking_id),
    INDEX idx_guest (guest_id),
    INDEX idx_date (refund_date),
    INDEX idx_status (status)
);

-- Create view for invoice summary
DROP VIEW IF EXISTS invoice_summary;
CREATE VIEW invoice_summary AS
SELECT 
    i.invoice_id,
    i.invoice_number,
    i.booking_id,
    i.guest_id,
    g.name as guest_name,
    g.phone as guest_phone,
    b.room_id,
    r.room_number,
    i.invoice_date,
    i.due_date,
    i.grand_total,
    i.amount_paid,
    i.amount_due,
    i.status,
    COALESCE(SUM(p.amount), 0) as total_payments,
    COUNT(DISTINCT p.payment_id) as payment_count
FROM invoices i
LEFT JOIN bookings b ON i.booking_id = b.booking_id
LEFT JOIN guests g ON i.guest_id = g.guest_id
LEFT JOIN rooms r ON b.room_id = r.room_id
LEFT JOIN payments p ON i.invoice_id = p.invoice_id
GROUP BY i.invoice_id;

-- Create view for payment summary
DROP VIEW IF EXISTS payment_summary;
CREATE VIEW payment_summary AS
SELECT 
    p.payment_id,
    p.payment_number,
    p.invoice_id,
    p.booking_id,
    p.guest_id,
    g.name as guest_name,
    i.invoice_number,
    b.room_id,
    r.room_number,
    p.amount,
    p.payment_method,
    p.payment_date,
    p.payment_status,
    p.received_by,
    i.grand_total as invoice_total
FROM payments p
LEFT JOIN invoices i ON p.invoice_id = i.invoice_id
LEFT JOIN bookings b ON p.booking_id = b.booking_id
LEFT JOIN guests g ON p.guest_id = g.guest_id
LEFT JOIN rooms r ON b.room_id = r.room_id;
