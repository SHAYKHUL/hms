-- Enhanced Room Status and Early Checkout Migration
-- Created: March 1, 2026
-- Purpose: Add enhanced room statuses, early checkout functionality, and improved conflict resolution

-- 1. Update room status enum to include more granular statuses
ALTER TABLE rooms 
MODIFY COLUMN status ENUM('Available', 'Reserved', 'Occupied', 'Booked', 'Maintenance', 'Under_Maintenance', 'Out_Of_Service') DEFAULT 'Available';

-- 2. Add actual checkout time and early checkout fields to bookings table
ALTER TABLE bookings 
ADD COLUMN actual_checkout_time DATETIME NULL AFTER check_out,
ADD COLUMN is_early_checkout BOOLEAN DEFAULT FALSE,
ADD COLUMN early_checkout_reason VARCHAR(255) NULL,
ADD COLUMN checkout_time TIMESTAMP NULL,
ADD INDEX idx_actual_checkout (actual_checkout_time),
ADD INDEX idx_early_checkout (is_early_checkout);

-- 3. Update room_cleaning_status enum with more precise statuses
ALTER TABLE room_cleaning_status 
MODIFY COLUMN cleaning_status ENUM('Dirty', 'Cleaning in Progress', 'Cleaned', 'Ready for Guest', 'Pending', 'Inspecting', 'Ready', 'Maintenance Required') DEFAULT 'Pending';

-- 4. Create a new table for room availability history to track real-time changes
CREATE TABLE room_availability_history (
    history_id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    booking_id INT NULL,
    previous_status ENUM('Available', 'Reserved', 'Occupied', 'Booked', 'Maintenance', 'Under_Maintenance', 'Out_Of_Service'),
    new_status ENUM('Available', 'Reserved', 'Occupied', 'Booked', 'Maintenance', 'Under_Maintenance', 'Out_Of_Service') NOT NULL,
    change_reason ENUM('Booking_Created', 'Check_In', 'Check_Out', 'Early_Check_Out', 'Cancelled', 'Maintenance', 'Manual') NOT NULL,
    changed_by VARCHAR(100),
    change_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON DELETE CASCADE,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE SET NULL,
    INDEX idx_room_id (room_id),
    INDEX idx_change_time (change_time),
    INDEX idx_status (new_status)
);

-- 5. Create function to handle early checkout and room availability
DELIMITER //
CREATE OR REPLACE FUNCTION handle_early_checkout(
    p_booking_id INT,
    p_checkout_reason VARCHAR(255)
)
RETURNS JSON
READS SQL DATA
MODIFIES SQL DATA
BEGIN
    DECLARE v_room_id INT;
    DECLARE v_guest_id INT;
    DECLARE v_current_status VARCHAR(20);
    DECLARE v_check_out_date DATE;
    DECLARE v_result JSON;
    
    -- Get booking details
    SELECT room_id, guest_id, booking_status, check_out 
    INTO v_room_id, v_guest_id, v_current_status, v_check_out_date
    FROM bookings 
    WHERE booking_id = p_booking_id;
    
    -- Check if booking exists and is eligible for early checkout
    IF v_room_id IS NULL THEN
        SET v_result = JSON_OBJECT('success', FALSE, 'message', 'Booking not found');
    ELSEIF v_current_status != 'CheckedIn' THEN
        SET v_result = JSON_OBJECT('success', FALSE, 'message', 'Guest is not currently checked in');
    ELSE
        -- Update booking with early checkout
        UPDATE bookings 
        SET booking_status = 'CheckedOut',
            actual_checkout_time = NOW(),
            is_early_checkout = TRUE,
            early_checkout_reason = p_checkout_reason,
            checkout_time = NOW()
        WHERE booking_id = p_booking_id;
        
        -- Update room status to Available
        UPDATE rooms 
        SET status = 'Available' 
        WHERE room_id = v_room_id;
        
        -- Log the change in room availability history
        INSERT INTO room_availability_history 
        (room_id, booking_id, previous_status, new_status, change_reason, notes)
        VALUES 
        (v_room_id, p_booking_id, 'Occupied', 'Available', 'Early_Check_Out', 
         CONCAT('Early checkout: ', IFNULL(p_checkout_reason, 'No reason provided')));
        
        -- Remove guest session if exists
        DELETE FROM guest_sessions WHERE booking_id = p_booking_id;
        
        SET v_result = JSON_OBJECT(
            'success', TRUE, 
            'message', 'Early checkout processed successfully',
            'room_id', v_room_id,
            'checkout_time', NOW()
        );
    END IF;
    
    RETURN v_result;
END//
DELIMITER ;

-- 6. Create function to check room availability with early checkout consideration
DELIMITER //
CREATE OR REPLACE FUNCTION check_room_availability_enhanced(
    p_room_id INT,
    p_start_date DATE,
    p_end_date DATE
)
RETURNS JSON
READS SQL DATA
BEGIN
    DECLARE v_conflict_count INT DEFAULT 0;
    DECLARE v_early_checkout_available BOOLEAN DEFAULT FALSE;
    DECLARE v_result JSON;
    
    -- Check for booking conflicts excluding early checkouts
    SELECT COUNT(*) INTO v_conflict_count
    FROM bookings 
    WHERE room_id = p_room_id 
    AND booking_status IN ('Confirmed', 'CheckedIn')
    AND (
        (check_in <= p_start_date AND check_out > p_start_date) 
        OR 
        (check_in < p_end_date AND check_out >= p_end_date)
        OR
        (check_in >= p_start_date AND check_out <= p_end_date)
    )
    -- Exclude bookings that have early checkout
    AND (actual_checkout_time IS NULL OR actual_checkout_time >= p_start_date);
    
    -- Check if there are any early checkouts that make the room available
    SELECT COUNT(*) > 0 INTO v_early_checkout_available
    FROM bookings 
    WHERE room_id = p_room_id 
    AND is_early_checkout = TRUE
    AND actual_checkout_time IS NOT NULL
    AND actual_checkout_time <= p_start_date
    AND check_out > p_start_date;
    
    SET v_result = JSON_OBJECT(
        'available', CASE 
            WHEN v_conflict_count = 0 THEN TRUE
            WHEN v_early_checkout_available THEN TRUE
            ELSE FALSE
        END,
        'conflicts', v_conflict_count,
        'early_checkout_available', v_early_checkout_available
    );
    
    RETURN v_result;
END//
DELIMITER ;

-- 7. Create trigger to automatically update room status on booking changes
DELIMITER //
CREATE OR REPLACE TRIGGER booking_status_change_trigger
    AFTER UPDATE ON bookings
    FOR EACH ROW
BEGIN
    -- Handle status changes
    IF OLD.booking_status != NEW.booking_status THEN
        CASE NEW.booking_status
            WHEN 'Confirmed' THEN
                UPDATE rooms SET status = 'Reserved' WHERE room_id = NEW.room_id;
                INSERT INTO room_availability_history 
                (room_id, booking_id, previous_status, new_status, change_reason)
                VALUES (NEW.room_id, NEW.booking_id, 'Available', 'Reserved', 'Booking_Created');
                
            WHEN 'CheckedIn' THEN
                UPDATE rooms SET status = 'Occupied' WHERE room_id = NEW.room_id;
                INSERT INTO room_availability_history 
                (room_id, booking_id, previous_status, new_status, change_reason)
                VALUES (NEW.room_id, NEW.booking_id, 'Reserved', 'Occupied', 'Check_In');
                
            WHEN 'CheckedOut' THEN
                UPDATE rooms SET status = 'Available' WHERE room_id = NEW.room_id;
                INSERT INTO room_availability_history 
                (room_id, booking_id, previous_status, new_status, change_reason)
                VALUES (NEW.room_id, NEW.booking_id, 'Occupied', 'Available', 
                    CASE WHEN NEW.is_early_checkout THEN 'Early_Check_Out' ELSE 'Check_Out' END);
                    
            WHEN 'Cancelled' THEN
                UPDATE rooms SET status = 'Available' WHERE room_id = NEW.room_id;
                INSERT INTO room_availability_history 
                (room_id, booking_id, previous_status, new_status, change_reason)
                VALUES (NEW.room_id, NEW.booking_id, 
                    CASE WHEN OLD.booking_status = 'CheckedIn' THEN 'Occupied' ELSE 'Reserved' END, 
                    'Available', 'Cancelled');
        END CASE;
    END IF;
END//
DELIMITER ;

-- 8. Update existing booking_details view to include new fields
DROP VIEW IF EXISTS booking_details;
CREATE VIEW booking_details AS
SELECT 
    b.booking_id,
    b.guest_id,
    g.name as guest_name,
    g.phone as guest_phone,
    g.email as guest_email,
    b.room_id,
    r.room_number,
    r.room_type,
    r.ac_type,
    b.check_in,
    b.check_out,
    b.actual_checkout_time,
    b.is_early_checkout,
    b.early_checkout_reason,
    b.number_of_guests,
    b.number_of_nights,
    b.room_price,
    b.total_amount,
    b.discount_type,
    b.discount_value,
    b.discount_reason,
    b.advance_payment,
    b.payment_status,
    b.payment_method,
    b.booking_status,
    b.special_requests,
    b.checkout_time,
    b.created_at,
    b.updated_at,
    -- Calculate if checkout is overdue
    CASE 
        WHEN b.booking_status = 'CheckedIn' AND CURDATE() > b.check_out THEN TRUE 
        ELSE FALSE 
    END as is_overdue,
    -- Calculate days until checkout
    CASE 
        WHEN b.booking_status = 'CheckedIn' THEN DATEDIFF(b.check_out, CURDATE())
        ELSE NULL 
    END as days_until_checkout,
    -- Room cleaning status
    COALESCE(rc.cleaning_status, 'Pending') as room_cleaning_status
FROM bookings b
LEFT JOIN guests g ON b.guest_id = g.guest_id
LEFT JOIN rooms r ON b.room_id = r.room_id
LEFT JOIN room_cleaning_status rc ON r.room_id = rc.room_id;

-- 9. Insert initial room availability history for existing rooms
INSERT INTO room_availability_history (room_id, previous_status, new_status, change_reason, notes)
SELECT 
    room_id, 
    'Available', 
    status, 
    'Manual', 
    'Initial status migration'
FROM rooms
WHERE room_id NOT IN (SELECT DISTINCT room_id FROM room_availability_history WHERE room_id IS NOT NULL);

-- 10. Create indexes for better performance
CREATE INDEX idx_booking_status_room ON bookings(room_id, booking_status);
CREATE INDEX idx_booking_dates_status ON bookings(check_in, check_out, booking_status);
CREATE INDEX idx_room_status_updated ON rooms(status, updated_at);

-- Add some sample data to validate the migration
-- This is commented out but can be used for testing
/*
INSERT INTO room_availability_history (room_id, booking_id, previous_status, new_status, change_reason, notes)
VALUES 
(1, NULL, 'Available', 'Available', 'Manual', 'System migration - room ready'),
(2, NULL, 'Available', 'Available', 'Manual', 'System migration - room ready');
*/

-- Grant necessary permissions (adjust as needed)
-- GRANT EXECUTE ON FUNCTION handle_early_checkout TO 'hotel_app_user'@'localhost';
-- GRANT EXECUTE ON FUNCTION check_room_availability_enhanced TO 'hotel_app_user'@'localhost';

-- Migration completed successfully
SELECT 'Enhanced room status and early checkout migration completed successfully' as migration_status;