-- Update script to add Room Services & Amenities to existing HMS database
-- Run this script AFTER the main schema.sql if you already have data

-- Drop views if they exist (to recreate them)
DROP VIEW IF EXISTS service_order_details;

-- Drop tables if they exist (careful - this will delete all service data!)
DROP TABLE IF EXISTS service_orders;
DROP TABLE IF EXISTS services;

-- Services Table (Room Service & Amenities Catalog)
CREATE TABLE services (
    service_id INT AUTO_INCREMENT PRIMARY KEY,
    service_name VARCHAR(100) NOT NULL,
    category ENUM('Food', 'Beverage', 'Laundry', 'Spa', 'Transport', 'Housekeeping', 'Other') NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    availability ENUM('Available', 'Unavailable') DEFAULT 'Available',
    image_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Service Orders Table (Track guest orders)
CREATE TABLE service_orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    service_id INT NOT NULL,
    quantity INT DEFAULT 1,
    unit_price DECIMAL(10, 2) NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    order_status ENUM('Pending', 'InProgress', 'Completed', 'Cancelled') DEFAULT 'Pending',
    special_instructions TEXT,
    ordered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(service_id) ON DELETE CASCADE
);

-- Insert sample services
INSERT INTO services (service_name, category, description, price, availability) VALUES
-- Food items
('Breakfast Buffet', 'Food', 'Continental breakfast with variety of options', 500.00, 'Available'),
('Chicken Curry with Rice', 'Food', 'Traditional chicken curry served with basmati rice', 350.00, 'Available'),
('Vegetable Biryani', 'Food', 'Aromatic vegetable biryani with raita', 300.00, 'Available'),
('Club Sandwich', 'Food', 'Classic club sandwich with fries', 250.00, 'Available'),
('Margherita Pizza', 'Food', 'Fresh mozzarella and basil pizza', 400.00, 'Available'),
('Caesar Salad', 'Food', 'Crispy romaine lettuce with Caesar dressing', 200.00, 'Available'),
-- Beverages
('Fresh Juice', 'Beverage', 'Freshly squeezed orange or apple juice', 120.00, 'Available'),
('Coffee', 'Beverage', 'Hot coffee (espresso, cappuccino, latte)', 100.00, 'Available'),
('Tea', 'Beverage', 'Selection of premium teas', 80.00, 'Available'),
('Soft Drinks', 'Beverage', 'Assorted soft drinks', 60.00, 'Available'),
('Mineral Water', 'Beverage', 'Premium mineral water', 40.00, 'Available'),
-- Laundry
('Laundry Service', 'Laundry', 'Wash and iron per kg', 150.00, 'Available'),
('Express Laundry', 'Laundry', 'Same day laundry service per kg', 250.00, 'Available'),
('Dry Cleaning', 'Laundry', 'Professional dry cleaning per item', 200.00, 'Available'),
-- Spa & Wellness
('Full Body Massage', 'Spa', '60-minute relaxing full body massage', 2000.00, 'Available'),
('Facial Treatment', 'Spa', 'Rejuvenating facial treatment', 1500.00, 'Available'),
('Aromatherapy', 'Spa', '45-minute aromatherapy session', 1200.00, 'Available'),
-- Transport
('Airport Pickup', 'Transport', 'One-way airport transfer', 800.00, 'Available'),
('City Tour', 'Transport', 'Half-day city sightseeing tour', 2500.00, 'Available'),
('Car Rental', 'Transport', 'Car rental per day with driver', 3000.00, 'Available'),
-- Housekeeping
('Extra Towels', 'Housekeeping', 'Additional towel set', 100.00, 'Available'),
('Extra Bedding', 'Housekeeping', 'Extra blankets and pillows', 150.00, 'Available'),
('Room Cleaning', 'Housekeeping', 'Additional room cleaning service', 200.00, 'Available'),
-- Other
('Newspaper', 'Other', 'Daily newspaper delivery', 30.00, 'Available'),
('Iron & Board', 'Other', 'Iron and ironing board rental', 50.00, 'Available'),
('Baby Cot', 'Other', 'Baby cot rental per day', 200.00, 'Available');

-- Create view for service order details
CREATE VIEW service_order_details AS
SELECT 
    so.order_id,
    so.quantity,
    so.unit_price,
    so.total_price,
    so.order_status,
    so.special_instructions,
    so.ordered_at,
    so.completed_at,
    s.service_name,
    s.category,
    b.booking_id,
    g.name AS guest_name,
    g.phone AS guest_phone,
    r.room_number
FROM service_orders so
JOIN services s ON so.service_id = s.service_id
JOIN bookings b ON so.booking_id = b.booking_id
JOIN guests g ON b.guest_id = g.guest_id
JOIN rooms r ON b.room_id = r.room_id;

-- Verification queries
SELECT 'Services Created:' AS Status, COUNT(*) AS Count FROM services;
SELECT 'Service Orders Table:' AS Status, 'Ready' AS Count FROM service_orders LIMIT 1;
