-- Performance Optimization: Add Missing Indexes
-- Created: March 1, 2026

-- Composite indexes for booking queries
CREATE INDEX IF NOT EXISTS idx_booking_room_status ON bookings(room_id, booking_status, check_in, check_out);
CREATE INDEX IF NOT EXISTS idx_booking_guest_status ON bookings(guest_id, booking_status);
CREATE INDEX IF NOT EXISTS idx_booking_status_dates ON bookings(booking_status, check_in, check_out);

-- Performance indexes for guest and room queries
CREATE INDEX IF NOT EXISTS idx_guest_name ON guests(name);
CREATE INDEX IF NOT EXISTS idx_guest_phone ON guests(phone);
CREATE INDEX IF NOT EXISTS idx_room_number ON rooms(room_number);

-- Index for sorting and filtering
CREATE INDEX IF NOT EXISTS idx_booking_created_at ON bookings(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_booking_payment_status ON bookings(payment_status);
CREATE INDEX IF NOT EXISTS idx_booking_checkout_type ON bookings(checkout_type);

-- Index for date range queries
CREATE INDEX IF NOT EXISTS idx_room_id_status ON rooms(room_id, status);

-- Indexes for service orders and related tables
CREATE INDEX IF NOT EXISTS idx_service_order_booking ON service_orders(booking_id);
CREATE INDEX IF NOT EXISTS idx_service_order_status ON service_orders(order_status);
