-- Checkout Time Enhancement Migration
-- Adds time tracking for check-in and check-out with automatic early checkout detection
-- Created: March 1, 2026

-- Add time-based fields to bookings table  
ALTER TABLE bookings 
ADD COLUMN actual_checkin_time DATETIME,
ADD COLUMN actual_checkout_time DATETIME,
ADD COLUMN is_early_checkout BOOLEAN DEFAULT FALSE,
ADD COLUMN checkout_type ENUM('Standard', 'Early', 'Late', 'Extended') DEFAULT 'Standard',
ADD COLUMN late_checkout_fee DECIMAL(10, 2) DEFAULT 0;

-- Add index for time-based queries
CREATE INDEX idx_actual_checkout_time ON bookings(actual_checkout_time);
CREATE INDEX idx_checkout_type ON bookings(checkout_type);

-- Update existing bookings to have standard checkout time (12:00 PM) on their checkout date  
UPDATE bookings 
SET actual_checkout_time = CASE 
    WHEN booking_status = 'CheckedOut' THEN CONCAT(check_out, ' 12:00:00')
    ELSE NULL 
END
WHERE booking_status IN ('CheckedOut');

-- Add function to automatically determine checkout type based on time
DELIMITER //
CREATE FUNCTION GetCheckoutType(checkout_date DATE, checkout_time TIME) 
RETURNS VARCHAR(20)
READS SQL DATA
DETERMINISTIC
BEGIN
    DECLARE standard_checkout_time TIME DEFAULT '12:00:00';
    DECLARE late_cutoff_time TIME DEFAULT '18:00:00';
    
    IF checkout_time < standard_checkout_time THEN
        RETURN 'Early';
    ELSEIF checkout_time > late_cutoff_time THEN  
        RETURN 'Late';
    ELSE
        RETURN 'Standard';
    END IF;
END//
DELIMITER ;

-- Add trigger to automatically set checkout type and early checkout flag
DELIMITER //
CREATE TRIGGER set_checkout_type 
BEFORE UPDATE ON bookings
FOR EACH ROW
BEGIN
    -- Only trigger when actual_checkout_time is being set and booking is being checked out
    IF NEW.actual_checkout_time IS NOT NULL AND OLD.actual_checkout_time IS NULL AND NEW.booking_status = 'CheckedOut' THEN
        -- Extract time component from actual_checkout_time  
        SET NEW.checkout_type = GetCheckoutType(DATE(NEW.actual_checkout_time), TIME(NEW.actual_checkout_time));
        
        -- Set early checkout flag
        IF NEW.checkout_type = 'Early' THEN
            SET NEW.is_early_checkout = TRUE;
        END IF;
        
        -- Calculate late checkout fee (if applicable)
        IF NEW.checkout_type = 'Late' THEN
            -- 20% of daily rate as late fee (can be customized)
            SET NEW.late_checkout_fee = NEW.room_price * 0.20;
        END IF;
    END IF;
END//
DELIMITER ;

-- Add configuration table for hotel policies
CREATE TABLE hotel_policies (
    policy_id INT AUTO_INCREMENT PRIMARY KEY,
    policy_name VARCHAR(50) UNIQUE NOT NULL,
    policy_value VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default hotel time policies
INSERT INTO hotel_policies (policy_name, policy_value, description) VALUES
('standard_checkin_time', '12:00:00', 'Standard check-in time (12:00 PM)'),
('standard_checkout_time', '12:00:00', 'Standard check-out time (12:00 PM)'),
('late_checkout_cutoff', '18:00:00', 'After this time, late checkout fees apply'),
('late_checkout_fee_percentage', '20', 'Percentage of room rate charged for late checkout'),
('early_checkout_grace_period', '2', 'Hours before standard time considered early');

-- Create view for booking details with checkout type information
CREATE OR REPLACE VIEW booking_details_enhanced AS
SELECT 
    b.*,
    g.name as guest_name,
    g.phone as guest_phone,
    g.email as guest_email,
    r.room_number,
    r.room_type,
    r.status as room_status,
    b.checkout_type,
    b.is_early_checkout,
    b.late_checkout_fee,
    CASE 
        WHEN b.actual_checkout_time IS NOT NULL THEN
            CONCAT(
                DATE_FORMAT(b.actual_checkout_time, '%Y-%m-%d %H:%i'),
                ' (', b.checkout_type, ')'
            )
        ELSE NULL
    END as checkout_details,
    -- Calculate time difference from standard checkout
    CASE 
        WHEN b.actual_checkout_time IS NOT NULL THEN
            TIMESTAMPDIFF(
                MINUTE, 
                CONCAT(DATE(b.actual_checkout_time), ' 12:00:00'),
                b.actual_checkout_time
            )
        ELSE NULL
    END as checkout_time_difference_minutes
FROM bookings b
LEFT JOIN guests g ON b.guest_id = g.guest_id  
LEFT JOIN rooms r ON b.room_id = r.room_id
ORDER BY b.booking_id DESC;

-- Add index to improve view performance
CREATE INDEX idx_bookings_enhanced ON bookings(booking_id, guest_id, room_id, booking_status);