-- Hotel Management System Database Schema
-- Created: February 24, 2026

-- Drop existing views if they exist
DROP VIEW IF EXISTS service_order_details;
DROP VIEW IF EXISTS booking_details;

-- Drop existing tables if they exist
DROP TABLE IF EXISTS maintenance_logs;
DROP TABLE IF EXISTS cleaning_tasks;
DROP TABLE IF EXISTS room_cleaning_status;
DROP TABLE IF EXISTS housekeeping_staff;
DROP TABLE IF EXISTS inventory_transactions;
DROP TABLE IF EXISTS inventory_stocks;
DROP TABLE IF EXISTS inventory_items;
DROP TABLE IF EXISTS inventory_categories;
DROP TABLE IF EXISTS guest_sessions;
DROP TABLE IF EXISTS service_orders;
DROP TABLE IF EXISTS services;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS guests;
DROP TABLE IF EXISTS rooms;

-- Rooms Table
CREATE TABLE rooms (
    room_id INT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(10) UNIQUE NOT NULL,
    room_type ENUM('Single', 'Double', 'Suite', 'Deluxe') NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    bed_count INT DEFAULT 1 NOT NULL,
    max_guests INT DEFAULT 2 NOT NULL,
    status ENUM('Available', 'Booked', 'Maintenance') DEFAULT 'Available',
    description TEXT,
    amenities VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_room_type (room_type)
);

-- Room Cleaning Status Table
CREATE TABLE room_cleaning_status (
    status_id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL UNIQUE,
    cleaning_status ENUM('Clean', 'Dirty', 'In Progress', 'Inspection', 'Out of Service') DEFAULT 'Clean',
    last_cleaned_by INT,
    last_cleaned_date DATETIME,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON DELETE CASCADE,
    INDEX idx_room (room_id),
    INDEX idx_status (cleaning_status)
);

-- Guests Table
CREATE TABLE guests (
    guest_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    email VARCHAR(100),
    id_proof VARCHAR(50) NOT NULL,
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Bookings Table
CREATE TABLE bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    guest_id INT NOT NULL,
    room_id INT NOT NULL,
    check_in DATE NOT NULL,
    check_out DATE NOT NULL,
    number_of_guests INT DEFAULT 1 NOT NULL,
    number_of_nights INT GENERATED ALWAYS AS (DATEDIFF(check_out, check_in)) STORED,
    room_price DECIMAL(10, 2) NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    discount_type ENUM('None', 'Percentage', 'Fixed') DEFAULT 'None',
    discount_value DECIMAL(10, 2) DEFAULT 0,
    discount_reason VARCHAR(100),
    advance_payment DECIMAL(10, 2) DEFAULT 0,
    payment_status ENUM('Pending', 'Partial', 'Paid') DEFAULT 'Pending',
    payment_method ENUM('Cash', 'Card', 'UPI', 'Online') DEFAULT 'Cash',
    booking_status ENUM('Confirmed', 'CheckedIn', 'CheckedOut', 'Cancelled') DEFAULT 'Confirmed',
    special_requests TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (guest_id) REFERENCES guests(guest_id) ON DELETE CASCADE,
    FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON DELETE CASCADE,
    INDEX idx_status (booking_status),
    INDEX idx_check_in (check_in),
    INDEX idx_check_out (check_out),
    INDEX idx_guest (guest_id)
);

-- Services Table (Room Service & Amenities Catalog)
CREATE TABLE services (
    service_id INT AUTO_INCREMENT PRIMARY KEY,
    service_name VARCHAR(100) NOT NULL,
    category ENUM('Food', 'Beverage', 'Laundry', 'Spa', 'Transport', 'Housekeeping', 'Other') NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    availability ENUM('Available', 'Unavailable') DEFAULT 'Available',
    image_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Service Orders Table (Track guest orders)
CREATE TABLE service_orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    service_id INT NOT NULL,
    quantity INT DEFAULT 1,
    unit_price DECIMAL(10, 2) NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    order_status ENUM('Pending', 'InProgress', 'Completed', 'Cancelled') DEFAULT 'Pending',
    special_instructions TEXT,
    ordered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(service_id) ON DELETE CASCADE
);

-- Guest Sessions Table (Guest Portal Access Tokens)
CREATE TABLE guest_sessions (
    session_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL UNIQUE,
    guest_id INT NOT NULL,
    access_token VARCHAR(256) NOT NULL UNIQUE,
    token_pin VARCHAR(6) NOT NULL,
    is_active TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NULL,
    checked_out_at TIMESTAMP NULL,
    last_accessed TIMESTAMP NULL,
    access_count INT DEFAULT 0,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
    FOREIGN KEY (guest_id) REFERENCES guests(guest_id) ON DELETE CASCADE,
    INDEX idx_token (access_token),
    INDEX idx_pin (token_pin),
    INDEX idx_booking (booking_id)
);

-- Inventory Categories Table
CREATE TABLE inventory_categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Inventory Items Table
CREATE TABLE inventory_items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    item_name VARCHAR(100) NOT NULL,
    category_id INT NOT NULL,
    unit ENUM('Pieces', 'Kg', 'Liters', 'Boxes', 'Sets', 'Rolls', 'Bottles') NOT NULL,
    unit_cost DECIMAL(10, 2) NOT NULL,
    description TEXT,
    supplier_name VARCHAR(100),
    supplier_phone VARCHAR(15),
    status ENUM('Active', 'Inactive') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES inventory_categories(category_id) ON DELETE CASCADE,
    INDEX idx_category (category_id),
    INDEX idx_status (status)
);

-- Inventory Stock Levels Table
CREATE TABLE inventory_stocks (
    stock_id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT NOT NULL UNIQUE,
    current_quantity INT DEFAULT 0,
    minimum_quantity INT DEFAULT 10,
    maximum_quantity INT DEFAULT 100,
    reorder_quantity INT DEFAULT 50,
    total_value DECIMAL(12, 2) DEFAULT 0,
    last_restocked TIMESTAMP NULL,
    last_consumed_date TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES inventory_items(item_id) ON DELETE CASCADE,
    INDEX idx_low_stock (current_quantity),
    INDEX idx_last_restocked (last_restocked)
);

-- Inventory Transactions Table (Audit Trail)
CREATE TABLE inventory_transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT NOT NULL,
    transaction_type ENUM('Restock', 'Consume', 'Adjustment', 'Damage', 'Expiry') NOT NULL,
    quantity_change INT NOT NULL,
    previous_quantity INT NOT NULL,
    new_quantity INT NOT NULL,
    notes TEXT,
    created_by VARCHAR(100),
    booked_against INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES inventory_items(item_id) ON DELETE CASCADE,
    FOREIGN KEY (booked_against) REFERENCES bookings(booking_id) ON DELETE SET NULL,
    INDEX idx_item (item_id),
    INDEX idx_type (transaction_type),
    INDEX idx_date (created_at)
);

-- Insert sample inventory categories
INSERT INTO inventory_categories (category_name, description) VALUES
('Linens & Bedding', 'Towels, bed sheets, pillow covers, blankets'),
('Toiletries', 'Soaps, shampoos, conditioners, toothbrushes'),
('Cleaning Supplies', 'Detergents, disinfectants, brooms, mops'),
('Kitchen Supplies', 'Utensils, plates, glasses, cutlery'),
('Laundry Supplies', 'Detergent, fabric softeners, stain removers'),
('Stationery', 'Notepads, pens, folders, envelopes'),
('Maintenance & Tools', 'Tools, spare parts, bulbs, batteries'),
('Beverages & Snacks', 'Coffee, tea, sugar, biscuits, chocolates');

-- Insert sample inventory items
INSERT INTO inventory_items (item_name, category_id, unit, unit_cost, description, supplier_name, supplier_phone) VALUES
('Bath Towel', 1, 'Pieces', 150.00, 'Premium cotton bath towel (white)', 'Linen World', '9876543210'),
('Bed Sheet', 1, 'Pieces', 250.00, 'Cotton bed sheet set (queen size)', 'Linen World', '9876543210'),
('Pillow Cover', 1, 'Pieces', 80.00, 'Cotton pillow cover', 'Linen World', '9876543210'),
('Blanket', 1, 'Pieces', 300.00, 'Warm blanket (double size)', 'Linen World', '9876543210'),
('Soap Bar', 2, 'Pieces', 20.00, 'Guest soap bar', 'Hygiene Plus', '9876543211'),
('Shampoo Bottle', 2, 'Bottles', 150.00, 'Premium shampoo (250ml)', 'Hygiene Plus', '9876543211'),
('Conditioner Bottle', 2, 'Bottles', 150.00, 'Conditioner (250ml)', 'Hygiene Plus', '9876543211'),
('Toothbrush', 2, 'Pieces', 15.00, 'Disposable toothbrush', 'Hygiene Plus', '9876543211'),
('Floor Cleaner', 3, 'Liters', 200.00, 'Multi-purpose floor cleaner (5L)', 'Clean Care', '9876543212'),
('Disinfectant Spray', 3, 'Bottles', 180.00, 'Room disinfectant spray (500ml)', 'Clean Care', '9876543212'),
('Dish Soap', 3, 'Liters', 100.00, 'Liquid dish soap (1L)', 'Clean Care', '9876543212'),
('Paper Plates', 4, 'Sets', 50.00, 'Disposable paper plates (50pcs)', 'Kitchen Plus', '9876543213'),
('Glass Cups', 4, 'Sets', 300.00, 'Glass cups set (6pcs)', 'Kitchen Plus', '9876543213'),
('Stainless Steel Cutlery', 4, 'Sets', 400.00, 'Cutlery set (6 place)', 'Kitchen Plus', '9876543213'),
('Laundry Detergent', 5, 'Kg', 250.00, 'Laundry detergent powder (1kg)', 'Wash World', '9876543214'),
('Fabric Softener', 5, 'Liters', 200.00, 'Fabric softener (1L)', 'Wash World', '9876543214'),
('Stain Remover', 5, 'Bottles', 180.00, 'Stain remover spray (500ml)', 'Wash World', '9876543214'),
('Office Notepad', 6, 'Pieces', 30.00, 'Spiral notepads', 'Paper Co', '9876543215'),
('Ballpoint Pen', 6, 'Boxes', 150.00, 'Ballpoint pens box (50pcs)', 'Paper Co', '9876543215'),
('Folder', 6, 'Pieces', 20.00, 'Plastic folder', 'Paper Co', '9876543215'),
('Light Bulb', 7, 'Pieces', 80.00, 'LED bulb 10W', 'Electricals', '9876543216'),
('Battery', 7, 'Boxes', 400.00, 'AA batteries (12 pack)', 'Electricals', '9876543216'),
('Coffee Powder', 8, 'Kg', 500.00, 'Premium instant coffee (250g)', 'Beverages Co', '9876543217'),
('Tea Bags', 8, 'Boxes', 300.00, 'Tea bags box (100pcs)', 'Beverages Co', '9876543217'),
('Sugar', 8, 'Kg', 60.00, 'White sugar (1kg)', 'Beverages Co', '9876543217'),
('Biscuits', 8, 'Boxes', 200.00, 'Assorted biscuits box', 'Beverages Co', '9876543217');

-- Initialize stock levels for inventory items with total_value calculation
INSERT INTO inventory_stocks (item_id, current_quantity, minimum_quantity, maximum_quantity, reorder_quantity, total_value) 
SELECT i.item_id, 50, 10, 100, 50, (50 * i.unit_cost) 
FROM inventory_items i;

-- Insert sample rooms
INSERT INTO rooms (room_number, room_type, price, status, description, amenities) VALUES
('101', 'Single', 1500.00, 'Available', 'Cozy single room with garden view', 'WiFi, TV, AC'),
('102', 'Single', 1500.00, 'Available', 'Single room with city view', 'WiFi, TV, AC'),
('201', 'Double', 2500.00, 'Available', 'Spacious double room', 'WiFi, TV, AC, Mini-bar'),
('202', 'Double', 2500.00, 'Available', 'Double room with balcony', 'WiFi, TV, AC, Mini-bar'),
('301', 'Suite', 5000.00, 'Available', 'Luxury suite with separate living area', 'WiFi, TV, AC, Mini-bar, Jacuzzi'),
('302', 'Suite', 5000.00, 'Maintenance', 'Premium suite under renovation', 'WiFi, TV, AC, Mini-bar, Jacuzzi'),
('401', 'Deluxe', 7500.00, 'Available', 'Deluxe room with premium amenities', 'WiFi, TV, AC, Mini-bar, Jacuzzi, Kitchen');

-- Initialize room cleaning status for all rooms
INSERT INTO room_cleaning_status (room_id, cleaning_status, last_cleaned_date, notes) 
SELECT room_id, 'Clean', NOW(), 'Initial setup' 
FROM rooms;

-- Insert sample services
INSERT INTO services (service_name, category, description, price, availability) VALUES
-- Food items
('Breakfast Buffet', 'Food', 'Continental breakfast with variety of options', 500.00, 'Available'),
('Chicken Curry with Rice', 'Food', 'Traditional chicken curry served with basmati rice', 350.00, 'Available'),
('Vegetable Biryani', 'Food', 'Aromatic vegetable biryani with raita', 300.00, 'Available'),
('Club Sandwich', 'Food', 'Classic club sandwich with fries', 250.00, 'Available'),
('Margherita Pizza', 'Food', 'Fresh mozzarella and basil pizza', 400.00, 'Available'),
('Caesar Salad', 'Food', 'Crispy romaine lettuce with Caesar dressing', 200.00, 'Available'),
-- Beverages
('Fresh Juice', 'Beverage', 'Freshly squeezed orange or apple juice', 120.00, 'Available'),
('Coffee', 'Beverage', 'Hot coffee (espresso, cappuccino, latte)', 100.00, 'Available'),
('Tea', 'Beverage', 'Selection of premium teas', 80.00, 'Available'),
('Soft Drinks', 'Beverage', 'Assorted soft drinks', 60.00, 'Available'),
('Mineral Water', 'Beverage', 'Premium mineral water', 40.00, 'Available'),
-- Laundry
('Laundry Service', 'Laundry', 'Wash and iron per kg', 150.00, 'Available'),
('Express Laundry', 'Laundry', 'Same day laundry service per kg', 250.00, 'Available'),
('Dry Cleaning', 'Laundry', 'Professional dry cleaning per item', 200.00, 'Available'),
-- Spa & Wellness
('Full Body Massage', 'Spa', '60-minute relaxing full body massage', 2000.00, 'Available'),
('Facial Treatment', 'Spa', 'Rejuvenating facial treatment', 1500.00, 'Available'),
('Aromatherapy', 'Spa', '45-minute aromatherapy session', 1200.00, 'Available'),
-- Transport
('Airport Pickup', 'Transport', 'One-way airport transfer', 800.00, 'Available'),
('City Tour', 'Transport', 'Half-day city sightseeing tour', 2500.00, 'Available'),
('Car Rental', 'Transport', 'Car rental per day with driver', 3000.00, 'Available'),
-- Housekeeping
('Extra Towels', 'Housekeeping', 'Additional towel set', 100.00, 'Available'),
('Extra Bedding', 'Housekeeping', 'Extra blankets and pillows', 150.00, 'Available'),
('Room Cleaning', 'Housekeeping', 'Additional room cleaning service', 200.00, 'Available'),
-- Other
('Newspaper', 'Other', 'Daily newspaper delivery', 30.00, 'Available'),
('Iron & Board', 'Other', 'Iron and ironing board rental', 50.00, 'Available'),
('Baby Cot', 'Other', 'Baby cot rental per day', 200.00, 'Available');

-- Housekeeping Staff Table
CREATE TABLE housekeeping_staff (
    staff_id INT AUTO_INCREMENT PRIMARY KEY,
    staff_name VARCHAR(100) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    email VARCHAR(100),
    role ENUM('Housekeeper', 'Supervisor', 'Manager') DEFAULT 'Housekeeper',
    shift ENUM('Morning', 'Afternoon', 'Night') DEFAULT 'Morning',
    status ENUM('Active', 'Inactive', 'On Leave') DEFAULT 'Active',
    assigned_floors VARCHAR(50),
    hire_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_role (role)
);

-- Cleaning Tasks Table
CREATE TABLE cleaning_tasks (
    task_id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    staff_id INT,
    task_type ENUM('Deep Clean', 'Regular Clean', 'Quick Clean', 'Turnover', 'Spot Clean') DEFAULT 'Regular Clean',
    status ENUM('Not Started', 'In Progress', 'Completed', 'Cancelled', 'Pending Approval') DEFAULT 'Not Started',
    priority ENUM('Low', 'Medium', 'High', 'Urgent') DEFAULT 'Medium',
    scheduled_date DATE NOT NULL,
    scheduled_time TIME,
    start_time DATETIME,
    completion_time DATETIME,
    notes TEXT,
    checklist_items VARCHAR(500),
    assigned_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON DELETE CASCADE,
    FOREIGN KEY (staff_id) REFERENCES housekeeping_staff(staff_id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_by) REFERENCES housekeeping_staff(staff_id) ON DELETE SET NULL,
    INDEX idx_room (room_id),
    INDEX idx_status (status),
    INDEX idx_date (scheduled_date),
    INDEX idx_staff (staff_id)
);

-- Maintenance Logs Table
CREATE TABLE maintenance_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    maintenance_type ENUM('Plumbing', 'Electrical', 'HVAC', 'Furniture', 'Appliance', 'Paint', 'Flooring', 'Other') NOT NULL,
    issue_description TEXT NOT NULL,
    severity ENUM('Low', 'Medium', 'High', 'Critical') DEFAULT 'Medium',
    status ENUM('Reported', 'Assigned', 'In Progress', 'Completed', 'On Hold') DEFAULT 'Reported',
    assigned_to VARCHAR(100),
    reported_by VARCHAR(100),
    reported_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_date DATETIME,
    cost_estimate DECIMAL(10, 2),
    actual_cost DECIMAL(10, 2),
    parts_required TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON DELETE CASCADE,
    INDEX idx_room (room_id),
    INDEX idx_status (status),
    INDEX idx_type (maintenance_type),
    INDEX idx_severity (severity)
);

-- Insert sample housekeeping staff
INSERT INTO housekeeping_staff (staff_name, phone, email, role, shift, status, assigned_floors) VALUES
('Priya Sharma', '9876543220', 'priya@hotel.com', 'Supervisor', 'Morning', 'Active', '1,2,3'),
('Rajesh Kumar', '9876543221', 'rajesh@hotel.com', 'Housekeeper', 'Morning', 'Active', '1,2'),
('Anita Singh', '9876543222', 'anita@hotel.com', 'Housekeeper', 'Morning', 'Active', '2,3'),
('Vikram Patel', '9876543223', 'vikram@hotel.com', 'Housekeeper', 'Afternoon', 'Active', '3,4'),
('Neha Gupta', '9876543224', 'neha@hotel.com', 'Housekeeper', 'Afternoon', 'Active', '1,4'),
('Suresh Verma', '9876543225', 'suresh@hotel.com', 'Manager', 'Morning', 'Active', '1,2,3,4'),
('Deepa Nair', '9876543226', 'deepa@hotel.com', 'Housekeeper', 'Night', 'On Leave', '2,3'),
('Arjun Singh', '9876543227', 'arjun@hotel.com', 'Housekeeper', 'Night', 'Active', '1,3,4');

-- Insert sample cleaning tasks
INSERT INTO cleaning_tasks (room_id, staff_id, task_type, status, priority, scheduled_date, scheduled_time, notes, assigned_by) VALUES
(1, 2, 'Turnover', 'Completed', 'High', CURDATE(), '09:00:00', 'Guest checkout - full deep clean', 1),
(2, 3, 'Regular Clean', 'In Progress', 'Medium', CURDATE(), '10:00:00', 'Standard daily cleaning', 1),
(3, 4, 'Quick Clean', 'Not Started', 'Low', CURDATE(), '11:00:00', 'Tidy up and restock amenities', 1),
(4, 5, 'Spot Clean', 'Pending Approval', 'High', CURDATE(), '14:00:00', 'Carpet stain removal in corridor', 1),
(5, 2, 'Regular Clean', 'Not Started', 'Medium', DATE_ADD(CURDATE(), INTERVAL 1 DAY), '09:00:00', 'Standard cleaning', 1),
(6, 3, 'Deep Clean', 'Not Started', 'High', DATE_ADD(CURDATE(), INTERVAL 1 DAY), '10:00:00', 'Full deep clean - maintenance done', 1),
(7, 4, 'Regular Clean', 'Cancelled', 'Low', CURDATE(), '15:00:00', 'Room not available', 1);

-- Insert sample maintenance logs
INSERT INTO maintenance_logs (room_id, maintenance_type, issue_description, severity, status, assigned_to, reported_by, cost_estimate, notes) VALUES
(2, 'Plumbing', 'Bathroom sink drains slowly', 'Medium', 'Assigned', 'Ali Hassan', 'Housekeeping Staff', 800.00, 'Needs pipe cleaning'),
(4, 'Electrical', 'Bedside lamp flickering', 'High', 'In Progress', 'Imran Khan', 'Guest Complaint', 500.00, 'Likely loose connection'),
(3, 'HVAC', 'AC not cooling properly', 'Critical', 'Reported', 'Arun', 'Housekeeping Staff', 3500.00, 'Compressor may need repair'),
(5, 'Furniture', 'Chair has broken leg', 'Low', 'Completed', 'Lokesh', 'Inspection', 400.00, 'Repaired successfully'),
(6, 'Appliance', 'Microwave not heating', 'Medium', 'In Progress', 'Pravesh', 'Guest Request', 1200.00, 'Needs service check'),
(7, 'Paint', 'Wall has water stain marks', 'Low', 'On Hold', 'Suresh', 'Inspection', 600.00, 'Waiting for rainy season to end'),
(1, 'Flooring', 'Carpet has burn mark', 'Medium', 'Assigned', 'Mohan', 'Housekeeping Staff', 2500.00, 'Spot replacement needed');

-- Create view for booking details
CREATE VIEW booking_details AS
SELECT 
    b.booking_id,
    b.check_in,
    b.check_out,
    b.total_amount,
    b.payment_status,
    b.booking_status,
    b.created_at,
    g.name AS guest_name,
    g.phone AS guest_phone,
    g.email AS guest_email,
    r.room_number,
    r.room_type,
    r.price AS room_price
FROM bookings b
JOIN guests g ON b.guest_id = g.guest_id
JOIN rooms r ON b.room_id = r.room_id;

-- Create view for service order details
CREATE VIEW service_order_details AS
SELECT 
    so.order_id,
    so.quantity,
    so.unit_price,
    so.total_price,
    so.order_status,
    so.special_instructions,
    so.ordered_at,
    so.completed_at,
    s.service_name,
    s.category,
    b.booking_id,
    g.name AS guest_name,
    g.phone AS guest_phone,
    r.room_number
FROM service_orders so
JOIN services s ON so.service_id = s.service_id
JOIN bookings b ON so.booking_id = b.booking_id
JOIN guests g ON b.guest_id = g.guest_id
JOIN rooms r ON b.room_id = r.room_id;
